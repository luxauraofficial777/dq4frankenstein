#!/usr/bin/env python3
"""Spot-check EDC/ECC on multiple sectors in the fixed range."""

import struct

ECC_F_LUT = [0] * 256
ECC_B_LUT = [0] * 256
EDC_LUT = [0] * 256

for _i in range(256):
    _j = (_i << 1) ^ (0x11D if (_i & 0x80) else 0)
    _j &= 0xFF
    ECC_F_LUT[_i] = _j
    ECC_B_LUT[_i ^ _j] = _i
    _edc = _i
    for _ in range(8):
        _edc = (_edc >> 1) ^ (0xD8018001 if (_edc & 1) else 0)
    EDC_LUT[_i] = _edc & 0xFFFFFFFF

def compute_edc(data, offset, length):
    edc = 0
    for i in range(length):
        edc = ((edc >> 8) ^ EDC_LUT[(edc ^ data[offset + i]) & 0xFF]) & 0xFFFFFFFF
    return edc

def compute_ecc_block(address, src, major_count, minor_count, major_mult, minor_inc):
    total_len = major_count * minor_count
    dest = bytearray(major_count * 2)
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        ecc_a = 0
        ecc_b = 0
        for minor in range(minor_count):
            if index < 4:
                temp = address[index]
            else:
                temp = src[index - 4]
            index += minor_inc
            if index >= total_len:
                index -= total_len
            ecc_a ^= temp
            ecc_b ^= temp
            ecc_a = ECC_F_LUT[ecc_a]
        ecc_a = ECC_B_LUT[ECC_F_LUT[ecc_a] ^ ecc_b]
        dest[major] = ecc_a
        dest[major + major_count] = ecc_a ^ ecc_b
    return dest

bin_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\output\dq4_frankenstein_fmv.bin"

check_lbas = [146621, 146700, 147000, 147500, 148000, 148620]

with open(bin_path, 'rb') as f:
    all_ok = True
    for lba in check_lbas:
        f.seek(lba * 2352)
        sector = bytearray(f.read(2352))

        edc_c = compute_edc(sector, 16, 2056)
        edc_s = struct.unpack_from('<I', sector, 2072)[0]

        address = bytes([0, 0, 0, 0])
        src = bytes(sector[16:])

        p_c = compute_ecc_block(address, src, 86, 24, 2, 86)
        p_s = bytes(sector[2076:2248])

        q_c = compute_ecc_block(address, src, 52, 43, 86, 88)
        q_s = bytes(sector[2248:2352])

        ok = edc_c == edc_s and bytes(p_c) == p_s and bytes(q_c) == q_s
        if not ok:
            all_ok = False
        print(f"LBA {lba}: {'OK' if ok else 'FAIL'} "
              f"EDC={'OK' if edc_c==edc_s else 'X'} "
              f"P={'OK' if bytes(p_c)==p_s else 'X'} "
              f"Q={'OK' if bytes(q_c)==q_s else 'X'}")

    print(f"\nAll OK: {all_ok}")
