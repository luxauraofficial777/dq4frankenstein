@echo off
call "C:\Program Files (x86)\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cd /d "c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline"
cl /std:c++17 /EHsc /nologo orphan_builder.cpp orphan_build_main.cpp /Fe:build_orphan.exe
