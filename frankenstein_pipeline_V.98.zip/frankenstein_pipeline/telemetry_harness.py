#!/usr/bin/env python3
"""
telemetry_harness.py — Multi-Target Dual-BIOS Telemetry Harness
================================================================

3 emulator targets × 2 BIOS regimes = full test matrix.

Targets:
  1. DuckStation (headless CLI, console log capture)
  2. PCSX-E      (study/psxe/bin/psxe.exe, -b BIOS, -L loglevel)
  3. CyberGrime  (cybergrime/psx_agent_runner.exe, telemetry JSON)

BIOS Regimes:
  A. SCPH-1001 (US stock — validates standard Sony kernel behavior)
  B. VHB Super BIOS (validates custom parent environment)

Telemetry Streams:
  1. CD-ROM IRQ & Status Tracing (parsed from logs)
  2. Exception & Panic Handlers (PC at crash/hang, register dump)
  3. Asset Stream Verification (LBA read sequence, block types)
  4. Automated Headless Run Logs (stdout/stderr capture)

Usage:
  python telemetry_harness.py --cue disc.cue --timeout 30
  python telemetry_harness.py --cue disc.cue --bios both --target all --timeout 60
  python telemetry_harness.py --cue disc.cue --bios scph --target duckstation --timeout 15
"""

import argparse
import hashlib
import json
import os
import re
import shutil
import subprocess
import sys
import time
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Tuple

# ── Paths ─────────────────────────────────────────────────────────────────────

PROJECT_ROOT = Path(r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION")

DUCKSTATION_EXE = PROJECT_ROOT / "duckstation" / "duckstation-qt-x64-ReleaseLTCG.exe"
DUCKSTATION_INI = PROJECT_ROOT / "duckstation" / "settings" / "duckstation-qt.ini"
DUCKSTATION_ROOT_INI = PROJECT_ROOT / "duckstation" / "duckstation-qt.ini"

PSXE_EXE = PROJECT_ROOT / "study" / "psxe" / "bin" / "psxe.exe"

CYBERGRIME_RUNNER = PROJECT_ROOT / "cybergrime" / "psx_agent_runner.exe"

BIOS_SCPH = PROJECT_ROOT / "bios" / "US" / "SCPH1001.BIN"
BIOS_VHB = PROJECT_ROOT / "bios" / "VHB" / "FRANKENSTEIN.BIOS"

OUTPUT_BASE = PROJECT_ROOT / "frankenstein_pipeline" / "telemetry_results"

# ── DuckStation INI templates ────────────────────────────────────────────────

DS_INI_TEMPLATE = """[Directories]
BIOSDirectory={bios_dir}

[Console]
Region=NTSC_U
Enable8MBRAM=false

[Logging]
LogLevel=Dev
LogToConsole=true
LogToFile=true
LogFileDir={log_dir}
LogFileName={log_name}

[Emulator]
FastBoot=false
SpeedLimiterEnabled=false
"""


# ── Telemetry Parsers ────────────────────────────────────────────────────────

class TelemetryParser:
    """Parses raw emulator logs into structured telemetry streams."""

    # CD-ROM patterns
    RE_CDROM_GETSTAT = re.compile(r'Getstat\s+Stat=(0x[0-9A-Fa-f]+)')
    RE_CDROM_SETLOC = re.compile(r'Setloc\s+([\d:]+)')
    RE_CDROM_READN = re.compile(r'ReadN\s+([\d:]+)')
    RE_CDROM_DATASECTOR = re.compile(r'DataSector\s+([\d:]+)\s+LBA=(\d+)\s+Mode=(\d)\s+Submode=(0x[0-9A-Fa-f]+)')
    RE_CDROM_INIT = re.compile(r'CDROM.*Init')
    RE_CDROM_PAUSE = re.compile(r'Pause')
    RE_CDROM_SEEK = re.compile(r'SeekL\s+([\d:]+)')

    # BIOS POST patterns
    RE_BIOS_POST = re.compile(r'BIOS POST status:\s+(\d+)')

    # Performance patterns
    RE_PERFMON = re.compile(r'FPS:\s+([\d.]+)\s+VPS:\s+([\d.]+)\s+CPU:\s+([\d.]+)')

    # Exception / crash patterns
    RE_EXCEPTION = re.compile(r'(?:exception|crash|illegal|fault|panic|abort)', re.IGNORECASE)
    RE_PC_HANG = re.compile(r'PC[:=]\s*(0x[0-9A-Fa-f]+)', re.IGNORECASE)

    @staticmethod
    def parse_duckstation(log_text: str) -> dict:
        """Parse DuckStation console output into structured telemetry."""
        lines = log_text.split('\n')

        cdrom_events = []
        bios_post_sequence = []
        perf_samples = []
        exceptions = []
        lba_read_sequence = []
        cdrom_commands = []

        for line in lines:
            # CD-ROM IRQ tracing
            m = TelemetryParser.RE_CDROM_DATASECTOR.search(line)
            if m:
                msf, lba, mode, submode = m.groups()
                cdrom_events.append({
                    'type': 'data_sector',
                    'msf': msf,
                    'lba': int(lba),
                    'mode': int(mode),
                    'submode': submode,
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                lba_read_sequence.append(int(lba))
                continue

            m = TelemetryParser.RE_CDROM_GETSTAT.search(line)
            if m:
                cdrom_commands.append({
                    'type': 'getstat',
                    'stat': m.group(1),
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            m = TelemetryParser.RE_CDROM_SETLOC.search(line)
            if m:
                cdrom_commands.append({
                    'type': 'setloc',
                    'msf': m.group(1),
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            m = TelemetryParser.RE_CDROM_READN.search(line)
            if m:
                cdrom_commands.append({
                    'type': 'readn',
                    'msf': m.group(1),
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            m = TelemetryParser.RE_CDROM_INIT.search(line)
            if m:
                cdrom_commands.append({
                    'type': 'init',
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            m = TelemetryParser.RE_CDROM_PAUSE.search(line)
            if m:
                cdrom_commands.append({
                    'type': 'pause',
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            # BIOS POST
            m = TelemetryParser.RE_BIOS_POST.search(line)
            if m:
                bios_post_sequence.append({
                    'status': int(m.group(1)),
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            # Performance
            m = TelemetryParser.RE_PERFMON.search(line)
            if m:
                fps, vps, cpu = m.groups()
                perf_samples.append({
                    'fps': float(fps),
                    'vps': float(vps),
                    'cpu': float(cpu),
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })
                continue

            # Exceptions
            if TelemetryParser.RE_EXCEPTION.search(line):
                exceptions.append({
                    'line': line.strip(),
                    'timestamp': TelemetryParser._extract_timestamp(line),
                })

        # Analyze LBA read sequence for stalls
        lba_ranges = []
        if lba_read_sequence:
            start = lba_read_sequence[0]
            prev = start
            for lba in lba_read_sequence[1:]:
                if lba != prev + 1:
                    lba_ranges.append({'start': start, 'end': prev, 'count': prev - start + 1})
                    start = lba
                prev = lba
            lba_ranges.append({'start': start, 'end': prev, 'count': prev - start + 1})

        # Detect stall: last 20 LBA reads all the same or no reads in final 30% of log
        stall_detected = False
        stall_pc = None
        if perf_samples:
            last_quarter = perf_samples[len(perf_samples)//4:]
            avg_fps = sum(s['fps'] for s in last_quarter) / max(len(last_quarter), 1)
            if avg_fps < 1.0:
                stall_detected = True

        # Max FPS reached
        max_fps = max((s['fps'] for s in perf_samples), default=0.0)
        max_cpu = max((s['cpu'] for s in perf_samples), default=0.0)

        # Total sectors read
        total_sectors = len(lba_read_sequence)

        # CD-ROM command summary
        cmd_counts = {}
        for cmd in cdrom_commands:
            cmd_counts[cmd['type']] = cmd_counts.get(cmd['type'], 0) + 1

        return {
            'stream_1_cdrom_irq': {
                'total_data_sectors': total_sectors,
                'lba_ranges': lba_ranges,
                'first_lba': lba_read_sequence[0] if lba_read_sequence else None,
                'last_lba': lba_read_sequence[-1] if lba_read_sequence else None,
                'command_counts': cmd_counts,
                'commands': cdrom_commands[:200],
            },
            'stream_2_exceptions': {
                'exceptions': exceptions,
                'stall_detected': stall_detected,
                'stall_pc': stall_pc,
            },
            'stream_3_asset_stream': {
                'lba_sequence': lba_read_sequence[:500],
                'lba_ranges': lba_ranges,
                'sectors_read': total_sectors,
            },
            'stream_4_perfmon': {
                'max_fps': max_fps,
                'max_cpu': max_cpu,
                'samples': perf_samples[:100],
                'sample_count': len(perf_samples),
            },
            'bios_post_sequence': [p['status'] for p in bios_post_sequence],
            'bios_post_events': bios_post_sequence,
        }

    @staticmethod
    def parse_cybergrime(telemetry_json: dict) -> dict:
        """Parse CyberGrime telemetry JSON into structured telemetry."""
        assertions = telemetry_json.get('Assertions', [])
        bios_calls = telemetry_json.get('BiosCalls', [])

        # Extract PC values
        pc_values = []
        for a in assertions:
            pc = a.get('PC', a.get('pc', None))
            if pc:
                pc_values.append(pc)

        # Extract BIOS call function numbers
        fn_counts = {}
        for call in bios_calls:
            fn = call.get('fn', call.get('function', '?'))
            fn_counts[fn] = fn_counts.get(fn, 0) + 1

        # Detect stall: PC stays in same range
        stall_detected = False
        stall_pc = None
        if len(pc_values) > 64:
            last_64 = pc_values[-64:]
            unique_pcs = set(last_64)
            if len(unique_pcs) <= 4:
                stall_detected = True
                stall_pc = list(unique_pcs)[0]

        return {
            'stream_1_cdrom_irq': {
                'bios_call_counts': fn_counts,
                'total_bios_calls': len(bios_calls),
            },
            'stream_2_exceptions': {
                'stall_detected': stall_detected,
                'stall_pc': stall_pc,
                'total_assertions': len(assertions),
            },
            'stream_3_asset_stream': {
                'pc_trace': pc_values[:500],
                'unique_pcs': len(set(pc_values)),
            },
            'stream_4_perfmon': {
                'total_instructions': telemetry_json.get('InstructionCount',
                                        telemetry_json.get('instructions', 0)),
            },
            'bios_post_sequence': [],
            'bios_post_events': [],
        }

    @staticmethod
    def _extract_timestamp(line: str) -> Optional[float]:
        """Extract [NN.NNNN] timestamp from log line."""
        m = re.match(r'\[\s*([\d.]+)\]', line)
        if m:
            return float(m.group(1))
        return None


# ── Verdict Engine ───────────────────────────────────────────────────────────

class VerdictEngine:
    """Determines pass/fail for each test run."""

    @staticmethod
    def evaluate(target: str, bios: str, telemetry: dict, run_duration: float) -> dict:
        verdict = {
            'target': target,
            'bios': bios,
            'duration_seconds': run_duration,
            'pass': False,
            'progress_level': 'none',
            'findings': [],
            'blockers': [],
        }

        perf = telemetry.get('stream_4_perfmon', {})
        cdrom = telemetry.get('stream_1_cdrom_irq', {})
        exceptions = telemetry.get('stream_2_exceptions', {})
        post_seq = telemetry.get('bios_post_sequence', [])

        max_fps = perf.get('max_fps', 0.0)
        total_sectors = cdrom.get('total_data_sectors', cdrom.get('total_bios_calls', 0))
        stall = exceptions.get('stall_detected', False)

        # Progress levels (cumulative)
        if post_seq:
            verdict['findings'].append(f"BIOS POST sequence: {post_seq}")
            verdict['progress_level'] = 'bios_post'

        if total_sectors > 0 or cdrom.get('total_bios_calls', 0) > 0:
            verdict['findings'].append(f"CD-ROM activity: {total_sectors} sectors/calls")
            verdict['progress_level'] = 'cdrom_active'

        if max_fps > 1.0:
            verdict['findings'].append(f"GPU active: max FPS={max_fps:.2f}")
            verdict['progress_level'] = 'gpu_active'

        if max_fps > 30.0:
            verdict['findings'].append(f"Full-speed rendering: max FPS={max_fps:.2f}")
            verdict['progress_level'] = 'rendering'

        # Stall detection
        if stall:
            verdict['blockers'].append(f"Stall detected at PC={exceptions.get('stall_pc', 'unknown')}")

        # Pass conditions
        if max_fps > 10.0 and not stall and total_sectors > 10:
            verdict['pass'] = True
            verdict['progress_level'] = ' gameplay'
        elif max_fps > 1.0 and not stall:
            verdict['pass'] = True
            verdict['progress_level'] = 'boot_progress'
        elif total_sectors > 5 and not stall:
            verdict['pass'] = True
            verdict['progress_level'] = 'cdrom_progress'
        elif post_seq and not stall:
            verdict['pass'] = True
            verdict['progress_level'] = 'bios_post'
        else:
            verdict['blockers'].append("No progress indicators detected")

        return verdict


# ── Test Runners ─────────────────────────────────────────────────────────────

class DuckStationRunner:
    """Runs DuckStation in headless batch mode with console capture."""

    def __init__(self, bios_path: Path, cue_path: Path, output_dir: Path, timeout: int):
        self.bios_path = bios_path
        self.cue_path = cue_path
        self.output_dir = output_dir
        self.timeout = timeout
        self.console_log = output_dir / "console.log"
        self.parsed_json = output_dir / "parsed_telemetry.json"
        self.verdict_json = output_dir / "verdict.json"

    def _write_ini(self):
        """Write DuckStation INI pointing to the correct BIOS."""
        bios_dir = str(self.bios_path.parent).replace('\\', '/')
        log_dir = str(self.output_dir).replace('\\', '/')

        ini_content = DS_INI_TEMPLATE.format(
            bios_dir=bios_dir,
            log_dir=log_dir,
            log_name="ds_file.log",
        )

        # Write to settings ini (takes priority)
        DUCKSTATION_INI.parent.mkdir(parents=True, exist_ok=True)
        DUCKSTATION_INI.write_text(ini_content, encoding='utf-8')

        # Also write root ini as backup
        DUCKSTATION_ROOT_INI.write_text(ini_content, encoding='utf-8')

    def run(self) -> dict:
        """Execute DuckStation and capture telemetry."""
        self.output_dir.mkdir(parents=True, exist_ok=True)
        self._write_ini()

        cmd = [
            str(DUCKSTATION_EXE),
            '-batch',
            '-earlyconsole',
            str(self.cue_path),
        ]

        print(f"  [DuckStation] Launching: BIOS={self.bios_path.name}, Disc={self.cue_path.name}")

        start_time = time.time()
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=str(DUCKSTATION_EXE.parent),
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            try:
                proc.wait(timeout=self.timeout)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()

            elapsed = time.time() - start_time
            console_output = proc.stdout.read().decode('utf-8', errors='replace') if proc.stdout else ""

        except Exception as e:
            console_output = f"RUNNER ERROR: {e}"
            elapsed = 0.0

        # Save raw console log
        self.console_log.write_text(console_output, encoding='utf-8')

        # Parse telemetry
        telemetry = TelemetryParser.parse_duckstation(console_output)
        self.parsed_json.write_text(json.dumps(telemetry, indent=2), encoding='utf-8')

        # Evaluate verdict
        verdict = VerdictEngine.evaluate('duckstation', self.bios_path.stem, telemetry, elapsed)
        self.verdict_json.write_text(json.dumps(verdict, indent=2), encoding='utf-8')

        print(f"  [DuckStation] Verdict: {verdict['progress_level']} (FPS={telemetry['stream_4_perfmon']['max_fps']:.1f}, sectors={telemetry['stream_1_cdrom_irq']['total_data_sectors']})")

        return verdict


class PCSXERunner:
    """Runs PCSX-E with BIOS and disc, capturing output."""

    def __init__(self, bios_path: Path, cue_path: Path, output_dir: Path, timeout: int):
        self.bios_path = bios_path
        self.cue_path = cue_path
        self.output_dir = output_dir
        self.timeout = timeout
        self.console_log = output_dir / "console.log"
        self.parsed_json = output_dir / "parsed_telemetry.json"
        self.verdict_json = output_dir / "verdict.json"

    def run(self) -> dict:
        """Execute PCSX-E and capture telemetry."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        cmd = [
            str(PSXE_EXE),
            '-b', str(self.bios_path),
            '-L', '3',  # High log level
            '-r', 'ntsc-u',
            '-a',  # Use CLI args, ignore settings
            str(self.cue_path),
        ]

        print(f"  [PCSX-E] Launching: BIOS={self.bios_path.name}, Disc={self.cue_path.name}")

        start_time = time.time()
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=str(PSXE_EXE.parent),
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            try:
                proc.wait(timeout=self.timeout)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()

            elapsed = time.time() - start_time
            console_output = proc.stdout.read().decode('utf-8', errors='replace') if proc.stdout else ""

        except Exception as e:
            console_output = f"RUNNER ERROR: {e}"
            elapsed = 0.0

        self.console_log.write_text(console_output, encoding='utf-8')

        # Parse (reuse DuckStation parser — PCSX-E log format is similar)
        telemetry = TelemetryParser.parse_duckstation(console_output)
        self.parsed_json.write_text(json.dumps(telemetry, indent=2), encoding='utf-8')

        verdict = VerdictEngine.evaluate('pcsxe', self.bios_path.stem, telemetry, elapsed)
        self.verdict_json.write_text(json.dumps(verdict, indent=2), encoding='utf-8')

        print(f"  [PCSX-E] Verdict: {verdict['progress_level']}")

        return verdict


class CyberGrimeRunner:
    """Runs CyberGrime psx_agent_runner with telemetry output."""

    def __init__(self, bios_path: Path, cue_path: Path, output_dir: Path, timeout: int):
        self.bios_path = bios_path
        self.cue_path = cue_path
        self.output_dir = output_dir
        self.timeout = timeout
        self.telemetry_log = output_dir / "telemetry.json"
        self.parsed_json = output_dir / "parsed_telemetry.json"
        self.verdict_json = output_dir / "verdict.json"

    def run(self) -> dict:
        """Execute CyberGrime runner and capture telemetry."""
        self.output_dir.mkdir(parents=True, exist_ok=True)

        # CyberGrime uses --bios and --disc flags
        # Instruction count based on timeout (rough: ~2M instr/sec)
        max_instr = str(self.timeout * 2_000_000)

        cmd = [
            str(CYBERGRIME_RUNNER),
            '--bios', str(self.bios_path),
            '--disc', str(self.cue_path),
            '--max-instr', max_instr,
            '--telemetry', str(self.telemetry_log),
        ]

        print(f"  [CyberGrime] Launching: BIOS={self.bios_path.name}, Disc={self.cue_path.name}")

        start_time = time.time()
        try:
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                cwd=str(CYBERGRIME_RUNNER.parent),
                creationflags=subprocess.CREATE_NO_WINDOW,
            )
            try:
                proc.wait(timeout=self.timeout)
            except subprocess.TimeoutExpired:
                proc.terminate()
                try:
                    proc.wait(timeout=5)
                except subprocess.TimeoutExpired:
                    proc.kill()
                    proc.wait()

            elapsed = time.time() - start_time
            console_output = proc.stdout.read().decode('utf-8', errors='replace') if proc.stdout else ""

        except Exception as e:
            console_output = f"RUNNER ERROR: {e}"
            elapsed = 0.0

        # Save console output
        (self.output_dir / "console.log").write_text(console_output, encoding='utf-8')

        # Parse telemetry JSON if it exists
        telemetry = {}
        if self.telemetry_log.exists():
            try:
                raw = json.loads(self.telemetry_log.read_text(encoding='utf-8'))
                telemetry = TelemetryParser.parse_cybergrime(raw)
            except (json.JSONDecodeError, KeyError) as e:
                telemetry = {'error': f'Failed to parse telemetry: {e}'}
        else:
            telemetry = {'error': 'No telemetry file produced'}

        self.parsed_json.write_text(json.dumps(telemetry, indent=2), encoding='utf-8')

        verdict = VerdictEngine.evaluate('cybergrime', self.bios_path.stem, telemetry, elapsed)
        self.verdict_json.write_text(json.dumps(verdict, indent=2), encoding='utf-8')

        print(f"  [CyberGrime] Verdict: {verdict['progress_level']}")

        return verdict


# ── Harness Orchestrator ─────────────────────────────────────────────────────

class TelemetryHarness:
    """Orchestrates multi-target dual-BIOS test matrix."""

    TARGETS = {
        'duckstation': DuckStationRunner,
        'pcsxe': PCSXERunner,
        'cybergrime': CyberGrimeRunner,
    }

    BIOS_REGIMES = {
        'scph': BIOS_SCPH,
        'vhb': BIOS_VHB,
    }

    def __init__(self, cue_path: Path, targets: List[str], bios_regimes: List[str],
                 timeout: int, output_base: Path = None):
        self.cue_path = cue_path
        self.targets = targets
        self.bios_regimes = bios_regimes
        self.timeout = timeout
        self.output_base = output_base or OUTPUT_BASE

    def run_matrix(self) -> dict:
        """Run full test matrix and return summary."""
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        run_dir = self.output_base / timestamp
        run_dir.mkdir(parents=True, exist_ok=True)

        print(f"\n{'='*70}")
        print(f"  TELEMETRY HARNESS — {timestamp}")
        print(f"  Disc: {self.cue_path.name}")
        print(f"  Targets: {', '.join(self.targets)}")
        print(f"  BIOS: {', '.join(self.bios_regimes)}")
        print(f"  Timeout: {self.timeout}s per run")
        print(f"  Output: {run_dir}")
        print(f"{'='*70}\n")

        # Verify inputs
        self._verify_inputs()

        results = {}
        total_runs = len(self.targets) * len(self.bios_regimes)
        run_num = 0

        for bios_name in self.bios_regimes:
            bios_path = self.BIOS_REGIMES[bios_name]
            for target_name in self.targets:
                run_num += 1
                run_name = f"{target_name}_{bios_name}"
                run_output = run_dir / run_name

                print(f"\n[{run_num}/{total_runs}] {run_name}")

                runner_class = self.TARGETS[target_name]
                runner = runner_class(bios_path, self.cue_path, run_output, self.timeout)
                verdict = runner.run()
                results[run_name] = verdict

        # Generate summary
        summary = {
            'timestamp': timestamp,
            'disc': str(self.cue_path),
            'disc_sha256': self._hash_file(self.cue_path),
            'targets': self.targets,
            'bios_regimes': self.bios_regimes,
            'timeout_seconds': self.timeout,
            'results': results,
            'pass_count': sum(1 for v in results.values() if v['pass']),
            'fail_count': sum(1 for v in results.values() if not v['pass']),
            'best_progress': max((v['progress_level'] for v in results.values()),
                                 key=['none', 'bios_post', 'cdrom_active', 'cdrom_progress',
                                      'gpu_active', 'boot_progress', 'rendering', ' gameplay'].index),
        }

        summary_path = run_dir / "summary.json"
        summary_path.write_text(json.dumps(summary, indent=2), encoding='utf-8')

        print(f"\n{'='*70}")
        print(f"  SUMMARY")
        print(f"  Pass: {summary['pass_count']}/{total_runs}")
        print(f"  Fail: {summary['fail_count']}/{total_runs}")
        print(f"  Best progress: {summary['best_progress']}")
        print(f"  Results: {summary_path}")
        print(f"{'='*70}\n")

        return summary

    def _verify_inputs(self):
        """Verify all required files exist."""
        issues = []

        if not self.cue_path.exists():
            issues.append(f"Disc CUE not found: {self.cue_path}")

        # Check corresponding .bin
        bin_path = self.cue_path.with_suffix('.bin')
        if not bin_path.exists():
            issues.append(f"Disc BIN not found: {bin_path}")

        for bios_name in self.bios_regimes:
            bios_path = self.BIOS_REGIMES[bios_name]
            if not bios_path.exists():
                issues.append(f"BIOS not found: {bios_path}")

        for target_name in self.targets:
            if target_name == 'duckstation' and not DUCKSTATION_EXE.exists():
                issues.append(f"DuckStation not found: {DUCKSTATION_EXE}")
            elif target_name == 'pcsxe' and not PSXE_EXE.exists():
                issues.append(f"PCSX-E not found: {PSXE_EXE}")
            elif target_name == 'cybergrime' and not CYBERGRIME_RUNNER.exists():
                issues.append(f"CyberGrime runner not found: {CYBERGRIME_RUNNER}")

        if issues:
            for issue in issues:
                print(f"  [ERROR] {issue}")
            raise FileNotFoundError("Input verification failed")

        print("  Input verification: PASS")

    @staticmethod
    def _hash_file(path: Path) -> str:
        """Compute SHA-256 of a file."""
        h = hashlib.sha256()
        with open(path, 'rb') as f:
            while True:
                chunk = f.read(65536)
                if not chunk:
                    break
                h.update(chunk)
        return h.hexdigest()


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Multi-Target Dual-BIOS Telemetry Harness",
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument('--cue', required=True, help='Path to disc .cue file')
    parser.add_argument('--timeout', type=int, default=30,
                        help='Timeout per run in seconds (default: 30)')
    parser.add_argument('--target', nargs='+', default=['all'],
                        choices=['all', 'duckstation', 'pcsxe', 'cybergrime'],
                        help='Emulator targets to test')
    parser.add_argument('--bios', nargs='+', default=['both'],
                        choices=['both', 'scph', 'vhb'],
                        help='BIOS regimes to test')
    parser.add_argument('--output', default=None,
                        help='Output directory (default: frankenstein_pipeline/telemetry_results)')

    args = parser.parse_args()

    # Resolve targets
    if 'all' in args.target:
        targets = ['duckstation', 'pcsxe', 'cybergrime']
    else:
        targets = args.target

    # Resolve BIOS regimes
    if 'both' in args.bios:
        bios_regimes = ['scph', 'vhb']
    else:
        bios_regimes = args.bios

    cue_path = Path(args.cue).resolve()
    output_base = Path(args.output) if args.output else None

    harness = TelemetryHarness(
        cue_path=cue_path,
        targets=targets,
        bios_regimes=bios_regimes,
        timeout=args.timeout,
        output_base=output_base,
    )

    summary = harness.run_matrix()

    # Exit code: 0 if any pass, 1 if all fail
    sys.exit(0 if summary['pass_count'] > 0 else 1)


if __name__ == '__main__':
    main()
