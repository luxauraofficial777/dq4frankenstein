#!/usr/bin/env python3
"""Print key sections from phase0_analysis_clean.json"""
import json

d = json.load(open("frankenstein_pipeline/phase0_analysis_clean.json"))

print("=== HEADER ===")
print(json.dumps(d["header"], indent=2))

print("\n=== OLD TREE REFS ===")
print(f"Count: {d['old_tree_refs']['count']}")
for r in d["old_tree_refs"]["refs"]:
    print(f"  {r['ram_addr']}: LUI={r['lui_word']} ADDIU={r['addiu_word']} -> {r['computed_addr']}")

print("\n=== BSS RANGE REFS ===")
print(f"Count: {d['bss_range_refs']['count']}")
for r in d["bss_range_refs"]["refs"]:
    print(f"  {r['ram_addr']}: LUI={r['lui_imm']} {r['next_op']}={r['next_imm']} -> {r['computed_addr']}")

print("\n=== HBD STRING ===")
print(json.dumps(d["hbd_string_scan"], indent=2))

print("\n=== THREAD ENTRY REFS ===")
print(json.dumps(d["thread_entry_refs"], indent=2))

print("\n=== PC0 DISASM ===")
for i in d["pc0_disasm"]:
    print(f"  {i['ram']}: 0x{i['word']:>08s} op={i['opcode']}")
