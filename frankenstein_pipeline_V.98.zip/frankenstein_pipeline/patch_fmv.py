#!/usr/bin/env python3
"""Copy DQ4 intro FMV data within HBD file to LBA 146621 target.

DW7 EXE hardcodes seek to LBA 146621 (32:34:71) for intro FMV.
On Frankenstein disc, that region is zeroed (DQ4 HBD is smaller).
DQ4's intro FMV data is at HBD file sector 105328 (disc LBA 105828).
We copy 2000 sectors to HBD file sector 146121 (disc LBA 146621).
"""

import sys
import shutil

HBD_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\fk_dump\HBD1PS1D.Q41"
HBD_PATH_BAK = HBD_PATH + ".bak"

SRC_SECTOR = 105328   # disc LBA 105828 (DQ4 FMV start, adjusted for HBD at LBA 500)
TGT_SECTOR = 146121   # disc LBA 146621 (DW7 EXE seek target)
NUM_SECTORS = 2000    # covers full DQ4 intro FMV (~1747 sectors from log)
SECTOR_SIZE = 2048

def main():
    src_off = SRC_SECTOR * SECTOR_SIZE
    tgt_off = TGT_SECTOR * SECTOR_SIZE
    copy_len = NUM_SECTORS * SECTOR_SIZE

    print(f"HBD file: {HBD_PATH}")
    print(f"Source: sector {SRC_SECTOR} (disc LBA {SRC_SECTOR + 500}), byte offset {src_off}")
    print(f"Target: sector {TGT_SECTOR} (disc LBA {TGT_SECTOR + 500}), byte offset {tgt_off}")
    print(f"Copy: {NUM_SECTORS} sectors ({copy_len} bytes)")

    # Read the source data
    with open(HBD_PATH, "rb") as f:
        f.seek(src_off)
        data = f.read(copy_len)

    # Verify source is non-zero
    if all(b == 0 for b in data[:32]):
        print("ERROR: Source data is all zeros!")
        sys.exit(1)

    print(f"Source first 16 bytes: {data[:16].hex()}")
    print(f"Source last  16 bytes: {data[-16:].hex()}")

    # Backup
    shutil.copy2(HBD_PATH, HBD_PATH_BAK)
    print(f"Backup saved: {HBD_PATH_BAK}")

    # Write to target
    with open(HBD_PATH, "r+b") as f:
        f.seek(tgt_off)
        f.write(data)

    print(f"Wrote {copy_len} bytes to target offset {tgt_off}")

    # Verify
    with open(HBD_PATH, "rb") as f:
        f.seek(tgt_off)
        verify = f.read(32)
        print(f"Verify target first 16 bytes: {verify[:16].hex()}")
        if verify[:16] == data[:16]:
            print("VERIFY: OK - target matches source")
        else:
            print("VERIFY: FAILED - target does not match source!")
            sys.exit(1)

    print("\nDone. Rebuild disc with mkpsxiso, then fix EDC/ECC with CDmage.")

if __name__ == "__main__":
    main()
