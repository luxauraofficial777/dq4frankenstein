#!/usr/bin/env python3
"""Fix EDC/ECC for Mode 2 Form 1 sectors on a PSX BIN file.

Uses the ecmtools algorithm (same as mkpsxiso) for EDC and ECC.
Only fixes sectors in the specified LBA range.
"""

import struct
import sys

# --- Build lookup tables (from ecmtools by Neill Corlett) ---

ECC_F_LUT = [0] * 256
ECC_B_LUT = [0] * 256
EDC_LUT = [0] * 256

for _i in range(256):
    _j = (_i << 1) ^ (0x11D if (_i & 0x80) else 0)
    _j &= 0xFF
    ECC_F_LUT[_i] = _j
    ECC_B_LUT[_i ^ _j] = _i

    _edc = _i
    for _ in range(8):
        _edc = (_edc >> 1) ^ (0xD8018001 if (_edc & 1) else 0)
    EDC_LUT[_i] = _edc & 0xFFFFFFFF


def compute_edc(data, offset, length):
    edc = 0
    for i in range(length):
        edc = ((edc >> 8) ^ EDC_LUT[(edc ^ data[offset + i]) & 0xFF]) & 0xFFFFFFFF
    return edc


def compute_ecc_block(address, src, major_count, minor_count, major_mult, minor_inc):
    total_len = major_count * minor_count
    dest = bytearray(major_count * 2)

    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        ecc_a = 0
        ecc_b = 0

        for minor in range(minor_count):
            if index < 4:
                temp = address[index]
            else:
                temp = src[index - 4]

            index += minor_inc
            if index >= total_len:
                index -= total_len

            ecc_a ^= temp
            ecc_b ^= temp
            ecc_a = ECC_F_LUT[ecc_a]

        ecc_a = ECC_B_LUT[ECC_F_LUT[ecc_a] ^ ecc_b]
        dest[major] = ecc_a
        dest[major + major_count] = ecc_a ^ ecc_b

    return dest


def fix_sector(sector):
    submode = sector[18]
    if submode & 0x20:
        return False

    edc = compute_edc(sector, 16, 2056)
    struct.pack_into('<I', sector, 2072, edc)

    address = bytes([0, 0, 0, 0])  # mkpsxiso uses zero address for ECC
    src = bytes(sector[16:])  # from subheader to end of sector

    p_parity = compute_ecc_block(address, src, 86, 24, 2, 86)
    sector[2076:2076 + 172] = p_parity

    q_parity = compute_ecc_block(address, src, 52, 43, 86, 88)
    sector[2248:2248 + 104] = q_parity

    return True


def main():
    bin_path = sys.argv[1] if len(sys.argv) > 1 else \
        r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\output\dq4_frankenstein_fmv.bin"

    start_lba = int(sys.argv[2]) if len(sys.argv) > 2 else 146621
    end_lba = int(sys.argv[3]) if len(sys.argv) > 3 else 148620

    SECTOR_SIZE = 2352

    print(f"Fixing EDC/ECC for {bin_path}")
    print(f"LBA range: {start_lba} to {end_lba} ({end_lba - start_lba + 1} sectors)")

    with open(bin_path, 'r+b') as f:
        fixed = 0
        skipped = 0
        for lba in range(start_lba, end_lba + 1):
            offset = lba * SECTOR_SIZE
            f.seek(offset)
            sector = bytearray(f.read(SECTOR_SIZE))

            if len(sector) < SECTOR_SIZE:
                print(f"  LBA {lba}: short read, stopping")
                break

            if fix_sector(sector):
                f.seek(offset)
                f.write(sector)
                fixed += 1
            else:
                skipped += 1

            if fixed % 200 == 0 and fixed > 0:
                print(f"  Fixed {fixed} sectors...")

        print(f"\nDone: {fixed} sectors fixed, {skipped} skipped (Form 2)")


if __name__ == "__main__":
    main()
