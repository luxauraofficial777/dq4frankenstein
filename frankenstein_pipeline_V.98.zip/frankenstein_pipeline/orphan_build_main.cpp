// orphan_build_main.cpp — Entry point for C++ Frankenstein Orphan Disc Builder
//
// Replaces build_orphan.py with a native C++ implementation.
// Uses mkpsxiso for disc mastering with native EDC/ECC (no edcre.exe).
//
// Build:  cl /std:c++17 /EHsc orphan_builder.cpp orphan_build_main.cpp /Fe:build_orphan.exe
// Usage:  build_orphan.exe [--skip-hash-check] [--output-dir <path>]

#include "orphan_builder.h"
#include <cstring>

int main(int argc, char* argv[]) {
    std::string output_dir = DEFAULT_OUTPUT;
    bool skip_hash = false;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--skip-hash-check" || arg == "-s") {
            skip_hash = true;
        } else if (arg == "--output-dir" && i + 1 < argc) {
            output_dir = argv[++i];
        } else if (arg == "--help" || arg == "-h") {
            printf("Frankenstein Orphan Disc Builder (C++ / mkpsxiso)\n\n");
            printf("Usage: build_orphan.exe [options]\n\n");
            printf("Options:\n");
            printf("  --skip-hash-check    Skip SHA-256 hash verification of inputs\n");
            printf("  --output-dir <path>  Output directory for .bin/.cue\n");
            printf("  --help               Show this help message\n");
            return 0;
        } else {
            fprintf(stderr, "Unknown argument: %s\n", arg.c_str());
            return 1;
        }
    }

    OrphanBuilder builder(output_dir, skip_hash);
    bool success = builder.build();
    return success ? 0 : 1;
}
