#!/usr/bin/env python3
"""Copy DW7 FMV raw sectors to Frankenstein disc at LBA 146621.

DW7 EXE expects raw STR video data at LBA 146621, not HBD blocks.
DQ4 stores FMV as HBD blocks — incompatible with DW7's FMV player.
Solution: copy DW7's own FMV data from DW7D1.bin to Frankenstein disc.
"""

import sys

DW7_BIN = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\DW7D1\DW7D1.bin"
FK_BIN = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\output\dq4_frankenstein_fmv.bin"

START_LBA = 146621
NUM_SECTORS = 9866  # LBA 146621 to 156486 (end of Frankenstein disc)
SECTOR_SIZE = 2352

def main():
    total_bytes = NUM_SECTORS * SECTOR_SIZE
    print(f"Copying {NUM_SECTORS} sectors ({total_bytes} bytes) from DW7 to Frankenstein")
    print(f"Source: {DW7_BIN} LBA {START_LBA}")
    print(f"Target: {FK_BIN} LBA {START_LBA}")

    with open(DW7_BIN, 'rb') as src, open(FK_BIN, 'r+b') as dst:
        src.seek(START_LBA * SECTOR_SIZE)
        dst.seek(START_LBA * SECTOR_SIZE)

        copied = 0
        chunk_size = 256 * SECTOR_SIZE  # 256 sectors at a time
        remaining = total_bytes

        while remaining > 0:
            read_size = min(chunk_size, remaining)
            data = src.read(read_size)
            if len(data) == 0:
                print(f"  Source ended early at {copied} bytes")
                break
            dst.write(data)
            copied += len(data)
            remaining -= len(data)

            sectors_done = copied // SECTOR_SIZE
            if sectors_done % 1000 == 0 and sectors_done > 0:
                print(f"  Copied {sectors_done} sectors...")

        print(f"\nDone: {copied} bytes ({copied // SECTOR_SIZE} sectors)")

    # Verify first and last sector
    with open(FK_BIN, 'rb') as f:
        f.seek(START_LBA * SECTOR_SIZE + 24)
        first = f.read(16)
        print(f"Verify LBA {START_LBA} first 16 bytes: {first.hex()}")

        last_lba = START_LBA + NUM_SECTORS - 1
        f.seek(last_lba * SECTOR_SIZE + 24)
        last = f.read(16)
        print(f"Verify LBA {last_lba} first 16 bytes: {last.hex()}")

    print("\nReady to test in DuckStation.")

if __name__ == "__main__":
    main()
