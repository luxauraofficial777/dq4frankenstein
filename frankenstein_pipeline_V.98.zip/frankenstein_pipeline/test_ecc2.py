#!/usr/bin/env python3
"""Verify EDC+ECC computation against known-good sectors using ecmtools algorithm."""

import struct

ECC_F_LUT = [0] * 256
ECC_B_LUT = [0] * 256
EDC_LUT = [0] * 256

for _i in range(256):
    _j = (_i << 1) ^ (0x11D if (_i & 0x80) else 0)
    _j &= 0xFF
    ECC_F_LUT[_i] = _j
    ECC_B_LUT[_i ^ _j] = _i
    _edc = _i
    for _ in range(8):
        _edc = (_edc >> 1) ^ (0xD8018001 if (_edc & 1) else 0)
    EDC_LUT[_i] = _edc & 0xFFFFFFFF

def compute_edc(data, offset, length):
    edc = 0
    for i in range(length):
        edc = ((edc >> 8) ^ EDC_LUT[(edc ^ data[offset + i]) & 0xFF]) & 0xFFFFFFFF
    return edc

def compute_ecc_block(address, src, major_count, minor_count, major_mult, minor_inc):
    total_len = major_count * minor_count
    dest = bytearray(major_count * 2)
    for major in range(major_count):
        index = (major >> 1) * major_mult + (major & 1)
        ecc_a = 0
        ecc_b = 0
        for minor in range(minor_count):
            if index < 4:
                temp = address[index]
            else:
                temp = src[index - 4]
            index += minor_inc
            if index >= total_len:
                index -= total_len
            ecc_a ^= temp
            ecc_b ^= temp
            ecc_a = ECC_F_LUT[ecc_a]
        ecc_a = ECC_B_LUT[ECC_F_LUT[ecc_a] ^ ecc_b]
        dest[major] = ecc_a
        dest[major + major_count] = ecc_a ^ ecc_b
    return dest

bin_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\output\dq4_frankenstein_fmv.bin"

with open(bin_path, 'rb') as f:
    for lba in [354, 105828, 146621]:
        f.seek(lba * 2352)
        sector = bytearray(f.read(2352))

        edc_c = compute_edc(sector, 16, 2056)
        edc_s = struct.unpack_from('<I', sector, 2072)[0]

        address = bytes([0, 0, 0, 0])  # mkpsxiso uses zero address for ECC
        src = bytes(sector[16:])  # from subheader to end of sector

        p_c = compute_ecc_block(address, src, 86, 24, 2, 86)
        p_s = bytes(sector[2076:2248])

        q_c = compute_ecc_block(address, src, 52, 43, 86, 88)
        q_s = bytes(sector[2248:2352])

        print(f"LBA {lba}: EDC={'OK' if edc_c==edc_s else 'MISMATCH'} "
              f"P={'OK' if bytes(p_c)==p_s else 'MISMATCH'} "
              f"Q={'OK' if bytes(q_c)==q_s else 'MISMATCH'}")

        if bytes(p_c) != p_s:
            print(f"  P comp[0:8]: {bytes(p_c[:8]).hex()}")
            print(f"  P stor[0:8]: {p_s[:8].hex()}")
        if bytes(q_c) != q_s:
            print(f"  Q comp[0:8]: {bytes(q_c[:8]).hex()}")
            print(f"  Q stor[0:8]: {q_s[:8].hex()}")
