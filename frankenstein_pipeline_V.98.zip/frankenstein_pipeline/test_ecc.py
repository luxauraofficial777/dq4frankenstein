#!/usr/bin/env python3
"""Verify EDC and ECC computation against known-good sectors."""

import struct

def build_edc_table():
    table = []
    for i in range(256):
        crc = i
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xD8018001
            else:
                crc >>= 1
        table.append(crc & 0xFFFFFFFF)
    return table

EDC_TABLE = build_edc_table()

def compute_edc(data, offset, length):
    crc = 0
    for i in range(length):
        crc = EDC_TABLE[(crc ^ data[offset + i]) & 0xFF] ^ (crc >> 8)
    return crc & 0xFFFFFFFF

# GF(2^8) tables
def build_gf_tables():
    exp = [0] * 512
    log = [0] * 256
    x = 1
    for i in range(255):
        exp[i] = x
        log[x] = i
        x <<= 1
        if x & 0x100:
            x ^= 0x11D
    for i in range(255, 512):
        exp[i] = exp[i - 255]
    return exp, log

GF_EXP, GF_LOG = build_gf_tables()

def gf_mul(a, b):
    if a == 0 or b == 0:
        return 0
    return GF_EXP[GF_LOG[a] + GF_LOG[b]]

def compute_p_parity(sector):
    parity = bytearray(172)
    for j in range(86):
        p0 = 0
        p1 = 0
        for i in range(24):
            b = sector[12 + j * 24 + i]
            p0 ^= b
            p1 ^= gf_mul(b, GF_EXP[i])
        parity[j * 2] = p0
        parity[j * 2 + 1] = p1
    return parity

def compute_q_parity(sector):
    q = bytearray(104)
    for k in range(52):
        q0 = 0
        q1 = 0
        for i in range(43):
            col = (k + i) % 86
            row = i % 26
            b = sector[12 + col * 26 + row]
            q0 ^= b
            q1 ^= gf_mul(b, GF_EXP[i])
        q[k * 2] = q0
        q[k * 2 + 1] = q1
    return q

bin_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\output\dq4_frankenstein_fmv.bin"

with open(bin_path, 'rb') as f:
    for lba in [354, 105828, 146621]:
        f.seek(lba * 2352)
        sector = bytearray(f.read(2352))

        # EDC
        edc_computed = compute_edc(sector, 16, 2056)
        edc_stored = struct.unpack_from('<I', sector, 2072)[0]
        edc_match = edc_computed == edc_stored

        # P-parity
        p_computed = compute_p_parity(sector)
        p_stored = bytes(sector[2076:2248])
        p_match = bytes(p_computed) == p_stored

        # Q-parity
        q_computed = compute_q_parity(sector)
        q_stored = bytes(sector[2248:2352])
        q_match = bytes(q_computed) == q_stored

        print(f"LBA {lba}: EDC={'OK' if edc_match else 'MISMATCH'} "
              f"P={'OK' if p_match else 'MISMATCH'} "
              f"Q={'OK' if q_match else 'MISMATCH'}")

        if not p_match:
            print(f"  P computed[0:8]: {bytes(p_computed[:8]).hex()}")
            print(f"  P stored  [0:8]: {p_stored[:8].hex()}")
        if not q_match:
            print(f"  Q computed[0:8]: {bytes(q_computed[:8]).hex()}")
            print(f"  Q stored  [0:8]: {q_stored[:8].hex()}")
