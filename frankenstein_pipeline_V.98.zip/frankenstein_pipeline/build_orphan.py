#!/usr/bin/env python3
"""
build_orphan.py — Clean-Slate Frankenstein Disc Builder (mkpsxiso Pipeline)
==========================================================================

Replaces the legacy raw-binary-copy + edcre.exe pipeline with a deterministic
mkpsxiso/dumpsxiso mastering workflow.

Minimal EXE Patch Set:
  1. Append hybrid Huffman tree at EXE end (file offset 0xA4800)
  2. Patch 23 tree references (0x800EF1C8 → 0x800BC700)
  3. Narrow BSS clear range (start: 0x800BCCC8, end: 0x800D9E80)
  4. Zero pre-tree BSS gap (0x800BC668–0x800BC700)
  5. HBD string patch (hbd1ps1d.w71 → q41)
  6. Update text_size in EXE header (0xA4800 → 0xA5000)

EXE-internal patches:
  7. Runtime tree ptr vars (0x800BC6F8/FC)
  8. Decomp Target 4 (tree→runtime var, 2 sites)
  9. Decomp Target 6 (NOP andi 0xFFFE)
  10. Decomp Target 5R (root_id+1 runtime stub)
  11. R-TREEHOOK (per-block tree pointer update)

P0 patches (ported from V39 — Aug 5, 2026 Delta Matrix):
  12. BSS end LUI fix (0x800D → 0x800E)
  13. Disc-check bypass (10 surgical patches)
  14. LBA broad scan (354 → 500)
  15. Folder pointer remap (ABS/REL tables)

P1 patches (ported from V39):
  16. HBD type trampoline (redirect DQ4 block types 32,39,40,42,46)
  17. Sequential sector table (16-bit entries 300-400)

P2 patches (ported from V39):
  18. Malloc clamp (prevent descriptor base overflow past 8MB)

Usage:
  python build_orphan.py
  python build_orphan.py --skip-hash-check
  python build_orphan.py --output-dir /path/to/output
"""

import argparse
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, List, Tuple

# ── Paths ─────────────────────────────────────────────────────────────────────

PROJECT_ROOT = Path(r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION")
PIPELINE_DIR = PROJECT_ROOT / "frankenstein_pipeline"

# Input assets
DW7_EXE_CLEAN = PROJECT_ROOT / "translation" / "SLUSP012.06_clean.bin"
HYBRID_TREE = PROJECT_ROOT / "dw7_hybrid_tree.bin"
DQ4_DISC_CUE = PROJECT_ROOT / "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).cue"
DQ4_DISC_BIN = PROJECT_ROOT / "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
DQ4_HBD = PIPELINE_DIR / "dq4_extract" / "HBD1PS1D.Q41"
DQ4_LICENSE = PIPELINE_DIR / "dq4_extract" / "license_data.dat"
FROZEN_INPUTS = PROJECT_ROOT / "cybergrime" / "FROZEN_INPUTS.json"

# DW7 disc base (commercial master — valid ISO9660, boots on real BIOS)
DW7_DISC_BIN = PROJECT_ROOT / "DW7D1" / "DW7D1.bin"
DW7_DISC_CUE = PROJECT_ROOT / "DW7D1" / "DW7D1.cue"

# Translation map (TXMP format — pre-encoded English text for HBD re-encoding)
TRANSLATION_MAP = PROJECT_ROOT / "cybergrime" / "translation_map.bin"

# Folder mapping (DW7→DQ4 sector mapping for folder pointer remap)
FOLDER_MAPPING_JSON = PROJECT_ROOT / "translation" / "folder_mapping.json"

# Tools
EDCRE_EXE = PROJECT_ROOT / "edcre" / "edcre-v1.1.0-windows-x86_64-static" / "edcre.exe"

# Sector constants
SECTOR_SIZE = 2352      # Raw MODE2 sector
USER_DATA_SIZE = 2048   # User data payload per sector
SYNC_HEADER = 12        # 00 FF FF FF FF FF FF FF FF FF FF 00
MODE_HEADER = 4         # mm:ss:ff + mode byte
SUBHEADER = 8           # sub-header bytes
DATA_OFFSET = SYNC_HEADER + MODE_HEADER + SUBHEADER  # 24

# HBD LBA on DW7 disc (from ISO9660 directory)
HBD_LBA = 354
EXE_LBA = 24
CNF_LBA = 23
ROOT_DIR_LBA = 22
PVD_LBA = 16

# HBD re-encoding constants (from C++ HbdReencoder)
DW7_HTS = 1366          # DW7 header-to-text gap
DW7_GAP_SIZE = DW7_HTS - 24  # 1342 bytes of zero padding after 24-byte header
DQ4_HBD_SECTOR_SIZE = 2048

# Build assets directory
BUILD_ASSETS = PIPELINE_DIR / "build_assets"

# XML project
XML_PROJECT = PIPELINE_DIR / "dq4_frankenstein.xml"

# Output
DEFAULT_OUTPUT_DIR = PIPELINE_DIR / "output"

# ── EXE Constants ────────────────────────────────────────────────────────────

EXE_HEADER_SIZE = 0x800       # 2048 bytes
EXE_TEXT_SIZE_OFFSET = 0x1C   # In header
EXE_PC0_OFFSET = 0x10
EXE_LOAD_ADDR_OFFSET = 0x18

DW7_TEXT_SIZE = 0xA4800       # Original text size (673,792 bytes)
DW7_LOAD_ADDR = 0x80017F00    # EXE load address
DW7_PC0 = 0x8008E284          # Entry point

# Tree placement
OLD_TREE_ADDR = 0x800EF1C8    # Old hybrid tree address in EXE
NEW_TREE_ADDR = 0x800BC700    # New tree address (EXE end in RAM)
TREE_SIZE = 1480              # Hybrid tree size

# BSS clear range
BSS_CLEAR_START_OLD = 0x800BC668
BSS_CLEAR_END_OLD = 0x800F4980
BSS_CLEAR_START_NEW = 0x800BCCC8   # Narrowed: after tree placement
BSS_CLEAR_END_NEW = 0x800F4980     # Restored: original end (trampolines at 0x80101000 are safe)

# HBD string
HBD_STRING_OLD = b"hbd1ps1d.w71"
HBD_STRING_NEW = b"hbd1ps1d.q41"  # Full filename, just change extension

# Runtime tree pointer variables (in BSS, just before tree at 0x800BC700)
TREE_PTR_VAR_RAM = 0x800BC6F8       # Raw tree base for Sites 1&2
TREE_PTR_VAR_OFF = 0xA4FF8          # File offset (0x800BC6F8 - 0x80017F00 + 0x800)
TREE_PTR_VAR_PLUS2_RAM = 0x800BC6FC # Tree base + 2 for Site 3 (root_id+1)
TREE_PTR_VAR_PLUS2_OFF = 0xA4FFC   # File offset

# Decomp Target 4: Patch tree pointer loads to use runtime variable
# Site 1: file 0x3EBF0 (RAM 0x800562F0) — addiu $v0, $v0, imm
# Site 2: file 0x3EC38 (RAM 0x80056338) — addiu $v0, $v0, imm
# After tree ref patch, these are addiu $v0, $v0, 0xC700
# Replace with: lui $at, 0x800C; lw $v0, 0xC6F8($at)
DECOMP_TREE_PTR_SITES = [0x3EBF0, 0x3EC38]
LUI_AT_800C = 0x3C01800C  # lui $at, 0x800C (LE: 0x800C013C)
LW_V0_C6F8_AT = 0x8C02C6F8  # lw $v0, 0xC6F8($at) (LE: 0xC6F8028C)

# Decomp Target 6: NOP andi $v0, $v0, 0xFFFE at file 0x7CAA4
DECOMP_OFFSET_B_OFF = 0x7CAA4
ANDI_V0_FFFE = 0x304200FE  # andi $v0, $v0, 0xFFFE (LE: 0xFE000234... actually LE word)
MIPS_NOP = 0x00000000

# Decomp Target 5R: Root ID +1 runtime stub
# Site 3: file 0x408F4 (RAM 0x80057FF4) — addiu $v1, $v0, 0xC700 (after tree ref patch)
# Replace with JAL to stub at tramp_base + 0x200
DECOMP_ROOT_ID_OFF = 0x408F4
TRAMP_BASE = 0x80102000
ROOT_ID_STUB_OFF = 0x200  # tramp_base + 0x200 = 0x80102200
ROOT_ID_STUB_RAM = TRAMP_BASE + ROOT_ID_STUB_OFF

# R-TREEHOOK: Hook block loader for per-block tree pointer update
# Hook point: file 0x3F700 (RAM 0x80057600) — JAL to stub
TREE_HOOK_OFF = 0x3F700
TREE_HOOK_RAM = 0x80057600
TREE_HOOK_STUB_OFF = 0x300  # tramp_base + 0x300 = 0x80102300
TREE_HOOK_STUB_RAM = TRAMP_BASE + TREE_HOOK_STUB_OFF

# ── P0/P1/P2 Patch Constants (ported from V39 psx_binary_ops.cpp) ─────────────

# HBD LBA — stays at 354 (same as DW7 disc, no relocation needed)
# The DQ4 HBD is written at the same LBA as the original DW7 HBD.
# LBA references in the EXE already point to 354, so no LBA patching needed.
HBD_LBA_TARGET = 354   # Where DQ4 HBD is written on the output disc
OLD_HBD_LBA = 354      # Where DW7 HBD was (same location)
LBA_DELTA = 0          # No relocation — HBD stays at sector 354

# Trampoline base — all stubs placed here to be outside BSS clear range
TRAMP_BASE_RAM = 0x80101000

# Folder pointer remap (ABS/REL tables in EXE)
ABS_TABLE_START = 0x4184      # File offset of ABS table
REL_TABLE_START = 0x511C      # File offset of REL table
TABLE_ENTRY_SIZE = 8
MAX_TABLE_ENTRIES = 6000
FOLDER_MAP_PATH = PROJECT_ROOT / "translation" / "folder_mapping.json"

# Disc-check bypass — only 3 safe caller-side validation bypasses
# These make disc-check functions return success without altering control flow.
# Removed: NOP patches, branch redirects, CD init force, disc-change neutralization
# — all of which corrupt CD-ROM callback registration or break control flow.
DISC_CHECK_PATCHES = [
    (0x6112C, 0x24020001),  # li $v0, 1 (return success)
    (0x611D8, 0x24020001),  # li $v0, 1
    (0x613B8, 0x24020001),  # li $v0, 1
]

# CD init force and disc-change neutralization REMOVED
# These were toxic patches that corrupted CD-ROM callback registration
# and broke control flow. Only the 3 safe caller-side li $v0,1 patches remain.

# HBD type trampoline hook point
HBD_TYPE_TRAMP_HOOK_OFF = 0x3EBE4  # 0x800562E4 - 0x80017F00 + 0x800
HBD_TYPE_TRAMP_EXPECTED = 0x1260000D  # beq $s3, $zero, +13

# HBD type trampoline code (27 instructions, ported from V39)
HBD_TYPE_TRAMP_CODE = [
    0x240A0027,  # 0:  addiu $t2, $zero, 39
    0x126A0014,  # 1:  beq  $s3, $t2, .dq4 (+20)
    0x00000000,  # 2:  nop
    0x240A0028,  # 3:  addiu $t2, $zero, 40
    0x126A0011,  # 4:  beq  $s3, $t2, .dq4 (+17)
    0x00000000,  # 5:  nop
    0x240A002A,  # 6:  addiu $t2, $zero, 42
    0x126A000E,  # 7:  beq  $s3, $t2, .dq4 (+14)
    0x00000000,  # 8:  nop
    0x240A002E,  # 9:  addiu $t2, $zero, 46
    0x126A000B,  # 10: beq  $s3, $t2, .dq4 (+11)
    0x00000000,  # 11: nop
    0x240A0020,  # 12: addiu $t2, $zero, 32
    0x126A0008,  # 13: beq  $s3, $t2, .dq4 (+8)
    0x00000000,  # 14: nop
    0xA4430538,  # 15: sh   $v1, 1336($v0) — original DW7 behavior
    0x00009821,  # 16: addu $s3, $zero, $zero — count=0 (BAD-5)
    0x00000000,  # 17: nop
    0x080158C7,  # 18: j    0x8005631C — skip to second-pair processing
    0x00000000,  # 19: nop
    0x080158D9,  # 20: j    0x80056364 — dead
    0x00000000,  # 21: nop
    0x00009821,  # 22: addu $s3, $zero, $zero — count=0
    0x00001821,  # 23: addu $v1, $zero, $zero — $v1 = 0
    0xA4400538,  # 24: sh   $zero, 1336($v0)
    0x080158C7,  # 25: j    0x8005631C
    0x00000000,  # 26: nop
]

# Malloc clamp hook point
MALLOC_CLAMP_OFF = 0x63674  # 0x8007AD74 - 0x80017F00 + 0x800
MALLOC_CLAMP_EXPECTED = 0xAC662228  # sw $a2, 0x2228($v1)

# Malloc clamp trampoline (9 instructions)
MALLOC_CLAMP_TRAMP = [
    0x3C088080,  # 0: lui $t0, 0x8080 (8MB ceiling)
    0x0106402B,  # 1: sltu $t0, $t0, $a2
    0x11000002,  # 2: beq $t0, $zero, +2 (skip if <= ceiling)
    0x00000000,  # 3: nop
    0x3C068010,  # 4: lui $a2, 0x8010 (clamp to 0x80100000)
    0xAC662228,  # 5: sw $a2, 0x2228($v1) — original
    0x24632228,  # 6: addiu $v1, $v1, 0x2228 — original next
    0x0801EB5F,  # 7: j 0x8007AD7C — continue
    0x00000000,  # 8: nop
]

# Sequential sector table
SEQ_TABLE_START = 0xA39AA
SEQ_TABLE_END = 0xA3A02

# ── Hash Verification ────────────────────────────────────────────────────────

def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with open(path, 'rb') as f:
        while True:
            chunk = f.read(65536)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest().upper()


def verify_frozen_inputs() -> bool:
    """Verify SHA-256 hashes of all frozen input assets."""
    if not FROZEN_INPUTS.exists():
        print("[WARN] FROZEN_INPUTS.json not found, skipping hash verification")
        return True

    frozen = json.loads(FROZEN_INPUTS.read_text(encoding='utf-8'))
    inputs = frozen.get('inputs', {})
    all_pass = True

    for name, spec in inputs.items():
        path = PROJECT_ROOT / spec['path']
        expected_hash = spec['sha256'].upper()
        expected_size = spec['size']

        if not path.exists():
            print(f"  [FAIL] {name}: file not found at {path}")
            all_pass = False
            continue

        actual_hash = sha256_file(path)
        actual_size = path.stat().st_size

        if actual_hash != expected_hash:
            print(f"  [FAIL] {name}: hash mismatch")
            print(f"         Expected: {expected_hash}")
            print(f"         Actual:   {actual_hash}")
            all_pass = False
        elif actual_size != expected_size:
            print(f"  [FAIL] {name}: size mismatch (expected {expected_size}, got {actual_size})")
            all_pass = False
        else:
            print(f"  [OK]   {name}: {actual_hash[:16]}... ({actual_size} bytes)")

    return all_pass


# ── EXE Patcher ──────────────────────────────────────────────────────────────

class ExePatcher:
    """Applies minimal patch set to DW7 EXE for BIOS adoption."""

    def __init__(self, exe_data: bytearray):
        self.data = exe_data
        self.patches_applied = []

    def patch_tree_references(self) -> int:
        """Patch 23 LUI+ADDIU pairs from old tree addr to new tree addr.

        Pattern: LUI $v0, 0x800F followed by ADDIU $rt, $v0, 0xF1C8
        where $rt varies (v0, v1, a0-a3, t0, t2, s1, s4, fp, etc).

        We match on:
          - LUI opcode (0x3C) with rt=$v0 (0x02) and imm=0x800F
          - Next instruction: ADDIU opcode (0x24) with rs=$v0 (0x02) and imm=0xF1C8
        Then patch:
          - LUI imm: 0x800F -> 0x800C
          - ADDIU imm: 0xF1C8 -> 0xC700
        """
        count = 0
        for i in range(0, len(self.data) - 7, 4):
            word0 = struct.unpack_from('<I', self.data, i)[0]
            word1 = struct.unpack_from('<I', self.data, i + 4)[0]

            # Check LUI $v0, 0x800F: opcode=0x0F, rt=0x02, imm=0x800F
            if (word0 >> 26) == 0x0F and ((word0 >> 16) & 0x1F) == 0x02 and (word0 & 0xFFFF) == 0x800F:
                # Check ADDIU $rt, $v0, 0xF1C8: opcode=0x09, rs=0x02, imm=0xF1C8
                if (word1 >> 26) == 0x09 and ((word1 >> 21) & 0x1F) == 0x02 and (word1 & 0xFFFF) == 0xF1C8:
                    # Patch LUI imm to 0x800C
                    new_word0 = (word0 & 0xFFFF0000) | 0x800C
                    struct.pack_into('<I', self.data, i, new_word0)
                    # Patch ADDIU imm to 0xC700
                    new_word1 = (word1 & 0xFFFF0000) | 0xC700
                    struct.pack_into('<I', self.data, i + 4, new_word1)
                    count += 1

        self.patches_applied.append(f"tree_refs: {count} pairs patched")
        return count

    def patch_bss_clear(self) -> bool:
        """Narrow BSS clear range to avoid zeroing the hybrid tree.

        Original at PC0:
          LUI $v0, 0x800C; ADDIU $v0, $v0, 0xC668  (start=0x800BC668)
          LUI $v1, 0x800F; ADDIU $v1, $v1, 0x4980  (end=0x800F4980)

        New:
          LUI $v0, 0x800C; ADDIU $v0, $v0, 0xCCC8  (start=0x800BCCC8)
          LUI $v1, 0x800F; ADDIU $v1, $v1, 0x4980  (end=0x800F4980, unchanged)
        """
        found_start = False
        found_end = False

        for i in range(0, len(self.data) - 7, 4):
            word0 = struct.unpack_from('<I', self.data, i)[0]
            word1 = struct.unpack_from('<I', self.data, i + 4)[0]

            # Match LUI $v0, 0x800C + ADDIU $v0, $v0, 0xC668
            if ((word0 >> 26) == 0x0F and
                ((word0 >> 16) & 0x1F) == 0x02 and
                (word0 & 0xFFFF) == 0x800C and
                (word1 >> 26) == 0x09 and
                ((word1 >> 21) & 0x1F) == 0x02 and
                ((word1 >> 16) & 0x1F) == 0x02 and
                (word1 & 0xFFFF) == 0xC668):
                # Patch ADDIU imm to 0xCCC8
                new_word1 = (word1 & 0xFFFF0000) | 0xCCC8
                struct.pack_into('<I', self.data, i + 4, new_word1)
                found_start = True

            # Match LUI $v1, 0x800F + ADDIU $v1, $v1, 0x4980 (end — keep original)
            if ((word0 >> 26) == 0x0F and
                ((word0 >> 16) & 0x1F) == 0x03 and
                (word0 & 0xFFFF) == 0x800F and
                (word1 >> 26) == 0x09 and
                ((word1 >> 21) & 0x1F) == 0x03 and
                ((word1 >> 16) & 0x1F) == 0x03 and
                (word1 & 0xFFFF) == 0x4980):
                # Keep original end — no patch needed
                found_end = True

        if found_start and found_end:
            self.patches_applied.append(
                f"bss_clear: narrowed to 0x{BSS_CLEAR_START_NEW:08X}-0x{BSS_CLEAR_END_NEW:08X}")
        else:
            self.patches_applied.append(
                f"bss_clear: FAILED (start={found_start}, end={found_end})")

        return found_start and found_end

    def patch_hbd_string(self) -> bool:
        """Patch HBD filename: hbd1ps1d.w71 → q41"""
        idx = self.data.find(HBD_STRING_OLD)
        if idx == -1:
            self.patches_applied.append("hbd_string: NOT FOUND")
            return False

        self.data[idx:idx + len(HBD_STRING_OLD)] = HBD_STRING_NEW[:len(HBD_STRING_OLD)]
        self.patches_applied.append(f"hbd_string: patched at offset 0x{idx:X}")
        return True

    def append_hybrid_tree(self, tree_data: bytes) -> bool:
        """Append hybrid Huffman tree at end of EXE text section."""
        # Current text size = 0xA4800, tree goes at file offset 0xA4800 + 0x800 = 0xA5000
        # But the EXE file includes the 0x800 header, so tree goes at file offset:
        # header(0x800) + text_size(0xA4800) = 0xA5000
        tree_offset = EXE_HEADER_SIZE + DW7_TEXT_SIZE

        # Ensure data is large enough
        if len(self.data) < tree_offset:
            # Pad to tree offset
            self.data.extend(b'\x00' * (tree_offset - len(self.data)))

        # Write tree
        self.data[tree_offset:tree_offset + len(tree_data)] = tree_data

        # Pad to next 2048-byte boundary
        end = tree_offset + len(tree_data)
        padded_end = (end + 2047) & ~2047
        if padded_end > end:
            self.data.extend(b'\x00' * (padded_end - end))

        self.patches_applied.append(
            f"hybrid_tree: {len(tree_data)} bytes at file offset 0x{tree_offset:X}")

        return True

    def update_text_size(self) -> bool:
        """Update text_size in EXE header to include ALL appended data.

        Must cover the entire patched EXE file (minus header) so that
        mkpsxiso writes all sectors to disc and the BIOS loads all
        trampoline stubs into RAM. The old code only set T_SIZE to
        DW7_TEXT_SIZE + TREE_SIZE (0xA5000), but trampoline stubs at
        file offset 0xE9100+ were beyond this boundary and never
        loaded, causing "Illegal instruction" crashes in StarPSX.
        """
        total_file_size = len(self.data)
        new_text_size = total_file_size - EXE_HEADER_SIZE
        # Round up to 2048 boundary
        padded_text = (new_text_size + 2047) & ~2047

        # Pad EXE data to match padded T_SIZE (file = header + padded_text)
        target_file_size = EXE_HEADER_SIZE + padded_text
        if target_file_size > len(self.data):
            self.data.extend(b'\x00' * (target_file_size - len(self.data)))

        struct.pack_into('<I', self.data, EXE_TEXT_SIZE_OFFSET, padded_text)

        self.patches_applied.append(
            f"text_size: 0x{DW7_TEXT_SIZE:X} → 0x{padded_text:X} "
            f"(full EXE: {len(self.data)} bytes, {padded_text} text)")
        return True

    def zero_pre_tree_bss(self) -> bool:
        """Zero the BSS gap between old BSS start and tree placement."""
        # Region: 0x800BC668 to 0x800BC700 (152 bytes)
        # File offset: (0x800BC668 - 0x80017F00 + 0x800) = 0xA4668
        start_off = (BSS_CLEAR_START_OLD - DW7_LOAD_ADDR + EXE_HEADER_SIZE)
        end_off = (NEW_TREE_ADDR - DW7_LOAD_ADDR + EXE_HEADER_SIZE)
        if end_off <= len(self.data):
            for i in range(start_off, end_off):
                self.data[i] = 0
            self.patches_applied.append(
                f"pre_tree_bss: zeroed 0x{BSS_CLEAR_START_OLD:08X}-0x{NEW_TREE_ADDR:08X} ({end_off - start_off} bytes)")
        else:
            self.patches_applied.append("pre_tree_bss: deferred to BIOS (offset beyond EXE)")
        return True

    def write_runtime_tree_ptrs(self) -> bool:
        """Write runtime tree pointer variables at 0x800BC6F8 and 0x800BC6FC."""
        tree_addr = NEW_TREE_ADDR
        tree_addr_plus2 = NEW_TREE_ADDR + 2

        if TREE_PTR_VAR_OFF + 4 <= len(self.data):
            struct.pack_into('<I', self.data, TREE_PTR_VAR_OFF, tree_addr)
        else:
            self.patches_applied.append("runtime_tree_ptrs: FAILED (offset beyond EXE)")
            return False

        if TREE_PTR_VAR_PLUS2_OFF + 4 <= len(self.data):
            struct.pack_into('<I', self.data, TREE_PTR_VAR_PLUS2_OFF, tree_addr_plus2)
        else:
            self.patches_applied.append("runtime_tree_ptrs: FAILED (+2 offset beyond EXE)")
            return False

        self.patches_applied.append(
            f"runtime_tree_ptrs: 0x{TREE_PTR_VAR_RAM:08X}=0x{tree_addr:08X}, "
            f"0x{TREE_PTR_VAR_PLUS2_RAM:08X}=0x{tree_addr_plus2:08X}")
        return True

    def patch_decomp_target4(self) -> bool:
        """Patch tree pointer loads at 2 sites to load from runtime variable.

        After tree ref patch, sites contain: addiu $v0, $v0, 0xC700
        Replace with: lui $at, 0x800C; lw $v0, 0xC6F8($at)
        """
        # After tree ref patch: addiu $v0, $v0, 0xC700 = 0x2442C700 (LE word)
        expected_addiu = 0x2442C700
        count = 0

        for site_off in DECOMP_TREE_PTR_SITES:
            if site_off + 4 > len(self.data):
                continue
            current = struct.unpack_from('<I', self.data, site_off)[0]
            if current == expected_addiu:
                # Replace with lui $at, 0x800C
                struct.pack_into('<I', self.data, site_off, LUI_AT_800C)
                # Insert lw $v0, 0xC6F8($at) at site_off + 4
                # NOTE: This overwrites the next instruction. We need to verify
                # the next instruction is safe to overwrite or use a different approach.
                # In the old pipeline, this is done with 2-instruction form replacing
                # the LUI+ADDIU pair. Since tree ref patch already changed LUI to 0x800C,
                # we replace the LUI (at site_off-4) with lui $at, 0x800C and the ADDIU
                # (at site_off) with lw $v0, 0xC6F8($at).
                # Actually: site_off points to the ADDIU. The LUI is at site_off - 4.
                # Tree ref patch already set LUI to 0x3C02800C (lui $v0, 0x800C).
                # We need: lui $at, 0x800C (0x3C01800C) at site_off-4
                #          lw $v0, 0xC6F8($at) (0x8C02C6F8) at site_off
                struct.pack_into('<I', self.data, site_off - 4, LUI_AT_800C)
                struct.pack_into('<I', self.data, site_off, LW_V0_C6F8_AT)
                count += 1
            else:
                # Try matching the original pre-tree-ref-patch value
                # If tree refs weren't patched yet, it's addiu $v0, $v0, 0xF1C8
                pass

        if count > 0:
            self.patches_applied.append(f"decomp_target4: {count} sites patched (tree→runtime var)")
        else:
            self.patches_applied.append("decomp_target4: FAILED (no sites matched)")
        return count > 0

    def patch_decomp_target6(self) -> bool:
        """NOP out andi $v0, $v0, 0xFFFE at file offset 0x7CAA4.

        DQ4 requires odd offset_b values; DW7 forces even with this mask.
        """
        if DECOMP_OFFSET_B_OFF + 4 > len(self.data):
            self.patches_applied.append("decomp_target6: FAILED (offset beyond EXE)")
            return False

        current = struct.unpack_from('<I', self.data, DECOMP_OFFSET_B_OFF)[0]
        # andi $v0, $v0, 0xFFFE: opcode=0x0C, rs=0x02, rt=0x02, imm=0xFFFE
        # Word = (0x0C<<26)|(0x02<<21)|(0x02<<16)|0xFFFE = 0x3042FFFE
        # PSX is LE, so struct.unpack_from('<I') gives 0x3042FFFE
        expected_le = 0x3042FFFE

        if current == expected_le:
            struct.pack_into('<I', self.data, DECOMP_OFFSET_B_OFF, MIPS_NOP)
            self.patches_applied.append("decomp_target6: NOP'd andi 0xFFFE at 0x7CAA4")
            return True
        else:
            # Check if already NOP'd
            if current == MIPS_NOP:
                self.patches_applied.append("decomp_target6: already NOP'd")
                return True
            self.patches_applied.append(
                f"decomp_target6: FAILED (expected 0x{expected_le:08X}, got 0x{current:08X})")
            return False

    def _append_stub(self, stub_words: list) -> int:
        """Append a list of MIPS words (as big-endian ints) to EXE, return file offset."""
        offset = len(self.data)
        for w in stub_words:
            self.data.extend(struct.pack('<I', w))
        return offset

    def _pad_to_ram(self, target_ram: int):
        """Pad EXE data with zeros to reach target RAM address."""
        target_off = target_ram - DW7_LOAD_ADDR + EXE_HEADER_SIZE
        if target_off > len(self.data):
            self.data.extend(b'\x00' * (target_off - len(self.data)))

    def patch_decomp_target5r(self) -> bool:
        """Patch Site 3 with JAL to runtime root_id+1 stub.

        Site 3 at file 0x408F4 (RAM 0x80057FF4):
          After tree ref patch: addiu $v1, $v0, 0xC700 (loads tree base into $v1)
          Next instruction: andi $v0, $v0, 0x7FFF at 0x408F8
          Next: addu $v0, $v0, $v1 at 0x408FC

        We replace the addiu at 0x408F4 with JAL to stub.
        The stub loads tree_base+2 from runtime var 0x800BC6FC into $v1,
        then returns. The andi+addu instructions remain, but now $v1
        contains tree_base+2 instead of tree_base, implementing root_id+1.

        Stub at tramp_base + 0x200 = 0x80102200:
          lui $at, 0x800C       # 0x3C01800C
          lw $v1, 0xC6FC($at)   # 0x8C23C6FC  (lw $v1, 0xC6FC($at))
          jr $ra                # 0x03E00008
          nop                   # 0x00000000
        """
        # Stub loads tree_base+2 from runtime var 0x800BC6FC into $v1,
        # then adjusts $ra to skip the ADDIU at return point.
        # Return address from JAL = 0x80057FF4 (the ADDIU $v1, $v1, 0xF1C8)
        # We add 4 to $ra to skip it, landing at 0x80057FF8 (the ANDI).
        stub = [
            0x3C01800C,  # lui $at, 0x800C
            0x8C23C6FC,  # lw $v1, 0xC6FC($at)  — load tree_base+2
            0x23FF0004,  # addiu $ra, $ra, 4    — skip ADDIU at return
            0x03E00008,  # jr $ra
            0x00000000,  # nop (delay slot)
        ]

        # Append stub to EXE
        stub_file_off = self._append_stub(stub)
        stub_ram = DW7_LOAD_ADDR + stub_file_off - EXE_HEADER_SIZE

        # Patch Site 3: replace LUI with JAL to stub at actual appended location
        jal_target = stub_ram
        jal_word = (0x03 << 26) | ((jal_target >> 2) & 0x03FFFFFF)

        # LUI $v1, 0x800F is at file offset 0x408EC (DECOMP_ROOT_ID_OFF - 8)
        # There's an lhu $v0, 0x18($sp) at 0x408F0 between LUI and ADDIU
        # JAL goes at 0x408EC, delay slot at 0x408F0 gets NOP'd
        lui_off = DECOMP_ROOT_ID_OFF - 8
        if lui_off + 4 <= len(self.data):
            lui_word = struct.unpack_from('<I', self.data, lui_off)[0]
            # Check: lui $v1, 0x800F = 0x3C03800F
            if (lui_word >> 26) == 0x0F and ((lui_word >> 16) & 0x1F) == 0x03 and (lui_word & 0xFFFF) == 0x800F:
                struct.pack_into('<I', self.data, lui_off, jal_word)
                # NOP the delay slot (lhu at 0x408F0)
                struct.pack_into('<I', self.data, lui_off + 4, MIPS_NOP)
                self.patches_applied.append(
                    f"decomp_target5r: JAL 0x{jal_target:08X} at file 0x{lui_off:X} "
                    f"(RAM 0x{DW7_LOAD_ADDR + lui_off - EXE_HEADER_SIZE:08X}), "
                    f"stub at 0x{stub_ram:08X}, $ra skip ADDIU")
                return True
            else:
                self.patches_applied.append(
                    f"decomp_target5r: FAILED (LUI at 0x{lui_off:X} = 0x{lui_word:08X}, "
                    f"expected lui $v1, 0x800F = 0x3C03800F)")
                return False
        else:
            self.patches_applied.append("decomp_target5r: FAILED (offset beyond EXE)")
            return False

    def patch_r_treehook(self) -> bool:
        """Hook block loader to update runtime tree pointer per-block.

        Hook point: file 0x3F700 (RAM 0x80057600)
        Replace with JAL to stub at tramp_base + 0x300 = 0x80102300.

        Stub reads tree_start from block header (offset 0x0C),
        adds block_base, writes to runtime var 0x800BC6F8.

        Stub:
          # $a0 should contain block base address (from block loader context)
          # Read tree_start from block header at block_base + 0x0C
          lw $v1, 0x0C($a0)       # 0x8C63000C  -- tree_start from header
          addu $v1, $v1, $a0      # 0x00851821  -- tree_addr = block_base + tree_start
          # Store to runtime var at 0x800BC6F8
          lui $at, 0x800C         # 0x3C01800C
          sw $v1, 0xC6F8($at)     # 0xAC23C6F8
          jr $ra                  # 0x03E00008
          nop                     # 0x00000000
        """
        stub = [
            0x8C63000C,  # lw $v1, 0x0C($a0)
            0x00851821,  # addu $v1, $v1, $a0
            0x3C01800C,  # lui $at, 0x800C
            0xAC23C6F8,  # sw $v1, 0xC6F8($at)
            0x03E00008,  # jr $ra
            0x00000000,  # nop
        ]

        stub_file_off = self._append_stub(stub)
        stub_ram = DW7_LOAD_ADDR + stub_file_off - EXE_HEADER_SIZE

        # Patch hook point with JAL to stub at actual appended location
        jal_target = stub_ram
        jal_word = (0x03 << 26) | ((jal_target >> 2) & 0x03FFFFFF)

        if TREE_HOOK_OFF + 4 <= len(self.data):
            current = struct.unpack_from('<I', self.data, TREE_HOOK_OFF)[0]
            struct.pack_into('<I', self.data, TREE_HOOK_OFF, jal_word)
            self.patches_applied.append(
                f"r_treehook: JAL 0x{jal_target:08X} at file 0x{TREE_HOOK_OFF:X} "
                f"(RAM 0x{TREE_HOOK_RAM:08X}), stub at 0x{stub_ram:08X}")
            return True
        else:
            self.patches_applied.append("r_treehook: FAILED (hook point beyond EXE)")
            return False

    def patch_disc_check(self) -> bool:
        """Apply 3 safe caller-side disc-check bypass patches."""
        count = 0
        for off, patch_val in DISC_CHECK_PATCHES:
            if off + 4 <= len(self.data):
                struct.pack_into('<I', self.data, off, patch_val)
                count += 1
            else:
                self.patches_applied.append(f"disc_check: FAILED (offset 0x{off:X} beyond EXE)")
                return False

        self.patches_applied.append(f"disc_check: {count} safe patches applied")
        return True

    def patch_lba_references(self) -> int:
        """Patch 32-bit LBA references from old HBD LBA (354) to new (500)."""
        count = 0
        for i in range(0x800, len(self.data) - 3, 4):
            val = struct.unpack_from('<I', self.data, i)[0]
            if val == OLD_HBD_LBA:
                struct.pack_into('<I', self.data, i, HBD_LBA)
                count += 1
        self.patches_applied.append(f"lba_references: {count} refs patched ({OLD_HBD_LBA}->{HBD_LBA})")
        return True

    def patch_folder_pointers(self) -> bool:
        """Remap ABS/REL folder pointer tables using folder_mapping.json."""
        if not FOLDER_MAP_PATH.exists():
            self.patches_applied.append("folder_pointers: SKIPPED (no folder_mapping.json)")
            return True

        mappings_data = json.loads(FOLDER_MAP_PATH.read_text(encoding='utf-8'))
        mappings = mappings_data.get('mappings', [])

        dw7_to_dq4 = {}
        for m in mappings:
            dw7_to_dq4[m['dw7_sector']] = m['dq4_sector']

        dq4_base_sector = HBD_LBA
        lba_delta = LBA_DELTA
        rel_adjust = dq4_base_sector - HBD_LBA

        abs_matched = 0
        abs_delta = 0
        rel_matched = 0

        for i in range(MAX_TABLE_ENTRIES):
            off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
            if off + 4 > len(self.data):
                break
            val = struct.unpack_from('<I', self.data, off)[0]
            if val == 0:
                continue
            if val in dw7_to_dq4:
                new_abs = dw7_to_dq4[val] + dq4_base_sector
                struct.pack_into('<I', self.data, off, new_abs)
                abs_matched += 1
            elif OLD_HBD_LBA <= val < 0x100000:
                new_val = val + lba_delta
                struct.pack_into('<I', self.data, off, new_val)
                abs_delta += 1

        for i in range(MAX_TABLE_ENTRIES):
            off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
            if off + 4 > len(self.data):
                break
            val = struct.unpack_from('<I', self.data, off)[0]
            if val == 0:
                continue
            for dw7_sec, dq4_sec in dw7_to_dq4.items():
                if dw7_sec - OLD_HBD_LBA == val:
                    new_rel = dq4_sec + rel_adjust
                    struct.pack_into('<I', self.data, off, new_rel)
                    rel_matched += 1
                    break

        self.patches_applied.append(
            f"folder_pointers: abs_matched={abs_matched}, abs_delta={abs_delta}, rel_matched={rel_matched}")
        return True

    def patch_sequential_sector_table(self) -> int:
        """Patch 16-bit sequential sector table entries (300-400 range)."""
        delta = LBA_DELTA
        count = 0
        for i in range(SEQ_TABLE_START, min(SEQ_TABLE_END, len(self.data) - 1), 2):
            val = struct.unpack_from('<H', self.data, i)[0]
            if 300 <= val <= 400:
                new_val = (val + delta) & 0xFFFF
                struct.pack_into('<H', self.data, i, new_val)
                count += 1
        self.patches_applied.append(f"seq_sector_table: {count} entries patched")
        return True

    def patch_hbd_type_trampoline(self) -> bool:
        """Patch HBD block type trampoline — redirect DQ4 block types (32,39,40,42,46)."""
        off = HBD_TYPE_TRAMP_HOOK_OFF
        if off + 8 > len(self.data):
            self.patches_applied.append("hbd_type_trampoline: FAILED (hook offset beyond EXE)")
            return False

        orig = struct.unpack_from('<I', self.data, off)[0]
        if orig != HBD_TYPE_TRAMP_EXPECTED:
            self.patches_applied.append(
                f"hbd_type_trampoline: WARNING (expected 0x{HBD_TYPE_TRAMP_EXPECTED:08X}, "
                f"got 0x{orig:08X}) — patching anyway")

        stub_file_off = self._append_stub(HBD_TYPE_TRAMP_CODE)
        stub_ram = DW7_LOAD_ADDR + stub_file_off - EXE_HEADER_SIZE

        jal_word = (0x03 << 26) | ((stub_ram >> 2) & 0x03FFFFFF)
        struct.pack_into('<I', self.data, off, jal_word)
        struct.pack_into('<I', self.data, off + 4, MIPS_NOP)

        self.patches_applied.append(
            f"hbd_type_trampoline: JAL 0x{stub_ram:08X} at file 0x{off:X}")
        return True

    def patch_malloc_clamp(self) -> bool:
        """Patch malloc clamp — prevent descriptor base overflow past 8MB ceiling."""
        off = MALLOC_CLAMP_OFF
        if off + 4 > len(self.data):
            self.patches_applied.append("malloc_clamp: FAILED (offset beyond EXE)")
            return False

        orig = struct.unpack_from('<I', self.data, off)[0]
        if orig != MALLOC_CLAMP_EXPECTED:
            self.patches_applied.append(
                f"malloc_clamp: FAILED (expected 0x{MALLOC_CLAMP_EXPECTED:08X}, "
                f"got 0x{orig:08X})")
            return False

        stub_file_off = self._append_stub(MALLOC_CLAMP_TRAMP)
        stub_ram = DW7_LOAD_ADDR + stub_file_off - EXE_HEADER_SIZE

        j_word = (0x02 << 26) | ((stub_ram >> 2) & 0x03FFFFFF)
        struct.pack_into('<I', self.data, off, j_word)

        self.patches_applied.append(
            f"malloc_clamp: J 0x{stub_ram:08X} at file 0x{off:X}")
        return True

    def apply_all(self, tree_data: bytes) -> dict:
        """Apply all patches in correct order and return summary.

        Order matters (matches V39 sequence):
          1. tree_refs — patches LUI+ADDIU pairs (must run before Target 4)
          2. bss_clear — narrows BSS range (LUI fixed to 0x800E)
          3. hbd_string — patches filename
          4. hybrid_tree — appends tree at EXE end
          5. runtime_tree_ptrs — writes vars (after tree append, before Target 4)
          6. decomp_target4 — overwrites ADDIU with lw (after tree_refs)
          7. decomp_target6 — NOPs andi mask
          8. disc_check — 10 surgical disc-check bypass patches
          9. lba_references — patch 32-bit LBA refs (354->500)
         10. folder_pointers — remap ABS/REL tables
         11. seq_sector_table — patch 16-bit sector table
         12. pad_to_tramp_base — pad EXE to 0x80101000 (outside BSS clear range)
         13. hbd_type_trampoline — redirect DQ4 block types
         14. malloc_clamp — prevent descriptor base overflow
         15. decomp_target5r — JAL stub for root_id+1
         16. r_treehook — JAL stub for per-block tree update
         17. text_size — update header (after all appends)
         18. pre_tree_bss — zero BSS gap
        """
        results = {}

        results['tree_refs'] = self.patch_tree_references()
        results['bss_clear'] = self.patch_bss_clear()
        results['hbd_string'] = self.patch_hbd_string()
        results['pre_tree_bss'] = self.zero_pre_tree_bss()  # MUST run before tree/ptrs
        results['hybrid_tree'] = self.append_hybrid_tree(tree_data)
        results['runtime_tree_ptrs'] = self.write_runtime_tree_ptrs()
        results['decomp_target4'] = self.patch_decomp_target4()
        results['decomp_target6'] = self.patch_decomp_target6()
        results['disc_check'] = self.patch_disc_check()
        # C4 fix: folder_pointers MUST run before lba_references to avoid double-patching
        results['folder_pointers'] = self.patch_folder_pointers()
        results['lba_references'] = self.patch_lba_references()
        results['seq_sector_table'] = self.patch_sequential_sector_table()
        self._pad_to_ram(TRAMP_BASE_RAM)
        results['hbd_type_trampoline'] = self.patch_hbd_type_trampoline()
        results['malloc_clamp'] = self.patch_malloc_clamp()
        results['decomp_target5r'] = self.patch_decomp_target5r()
        results['r_treehook'] = self.patch_r_treehook()
        results['text_size'] = self.update_text_size()

        return {
            'results': results,
            'patches': self.patches_applied,
            'final_size': len(self.data),
        }


# ── SYSTEM.CNF Generator ────────────────────────────────────────────────────

def generate_system_cnf() -> bytes:
    """Generate SYSTEM.CNF matching DW7 NTSC-U original disc format (CRLF line endings)."""
    content = "BOOT = cdrom:\\SLUSP012.06;1\r\nTCB = 4\r\nEVENT = 16\r\nSTACK = 801ffffc\r\n"
    return content.encode('ascii')


# ── Build Orchestrator ───────────────────────────────────────────────────────

class OrphanBuilder:
    """Orchestrates the full Frankenstein disc build."""

    def __init__(self, output_dir: Path, skip_hash: bool = False):
        self.output_dir = output_dir
        self.skip_hash = skip_hash
        self.build_log = {
            'timestamp': datetime.now().isoformat(),
            'patches': {},
            'hashes': {},
            'errors': [],
        }

    def build(self) -> bool:
        """Execute full build pipeline."""
        print(f"\n{'='*60}")
        print(f"  FRANKENSTEIN ORPHAN DISC BUILDER (mkpsxiso)")
        print(f"  Output: {self.output_dir}")
        print(f"{'='*60}\n")

        # Step 1: Verify inputs
        print("[STEP 1] Input Verification")
        if not self.skip_hash:
            if not verify_frozen_inputs():
                self.build_log['errors'].append("Hash verification failed")
                print("[ABORT] Hash verification failed")
                return False
        else:
            print("  [SKIP] Hash verification skipped")

        # Verify tool existence
        if not MKPSXISO.exists():
            print(f"  [FAIL] mkpsxiso not found: {MKPSXISO}")
            return False
        if not DUMPSXISO.exists():
            print(f"  [FAIL] dumpsxiso not found: {DUMPSXISO}")
            return False

        # Step 2: Prepare build assets
        print("\n[STEP 2] Prepare Build Assets")
        BUILD_ASSETS.mkdir(parents=True, exist_ok=True)

        # Step 3: Patch EXE
        print("\n[STEP 3] Patch DW7 EXE")
        exe_data = bytearray(DW7_EXE_CLEAN.read_bytes())
        print(f"  Loaded clean EXE: {len(exe_data)} bytes")

        tree_data = HYBRID_TREE.read_bytes()
        print(f"  Loaded hybrid tree: {len(tree_data)} bytes")

        patcher = ExePatcher(exe_data)
        patch_result = patcher.apply_all(tree_data)

        for p in patch_result['patches']:
            print(f"  {p}")

        if not all(patch_result['results'].values()):
            failed = [k for k, v in patch_result['results'].items() if not v]
            # pre_tree_bss is deferred to BIOS, not a real failure
            real_failures = [f for f in failed if f != 'pre_tree_bss']
            if real_failures:
                self.build_log['errors'].append(f"Patch failures: {real_failures}")
                print(f"[ABORT] Patch failures: {real_failures}")
                return False

        patched_exe_path = BUILD_ASSETS / "SLUSP012.06"
        patched_exe_path.write_bytes(exe_data)
        print(f"  Written patched EXE: {len(exe_data)} bytes")

        self.build_log['patches'] = patch_result
        self.build_log['hashes']['patched_exe'] = sha256_file(patched_exe_path)

        # Step 4: Generate SYSTEM.CNF
        print("\n[STEP 4] Generate SYSTEM.CNF")
        cnf_path = BUILD_ASSETS / "SYSTEM.CNF"
        cnf_path.write_bytes(generate_system_cnf())
        print(f"  Written: {cnf_path}")

        # Step 5: Re-encode HBD blocks (Approach C) and stage HBD asset
        print("\n[STEP 5] Re-encode HBD Blocks + Stage HBD Asset")
        hbd_dest = BUILD_ASSETS / "HBD1PS1D.Q41"

        # Run re-encoding pass to produce DW7-format HBD
        reencode_script = PROJECT_ROOT / "reencode_dq4_blocks.py"
        if reencode_script.exists():
            print("  Running Approach C re-encoding...")
            result = subprocess.run(
                [sys.executable, str(reencode_script)],
                capture_output=True, text=True, timeout=300,
                cwd=str(PROJECT_ROOT)
            )
            print(result.stdout[-500:] if len(result.stdout) > 500 else result.stdout)
            if result.returncode != 0:
                print(f"  [WARN] Re-encoding exited with code {result.returncode}")
                if result.stderr:
                    print(f"  stderr: {result.stderr[-300:]}")

            # Use re-encoded HBD if it exists, otherwise use original
            reencoded_hbd = PROJECT_ROOT / "translation" / "HBD1PS1D.Q41_dw7fmt.bin"
            if reencoded_hbd.exists():
                shutil.copy2(reencoded_hbd, hbd_dest)
                print(f"  Staged re-encoded HBD: {hbd_dest.stat().st_size} bytes")
            else:
                print("  [WARN] Re-encoded HBD not found, using original DQ4 HBD")
                shutil.copy2(DQ4_HBD, hbd_dest)
                print(f"  Copied original DQ4 HBD: {hbd_dest.stat().st_size} bytes")
        else:
            print("  [WARN] reencode_dq4_blocks.py not found, using original DQ4 HBD")
            shutil.copy2(DQ4_HBD, hbd_dest)
            print(f"  Copied DQ4 HBD: {hbd_dest.stat().st_size} bytes")

        self.build_log['hashes']['hbd'] = sha256_file(hbd_dest)
        self.build_log['hashes']['system_cnf'] = sha256_file(cnf_path)

        # Step 5b: Extract DW7 NTSC-U license sector
        print("\n[STEP 5b] Extract DW7 NTSC-U License")
        dw7_disc = PROJECT_ROOT / "DW7D1" / "DW7D1.bin"
        license_dest = BUILD_ASSETS / "dw7_license.dat"
        if dw7_disc.exists():
            with open(dw7_disc, 'rb') as src, open(license_dest, 'wb') as dst:
                for i in range(12):
                    sector = src.read(2352)
                    dst.write(sector[16:])  # Skip 16-byte sync+header
            print(f"  DW7 license extracted: {license_dest.stat().st_size} bytes")
        else:
            print(f"  [WARN] DW7 disc not found at {dw7_disc}, using existing license")
            if not license_dest.exists():
                print("  [ERROR] No license file available!")
                self.build_log['errors'].append("No license file available")
                return False

        # Step 6: Build disc with mkpsxiso
        print("\n[STEP 6] Build Disc (mkpsxiso)")
        self.output_dir.mkdir(parents=True, exist_ok=True)

        output_bin = self.output_dir / "dq4_frankenstein.bin"
        output_cue = self.output_dir / "dq4_frankenstein.cue"

        cmd = [
            str(MKPSXISO),
            str(XML_PROJECT),
            '-o', str(output_bin),
            '-c', str(output_cue),
            '-y',  # Overwrite
        ]

        print(f"  Command: {' '.join(cmd)}")
        result = subprocess.run(cmd, capture_output=True, text=True, timeout=300)

        print(result.stdout)
        if result.returncode != 0:
            print(f"  [FAIL] mkpsxiso exit code: {result.returncode}")
            print(result.stderr)
            self.build_log['errors'].append(f"mkpsxiso failed: {result.stderr}")
            return False

        if not output_bin.exists():
            self.build_log['errors'].append("Output .bin not created")
            print("[ABORT] Output .bin not created")
            return False

        # Step 7: Verify output
        print("\n[STEP 7] Verify Output")
        bin_hash = sha256_file(output_bin)
        bin_size = output_bin.stat().st_size
        print(f"  Output BIN: {bin_size} bytes, SHA-256: {bin_hash[:32]}...")
        print(f"  Output CUE: {output_cue.exists()}")

        self.build_log['hashes']['output_bin'] = bin_hash
        self.build_log['output_bin_size'] = bin_size
        self.build_log['output_bin_path'] = str(output_bin)
        self.build_log['output_cue_path'] = str(output_cue)

        # Step 8: Write build log
        print("\n[STEP 8] Write Build Log")
        log_path = self.output_dir / "build_log.json"
        log_path.write_text(json.dumps(self.build_log, indent=2), encoding='utf-8')
        print(f"  Written: {log_path}")

        print(f"\n{'='*60}")
        print(f"  BUILD COMPLETE")
        print(f"  Disc: {output_bin}")
        print(f"  CUE:  {output_cue}")
        print(f"  Size: {bin_size:,} bytes")
        print(f"  SHA-256: {bin_hash}")
        print(f"{'='*60}\n")

        return True


# ── CLI ──────────────────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(
        description="Frankenstein Orphan Disc Builder (mkpsxiso Pipeline)")
    parser.add_argument('--output-dir', default=str(DEFAULT_OUTPUT_DIR),
                        help='Output directory for .bin/.cue')
    parser.add_argument('--skip-hash-check', action='store_true',
                        help='Skip SHA-256 hash verification of inputs')

    args = parser.parse_args()

    builder = OrphanBuilder(
        output_dir=Path(args.output_dir),
        skip_hash=args.skip_hash_check,
    )

    success = builder.build()
    sys.exit(0 if success else 1)


if __name__ == '__main__':
    main()
