#ifndef ORPHAN_BUILDER_H
#define ORPHAN_BUILDER_H

#include <cstdint>
#include <string>
#include <vector>
#include <map>
#include <filesystem>
#include <fstream>

namespace fs = std::filesystem;

// ── Paths ───────────────────────────────────────────────────────────────────

static const std::string PROJECT_ROOT = R"(C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION)";
static const std::string PIPELINE_DIR  = PROJECT_ROOT + R"(\frankenstein_pipeline)";

static const std::string DW7_EXE_CLEAN  = PROJECT_ROOT + R"(\translation\SLUSP012.06_clean.bin)";
static const std::string HYBRID_TREE   = PROJECT_ROOT + R"(\dw7_hybrid_tree.bin)";
static const std::string DQ4_HBD       = PIPELINE_DIR + R"(\dq4_extract\HBD1PS1D.Q41)";
static const std::string DQ4_LICENSE   = PIPELINE_DIR + R"(\dq4_extract\license_data.dat)";
static const std::string FROZEN_INPUTS = PROJECT_ROOT + R"(\cybergrime\FROZEN_INPUTS.json)";
static const std::string FOLDER_MAP    = PROJECT_ROOT + R"(\translation\folder_mapping.json)";

static const std::string MKPSXISO      = R"(C:\LuxAura\VoidWalkers_Project\tools\mkpsxiso\build\mkpsxiso.exe)";
static const std::string DUMPSXISO     = R"(C:\LuxAura\VoidWalkers_Project\tools\mkpsxiso\build\dumpsxiso.exe)";

static const std::string BUILD_ASSETS  = PIPELINE_DIR + R"(\build_assets)";
static const std::string XML_PROJECT   = PIPELINE_DIR + R"(\dq4_frankenstein.xml)";
static const std::string DEFAULT_OUTPUT = PIPELINE_DIR + R"(\output)";

// ── EXE Constants ───────────────────────────────────────────────────────────

static const uint32_t EXE_HEADER_SIZE      = 0x800;
static const uint32_t EXE_TEXT_SIZE_OFFSET = 0x1C;
static const uint32_t EXE_PC0_OFFSET       = 0x10;
static const uint32_t EXE_LOAD_ADDR_OFFSET = 0x18;

static const uint32_t DW7_TEXT_SIZE  = 0xA4800;
static const uint32_t DW7_LOAD_ADDR  = 0x80017F00;
static const uint32_t DW7_PC0        = 0x8008E284;

static const uint32_t OLD_TREE_ADDR  = 0x800EF1C8;
static const uint32_t NEW_TREE_ADDR  = 0x800BC700;
static const uint32_t TREE_SIZE      = 1480;

static const uint32_t BSS_CLEAR_START_OLD = 0x800BC668;
static const uint32_t BSS_CLEAR_END_OLD   = 0x800F4980;
static const uint32_t BSS_CLEAR_START_NEW = 0x800BCCC8;
static const uint32_t BSS_CLEAR_END_NEW   = 0x800F4980;  // Match Python: original end

static const uint32_t HBD_LBA     = 500;
static const uint32_t OLD_HBD_LBA = 354;
static const uint32_t LBA_DELTA   = HBD_LBA - OLD_HBD_LBA;

static const uint32_t TRAMP_BASE_RAM    = 0x80101000;
static const uint32_t TRAMP_BASE        = 0x80102000;

// Runtime tree pointer variables
static const uint32_t TREE_PTR_VAR_RAM       = 0x800BC6F8;
static const uint32_t TREE_PTR_VAR_OFF       = 0xA4FF8;
static const uint32_t TREE_PTR_VAR_PLUS2_RAM = 0x800BC6FC;
static const uint32_t TREE_PTR_VAR_PLUS2_OFF = 0xA4FFC;

// Decomp Target 4
static const uint32_t DECOMP_TREE_PTR_SITES[] = { 0x3EBF0, 0x3EC38 };
static const uint32_t LUI_AT_800C   = 0x3C01800C;
static const uint32_t LW_V0_C6F8_AT = 0x8C02C6F8;

// Decomp Target 6
static const uint32_t DECOMP_OFFSET_B_OFF = 0x7CAA4;
static const uint32_t MIPS_NOP            = 0x00000000;

// Decomp Target 5R
static const uint32_t DECOMP_ROOT_ID_OFF = 0x408F4;
static const uint32_t ROOT_ID_STUB_OFF   = 0x200;

// R-TREEHOOK
static const uint32_t TREE_HOOK_OFF      = 0x3F700;
static const uint32_t TREE_HOOK_RAM      = 0x80057600;
static const uint32_t TREE_HOOK_STUB_OFF = 0x300;

// Folder pointer remap
static const uint32_t ABS_TABLE_START   = 0x4184;
static const uint32_t REL_TABLE_START   = 0x511C;
static const uint32_t TABLE_ENTRY_SIZE  = 8;
static const uint32_t MAX_TABLE_ENTRIES = 6000;

// Sequential sector table
static const uint32_t SEQ_TABLE_START = 0xA39AA;
static const uint32_t SEQ_TABLE_END   = 0xA3A02;

// HBD type trampoline
static const uint32_t HBD_TYPE_TRAMP_HOOK_OFF  = 0x3EBE4;
static const uint32_t HBD_TYPE_TRAMP_EXPECTED  = 0x1260000D;

// Malloc clamp
static const uint32_t MALLOC_CLAMP_OFF       = 0x63674;
static const uint32_t MALLOC_CLAMP_EXPECTED  = 0xAC662228;

// ── Helper Functions ────────────────────────────────────────────────────────

static inline uint32_t read_le32(const uint8_t* p) {
    return (uint32_t)p[0] | ((uint32_t)p[1] << 8) |
           ((uint32_t)p[2] << 16) | ((uint32_t)p[3] << 24);
}

static inline void write_le32(uint8_t* p, uint32_t v) {
    p[0] = v & 0xFF; p[1] = (v >> 8) & 0xFF;
    p[2] = (v >> 16) & 0xFF; p[3] = (v >> 24) & 0xFF;
}

static inline uint16_t read_le16(const uint8_t* p) {
    return (uint16_t)p[0] | ((uint16_t)p[1] << 8);
}

static inline void write_le16(uint8_t* p, uint16_t v) {
    p[0] = v & 0xFF; p[1] = (v >> 8) & 0xFF;
}

static inline uint32_t jal_target(uint32_t ram_addr) {
    return (0x03 << 26) | ((ram_addr >> 2) & 0x03FFFFFF);
}

static inline uint32_t j_target(uint32_t ram_addr) {
    return (0x02 << 26) | ((ram_addr >> 2) & 0x03FFFFFF);
}

// ── ExePatcher ──────────────────────────────────────────────────────────────

class ExePatcher {
public:
    explicit ExePatcher(std::vector<uint8_t>& exe_data);

    // All 19 patch methods (in apply order)
    int  patch_tree_references();
    bool patch_bss_clear();
    bool patch_hbd_string();
    bool append_hybrid_tree(const std::vector<uint8_t>& tree_data);
    bool write_runtime_tree_ptrs();
    bool patch_decomp_target4();
    bool patch_decomp_target6();
    bool patch_disc_check();
    bool patch_lba_references();
    bool patch_folder_pointers();
    bool patch_sequential_sector_table();
    void pad_to_ram(uint32_t target_ram);
    bool patch_hbd_type_trampoline();
    bool patch_malloc_clamp();
    bool patch_decomp_target5r();
    bool patch_r_treehook();
    bool update_text_size();
    bool zero_pre_tree_bss();

    // Apply all patches in order
    struct PatchResults {
        int  tree_refs;
        bool bss_clear;
        bool hbd_string;
        bool hybrid_tree;
        bool runtime_tree_ptrs;
        bool decomp_target4;
        bool decomp_target6;
        bool disc_check;
        bool lba_references;
        bool folder_pointers;
        bool seq_sector_table;
        bool hbd_type_trampoline;
        bool malloc_clamp;
        bool decomp_target5r;
        bool r_treehook;
        bool text_size;
        bool pre_tree_bss;
    };

    PatchResults apply_all(const std::vector<uint8_t>& tree_data);

    std::vector<std::string> patches_applied;
    std::vector<uint8_t>& data;

private:
    uint32_t append_stub(const std::vector<uint32_t>& stub_words);
};

// ── OrphanBuilder ───────────────────────────────────────────────────────────

class OrphanBuilder {
public:
    OrphanBuilder(const std::string& output_dir, bool skip_hash);

    bool build();

private:
    std::string output_dir;
    bool skip_hash;

    std::string sha256_file(const std::string& path);
    bool verify_frozen_inputs();
    bool generate_system_cnf(const std::string& path);
    bool run_mkpsxiso(const std::string& xml_path,
                      const std::string& bin_path,
                      const std::string& cue_path);
};

#endif // ORPHAN_BUILDER_H
