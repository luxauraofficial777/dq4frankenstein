#include "orphan_builder.h"
#include <algorithm>
#include <cstdio>
#include <cstring>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <chrono>
#include <ctime>

// ── ExePatcher ──────────────────────────────────────────────────────────────

ExePatcher::ExePatcher(std::vector<uint8_t>& exe_data)
    : data(exe_data) {}

uint32_t ExePatcher::append_stub(const std::vector<uint32_t>& stub_words) {
    uint32_t offset = (uint32_t)data.size();
    for (uint32_t w : stub_words) {
        data.push_back(w & 0xFF);
        data.push_back((w >> 8) & 0xFF);
        data.push_back((w >> 16) & 0xFF);
        data.push_back((w >> 24) & 0xFF);
    }
    return offset;
}

void ExePatcher::pad_to_ram(uint32_t target_ram) {
    uint32_t target_off = target_ram - DW7_LOAD_ADDR + EXE_HEADER_SIZE;
    if (target_off > data.size()) {
        data.resize(target_off, 0x00);
    }
}

// Patch 1: Tree references (23 LUI+ADDIU pairs)
int ExePatcher::patch_tree_references() {
    int count = 0;
    for (size_t i = 0; i + 7 < data.size(); i += 4) {
        uint32_t w0 = read_le32(&data[i]);
        uint32_t w1 = read_le32(&data[i + 4]);

        if ((w0 >> 26) == 0x0F && ((w0 >> 16) & 0x1F) == 0x02 && (w0 & 0xFFFF) == 0x800F &&
            (w1 >> 26) == 0x09 && ((w1 >> 21) & 0x1F) == 0x02 && (w1 & 0xFFFF) == 0xF1C8) {
            write_le32(&data[i], (w0 & 0xFFFF0000) | 0x800C);
            write_le32(&data[i + 4], (w1 & 0xFFFF0000) | 0xC700);
            count++;
        }
    }
    patches_applied.push_back("tree_refs: " + std::to_string(count) + " pairs patched");
    return count;
}

// Patch 2: BSS clear range
bool ExePatcher::patch_bss_clear() {
    bool found_start = false, found_end = false;

    for (size_t i = 0; i + 7 < data.size(); i += 4) {
        uint32_t w0 = read_le32(&data[i]);
        uint32_t w1 = read_le32(&data[i + 4]);

        if ((w0 >> 26) == 0x0F && ((w0 >> 16) & 0x1F) == 0x02 && (w0 & 0xFFFF) == 0x800C &&
            (w1 >> 26) == 0x09 && ((w1 >> 21) & 0x1F) == 0x02 && ((w1 >> 16) & 0x1F) == 0x02 &&
            (w1 & 0xFFFF) == 0xC668) {
            write_le32(&data[i + 4], (w1 & 0xFFFF0000) | 0xCCC8);
            found_start = true;
        }

        if ((w0 >> 26) == 0x0F && ((w0 >> 16) & 0x1F) == 0x03 && (w0 & 0xFFFF) == 0x800F &&
            (w1 >> 26) == 0x09 && ((w1 >> 21) & 0x1F) == 0x03 && ((w1 >> 16) & 0x1F) == 0x03 &&
            (w1 & 0xFFFF) == 0x4980) {
            write_le32(&data[i], (w0 & 0xFFFF0000) | 0x800E);
            write_le32(&data[i + 4], (w1 & 0xFFFF0000) | 0x9E80);
            found_end = true;
        }
    }

    char buf[128];
    if (found_start && found_end) {
        snprintf(buf, sizeof(buf), "bss_clear: narrowed to 0x%08X-0x%08X",
                 BSS_CLEAR_START_NEW, BSS_CLEAR_END_NEW);
    } else {
        snprintf(buf, sizeof(buf), "bss_clear: FAILED (start=%d, end=%d)",
                 found_start, found_end);
    }
    patches_applied.push_back(buf);
    return found_start && found_end;
}

// Patch 3: HBD string
bool ExePatcher::patch_hbd_string() {
    const uint8_t old_str[] = {'h','b','d','1','p','s','1','d','.','w','7','1'};
    auto it = std::search(data.begin(), data.end(), old_str, old_str + 12);
    if (it == data.end()) {
        patches_applied.push_back("hbd_string: NOT FOUND");
        return false;
    }
    size_t idx = it - data.begin();
    const uint8_t new_str[] = {'q','4','1',0,0,0,0,0,0,0,0,0};
    memcpy(&data[idx], new_str, 12);
    char buf[64];
    snprintf(buf, sizeof(buf), "hbd_string: patched at offset 0x%zX", idx);
    patches_applied.push_back(buf);
    return true;
}

// Patch 4: Append hybrid tree
bool ExePatcher::append_hybrid_tree(const std::vector<uint8_t>& tree_data) {
    uint32_t tree_offset = EXE_HEADER_SIZE + DW7_TEXT_SIZE;
    if (data.size() < tree_offset) {
        data.resize(tree_offset, 0x00);
    }
    data.resize(tree_offset + tree_data.size());
    memcpy(&data[tree_offset], tree_data.data(), tree_data.size());

    uint32_t end = tree_offset + (uint32_t)tree_data.size();
    uint32_t padded_end = (end + 2047) & ~2047;
    if (padded_end > end) {
        data.resize(padded_end, 0x00);
    }
    char buf[80];
    snprintf(buf, sizeof(buf), "hybrid_tree: %zu bytes at file offset 0x%X",
             tree_data.size(), tree_offset);
    patches_applied.push_back(buf);
    return true;
}

// Patch 5: Runtime tree pointers
bool ExePatcher::write_runtime_tree_ptrs() {
    if (TREE_PTR_VAR_OFF + 4 > data.size()) {
        patches_applied.push_back("runtime_tree_ptrs: FAILED (offset beyond EXE)");
        return false;
    }
    write_le32(&data[TREE_PTR_VAR_OFF], NEW_TREE_ADDR);
    if (TREE_PTR_VAR_PLUS2_OFF + 4 > data.size()) {
        patches_applied.push_back("runtime_tree_ptrs: FAILED (+2 offset beyond EXE)");
        return false;
    }
    write_le32(&data[TREE_PTR_VAR_PLUS2_OFF], NEW_TREE_ADDR + 2);
    char buf[128];
    snprintf(buf, sizeof(buf), "runtime_tree_ptrs: 0x%08X=0x%08X, 0x%08X=0x%08X",
             TREE_PTR_VAR_RAM, NEW_TREE_ADDR, TREE_PTR_VAR_PLUS2_RAM, NEW_TREE_ADDR + 2);
    patches_applied.push_back(buf);
    return true;
}

// Patch 6: Decomp Target 4
bool ExePatcher::patch_decomp_target4() {
    const uint32_t expected_addiu = 0x2442C700;
    int count = 0;
    for (uint32_t site_off : DECOMP_TREE_PTR_SITES) {
        if (site_off + 4 > data.size()) continue;
        uint32_t current = read_le32(&data[site_off]);
        if (current == expected_addiu) {
            write_le32(&data[site_off - 4], LUI_AT_800C);
            write_le32(&data[site_off], LW_V0_C6F8_AT);
            count++;
        }
    }
    if (count > 0) {
        patches_applied.push_back("decomp_target4: " + std::to_string(count) +
                                  " sites patched (tree->runtime var)");
    } else {
        patches_applied.push_back("decomp_target4: FAILED (no sites matched)");
    }
    return count > 0;
}

// Patch 7: Decomp Target 6
bool ExePatcher::patch_decomp_target6() {
    if (DECOMP_OFFSET_B_OFF + 4 > data.size()) {
        patches_applied.push_back("decomp_target6: FAILED (offset beyond EXE)");
        return false;
    }
    uint32_t current = read_le32(&data[DECOMP_OFFSET_B_OFF]);
    const uint32_t expected = 0x3042FFFE;
    if (current == expected) {
        write_le32(&data[DECOMP_OFFSET_B_OFF], MIPS_NOP);
        patches_applied.push_back("decomp_target6: NOP'd andi 0xFFFE at 0x7CAA4");
        return true;
    }
    if (current == MIPS_NOP) {
        patches_applied.push_back("decomp_target6: already NOP'd");
        return true;
    }
    char buf[80];
    snprintf(buf, sizeof(buf), "decomp_target6: FAILED (expected 0x%08X, got 0x%08X)",
             expected, current);
    patches_applied.push_back(buf);
    return false;
}

// Patch 8: Disc-check bypass (8 surgical patches + neutralize disc change)
bool ExePatcher::patch_disc_check() {
    struct DiscPatch { uint32_t offset; uint32_t value; const char* desc; };
    DiscPatch patches[] = {
        {0x6112C, 0x24020001, "li $v0, 1 (return success)"},
        {0x611D8, 0x24020001, "li $v0, 1"},
        {0x613B8, 0x24020001, "li $v0, 1"},
        {0x614A4, 0x00000000, "nop (timeout check)"},
        {0x614F8, 0x00000000, "nop (error path)"},
        {0x61424, 0x1000000B, "beq $zero,$zero,+11 (always skip)"},
        {0x6151C, 0x1000000B, "beq $zero,$zero,+11 (skip disc check call)"},
        {0x61360, 0x1000000A, "beq $zero,$zero,+10"},
    };

    int count = 0;
    for (const auto& p : patches) {
        if (p.offset + 4 > data.size()) {
            patches_applied.push_back(std::string("disc_check: FAILED (offset 0x") +
                std::to_string(p.offset) + " beyond EXE)");
            continue;
        }
        write_le32(&data[p.offset], p.value);
        count++;
    }

    // Neutralize disc-change handler at 0x387CC: jr $ra; nop; nop
    const uint32_t NEUTRALIZE_OFF = 0x387CC;
    if (NEUTRALIZE_OFF + 12 <= data.size()) {
        write_le32(&data[NEUTRALIZE_OFF], 0x03E00008);     // jr $ra
        write_le32(&data[NEUTRALIZE_OFF + 4], 0x00000000); // nop
        write_le32(&data[NEUTRALIZE_OFF + 8], 0x00000000); // nop
        count++;
    }

    char buf[80];
    snprintf(buf, sizeof(buf), "disc_check: %d patches applied", count);
    patches_applied.push_back(buf);
    return count > 0;
}

// Patch 9: LBA references
bool ExePatcher::patch_lba_references() {
    int count = 0;
    for (size_t i = 0x800; i + 3 < data.size(); i += 4) {
        uint32_t val = read_le32(&data[i]);
        if (val == OLD_HBD_LBA) {
            write_le32(&data[i], HBD_LBA);
            count++;
        }
    }
    char buf[80];
    snprintf(buf, sizeof(buf), "lba_references: %d refs patched (%d->%d)",
             count, OLD_HBD_LBA, HBD_LBA);
    patches_applied.push_back(buf);
    return true;
}

// Patch 10: Folder pointer remap
bool ExePatcher::patch_folder_pointers() {
    if (!fs::exists(FOLDER_MAP)) {
        patches_applied.push_back("folder_pointers: SKIPPED (no folder_mapping.json)");
        return true;
    }

    // Minimal JSON parse for folder_mapping.json
    // Format: {"mappings": [{"dw7_sector": N, "dq4_sector": M}, ...]}
    std::map<uint32_t, uint32_t> dw7_to_dq4;
    std::ifstream f(FOLDER_MAP);
    std::string content((std::istreambuf_iterator<char>(f)),
                         std::istreambuf_iterator<char>());
    // Simple regex-like parsing
    size_t pos = 0;
    while (pos < content.size()) {
        size_t dw7_pos = content.find("\"dw7_sector\"", pos);
        if (dw7_pos == std::string::npos) break;
        size_t colon = content.find(':', dw7_pos);
        size_t dq4_pos = content.find("\"dq4_sector\"", colon);
        if (dq4_pos == std::string::npos) break;
        size_t colon2 = content.find(':', dq4_pos);
        size_t end1 = content.find_first_of(",}", colon);
        size_t end2 = content.find_first_of(",}", colon2);
        uint32_t dw7_sec = std::stoul(content.substr(colon + 1, end1 - colon - 1));
        uint32_t dq4_sec = std::stoul(content.substr(colon2 + 1, end2 - colon2 - 1));
        dw7_to_dq4[dw7_sec] = dq4_sec;
        pos = end2;
    }

    int abs_matched = 0, abs_delta = 0, rel_matched = 0;
    for (uint32_t i = 0; i < MAX_TABLE_ENTRIES; i++) {
        uint32_t off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE;
        if (off + 4 > data.size()) break;
        uint32_t val = read_le32(&data[off]);
        if (val == 0) continue;
        auto it = dw7_to_dq4.find(val);
        if (it != dw7_to_dq4.end()) {
            write_le32(&data[off], it->second + HBD_LBA);
            abs_matched++;
        } else if (val >= OLD_HBD_LBA && val < 0x100000) {
            write_le32(&data[off], val + LBA_DELTA);
            abs_delta++;
        }
    }

    for (uint32_t i = 0; i < MAX_TABLE_ENTRIES; i++) {
        uint32_t off = REL_TABLE_START + i * TABLE_ENTRY_SIZE;
        if (off + 4 > data.size()) break;
        uint32_t val = read_le32(&data[off]);
        if (val == 0) continue;
        for (auto& kv : dw7_to_dq4) {
            if (kv.first - OLD_HBD_LBA == val) {
                write_le32(&data[off], kv.second);
                rel_matched++;
                break;
            }
        }
    }

    char buf[128];
    snprintf(buf, sizeof(buf), "folder_pointers: abs_matched=%d, abs_delta=%d, rel_matched=%d",
             abs_matched, abs_delta, rel_matched);
    patches_applied.push_back(buf);
    return true;
}

// Patch 11: Sequential sector table
bool ExePatcher::patch_sequential_sector_table() {
    int count = 0;
    uint32_t end = std::min(SEQ_TABLE_END, (uint32_t)data.size() - 1);
    for (uint32_t i = SEQ_TABLE_START; i < end; i += 2) {
        uint16_t val = read_le16(&data[i]);
        if (val >= 300 && val <= 400) {
            write_le16(&data[i], (val + LBA_DELTA) & 0xFFFF);
            count++;
        }
    }
    patches_applied.push_back("seq_sector_table: " + std::to_string(count) + " entries patched");
    return true;
}

// Patch 12: HBD type trampoline
bool ExePatcher::patch_hbd_type_trampoline() {
    uint32_t off = HBD_TYPE_TRAMP_HOOK_OFF;
    if (off + 8 > data.size()) {
        patches_applied.push_back("hbd_type_trampoline: FAILED (hook offset beyond EXE)");
        return false;
    }
    uint32_t orig = read_le32(&data[off]);
    if (orig != HBD_TYPE_TRAMP_EXPECTED) {
        char buf[100];
        snprintf(buf, sizeof(buf),
                 "hbd_type_trampoline: WARNING (expected 0x%08X, got 0x%08X) — patching anyway",
                 HBD_TYPE_TRAMP_EXPECTED, orig);
        patches_applied.push_back(buf);
    }

    std::vector<uint32_t> tramp_code = {
        0x240A0027, 0x126A0014, 0x00000000, 0x240A0028, 0x126A0011, 0x00000000,
        0x240A002A, 0x126A000E, 0x00000000, 0x240A002E, 0x126A000B, 0x00000000,
        0x240A0020, 0x126A0008, 0x00000000, 0xA4430538, 0x00009821, 0x00000000,
        0x080158C7, 0x00000000, 0x080158D9, 0x00000000, 0x00009821, 0x00001821,
        0xA4400538, 0x080158C7, 0x00000000,
    };

    uint32_t stub_off = append_stub(tramp_code);
    uint32_t stub_ram = DW7_LOAD_ADDR + stub_off - EXE_HEADER_SIZE;
    write_le32(&data[off], jal_target(stub_ram));
    write_le32(&data[off + 4], MIPS_NOP);

    char buf[80];
    snprintf(buf, sizeof(buf), "hbd_type_trampoline: JAL 0x%08X at file 0x%X", stub_ram, off);
    patches_applied.push_back(buf);
    return true;
}

// Patch 13: Malloc clamp
bool ExePatcher::patch_malloc_clamp() {
    uint32_t off = MALLOC_CLAMP_OFF;
    if (off + 4 > data.size()) {
        patches_applied.push_back("malloc_clamp: FAILED (offset beyond EXE)");
        return false;
    }
    uint32_t orig = read_le32(&data[off]);
    if (orig != MALLOC_CLAMP_EXPECTED) {
        char buf[100];
        snprintf(buf, sizeof(buf), "malloc_clamp: FAILED (expected 0x%08X, got 0x%08X)",
                 MALLOC_CLAMP_EXPECTED, orig);
        patches_applied.push_back(buf);
        return false;
    }

    std::vector<uint32_t> tramp = {
        0x3C088080, 0x0106402B, 0x11000002, 0x00000000,
        0x3C068010, 0xAC662228, 0x24632228, 0x0801EB5F, 0x00000000,
    };

    uint32_t stub_off = append_stub(tramp);
    uint32_t stub_ram = DW7_LOAD_ADDR + stub_off - EXE_HEADER_SIZE;
    write_le32(&data[off], j_target(stub_ram));

    char buf[80];
    snprintf(buf, sizeof(buf), "malloc_clamp: J 0x%08X at file 0x%X", stub_ram, off);
    patches_applied.push_back(buf);
    return true;
}

// Patch 14: Decomp Target 5R
bool ExePatcher::patch_decomp_target5r() {
    std::vector<uint32_t> stub = {
        0x3C01800C,  // lui $at, 0x800C
        0x8C23C6FC,  // lw $v1, 0xC6FC($at)
        0x23FF0004,  // addiu $ra, $ra, 4
        0x03E00008,  // jr $ra
        0x00000000,  // nop
    };

    uint32_t stub_off = append_stub(stub);
    uint32_t stub_ram = DW7_LOAD_ADDR + stub_off - EXE_HEADER_SIZE;
    uint32_t jal_word = jal_target(stub_ram);

    uint32_t lui_off = DECOMP_ROOT_ID_OFF - 8;
    if (lui_off + 4 > data.size()) {
        patches_applied.push_back("decomp_target5r: FAILED (offset beyond EXE)");
        return false;
    }
    uint32_t lui_word = read_le32(&data[lui_off]);
    if ((lui_word >> 26) == 0x0F && ((lui_word >> 16) & 0x1F) == 0x03 &&
        (lui_word & 0xFFFF) == 0x800F) {
        write_le32(&data[lui_off], jal_word);
        write_le32(&data[lui_off + 4], MIPS_NOP);
        char buf[128];
        snprintf(buf, sizeof(buf),
                 "decomp_target5r: JAL 0x%08X at file 0x%X (RAM 0x%08X), stub at 0x%08X",
                 stub_ram, lui_off, DW7_LOAD_ADDR + lui_off - EXE_HEADER_SIZE, stub_ram);
        patches_applied.push_back(buf);
        return true;
    }
    char buf[128];
    snprintf(buf, sizeof(buf),
             "decomp_target5r: FAILED (LUI at 0x%X = 0x%08X, expected lui $v1, 0x800F)",
             lui_off, lui_word);
    patches_applied.push_back(buf);
    return false;
}

// Patch 15: R-TREEHOOK
bool ExePatcher::patch_r_treehook() {
    std::vector<uint32_t> stub = {
        0x8C63000C,  // lw $v1, 0x0C($a0)
        0x00851821,  // addu $v1, $v1, $a0
        0x3C01800C,  // lui $at, 0x800C
        0xAC23C6F8,  // sw $v1, 0xC6F8($at)
        0x03E00008,  // jr $ra
        0x00000000,  // nop
    };

    uint32_t stub_off = append_stub(stub);
    uint32_t stub_ram = DW7_LOAD_ADDR + stub_off - EXE_HEADER_SIZE;
    uint32_t jal_word = jal_target(stub_ram);

    if (TREE_HOOK_OFF + 4 > data.size()) {
        patches_applied.push_back("r_treehook: FAILED (hook point beyond EXE)");
        return false;
    }
    write_le32(&data[TREE_HOOK_OFF], jal_word);
    char buf[128];
    snprintf(buf, sizeof(buf),
             "r_treehook: JAL 0x%08X at file 0x%X (RAM 0x%08X), stub at 0x%08X",
             stub_ram, TREE_HOOK_OFF, TREE_HOOK_RAM, stub_ram);
    patches_applied.push_back(buf);
    return true;
}

// Patch 16: Text size update — must cover entire file including all appended stubs
bool ExePatcher::update_text_size() {
    uint32_t actual_size = (uint32_t)data.size() - EXE_HEADER_SIZE;
    uint32_t padded = (actual_size + 2047) & ~2047;
    write_le32(&data[EXE_TEXT_SIZE_OFFSET], padded);
    char buf[64];
    snprintf(buf, sizeof(buf), "text_size: 0x%X -> 0x%X (file=%zu)", DW7_TEXT_SIZE, padded, data.size());
    patches_applied.push_back(buf);
    return true;
}

// Patch 17: Pre-tree BSS zero
bool ExePatcher::zero_pre_tree_bss() {
    uint32_t start_off = BSS_CLEAR_START_OLD - DW7_LOAD_ADDR + EXE_HEADER_SIZE;
    uint32_t end_off = NEW_TREE_ADDR - DW7_LOAD_ADDR + EXE_HEADER_SIZE;
    if (end_off <= data.size()) {
        memset(&data[start_off], 0, end_off - start_off);
        char buf[100];
        snprintf(buf, sizeof(buf), "pre_tree_bss: zeroed 0x%08X-0x%08X (%u bytes)",
                 BSS_CLEAR_START_OLD, NEW_TREE_ADDR, end_off - start_off);
        patches_applied.push_back(buf);
    } else {
        patches_applied.push_back("pre_tree_bss: deferred to BIOS (offset beyond EXE)");
    }
    return true;
}

// Apply all patches in correct order (matches Python build_orphan.py)
ExePatcher::PatchResults ExePatcher::apply_all(const std::vector<uint8_t>& tree_data) {
    PatchResults r{};
    r.tree_refs            = patch_tree_references();
    r.bss_clear            = patch_bss_clear();
    r.hbd_string           = patch_hbd_string();
    r.pre_tree_bss         = zero_pre_tree_bss();  // C1 FIX: MUST run before tree/ptrs
    r.hybrid_tree          = append_hybrid_tree(tree_data);
    r.runtime_tree_ptrs    = write_runtime_tree_ptrs();
    r.decomp_target4       = patch_decomp_target4();
    r.decomp_target6       = patch_decomp_target6();
    r.disc_check           = patch_disc_check();
    r.folder_pointers      = patch_folder_pointers();  // C4 FIX: before LBA
    r.lba_references       = patch_lba_references();   // C4 FIX: after folder
    r.seq_sector_table     = patch_sequential_sector_table();
    pad_to_ram(TRAMP_BASE_RAM);
    r.hbd_type_trampoline  = patch_hbd_type_trampoline();
    r.malloc_clamp         = patch_malloc_clamp();
    r.decomp_target5r      = patch_decomp_target5r();
    r.r_treehook           = patch_r_treehook();
    r.text_size            = update_text_size();
    return r;
}

// ── OrphanBuilder ───────────────────────────────────────────────────────────

OrphanBuilder::OrphanBuilder(const std::string& out_dir, bool skip)
    : output_dir(out_dir), skip_hash(skip) {}

std::string OrphanBuilder::sha256_file(const std::string& path) {
    std::string cmd = "certutil -hashfile \"" + path + "\" SHA256 2>nul";
    FILE* pipe = _popen(cmd.c_str(), "r");
    if (!pipe) return "";
    char buffer[512];
    std::string result;
    while (fgets(buffer, sizeof(buffer), pipe)) {
        result += buffer;
    }
    _pclose(pipe);
    // Parse: "SHA256 hash of file: <path>:\n<hash>\n"
    size_t pos = result.find("\n");
    if (pos == std::string::npos) return "";
    pos = result.find_first_not_of(" \t", pos + 1);
    if (pos == std::string::npos) return "";
    size_t end = result.find("\n", pos);
    if (end == std::string::npos) end = result.size();
    std::string hash = result.substr(pos, end - pos);
    // Remove spaces
    hash.erase(std::remove(hash.begin(), hash.end(), ' '), hash.end());
    // Uppercase
    std::transform(hash.begin(), hash.end(), hash.begin(), ::toupper);
    return hash;
}

bool OrphanBuilder::verify_frozen_inputs() {
    if (!fs::exists(FROZEN_INPUTS)) {
        printf("  [WARN] FROZEN_INPUTS.json not found, skipping hash verification\n");
        return true;
    }
    // Minimal: just check files exist. Full JSON hash verification would require
    // a JSON parser. For C++ port, we rely on file existence + size checks.
    const char* inputs[] = {
        DW7_EXE_CLEAN.c_str(),
        HYBRID_TREE.c_str(),
        DQ4_HBD.c_str(),
        DQ4_LICENSE.c_str(),
    };
    for (const char* path : inputs) {
        if (!fs::exists(path)) {
            printf("  [FAIL] Input not found: %s\n", path);
            return false;
        }
        printf("  [OK]   %s (%lld bytes)\n", path, (long long)fs::file_size(path));
    }
    return true;
}

bool OrphanBuilder::generate_system_cnf(const std::string& path) {
    FILE* f = fopen(path.c_str(), "wb");
    if (!f) return false;
    fprintf(f, "BOOT = cdrom:\\SLUSP012.06;1\nTCB = 4\nEVENT = 16\nSTACK = 801ffffc\n");
    fclose(f);
    return true;
}

bool OrphanBuilder::run_mkpsxiso(const std::string& xml_path,
                                  const std::string& bin_path,
                                  const std::string& cue_path) {
    // Use cmd /c wrapper — system() on Windows has issues with long quoted paths
    std::string cmd = "cmd /c \"\"";
    cmd += MKPSXISO;
    cmd += "\" \"";
    cmd += xml_path;
    cmd += "\" -o \"";
    cmd += bin_path;
    cmd += "\" -c \"";
    cmd += cue_path;
    cmd += "\" -y\"";
    printf("  Command: %s\n", cmd.c_str());
    int ec = system(cmd.c_str());
    return (ec == 0);
}

bool OrphanBuilder::build() {
    printf("\n============================================================\n");
    printf("  FRANKENSTEIN ORPHAN DISC BUILDER (C++ / mkpsxiso)\n");
    printf("  Output: %s\n", output_dir.c_str());
    printf("============================================================\n\n");

    // Step 1: Verify inputs
    printf("[STEP 1] Input Verification\n");
    if (!skip_hash) {
        if (!verify_frozen_inputs()) {
            printf("[ABORT] Input verification failed\n");
            return false;
        }
    } else {
        printf("  [SKIP] Hash verification skipped\n");
    }
    if (!fs::exists(MKPSXISO)) {
        printf("  [FAIL] mkpsxiso not found: %s\n", MKPSXISO.c_str());
        return false;
    }

    // Step 2: Prepare build assets
    printf("\n[STEP 2] Prepare Build Assets\n");
    fs::create_directories(BUILD_ASSETS);

    // Step 3: Patch EXE
    printf("\n[STEP 3] Patch DW7 EXE\n");
    std::ifstream exe_file(DW7_EXE_CLEAN, std::ios::binary);
    if (!exe_file) {
        printf("[ABORT] Cannot open clean EXE: %s\n", DW7_EXE_CLEAN.c_str());
        return false;
    }
    std::vector<uint8_t> exe_data((std::istreambuf_iterator<char>(exe_file)),
                                   std::istreambuf_iterator<char>());
    exe_file.close();
    printf("  Loaded clean EXE: %zu bytes\n", exe_data.size());

    std::ifstream tree_file(HYBRID_TREE, std::ios::binary);
    if (!tree_file) {
        printf("[ABORT] Cannot open hybrid tree: %s\n", HYBRID_TREE.c_str());
        return false;
    }
    std::vector<uint8_t> tree_data((std::istreambuf_iterator<char>(tree_file)),
                                    std::istreambuf_iterator<char>());
    tree_file.close();
    printf("  Loaded hybrid tree: %zu bytes\n", tree_data.size());

    ExePatcher patcher(exe_data);
    auto results = patcher.apply_all(tree_data);

    for (const auto& p : patcher.patches_applied) {
        printf("  %s\n", p.c_str());
    }

    // Check for failures
    bool all_ok = results.bss_clear && results.hbd_string && results.hybrid_tree &&
                  results.runtime_tree_ptrs && results.decomp_target4 &&
                  results.decomp_target6 && results.disc_check &&
                  results.lba_references && results.folder_pointers &&
                  results.seq_sector_table && results.hbd_type_trampoline &&
                  results.malloc_clamp && results.decomp_target5r &&
                  results.r_treehook && results.text_size;
    if (!all_ok) {
        printf("[ABORT] One or more patches failed\n");
        return false;
    }

    // Write patched EXE
    std::string patched_exe = BUILD_ASSETS + "\\SLUSP012.06";
    std::ofstream out_exe(patched_exe, std::ios::binary);
    out_exe.write((const char*)exe_data.data(), exe_data.size());
    out_exe.close();
    printf("  Written patched EXE: %zu bytes\n", exe_data.size());

    // Step 4: Generate SYSTEM.CNF
    printf("\n[STEP 4] Generate SYSTEM.CNF\n");
    std::string cnf_path = BUILD_ASSETS + "\\SYSTEM.CNF";
    generate_system_cnf(cnf_path);
    printf("  Written: %s\n", cnf_path.c_str());

    // Step 5: Copy HBD asset
    printf("\n[STEP 5] Stage HBD Asset\n");
    std::string hbd_dest = BUILD_ASSETS + "\\HBD1PS1D.Q41";
    if (fs::exists(DQ4_HBD)) {
        fs::copy_file(DQ4_HBD, hbd_dest, fs::copy_options::overwrite_existing);
        printf("  Copied DQ4 HBD: %lld bytes\n", (long long)fs::file_size(hbd_dest));
    } else {
        printf("[ABORT] HBD not found: %s\n", DQ4_HBD.c_str());
        return false;
    }

    // Step 6: Build disc with mkpsxiso
    printf("\n[STEP 6] Build Disc (mkpsxiso)\n");
    fs::create_directories(output_dir);
    std::string output_bin = output_dir + "\\dq4_frankenstein.bin";
    std::string output_cue = output_dir + "\\dq4_frankenstein.cue";

    if (!run_mkpsxiso(XML_PROJECT, output_bin, output_cue)) {
        printf("  [FAIL] mkpsxiso failed\n");
        return false;
    }
    if (!fs::exists(output_bin)) {
        printf("[ABORT] Output .bin not created\n");
        return false;
    }

    // Step 7: Verify output
    printf("\n[STEP 7] Verify Output\n");
    uintmax_t bin_size = fs::file_size(output_bin);
    std::string bin_hash = sha256_file(output_bin);
    printf("  Output BIN: %lld bytes, SHA-256: %.32s...\n",
           (long long)bin_size, bin_hash.c_str());
    printf("  Output CUE: %s\n", fs::exists(output_cue) ? "exists" : "MISSING");

    // Step 8: Write build log
    printf("\n[STEP 8] Write Build Log\n");
    std::string log_path = output_dir + "\\build_log_cpp.txt";
    FILE* log = fopen(log_path.c_str(), "w");
    if (log) {
        auto now = std::chrono::system_clock::now();
        auto t = std::chrono::system_clock::to_time_t(now);
        fprintf(log, "Build Log — Frankenstein Orphan Disc Builder (C++)\n");
        fprintf(log, "Timestamp: %s", std::ctime(&t));
        fprintf(log, "Output BIN: %s (%lld bytes)\n", output_bin.c_str(), (long long)bin_size);
        fprintf(log, "Output CUE: %s\n", output_cue.c_str());
        fprintf(log, "SHA-256: %s\n", bin_hash.c_str());
        fprintf(log, "\nPatches Applied:\n");
        for (const auto& p : patcher.patches_applied) {
            fprintf(log, "  %s\n", p.c_str());
        }
        fclose(log);
        printf("  Written: %s\n", log_path.c_str());
    }

    printf("\n============================================================\n");
    printf("  BUILD COMPLETE\n");
    printf("  Disc: %s\n", output_bin.c_str());
    printf("  CUE:  %s\n", output_cue.c_str());
    printf("  Size: %lld bytes\n", (long long)bin_size);
    printf("  SHA-256: %s\n", bin_hash.c_str());
    printf("============================================================\n\n");

    return true;
}
