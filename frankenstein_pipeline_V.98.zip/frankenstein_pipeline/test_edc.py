#!/usr/bin/env python3
"""Verify EDC computation against known-good sectors."""

import struct

def build_edc_table():
    table = []
    for i in range(256):
        crc = i
        for _ in range(8):
            if crc & 1:
                crc = (crc >> 1) ^ 0xD8018001
            else:
                crc >>= 1
        table.append(crc & 0xFFFFFFFF)
    return table

EDC_TABLE = build_edc_table()

def compute_edc(data, offset, length):
    crc = 0
    for i in range(length):
        crc = EDC_TABLE[(crc ^ data[offset + i]) & 0xFF] ^ (crc >> 8)
    return crc & 0xFFFFFFFF

bin_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\frankenstein_pipeline\output\dq4_frankenstein_fmv.bin"

with open(bin_path, 'rb') as f:
    # Test LBA 354 (known-good, HBD start)
    f.seek(354 * 2352)
    sector = f.read(2352)
    computed = compute_edc(sector, 16, 2056)
    stored = struct.unpack_from('<I', sector, 2072)[0]
    print(f"LBA 354: computed={computed:08X} stored={stored:08X} match={computed == stored}")

    # Test LBA 105828 (source FMV)
    f.seek(105828 * 2352)
    sector = f.read(2352)
    computed = compute_edc(sector, 16, 2056)
    stored = struct.unpack_from('<I', sector, 2072)[0]
    print(f"LBA 105828: computed={computed:08X} stored={stored:08X} match={computed == stored}")

    # Test LBA 146621 (target FMV)
    f.seek(146621 * 2352)
    sector = f.read(2352)
    computed = compute_edc(sector, 16, 2056)
    stored = struct.unpack_from('<I', sector, 2072)[0]
    print(f"LBA 146621: computed={computed:08X} stored={stored:08X} match={computed == stored}")

    # Test LBA 24 (EXE start)
    f.seek(24 * 2352)
    sector = f.read(2352)
    computed = compute_edc(sector, 16, 2056)
    stored = struct.unpack_from('<I', sector, 2072)[0]
    print(f"LBA 24: computed={computed:08X} stored={stored:08X} match={computed == stored}")
