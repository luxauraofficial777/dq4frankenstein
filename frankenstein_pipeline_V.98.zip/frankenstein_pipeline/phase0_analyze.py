#!/usr/bin/env python3
"""Phase 0: DW7 EXE Static Analysis — tree refs, BSS loop, HBD string scan."""
import struct, json, os

BASE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
EXE_PATH = os.path.join(BASE, "translation", "SLUSP012.06_clean.bin")
EXE_TEXT_START = 0x80017F00
FILE_HEADER = 0x800  # PS-X EXE header is 2048 bytes

def ram_from_offset(off):
    return EXE_TEXT_START + off - FILE_HEADER

def main():
    with open(EXE_PATH, "rb") as f:
        data = f.read()

    results = {}

    # 1. Header fields
    results["header"] = {
        "magic": data[0:8].decode("ascii", "replace"),
        "pc0": hex(struct.unpack("<I", data[0x10:0x14])[0]),
        "load_addr": hex(struct.unpack("<I", data[0x18:0x1C])[0]),
        "text_size": hex(struct.unpack("<I", data[0x1C:0x20])[0]),
        "text_size_dec": struct.unpack("<I", data[0x1C:0x20])[0],
        "bss_start": hex(struct.unpack("<I", data[0x30:0x34])[0]),
        "bss_size": hex(struct.unpack("<I", data[0x34:0x38])[0]),
        "file_size": len(data),
        "exe_end_ram": hex(0x80017F00 + struct.unpack("<I", data[0x1C:0x20])[0]),
    }

    # 2. Scan for old tree references: LUI 0x800E + ADDIU 0xF1C8
    #    LUI opcode = 0x0F, ADDIU opcode = 0x09
    #    Also check LUI 0x800F + ADDIU with sign extension to 0x800EF1C8
    tree_refs = []
    i = FILE_HEADER
    while i < len(data) - 8:
        word1 = struct.unpack("<I", data[i:i+4])[0]
        op1 = (word1 >> 26) & 0x3F
        imm1 = word1 & 0xFFFF

        if op1 == 0x0F:  # LUI
            # Check if next instruction is ADDIU with matching low bits
            word2 = struct.unpack("<I", data[i+4:i+8])[0]
            op2 = (word2 >> 26) & 0x3F
            imm2 = word2 & 0xFFFF

            if op2 == 0x09:  # ADDIU
                # Compute full address with sign extension
                addr = (imm1 << 16) + (imm2 if imm2 < 0x8000 else imm2 - 0x10000)
                if addr == 0x800EF1C8:
                    tree_refs.append({
                        "file_off": hex(i),
                        "ram_addr": hex(ram_from_offset(i)),
                        "lui_word": hex(word1),
                        "addiu_word": hex(word2),
                        "computed_addr": hex(addr),
                    })
                    i += 8
                    continue
        i += 4

    results["old_tree_refs"] = {
        "count": len(tree_refs),
        "refs": tree_refs,
    }

    # 3. Scan for BSS clear loop pattern
    #    Look for LUI with 0x800B or 0x800F followed by ADDIU
    #    targeting the known BSS range 0x800BC668 - 0x800F4980
    bss_candidates = []
    i = FILE_HEADER
    while i < len(data) - 8:
        word1 = struct.unpack("<I", data[i:i+4])[0]
        op1 = (word1 >> 26) & 0x3F
        imm1 = word1 & 0xFFFF

        if op1 == 0x0F:  # LUI
            word2 = struct.unpack("<I", data[i+4:i+8])[0]
            op2 = (word2 >> 26) & 0x3F
            imm2 = word2 & 0xFFFF

            if op2 in (0x09, 0x0D):  # ADDIU or ORI
                if op2 == 0x09:
                    addr = (imm1 << 16) + (imm2 if imm2 < 0x8000 else imm2 - 0x10000)
                else:  # ORI
                    addr = (imm1 << 16) | imm2

                # Check if address is in BSS range
                if 0x800BC000 <= addr <= 0x800F5000:
                    bss_candidates.append({
                        "file_off": hex(i),
                        "ram_addr": hex(ram_from_offset(i)),
                        "lui_word": hex(word1),
                        "lui_imm": hex(imm1),
                        "next_word": hex(word2),
                        "next_imm": hex(imm2),
                        "next_op": "ADDIU" if op2 == 0x09 else "ORI",
                        "computed_addr": hex(addr),
                    })
                    i += 8
                    continue
        i += 4

    results["bss_range_refs"] = {
        "count": len(bss_candidates),
        "refs": bss_candidates,
    }

    # 4. Scan for HBD string "hbd1ps1d.w71"
    hbd_string = b"hbd1ps1d.w71"
    hbd_hits = []
    pos = 0
    while True:
        idx = data.find(hbd_string, pos)
        if idx == -1:
            break
        hbd_hits.append({
            "file_off": hex(idx),
            "ram_addr": hex(ram_from_offset(idx)) if idx >= FILE_HEADER else "header",
        })
        pos = idx + 1

    results["hbd_string_scan"] = {
        "pattern": "hbd1ps1d.w71",
        "count": len(hbd_hits),
        "hits": hbd_hits,
    }

    # 5. Scan for thread entry 0x800D9E80 references
    #    Look for LUI+ADDIU pairs computing 0x800D9E80
    thread_refs = []
    i = FILE_HEADER
    while i < len(data) - 8:
        word1 = struct.unpack("<I", data[i:i+4])[0]
        op1 = (word1 >> 26) & 0x3F
        imm1 = word1 & 0xFFFF

        if op1 == 0x0F:
            word2 = struct.unpack("<I", data[i+4:i+8])[0]
            op2 = (word2 >> 26) & 0x3F
            imm2 = word2 & 0xFFFF

            if op2 == 0x09:
                addr = (imm1 << 16) + (imm2 if imm2 < 0x8000 else imm2 - 0x10000)
                if addr == 0x800D9E80:
                    thread_refs.append({
                        "file_off": hex(i),
                        "ram_addr": hex(ram_from_offset(i)),
                        "lui_word": hex(word1),
                        "addiu_word": hex(word2),
                    })
                    i += 8
                    continue
        i += 4

    results["thread_entry_refs"] = {
        "target": "0x800D9E80",
        "count": len(thread_refs),
        "refs": thread_refs,
    }

    # 6. Disassemble first 20 instructions at PC0
    pc0_offset = 0x8008E284 - 0x80017F00 + FILE_HEADER
    instrs = []
    for j in range(20):
        off = pc0_offset + j * 4
        if off + 4 <= len(data):
            word = struct.unpack("<I", data[off:off+4])[0]
            op = (word >> 26) & 0x3F
            instrs.append({
                "index": j,
                "ram": hex(0x8008E284 + j * 4),
                "file_off": hex(off),
                "word": hex(word),
                "opcode": op,
            })

    results["pc0_disasm"] = instrs

    # Sanitize: remove any null bytes from output
    output = json.dumps(results, indent=2)
    output = output.replace('\x00', '')
    with open(os.path.join(os.path.dirname(__file__), "phase0_analysis_clean.json"), "w") as f:
        f.write(output)
    print(output)

if __name__ == "__main__":
    main()
