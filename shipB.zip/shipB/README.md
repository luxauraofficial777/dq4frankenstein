# ShipB — DQ4 PSX English Build Pipeline (Pipeline-Only Distribution)

**Repo:** https://github.com/luxauraofficial777/dq4frankenstein
**We ship NO binary.** Build your own English master from your own pristine Japanese disc.

## Quick start

```
1. Place YOUR pristine image in the repo root (one level above shipB\):
      Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin
   Required SHA-1: 85064625AFA12219880FC8D07047A3CC1C595CB9
2. (Optional but recommended) Download edcre.exe (RadMage's PSX EDC/ECC tool)
   and place it at  shipB\edcre\edcre.exe   — without it, EDC/ECC steps are
   skipped and the output is NOT hardware-safe.
3. python shipB\tools\native_build_shipB.py
   (~80 min; output shipB\build\dq4_shipB.bin + .cue)
4. Play the .cue in DuckStation with a RETAIL PSX BIOS. No custom BIOS needed.
```

## Full guide
See `docs\TESTER_GUIDE.md` (prerequisites, pinned step chain, gates, seal, bug reporting).

## What's in this folder
| Path | Purpose |
|---|---|
| `tools\native_build_shipB.py` | the pinned build orchestrator (F6 patches removed — proven crash cause) |
| `tools\patch_block048c_verified.py` | STEP 4e same-tree 048C rebuilder |
| `tools\patch_d2_d3_4g2.py` | STEP 4g-2 church-offering/victory identity fix |
| `tools\build_all_facilities.py` | STEP 0a facility corpus generation |
| `study\` | gate + remap tooling (G2/G8/G10/G11, sweep, bare pages, EDC verifier) |
| `translation-tools\`, `psx_tools\` | codecs and lane patchers (self-contained copies) |
| `translation\` | corpus + lane JSONs (build works on a LOCAL copy here) |
| `build\` | outputs + `ram_scan_2_cache.pkl` (sweep input) — created/filled by the build |
| `docs\TESTER_GUIDE.md` | the tester manual |

## Useful flags
```
--skip-dialogue        reuse shipB\build\dq4_dialogue_en.bin (saves ~10 min)
--from-step <name>     resume at a named step (0a 0 1 1c 2 3 4 4b 4c 4e 4d 4h 1e 4f 4g 4g-2 5 6 7)
--g11-dumps a.bin b.bin  finish the STEP 7 seal with post-battle menu RAM dumps
```

## Legal
No copyrighted content is distributed here. The pipeline transforms YOUR own disc image.

---

## INSTALL & USAGE (shipped: VoidPatcher + BuildB pipeline)

### What you need
- Your own **pristine Japanese** disc image:
  `Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin`
  - SHA-1: `85064625AFA12219880FC8D07047A3CC1C595CB9`
  - SHA-256: `100D87DB9DEADF8F9FA4BB891D3A5D0BB112ACBF5ADBCBC93C637848ED9C7531`
- Windows 7+ (patcher) and, for the pipeline, Python 3.8+ with `pip install numpy`.
- **DuckStation** (retail PSX BIOS — e.g. SCPH-1001) to play. No custom BIOS required.
- `edcre.exe` (RadMage's PSX EDC/ECC recalculator) — **download it yourself**; not
  distributed. Required only by the pipeline for hardware-safe output.

### INSTALL

**Path A — VoidPatcher (recommended, ~2 minutes):**
1. Unzip the distribution anywhere.
2. You get `VoidPatcher_RB1.exe` — a single self-contained executable, nothing to install.
   (Optional: put a copy of your pristine image next to it, or just browse to it in Step 2.)

**Path B — BuildB source pipeline:**
1. Unzip the distribution, keeping the folder layout intact
   (`shipB\tools`, `shipB\translation-tools`, `shipB\study`, `shipB\translation`, ...).
2. Python 3.8+: `pip install numpy`
3. Download `edcre.exe` and place it at `shipB\edcre\edcre.exe`
   (without it the build finishes but EDC/ECC steps are SKIPPED — output will not be
   hardware-safe).
4. Place your pristine image at the repo root (one level above `shipB\`).

### USAGE

**VoidPatcher (Path A):**
1. Run `VoidPatcher_RB1.exe`.
2. TARGET DISC IMAGE → **BROWSE** (or type the path). The file is checked on selection
   (size + SLPM_869.16 boot reference).
3. Leave **SEALED PAYLOAD (DEFAULT)** selected.
4. Press **[ >>> APPLY PATCH <<< ]** (~2 min; watch the stage panel / ETA / log).
5. Output appears next to the exe:
   - `dq4_zenithian_english_RB1.bin` — verified by an automatic final SHA-256 gate
     (must equal `AC9F94A13A5627C30013FB0D13C88CD96F4BCEC878A2DA6E7B1978E1CD4E5703`)
   - `dq4_zenithian_english_RB1.cue` — load this in DuckStation, or burn the .bin at 4x–8x.

Headless (scriptable):
```
VoidPatcher_RB1.exe --headless "your pristine image.bin" output.bin
```
Exit 0 = all verification gates passed. The patcher refuses non-pristine sources
(already-patched masters, the known non-booting/broken images) with a specific message.

**BuildB pipeline (Path B, ~80 minutes):**
```
python shipB\tools\native_build_shipB.py
```
- Output: `shipB\build\dq4_shipB.bin` + `.cue` (master SHA-256 printed at the end).
- Resume a long build: `--from-step 4g` (step names: 0a 0 1 1c 2 3 4 4b 4c 4e 4d 4h 1e 4f 4g 4g-2 5 6 7)
- Faster iteration: `--skip-dialogue` (reuses `shipB\build\dq4_dialogue_en.bin`)
- The build runs hard gates (G2 dispatch integrity, G10 corpus census, G5 EDC/ECC) and a
  seal step (STEP 7); the seal waits for menu RAM dumps (`--g11-dumps a.bin b.bin`) or
  records `G11_PENDING`.
- Custom translations: copy the corpus JSON, edit it, then
  `python shipB\tools\native_build_shipB.py --corpus your_corpus.json`

### PLAYING
1. Open DuckStation → File → Open Disc → select the generated `.cue`.
2. Boot with a **retail PSX BIOS** (SCPH-1001 or your region's). No custom BIOS is needed.
3. Verify: title screen → prologue → Chapter 1; dialogue, battles, sound, and saving.

### Reporting bugs
See `docs\TESTER_GUIDE.md` §5: location + description; for freezes attach the DuckStation
log (timestamp, failing LBA range, CD-ROM buffer status) and paired RAM dumps; include your
master's SHA-256. Credits and Lux Aura links live in `CREDITS.md`.

### Source & downloads
- Project repository: **https://github.com/luxauraofficial777/dq4frankenstein**
- Follow Lux Aura: Bandcamp https://luxaura.bandcamp.com ·
  Facebook https://www.facebook.com/LuxAuraOfficial/ ·
  YouTube https://www.youtube.com/LuxAuraOfficial ·
  Steam (via SteamDB): https://steamdb.info/publisher/Lux+Aura/
