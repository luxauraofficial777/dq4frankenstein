# ShipB — DQ4 PSX English Build Pipeline (Pipeline-Only Distribution)

**We ship NO binary.** Build your own English master from your own pristine Japanese disc.

## Quick start

```
1. Place YOUR pristine image in the repo root (one level above shipB\):
      Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin
   Required SHA-1: 85064625AFA12219880FC8D07047A3CC1C595CB9
2. (Optional but recommended) Download edcre.exe (RadMage's PSX EDC/ECC tool)
   and place it at  shipB\edcre\edcre.exe   — without it, EDC/ECC steps are
   skipped and the output is NOT hardware-safe.
3. python shipB\tools\native_build_shipB.py
   (~80 min; output shipB\build\dq4_shipB.bin + .cue)
4. Play the .cue in DuckStation with a RETAIL PSX BIOS. No custom BIOS needed.
```

## Full guide
See `docs\TESTER_GUIDE.md` (prerequisites, pinned step chain, gates, seal, bug reporting).

## What's in this folder
| Path | Purpose |
|---|---|
| `tools\native_build_shipB.py` | the pinned build orchestrator (F6 patches removed — proven crash cause) |
| `tools\patch_block048c_verified.py` | STEP 4e same-tree 048C rebuilder |
| `tools\patch_d2_d3_4g2.py` | STEP 4g-2 church-offering/victory identity fix |
| `tools\build_all_facilities.py` | STEP 0a facility corpus generation |
| `study\` | gate + remap tooling (G2/G8/G10/G11, sweep, bare pages, EDC verifier) |
| `translation-tools\`, `psx_tools\` | codecs and lane patchers (self-contained copies) |
| `translation\` | corpus + lane JSONs (build works on a LOCAL copy here) |
| `build\` | outputs + `ram_scan_2_cache.pkl` (sweep input) — created/filled by the build |
| `docs\TESTER_GUIDE.md` | the tester manual |

## Useful flags
```
--skip-dialogue        reuse shipB\build\dq4_dialogue_en.bin (saves ~10 min)
--from-step <name>     resume at a named step (0a 0 1 1c 2 3 4 4b 4c 4e 4d 4h 1e 4f 4g 4g-2 5 6 7)
--g11-dumps a.bin b.bin  finish the STEP 7 seal with post-battle menu RAM dumps
```

## Legal
No copyrighted content is distributed here. The pipeline transforms YOUR own disc image.
