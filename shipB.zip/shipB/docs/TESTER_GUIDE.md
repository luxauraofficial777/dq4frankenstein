# DQ4 ShipB — Tester Guide (PIPELINE-ONLY DISTRIBUTION)

**We ship NO binary.** You build your own English master from **your own pristine Japanese
disc image** using the pinned pipeline in this folder. Nothing copyrighted is distributed.

## 1. Prerequisites

| Requirement | Notes |
|---|---|
| Your pristine Japanese image | `Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin` — place it in the **repo root** (one level above `shipB\`) or pass `--image` |
| SHA-1 of your image | must be `85064625AFA12219880FC8D07047A3CC1C595CB9` |
| Python 3.8+ | plus `numpy` (`pip install numpy`) |
| edcre.exe | **not bundled — download it yourself** (RadMage's PSX EDC/ECC recalculator) and place it at `shipB\edcre\edcre.exe`. Without it the build completes but EDC/ECC steps are SKIPPED and the output is NOT hardware-safe. |
| DuckStation | any recent build; **retail PSX BIOS** (SCPH-1001 etc.) — no custom BIOS needed |

## 2. Build (~80 min)

```powershell
cd <repo root>
python shipB\tools\native_build_shipB.py
```

- The pipeline is **self-contained**: it uses the `shipB\translation-tools\`, `shipB\study\`,
  `shipB\tools\`, `shipB\translation\` copies (staged in this folder) and works on a
  **shipB-local corpus copy** — it never mutates shared repo data.
- Output: `shipB\build\dq4_shipB.bin` + `.cue` (plus a `release\` artifact after the seal gate).
- Options: `--skip-dialogue` (reuse the dialogue bin), `--from-step <name>` (resume),
  `--g11-dumps d1.bin d2.bin` (seal gate with post-battle menu RAM dumps).

## 3. What the pipeline runs (pinned, F6 patches REMOVED)

0a facility corpus -> 0 validation (+G8) -> 1 native dialogue -> 1c type-39 remap ->
2 Font 1 (0x048C) -> 3 save menu (0x0474) -> 4 battle overlay (0x048B) -> 4b overlay refs ->
4c overlay duplicates -> 4e 048C same-tree rebuild (writeback + readback verified) ->
4d word sweep -> 4h page-table remap -> 1e EXE 0x048F -> 4f D4 split-imm -> 4g table refs ->
4g-2 D2/D3 identity -> 5 cue + EDC/ECC -> 6 gates (G2 dispatch / G10 census / G5 EDC) ->
7 seal (G11 residency; writes `G11_PENDING` until dumps are supplied).

F6 (VSync bypass / overlay-collision redirect / allocator guard) are intentionally absent —
they were proven to cause the prologue streaming crash (LBA 106958+, sectors dropped, FPS 0).

## 4. Expected result

- Gates G2/G5/G10 PASS on your built master; STEP 7 either seals (with dumps) or marks
  `G11_PENDING` — that is normal; supply two post-battle menu RAM dumps to finish sealing.
- Play the `.cue` in DuckStation (retail BIOS). The floor: clean boot → prologue → Chapter 1,
  dialogue/battles/sound/saving working.

## 5. Reporting bugs

Include: (1) exact in-game location + what happened; (2) for freezes, the DuckStation log
(timestamp, failing LBA range, CD-ROM buffer status); (3) paired RAM dumps for any screen
that fails to advance; (4) your master's SHA-256 (printed at the end of the build).
