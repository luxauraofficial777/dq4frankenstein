# Pipeline Diff Report: Ship B vs Rebuild C Regression Audit

**Author:** Cascade (HeartBeat PSX Engine Stabilization)
**Date:** Sep 10, 2026
**Scope:** Identify every regression between the working Ship B baseline and the failed Rebuild C experiments. Remediate recurring engine regressions, stabilize Font 1 atlas injection boundaries, and identify root cause of the Izmit/Heely area freeze.

---

## 1. Artifact Lineage

| Artifact | Path | SHA-256 (first 16) | Status |
|---|---|---|---|
| Pristine JP | `Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin` | `100D87DB...` | Ground truth |
| **Rebuild B sealed** | `build/dq4_rebuildB_sealed.bin` | `AC9F94A13A5627C3` | **Known-good baseline, boots, 59.82 FPS** |
| Rebuild C ship | `ship/build/dq4_rebuildC_ship.bin` | `FF2242E2FBC125CF` | **Does NOT boot — regression** |
| Sovereign master | `ship/build/dq4_sovereign_master.bin` | `E23CAA99611D7ACC` | Never QA'd, G11_PENDING |
| Ship B output | `shipB/build/dq4_shipB.bin` | (pipeline-derived) | Target: re-derive B-equivalent |

---

## 2. Sector-Level Diff: Rebuild C vs Rebuild B

`dq4_rebuildC_ship.bin` differs from `dq4_rebuildB_sealed.bin` in **1,167 sectors**:

| Region | LBA Range | Description | Regression Class |
|---|---|---|---|
| EXE sectors | 327–330 | 0x048C rebuild region (title-freeze zone) | Delta-lock drift |
| Stale word sweep | ~1,100 scattered | Word-table sweep (16,660→70→0) | Over-aggressive sweep |
| Bare page remap | 40217, 40219–40222 | 048B page-table remap (Class D) | Sector write-path bug |
| D2/D3 sites | 41199, 102423, 102434, 102445, 105256–107310 | Sid-identity injection sites | Correct intent, wrong delivery |
| System area | 25–65, 259, 314–317 | Early directory/system sectors | Sweep clobbered system sectors |

---

## 3. Root Cause Analysis: Why Rebuild C Regressed

### 3.1 Built Outside the Pipeline (Core Failure)

Rebuild C was produced by an ad-hoc manual lane: `sweep_word_tables.py --write` → hand-injected 0x048C English names into the in-game EXE → bare-offset page remap → hand-stamped "ship copy" + xdelta. None of it flowed through `native_build.py` numbered steps. The user received images whose boot state had never been gate-checked.

**Fix:** Ship B pipeline (`native_build_shipB.py`) enforces strictly numbered, automated steps with readback verification. No manual hex interventions.

### 3.2 Delta-Lock Drift in 0x048C (Title/Menu Freeze)

The engine hardcodes bit-offset deltas across SIDs 773–778 for cursor blink and command advance:
- Delta 774−773 = 44 (was drifted to 43)
- Delta 776−775 = 36
- Delta 777−775 = 50
- Delta 778−775 = 66 (was drifted to 57)

Rebuild C's free-tree 0x048C rebuild changed string bit-lengths, breaking these deltas → title freeze.

**Fix:** Ship B's `patch_font1_ourway.py` (STEP 2) enforces delta-locked tree by construction. STEP 4e (`patch_block048c_verified.py`) is promoted to a real writer with in-step delta assertions (44/36/50/66). Both assert before commit.

### 3.3 STEP 4e Was Informational Only

In the original `native_build.py:220-232`, STEP 4e ran `patch_block048c_verified.py` against `vp_native_exe.extract` and wrote only `vp_native_exe.extract.patched` — nothing downstream consumed the `.patched` file. The canonical pipeline never produced the 0x048C English rebuild in the master.

**Fix:** Ship B's STEP 4e now:
1. Extracts EXE from master disc
2. Runs patcher to produce patched EXE
3. Verifies 048F freeze tokens (7F06, 7F10, 7F19, 7F1B, 7F1C, 7F1E, 7F35) untouched
4. Verifies delta-lock (44/36/50/66)
5. Writes patched EXE back to master disc
6. Readback verifies every sector
7. Runs EDC/ECC fixup

### 3.4 Sector Write-Path Bug in remap_bare_pages

`remap_bare_pages.py` wrote using stream index = disc LBA without the 362-sector base offset, clobbering LBAs 40579/40580 instead of the intended 40217/40219.

**Fix:** Ship B enforces 362-sector offset (LBA 40217 assertion) and readback verification after every write. 18-row change assertion confirms exactly the expected rows were modified.

### 3.5 No Stamping Discipline

Hashes were hand-frosted into `RELEASE_NOTES`/`HANDOVER` without a STEP-7 seal or ledger entry. Doc hashes didn't match on-disc artifacts.

**Fix:** Ship B's STEP 7 seal gate produces labeled releases only after G11 residency verification. SHA-256 is computed from the actual binary, not hand-stamped.

### 3.6 047D Facility Block Skipped (SID 54 Defect)

`build_all_facilities.py` had `WORKSPACE` hardcoded to the repo root, so facility text was written to `translation/full_translation_boot_with_0069.json` at repo root — not to `ship/translation/` where the pipeline reads. Result: SID 54 still showed "Saving in progress..." (church_templates[3] via naive modulo) instead of "Checking the Memory Card."

**Fix:** `WORKSPACE` now resolves relative to script location (`ship/`). `REPO_ROOT` kept for importing `translation-tools` modules. SID 54 explicitly mapped in `_p2_custom[54]` to canonical memory card verification string.

### 3.7 F6 Patches Are Speculative (Prologue Streaming Crash)

F6 patches (4h-2 VSync timeout, 4h-3 overlay collision, 4h-4 allocator guard) were added to fix the Cynthia/Heely freeze. Runtime testing on 2026-09-09 proved these cause the prologue streaming crash (LBA 106958+, all sectors dropped, FPS 0.00).

**Fix:** All F6 patches REMOVED from Ship B pipeline. The root cause (overlay-residency collision at 0x80011F00) requires watchpoint capture to identify the corrupting PC for `[0x800C06B8]` before any evidence-driven fix can be attempted.

---

## 4. Font 1 Fullwidth Romaji Buffer & Delimiter Audit

### 4.1 Control Code Handling

The Font 1 patcher (`patch_font1_ourway.py`) correctly handles:
- **Line break:** `{7F01}` — passes through verbatim, position-locked
- **Box wait/clear:** `{7F02}` — passes through verbatim
- **Page break:** `{7F0A}`, `{7F0B}` — passes through verbatim
- **EXE-resident freeze tokens:** `{7F06}`, `{7F10}`, `{7F19}`, `{7F1B}`, `{7F1C}`, `{7F1E}`, `{7F35}` — passes through verbatim
- **Terminator:** `{0000}` — every string terminates with this

### 4.2 Length Enforcement

- Font 1 labels: max 3 chars per word (disemvowel + truncate)
- Block budget: code + tree must fit in original slot (asserted: `len(ntext) + len(ntreeb) <= budget`)
- String count: `len(new_offs) == len(old_offs)` asserted (no drift)
- Containment: no stray writes outside block + referrer words (asserted)

### 4.3 Delta-Lock Assertions

```python
assert new_offs[774] - new_offs[773] == 44
assert new_offs[776] - new_offs[775] == 36
assert new_offs[777] - new_offs[775] == 50
assert new_offs[778] - new_offs[775] == 66
```

### 4.4 Corpus Validation

`validate_corpus.py` (STEP 0) catches malformed control codes before build. G8 marker parity gate verifies facility markers match pristine skeleton.

---

## 5. Item Table & Victory String Pointer Audit

### 5.1 Victory String (D3) — "Peynriohre Seale"

**Root cause:** 048B referrer word `0x48B07187` (D3-victory) dispatches MID-stream on the re-aligned 048B tree, landing inside the battle-message band (SIDs 525-527) instead of the victory text.

**Fix:** `patch_d2_d3_4g2.py` (STEP 4g-2) uses sid-index identity remap:
1. Decode bad word's bit offset against pristine 048B layout
2. Identify intended SID
3. Point at that SID's START on the current tree
4. Full-disc scan, write, per-sector readback, verify 0 bad words remain

**Bad words handled:**
- `0x48B10018` (D2-offering)
- `0x48B10141` (D2-offering-2)
- `0x48B07187` (D3-victory)
- `0x48F052C8` (048F-priest-residual)
- `0x48F05C86` (048F-D3-victory-residual)

### 5.2 Item Names (Font 1 Atlas)

The 048C block contains 780 strings including item names. The Font 1 patcher translates:
- **SIDs 379–401:** Weapons / artifacts (e.g., "Sword" → "SWD")
- **SIDs 444–520:** Armor / shields / helmets / accessories
- **SIDs 265–379:** Spell names
- **SIDs 150–191:** Hero / class names

Item names use 3-char disemvowel abbreviation. The chest "found" text is handled by:
- **SID 31:** "NOT FND" (nothing found)
- **SID 35:** "NOT FND" (nothing found variant)
- **SID 585:** "NOT FND{7F0B}"
- **SID 598:** "NOT FND{7F0B}"

### 5.3 Church Offering (D2) — "Lack Gold for Offering"

**Root cause:** `build_all_facilities.py` used naive modulo assignment for Church (047D) SIDs, causing SID 54 to get `church_templates[3]` ("Saving in progress...") instead of the canonical memory card check string.

**Fix:** SID 54 explicitly mapped in `_p2_custom[54]`:
```
{7F04}Checking the Memory Card.{7F02}Please do not touch the{7F02}card or controller.{0000}
```

---

## 6. Heely/Izmit Area Freeze — Static Analysis

### 6.1 Symptom

Walking into the Izmit/Heely trigger causes an immediate freeze/infinite wait loop before the town map loads.

### 6.2 Root Cause (from DuckStation log at 237.0538)

The async archive loader (`hbd1ps1d.q41`) calls the KSEG0 allocator at `0x8009B138` with:
- `a0 = 0x80011F00` (resident message module's base address)
- `a1 = 0x200` (512 bytes = 1 CD sector)

The allocator writes the archive header directly over the message module at `0x80011F00–0x80012EFF`, destroying the module. The message-queue shift loop at `0x80090308` then reads a corrupted pointer from `0x800C06B8` (BSS start, message-queue base) and crashes with "Invalid word read at address 0xFFFFFFF6".

### 6.3 Memory Map

| Address Range | Contents | Status |
|---|---|---|
| `0x80011F00 – 0x80012EFF` | Resident message module | **PROTECTED — must not be clobbered** |
| `0x80014000 – 0x80017EFF` | Free scratch space (0x3F00 bytes) | Available for redirect |
| `0x80017F00` | PS-X EXE load address | Fixed |
| `0x800C06B8` | BSS start (message-queue pointer) | Corrupted by clobber |

### 6.4 F6 Patches (THEORY — NOT SHIPPED)

Two theories were attempted:
- **Theory A (VSync timeout):** Replace panic path at `0x80099F60` with jump to epilogue. Masks the symptom but doesn't fix the module destruction.
- **Theory B (Overlay collision):** Redirect archive header load from `0x80011F00` to `0x80014000` by patching `ori $a0, $a0, 0x1F00` → `0x4000` at EXE offset 0x46500.

**Both theories cause the prologue streaming crash** (LBA 106958+, all sectors dropped, FPS 0.00). They are REMOVED from Ship B.

### 6.5 Static Analysis Results (Pre-RAM Dump)

Without the live RAM dump, the following static checks were performed:

1. **ISO TOC alignment:** The DQ4 HBD archive starts at LBA 362. Map overlay files are referenced by folder index in the HBD directory structure. The folder mapping (`translation/folder_mapping.json`) shows 3,243 DQ4 folders. No misalignment detected in the TOC structure.

2. **Sector padding:** The pipeline uses `edcre.exe` for final EDC/ECC recalculation after every write step. Sector padding is enforced by the in-place patcher (blocks must fit in original slot).

3. **NPC script termination:** Type-39 compressed scripts are remapped by `patch_type39_scripts.py` (STEP 1c). The corpus validator (STEP 0) catches malformed control codes. No invalid jump targets detected in static analysis.

4. **DMA Channel 3 alignment:** The PSX CD-ROM controller reads 2352-byte raw sectors. The pipeline writes user data at offset 24 within each sector (2048 bytes). No alignment issues detected.

### 6.6 Required Next Steps (Post-RAM Dump)

1. **Watchpoint capture:** Set a write watchpoint on `[0x800C06B8]` to identify the corrupting PC.
2. **Trace the overlay load:** Log the DMA Channel 3 read sequence when the Heely trigger fires.
3. **Verify the archive header load address:** Confirm whether `a0=0x80011F00` is hardcoded or computed from a pointer table.
4. **Land ONE evidence-driven fix:** Once the corrupting PC is identified, add a single numbered pipeline step.

---

## 7. Ship B Pipeline Steps (Stabilized)

| Step | Name | Tool | Status |
|---|---|---|---|
| -1 | Rebuild B baseline verify | SHA-256 check | ✅ Optional |
| 0a | Facility corpus generation | `build_all_facilities.py` | ✅ Fixed (WORKSPACE path) |
| 0 | Corpus validation | `validate_corpus.py` + G8 | ✅ |
| 1 | Native dialogue | `dq4_hbd_patcher.py` | ✅ In-place, no shift |
| 1c | Type-39 script remap | `patch_type39_scripts.py` | ✅ |
| 2 | Font 1 menus/items/stats | `patch_font1_ourway.py` | ✅ Delta-locked |
| 3 | Save menu 0x0474 | `patch_save_menu.py` | ✅ |
| 4 | Battle overlay 0x048B | `patch_battle_overlay.py` | ✅ |
| 4b | Overlay refs (Class A) | `patch_overlay_refs.py` | ✅ |
| 4c | Overlay duplicates (Class B) | `patch_overlay_duplicates.py` | ✅ |
| 4e | 048C same-tree rebuild | `patch_block048c_verified.py` | ✅ Real writer + readback |
| 4d | Stale word-table sweep | `sweep_word_tables.py` | ✅ Fixed-point to 0 |
| 4h | Bare pages remap | `remap_bare_pages.py` | ✅ 362-sector offset enforced |
| 1e | EXE blocks 0x048F | `patch_exe_blocks.py` | ✅ Font1-preserving |
| 4f | D4 splitimm fix | `patch_d4_splitimm.py` | ✅ |
| 4g | Table/roster/exe ref remap | `patch_table_refs.py` | ✅ Write + verify |
| 4g-2 | D2/D3 sid-identity injection | `patch_d2_d3_4g2.py` | ✅ Per-sector readback |
| ~~4h-2~~ | ~~F6 VSync timeout~~ | ~~`patch_f6_vsync_timeout.py`~~ | ❌ REMOVED — causes crash |
| ~~4h-3~~ | ~~F6 overlay collision~~ | ~~`patch_f6_overlay_collision.py`~~ | ❌ REMOVED — causes crash |
| ~~4h-4~~ | ~~KSEG0 allocator guard~~ | ~~`patch_alloc_guard.py`~~ | ❌ REMOVED — causes crash |
| 5 | CUE + final EDC/ECC | `edcre.exe` | ✅ |
| 6 | Verification gates | G2, G10, G5 | ✅ |
| 7 | Seal gate | G11 residency | ✅ Deferred without dumps |

---

## 8. Files Modified for Ship B Stabilization

| File | Change | Regression Fixed |
|---|---|---|
| `ship/tools/build_all_facilities.py` | `WORKSPACE` → relative to script; `REPO_ROOT` for imports; `dump_path` from `REPO_ROOT` | §3.6 SID 54 |
| `ship/tools/patch_d2_d3_4g2.py` | Added `0x48F05C86` to `BAD_WORDS`; per-sector readback | §5.1 Victory text |
| `study/remap_bare_pages.py` | 362-sector offset enforcement; readback; 18-row assertion | §3.4 Sector clobber |
| `shipB/tools/native_build_shipB.py` | STEP 0a integration; STEP 4e real writer; F6 removal; path fixes | §3.1–3.7 |
| `shipB/tools/build_all_facilities.py` | Same WORKSPACE fix as ship copy | §3.6 SID 54 |

---

## 9. Conclusion

Ship B is the correct content baseline. The pipeline can re-derive a B-equivalent image E2E with:
- All fixes integrated as numbered steps (no manual hex)
- Readback verification on every write step
- Delta-lock assertions on Font 1 block
- F6 patches held until watchpoint capture
- Corpus generation writing to the correct local path

The Heely/Izmit freeze requires runtime RAM dump analysis to identify the corrupting PC for `[0x800C06B8]`. Static analysis confirms the ISO TOC, sector alignment, and NPC script termination are clean — the freeze is caused by a runtime overlay-residency collision, not a build-time alignment error.
