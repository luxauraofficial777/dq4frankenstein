#!/usr/bin/env python3
"""g8_marker_parity.py — G8 gate: facility-block marker parity (HARD-FAIL).

Verifies that the live corpus carries the pristine facility marker skeleton
(7Fxx slots + 7Exx variables) for every sid the pipeline restores, with the
exact marker ORDER preserved (order is the Font-1 formatter's protocol).

Scope (deliberate, documented):
  048f, 047d   — menu-FRAMED sids only ({7F04}/{7F07}/{7F47}/{7F11-14}/{7F05}
                 present in the pristine unit). These are the strings the
                 Font-1 formatter consumes (start menu / priest menu). Plain
                 sids (battle cries, standard-renderer dialogue) were reverted
                 to the pre-restore corpus: they rendered fine in the
                 playtested sealed build, and the full var restoration
                 overflowed the blocks' budgets (047D +1852B, 048F +320B) and
                 was silently skipped in STEP 1 / failed STEP 1e.
  0479/047b/047c — EXCLUDED this cycle: reverted to pre-restore (never
                 confirmed garbled; restoration overflowed budgets).

  18-block token-gap list (CONTROL_CODE_DEEP_AUDIT §5): per-block structural
  token parity for dialogue-side blocks where the corpus dropped a pristine
  token.  The check verifies the token is present somewhere in the block's
  corpus translations.  For block 0022, also verifies 7F0A was not spuriously
  inserted (pristine has none).

Exit 0 = parity holds. Exit 1 = shortfall / order violation (build must abort).
"""
import json, os, re, sys
sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))


def _find_repo_root():
    """Walk up from HERE until a dir containing psx_tools/dq4 is found (the
    TRUE repo root). Resolving by "contains ship/translation" made ship/study
    resolve ROOT=ship -> CORPUS=ship/ship/translation (a stale snapshot) --
    the same bug class fixed in verify_ship_parity.py."""
    d = HERE
    for _ in range(6):
        if os.path.isdir(os.path.join(d, "psx_tools", "dq4")):
            return d
        d = os.path.dirname(d)
    raise SystemExit("G8 FAIL: cannot locate repo root (corpus not found)")


ROOT = _find_repo_root()
CORPUS = os.path.join(ROOT, "ship", "translation", "full_translation_boot_with_0069.json")
_ws_candidates = [os.path.join(HERE, "facility_marker_worksheet.json"),
                  os.path.join(ROOT, "study", "facility_marker_worksheet.json")]
WORKSHEET = next(p for p in _ws_candidates if os.path.isfile(p))
MENU = {"7F04", "7F07", "7F47", "7F11", "7F12", "7F13", "7F14", "7F05"}
TOKEN = re.compile(r"\{([0-9A-Fa-f]{4})\}")

# 18-block token-gap list from CONTROL_CODE_DEEP_AUDIT §5.
# Maps block_id -> {token: min_expected_count, ...}
# A count of 0 means the token must NOT be present (spurious insertion).
# All others mean the token must appear at least that many times across
# all sids in the block's corpus translations.
TOKEN_GAP_BLOCKS = {
    "0168": {"7F4B": 1},
    "0169": {"7F4B": 1},
    "0224": {"7F4B": 1},
    "022A": {"7F4B": 1},
    "02BA": {"7F4B": 1},
    "02F7": {"7F4B": 1},
    "02D7": {"7F0B": 1},
    "03EE": {"7F0B": 1},
    "0422": {"7F0B": 1},
    "0423": {"7F0B": 1},
    "0424": {"7F0B": 1},
    "042F": {"7F0B": 1},
    "043E": {"7F0B": 1},
    "043F": {"7F0B": 1},
    "0021": {"7F13": 1},
    "0023": {"7F13": 1},
    "0022": {"7F12": 1, "7F0A": 0},
    "015B": {"7F20": 1},
}
_GAP_TOKEN = re.compile(r"[<{]([0-9A-Fa-f]{4})[>}]")


def marker_payloads(text):
    # normalize FE->7E: the disc stores 0x7Exx (high-bit-stripped); some
    # decoders render the restored form 0xFExx (RESOLVED-doc convention).
    # Both notations mean the same leaf.
    out = []
    for m in TOKEN.finditer(text):
        p = m.group(1).upper()
        if p.startswith("FE"):
            p = "7E" + p[2:]
        if not p.startswith("00"):
            out.append(p)
    return out


def main():
    ws = json.load(open(WORKSHEET, encoding="utf-8"))
    d = json.load(open(CORPUS, encoding="utf-8"))
    checks = fails = 0
    # scope: menu-framed sids only (see module docstring)
    scope = [(bid, [sid for sid, u in ws[bid].items()
                    if any(re.match(r"[<{]([0-9A-Fa-f]{4})[>}]", t).group(1).upper() in MENU
                           for t in u["markers"])])
             for bid in ("048f", "047d")]
    for bid, sids in scope:
        blk = d.get(bid, {})
        for sid in sids:
            v = blk.get(sid)
            if not isinstance(v, dict):
                print("G8 FAIL %s/%s: entry missing" % (bid, sid))
                fails += 1
                continue
            field = "translation" if v.get("translation") is not None else "en"
            en = v.get(field) or ""
            want = [re.match(r"[<{]([0-9A-Fa-f]{4})[>}]", t).group(1).upper()
                    for t in ws[bid][sid]["markers"]]
            if bid == "047d":
                # RC-2 (047D module lane): 047d is FULLY re-encoded from the
                # corpus, and the corpus deliberately resolves the {7Exx}
                # dictionary refs into literal English words (keeping them
                # interleaved with EN text is the mixed-encoding priest-garble
                # class). The protective intent of this check is preserved for
                # the structural markers ({7F04}/{7F07}/{7F47} hoisted runs,
                # {7F02}/{7F0A}/{7F0B} breaks, {7F15}+ variable slots) -- only
                # the dict-ref leaves are exempt. 048f keeps its refs: the
                # word-fold system dispatches on them.
                want = [w for w in want if not w.startswith("7E")]
            got = marker_payloads(en)
            # subsequence check: want must appear in got in ORDER (EN may not
            # interleave extra 7E tokens, but pagination tokens are absent
            # from want by construction; every want token must be in got
            # at the same relative order)
            it = iter(got)
            missing = [w for w in want if not any(x == w for x in it)]
            if missing:
                print("G8 FAIL %s/%s: missing/unordered %s" % (bid, sid, missing))
                fails += 1
            checks += 1
    # --- 18-block token-gap check (dialogue-side structural tokens) ---
    gap_checks = gap_fails = 0
    for bid, expected in TOKEN_GAP_BLOCKS.items():
        # corpus keys are lowercase hex; a case-sensitive lookup silently
        # blanked every id containing A-F (042F/043E/043F/015B/02D7/02F7/03EE)
        blk = d.get(bid.lower(), {})
        if not isinstance(blk, dict):
            print("G8 FAIL %s: block missing from corpus" % bid)
            gap_fails += 1
            gap_checks += 1
            continue
        # Collect all tokens across all sids in this block
        block_tokens = []
        for sid, sv in blk.items():
            if not isinstance(sv, dict):
                continue
            field = "translation" if sv.get("translation") is not None else "en"
            en = sv.get(field) or ""
            block_tokens.extend(
                m.upper() for m in _GAP_TOKEN.findall(en)
                if not m.upper().startswith("00")
            )
        for tok, min_count in expected.items():
            tok_up = tok.upper()
            actual = block_tokens.count(tok_up)
            if min_count == 0:
                if actual > 0:
                    print("G8 FAIL %s: spurious %s inserted (%d occurrences, "
                          "pristine has 0)" % (bid, tok_up, actual))
                    gap_fails += 1
            else:
                if actual < min_count:
                    print("G8 FAIL %s: %s dropped (corpus %d, expected >= %d)"
                          % (bid, tok_up, actual, min_count))
                    gap_fails += 1
            gap_checks += 1

    total_fails = fails + gap_fails
    print("G8 marker-parity: %s — %d menu sids checked (%d failures), "
          "%d token-gap checks (%d failures)"
          % ("PASS" if total_fails == 0 else "FAIL",
             checks, fails, gap_checks, gap_fails))
    return 1 if total_fails else 0


if __name__ == "__main__":
    sys.exit(main())
