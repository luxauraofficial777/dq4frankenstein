#!/usr/bin/env python3
"""g2_dispatch_gate.py — G2 dispatch integrity gate (closes V22 U7).

Disc-wide + EXE scan for 0x48B/0x48C/0x48F-prefixed referrer words; classifies
each against the CURRENT block tree as START (== a sequence boundary) or MID
(inside a leaf run). LIVE MID COUNT MUST BE 0 — a MID word = a referrer
pointing into the middle of the re-encoded block = wrong-string-selection.

hts conventions (MASTER_DISC_CONTENT_MAP, Sep 7): 048B hts=24 (c*8=192),
048C hts=24 (c*8=192), 048F hts=648 (c*8=5184). 048B tree lives in the archive
(HBD); 048C/048F trees live in the EXE region.

Whitelist: the known past-end monster-name-table tail (bit offset > sid-817
start) is structural, not a dispatch word — reported separately, not failed.

Exit codes: 0 = PASS, 1 = FAIL, 2 = usage.
Usage: g2_dispatch_gate.py [--disc PATH] [--pristine PATH] [--write-out REPORT]
"""
import argparse
import bisect
import os
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
_psx = os.path.join(ROOT, "psx_tools")
if not os.path.isdir(_psx): _psx = os.path.join(os.path.dirname(ROOT), "psx_tools")
sys.path.insert(0, _psx)
import dq4_hbd_patcher as P  # noqa: E402
from hbe.huffman.dq4 import DQ4Schema  # noqa: E402
from hbe.huffman.node import NodeType  # noqa: E402
from dq4.textblock import TextBlock  # noqa: E402

RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA0, EXE_LBA1 = 24, 361
HBD_LBA = 362

# block id -> (hts, sig_search_start_sector)
BLOCKS = {0x48B: (24, 100000), 0x48C: (24, EXE_LBA0), 0x48F: (648, EXE_LBA0)}


def user_data(path):
    data = open(path, "rb").read()
    n = len(data) // RAW
    return b"".join(data[i * RAW + UOFF: i * RAW + UOFF + USZ] for i in range(n))


def load_block(u, bid, hts, start_sector):
    sig = struct.pack("<II", bid, hts)
    idx = u.find(sig, start_sector * USZ)
    if idx < 0:
        raise SystemExit("[FAIL] block %03X signature (hts=%d) not found" % (bid, hts))
    hdr_off = idx - 4
    end = struct.unpack_from("<I", u, hdr_off)[0]
    blk = u[hdr_off: hdr_off + end]
    tb = TextBlock(blk)
    sc = DQ4Schema()
    base, mid, _root = struct.unpack_from("<IIH", blk, tb.e)
    tlen = (mid - base + 1) * 2
    tree = sc.parse_tree(blk[base: base + tlen])
    leaves = sc.decode(blk[tb.c: tb.e], tree)
    seq_offs = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]
    return blk, tb, tree, leaves, seq_offs


def classify(bit, seq_offs, end_bit):
    """START / MID / PAST-END classification for a block bit offset."""
    if bit >= end_bit:
        return "PAST-END"
    k = bisect.bisect_left(seq_offs, bit)
    if k < len(seq_offs) and seq_offs[k] == bit:
        return "START"
    return "MID"


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_rebuildC_wip.bin"))
    ap.add_argument("--pristine", default=os.path.join(
        ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"))
    ap.add_argument("--v22", default=os.path.join(
        ROOT, "ship", "build", "dq4_rebuildC_ship.bin"),
        help="v2.2+1 lineage image for multi-tree missed-remap classification")
    ap.add_argument("--strict-dt", action="store_true",
                    help="hard-fail on 048F description-table MID words (§11.4 class)")
    ap.add_argument("--write-out", default=None, help="report TSV path")
    args = ap.parse_args()

    u = user_data(args.disc)
    up = user_data(args.pristine)
    uv22 = user_data(args.v22) if os.path.exists(args.v22) else None
    if uv22 is None:
        print("[G2 WARN] v2.2 lineage image not found at %s — single-tree classification"
              % args.v22)

    def block_bits(tree, leaves):
        codes = {}

        def walk(node, code):
            if node.node_type == NodeType.Branch:
                walk(node.children[0], code + "0")
                walk(node.children[1], code + "1")
            else:
                codes[id(node)] = code
        walk(tree, "")
        return codes, sum(len(codes[id(lf)]) for lf in leaves)

    # --- load all three block trees, current + pristine + v2.2 lineage ---
    trees = {}
    for bid, (hts, start) in sorted(BLOCKS.items()):
        blk, tb, tree, leaves, seq_offs = load_block(u, bid, hts, start)
        blk_p, tb_p, tree_p, leaves_p, seq_p = load_block(up, bid, hts, start)
        codes, end_bit = block_bits(tree, leaves)
        codes_p, end_bit_p = block_bits(tree_p, leaves_p)
        t = {"tb": tb, "seq": seq_offs, "end": end_bit,
             "tb_p": tb_p, "seq_p": seq_p, "end_p": end_bit_p,
             "n": len(seq_offs), "n_p": len(seq_p)}
        if uv22 is not None:
            blk_v, tb_v, tree_v, leaves_v, seq_v = load_block(uv22, bid, hts, start)
            _cv, end_bit_v = block_bits(tree_v, leaves_v)
            t["tb_v"] = tb_v
            t["seq_v"] = seq_v
            t["end_v"] = end_bit_v
        trees[bid] = t
        extra = " | v2.2: seqs=%d bits=%d" % (len(t.get("seq_v", [])), t.get("end_v", 0)) \
            if uv22 is not None else ""
        print("current %03X: seqs=%d bits=%d | pristine: seqs=%d bits=%d%s" % (
            bid, len(seq_offs), end_bit, len(seq_p), end_bit_p, extra))

    # --- collect candidate words per block: EXE region u32 + archive data tables ---
    sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
    import patch_table_refs as R  # noqa: E402
    arch = u[HBD_LBA * USZ:]
    blocks = R.hbd.scan_blocks(arch)
    subs = R.hbd.sub_blocks(blocks)
    TABLE_TYPES = {(10, 1280), (13, 1280), (25, 1280), (44, 1280), (44, 0), (40, 0), (26, 0), (42, 0)}
    subs_sorted = sorted((s["off"], s["dlen"], b, s) for b, s in subs)

    exe = bytearray()
    for s in range(EXE_LBA0, EXE_LBA1 + 1):
        exe.extend(u[s * USZ: (s + 1) * USZ])

    words_by_block = {bid: [] for bid in BLOCKS}
    for off in range(0, len(exe) - 4, 4):
        v = struct.unpack_from("<I", exe, off)[0]
        bid = v >> 20
        if bid in words_by_block:
            words_by_block[bid].append(("EXE+0x%X" % (off + EXE_LBA0 * USZ), v))
    for so, dl, b, s in subs_sorted:
        if (s["type"], s["flags"]) not in TABLE_TYPES:
            continue
        for pos in range(so, min(so + dl, len(arch)) - 4, 4):
            v = struct.unpack_from("<I", arch, pos)[0]
            bid = v >> 20
            if bid in words_by_block:
                words_by_block[bid].append(("ARCH+0x%X" % (HBD_LBA * USZ + pos), v))
    for bid in sorted(words_by_block):
        print("candidate %03X words: %d" % (bid, len(words_by_block[bid])))

    rows, all_mids = [], []
    overall_fail = False
    for bid in sorted(BLOCKS):
        t = trees[bid]
        sid_last_start = t["seq"][817] if (bid == 0x48B and len(t["seq"]) > 817) \
            else (t["seq"][-1] if t["seq"] else t["end"])
        stats = {"START": 0, "MID": 0, "PAST-END": 0, "BASE": 0, "P-PAST-END": 0}
        mids = []
        for where, v in words_by_block[bid]:
            bit = (v & 0xFFFFF) - t["tb"].c * 8
            bit_p = (v & 0xFFFFF) - t["tb_p"].c * 8
            if bit == 0:
                stats["BASE"] += 1
                rows.append((where, v, bit, "%03X/BASE" % bid))
                continue
            cls_new = classify(bit, t["seq"], t["end"])
            cls_old = classify(bit_p, t["seq_p"], t["end_p"])
            # Multi-tree lineage (§11.3): a word that is a valid dispatch
            # boundary on ANY lineage tree (pristine or v2.2+1) but decodes
            # MID on the current tree is a missed remap. Everything MID/PAST
            # on all lineage trees is non-dispatch data.
            cls_v22 = "MID"
            if "seq_v" in t:
                bit_v = (v & 0xFFFFF) - t["tb_v"].c * 8
                cls_v22 = classify(bit_v, t["seq_v"], t["end_v"])
            lineage_start = (cls_old == "START") or (cls_v22 == "START")
            if lineage_start and cls_new == "MID":
                stats["MID"] += 1
                mids.append((where, v, bit))
                rows.append((where, v, bit, "%03X/MID(missed-remap)" % bid))
                continue
            if cls_new == "START":
                stats["START"] += 1
            elif cls_new == "MID":
                stats["MID"] += 1
            elif cls_new == "PAST-END":
                if bit >= sid_last_start:
                    stats["PAST-END"] += 1  # whitelisted structural tail
                else:
                    stats["P-PAST-END"] += 1
            rows.append((where, v, bit, "%03X/%s" % (bid, cls_new)))
        print("%03X classification: START=%d MID=%d PAST-END(tail)=%d PAST-END(mid-band)=%d BASE=%d"
              % (bid, stats["START"], stats["MID"], stats["PAST-END"],
                 stats["P-PAST-END"], stats["BASE"]))
        if mids:
            print("[G2 FAIL] %03X missed-remap referrers (pristine START -> current MID): %d"
                  % (bid, len(mids)))
            for where, v, bit in mids[:40]:
                print("   MID %s word=0x%08X bit=0x%05X" % (where, v, bit))
            overall_fail = True
            all_mids.extend((bid,) + m for m in mids)
        else:
            print("[G2 PASS] %03X missed-remap count == 0" % bid)
    # --- §11.4 class: 048F description-table MID words (gate-invisible on
    # all lineage trees, disc-embedded in the D4 data files). These are
    # reported separately; --strict-dt promotes them to a hard failure.
    DESCRIPTION_TABLE_WORDS = {
        0x48F045B0: "048F sid 99  item/spell description",
        0x48F06492: "048F sid 137 item/spell description",
        0x48F07F34: "048F sid 188 item/spell description",
    }
    dt_sites = {w: [] for w in DESCRIPTION_TABLE_WORDS}
    for w in DESCRIPTION_TABLE_WORDS:
        pat = struct.pack("<I", w)
        i = u.find(pat)
        while i != -1:
            sec_i, off_i = divmod(i, USZ)
            if off_i % 4 == 0:
                dt_sites[w].append("LBA %d u_off 0x%X" % (HBD_LBA + sec_i, off_i))
            i = u.find(pat, i + 1)
    dt_total = sum(len(v) for v in dt_sites.values())
    if dt_total:
        print("[G2 %s] 048F description-table MID words on disc: %d (§11.4 class)"
              % ("FAIL" if args.strict_dt else "WARN", dt_total))
        for w in sorted(dt_sites):
            for loc in dt_sites[w][:8]:
                print("   DT %s word=0x%08X (%s)"
                      % (loc, w, DESCRIPTION_TABLE_WORDS[w]))
        if args.strict_dt:
            overall_fail = True
    else:
        print("[G2 PASS] 048F description-table MID words: 0")

    if args.write_out:
        with open(args.write_out, "w", encoding="utf-8") as f:
            f.write("where\tword\tbit\tclass\n")
            for where, v, bit, cls in rows:
                f.write("%s\t0x%08X\t0x%05X\t%s\n" % (where, v, bit, cls))
    if overall_fail:
        print("[G2 FAIL] total missed-remap referrers: %d" % len(all_mids))
        return 1
    print("[G2 PASS] missed-remap count == 0 across 048B/048C/048F")
    return 0


if __name__ == "__main__":
    sys.exit(main())
