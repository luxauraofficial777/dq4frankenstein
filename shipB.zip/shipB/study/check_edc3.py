#!/usr/bin/env python3
"""XA Mode2/Form1 EDC verifier - Corlett convention (poly 0xD8018001 reflected,
span = subhead+data = bytes 16..2071, stored LE at 2072). Calibrated on sealed B."""
import sys, os, struct
sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
RAW = 2352

LUT = []
for i in range(256):
    edc = i
    for _ in range(8):
        edc = (edc >> 1) ^ (0xD8018001 if edc & 1 else 0)
    LUT.append(edc)


def edc_calc(data):
    edc = 0
    for b in data:
        edc = (edc >> 8) ^ LUT[(edc ^ b) & 0xFF]
    return edc


def check(path):
    n = os.path.getsize(path) // RAW
    bad = {}
    checked = 0
    with open(path, "rb") as f:
        for lba in range(n):
            sec = f.read(RAW)
            if len(sec) < RAW:
                break
            if sec[15] != 2 or (sec[18] & 0x20):
                continue  # not Mode2 Form1
            checked += 1
            stored = struct.unpack_from("<I", sec, 2072)[0]
            if edc_calc(sec[16:2072]) != stored:
                band = "exe(<=361)" if lba <= 361 else ("sys" if lba < 1000 else "arch")
                bad[band] = bad.get(band, 0) + 1
    return checked, bad


if __name__ == "__main__":
    named = {
        "sealed": "dq4_rebuildB_sealed.bin",
        "ship": "dq4_rebuildC_ship.bin",
        "wip": "dq4_rebuildC_wip.bin",
        "pristine": "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin",
    }
    for which in sys.argv[1:] or ["sealed"]:
        if "/" in which or "\\" in which or ":" in which:
            path = which          # explicit path (pipeline use)
            label = os.path.basename(which)
        else:
            p = named[which]
            path = os.path.join(ROOT, p) if which == "pristine" else os.path.join(ROOT, "build", p)
            label = which
        n, bad = check(path)
        print("%-16s form1=%d badEDC=%s" % (label, n, bad))
