#!/usr/bin/env python3
"""sweep_word_tables: remap stale referrer words in marker+word data tables.

Site classes (per RAM-dump + disc evidence):
  A) archive sub-blocks holding raw u32 tables: types (10,13,25,44) flags
     0x0500 (=1280), plus raw (40,0)/(26,0) tables â€” exact stale-word match.
  B) EXE raw u32 words (aligned).
  C) EXE lui/ori immediate pairs encoding (tid<<20)|off.

Report mode by default; --write applies.
"""
import os
import pickle
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
import patch_table_refs as R  # noqa: E402

RAW, UOFF, USZ = 2352, 24, 2048
HBD_LBA = 362
EXE_LBA0, EXE_LBA1 = 24, 361
WIP = os.path.join(ROOT, "build", "dq4_rebuildC_wip.bin")
CACHE = os.path.join(ROOT, "build", "ram_scan_2_cache.pkl")

TABLE_TYPES = {(10, 1280), (13, 1280), (25, 1280), (44, 1280), (44, 0),
               (40, 0), (26, 0), (42, 0)}


def read_sector(path, sec):
    with open(path, "rb") as f:
        f.seek(sec * RAW + UOFF)
        return f.read(USZ)


def main():
    # CLI: [--write] [--disc PATH] [--cache PATH]  (defaults preserved for standalone use)
    args = list(sys.argv[1:])
    do_write = "--write" in args
    disc = WIP
    cache = CACHE
    if "--disc" in args:
        disc = args[args.index("--disc") + 1]
        del args[args.index("--disc"):args.index("--disc") + 2]
    if "--cache" in args:
        cache = args[args.index("--cache") + 1]
        del args[args.index("--cache"):args.index("--cache") + 2]
    if do_write:
        args.remove("--write")
    with open(cache, "rb") as f:
        stale, _index_m = pickle.load(f)
    print("stale words: %d (disc=%s)" % (len(stale), disc))

    # ---------- A) archive data-table subs ----------
    arch_raw = bytearray()
    nsec = os.path.getsize(disc) // RAW
    for s in range(HBD_LBA, nsec):
        arch_raw.extend(read_sector(disc, s))
    arch = bytes(arch_raw)
    blocks = R.hbd.scan_blocks(arch)
    subs = R.hbd.sub_blocks(blocks)
    import bisect
    subs_sorted = sorted((s["off"], s["dlen"], b, s) for b, s in subs)
    offs = [t[0] for t in subs_sorted]
    edits = {}  # pos -> (old, new, where)
    n_sites = 0
    for so, dl, b, s in subs_sorted:
        if (s["type"], s["flags"]) not in TABLE_TYPES:
            continue
        base = so
        for o in range(so, so + dl - 3, 4):
            v = struct.unpack_from("<I", arch, o)[0]
            ent = stale.get(v)
            if ent is None:
                continue
            edits[o] = (v, ent[0], "ARCH type %d flags %d (sec %d)" %
                        (s["type"], s["flags"], HBD_LBA + (o // USZ)))
            n_sites += 1
    print("A) archive table sites: %d" % n_sites)
    # dedupe stats by word
    words_a = sorted(set(v for v, _n, _w in edits.values()))
    print("   distinct stale words: %d" % len(words_a))
    # ---------- B) EXE raw u32 ----------
    exe = bytearray()
    for s in range(EXE_LBA0, EXE_LBA1 + 1):
        exe.extend(read_sector(disc, s))
    exe = bytes(exe)
    b_hits = 0
    for o in range(0, len(exe) - 3, 4):
        v = struct.unpack_from("<I", exe, o)[0]
        ent = stale.get(v)
        if ent is not None:
            edits["E%d" % o] = (v, ent[0], "EXE u32 @0x%X" % (EXE_LBA0 * USZ + o))
            b_hits += 1
    print("B) EXE raw u32 sites: %d" % b_hits)
    # ---------- C) EXE lui/ori ----------
    hi = {}
    for w in stale:
        hi.setdefault(w >> 16, set()).add(w)
    c_hits = 0
    for o in range(0, len(exe) - 7, 4):
        ins = struct.unpack_from("<I", exe, o)[0]
        if (ins & 0xFC000000) != 0x3C000000:
            continue
        h = ins & 0xFFFF
        if h not in hi:
            continue
        ins2 = struct.unpack_from("<I", exe, o + 4)[0]
        if (ins2 & 0xFC000000) == 0x34000000:
            lo = ins2 & 0xFFFF
            w = (h << 16) | lo
            if w in stale:
                edits["C%d" % o] = (w, stale[w][0],
                                    "EXE lui/ori @0x%X (lui 0x%04X ori 0x%04X)"
                                    % (EXE_LBA0 * USZ + o, h, lo))
                c_hits += 1
    print("C) EXE lui/ori sites: %d" % c_hits)

    # ---------- report ----------
    from collections import Counter
    where_c = Counter(w for _o, _v, w in edits.values())
    print("total sites: %d" % len(edits))
    agg = Counter()
    sub_of = {}
    for _o, (_v, _n, w) in edits.items():
        if w.startswith("ARCH type"):
            key = w.split(" (sec")[0]
            agg[key] += 1
            sub_of.setdefault(key, set()).add(w)
    print("-- archive sites by class --")
    for key, n in agg.most_common():
        print("   %-32s sites %d in %d subs" % (key, n, len(sub_of[key])))
    # context samples per class (marker check)
    import re
    byclass = {}
    for o, (v, wnew, w) in edits.items():
        if isinstance(o, int):
            m = re.match(r"ARCH (type \d+ flags \d+)", w)
            byclass.setdefault(m.group(1), []).append((o, v, wnew, w))
    for key, lst in sorted(byclass.items()):
        print("-- samples %s (marker 0xFFF0xxxx within +-8B?) --" % key)
        nmark = 0
        for o, v, wnew, w in lst:
            lo = max(0, o - 8)
            ctx = struct.unpack_from("<%dI" % ((o + 4 - lo) // 4), arch, lo)
            if any(0xFFF00000 <= x <= 0xFFF0FFFF for x in ctx):
                nmark += 1
        print("   marker-present: %d/%d" % (nmark, len(lst)))
        for o, v, wnew, w in lst[:3]:
            lo = max(0, o - 12)
            ctx = arch[lo:o + 8].hex()
            print("   0x%08X -> 0x%08X @u%d %s ctx=%s" % (v, wnew, o, w, ctx))
    print("total sites: %d" % len(edits))
    for k, n in where_c.most_common(30):
        print("   %-50s %d" % (k, n))
    if do_write and edits:
        # apply: archive via user data buffer rewrite, EXE likewise,
        # then map back to physical sectors
        new_arch = bytearray(arch)
        n_arch = 0
        for o, (v, wnew, w) in edits.items():
            if isinstance(o, int) and w.startswith("ARCH"):
                struct.pack_into("<I", new_arch, o, wnew)
                n_arch += 1
        # write back per sector
        sec_data = {}
        for o, (v, wnew, w) in edits.items():
            if not (isinstance(o, int) and w.startswith("ARCH")):
                continue
            sec = o // USZ
            sec_data.setdefault(sec, bytearray(new_arch[sec * USZ:(sec + 1) * USZ]))
        n_written = 0
        for sec, data in sec_data.items():
            if bytes(data) == arch[sec * USZ:(sec + 1) * USZ]:
                continue
            with open(disc, "r+b") as f:
                f.seek((HBD_LBA + sec) * RAW + UOFF)
                f.write(bytes(data))
            n_written += 1
        print("wrote %d archive sectors" % n_written)
        new_exe = bytearray(exe)
        n_exe = 0
        for o, (v, wnew, w) in edits.items():
            if not isinstance(o, str):
                continue
            idx = int(o[1:])
            kind = o[0]
            if kind == "E":
                struct.pack_into("<I", new_exe, idx, wnew)
                n_exe += 1
            elif kind == "C":
                w = v
                hi16 = wnew >> 16
                lo16 = wnew & 0xFFFF
                ins = struct.unpack_from("<I", new_exe, idx)[0]
                struct.pack_into("<I", new_exe, idx, (ins & 0xFFFF0000) | hi16)
                ins2 = struct.unpack_from("<I", new_exe, idx + 4)[0]
                struct.pack_into("<I", new_exe, idx + 4, (ins2 & 0xFFFF0000) | lo16)
                n_exe += 1
        if n_exe:
            n_wsec = 0
            for i in range(0, len(new_exe), USZ):
                old_s = exe[i:i + USZ]
                new_s = bytes(new_exe[i:i + USZ])
                if old_s != new_s:
                    with open(disc, "r+b") as f:
                        f.seek((EXE_LBA0 + i // USZ) * RAW + UOFF)
                        f.write(new_s)
                    n_wsec += 1
            print("wrote %d EXE sectors (%d words)" % (n_wsec, n_exe))
        print("NOTE: re-run edcre (STEP 5).")


if __name__ == "__main__":
    main()

