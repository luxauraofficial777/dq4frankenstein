#!/usr/bin/env python3
"""g11_menu_residency_gate.py -- G11 menu-module residency gate (RC-2).

Wires the RAM miner's freeze forensics (RAM_MINER_INCIDENT_75fe6aff /
163_175, Sep-08) into a seal condition: a build may only be RELEASED after
paired RAM dumps captured on menu screens reached THROUGH a battle
transition prove the menu/message modules stay resident and structurally
clean. Checks per dump (file offset = ram_addr - 0x80000000):

  1. THREAD-CLOBBER  the disc-file-load thread signature ("hbd1ps1d") inside
     0x11000-0x13A00 = the message module was clobbered mid-DMA by the next
     HBD thread open (freeze #175 signature). FAIL.
  1b. DMA-TARGET GUARDRAIL (RAM_MINER_FORENSICS_006C_FREEZE §5/§8.2): the
     resident module slot 0x11000-0x13A00 must be BYTE-IDENTICAL across all
     paired dumps in the set -- async file-load threads may never write into
     it, and a mid-dialogue thread-open must not swap its content (freeze
     #175 vs #174: 971 dwords differ). Any divergence = FAIL.
  1c. FREEZE DISCRIMINATOR: look-ahead/terminal slot 0xF4F0A holding
     FE 06 FF 06 3C 07 is the proven freeze signature (healthy: 7D 07 7E 07
     7F 07). FAIL if present.
  2. MENU RESIDENCY  at least one held 0x48C (Font-1) word, i.e. the menu
     renderer is actually resident in the captured state. FAIL if zero
     (dump is not a post-battle menu state -- not a build defect, but the
     gate cannot vouch; re-capture).
  3. STRUCTURE       held words for TIDs {048B,048C,048F,0479,047B,047C,047D}:
     any NEGATIVE-BIT word (tree-header pointer, the railroaded-dispatch
     class 0x48C00040/0x48C00080), any PAST-END word (the G9 bare-table
     band), or any word MID on the current tree AND START on the pristine
     lineage tree (missed remap) FAILs. Multi-tree rule identical to G6.
     006C is deliberately excluded (its dispatch words are text-relative,
     e.g. sid 1 start = 0x006C0247 with NO hts*8 subtraction).
  4. STAGING         if the message staging pool tail 0xF4DE8-0xF4F10 holds
     staged content, at least one pointer ref to 0x800F4DE8 must exist
     (healthy dumps: 4). Zero refs with staged content = the staging-cursor
     teardown class of freeze #174/#175. FAIL.

Usage:
  python study/g11_menu_residency_gate.py --disc <master> \
      --ram dump1.bin dump2.bin --record build/G11_PASS.json
Exit 0 = PASS (record written), 1 = FAIL.
"""
import argparse
import hashlib
import json
import os
import struct
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
sys.path.insert(0, os.path.join(ROOT, "psx_tools"))

from hbe.huffman.dq4 import DQ4Schema                      # noqa: E402
import patch_battle_overlay as PBO                         # noqa: E402
import patch_overlay_refs as POR                           # noqa: E402
import dq4_hbd_patcher as P                                # noqa: E402

RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA, EXE_SECTORS = 24, 338
EXE_BLOCKS = {0x48C: 0x97AC8, 0x48F: 0x99624}
RAM_BASE = 0x80000000

MENU_TIDS = (0x48B, 0x48C, 0x48F, 0x479, 0x47B, 0x47C, 0x47D)
WHITELIST_RAM = {0x48B1326F, 0x48C04475, 0x48C01420}   # G6 RAM baselines

STAGE_LO, STAGE_HI = 0xF4DE8, 0xF4F10     # staging pool tail (file offsets)
STAGE_HEAD = 0x800F4DE8
CLOBBER_ZONE = (0x11000, 0x13A00)
CLOBBER_SIG = b"hbd1ps1d"
# DMA-TARGET GUARDRAIL: the resident overlay module slot. No asynchronous
# file-load thread may target or write here; module content must be static
# across paired captures.
MODULE_ZONE = (0x11000, 0x13A00)
# Look-ahead/terminal slot freeze signature (forensics §1.1 item 6; offset
# re-measured on the raw dumps: healthy holds FD 06 FE 06 FF 06 at 0xF4F10,
# freeze holds FE 06 FF 06 3C 07).
FREEZE_DISCRIMINATOR = b"\xFE\x06\xFF\x06\x3C\x07"
FREEZE_DISCRIMINATOR_OFF = 0xF4F10

SC = DQ4Schema()


def _block_meta(blk):
    end, bid, hts, tre, txe, unk = struct.unpack_from("<6I", blk, 0)
    ts, tm, nn = struct.unpack_from("<IIH", blk, txe)
    tree = SC.parse_tree(bytes(blk[ts:ts + 4 * nn + 6]))
    leaves = SC.decode(blk[hts:txe], tree)
    offs = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]
    return {"offs": offs, "c": hts * 8, "end": (txe - hts) * 8,
            "starts": set(offs)}


def build_trees(disc):
    """current-tree + pristine-lineage START sets for the multi-tree rule."""
    cur, lin = {}, {}
    # 048B battle overlay
    sec, off, hdr = PBO.find_block_048b(disc)
    if sec is not None:
        cur[0x48B] = _block_meta(POR.read_block_bytes(disc, sec, off, hdr[0]))
    # EXE-resident
    def _rd(lba, nsec):
        out = bytearray()
        with open(disc, "rb") as f:
            for s in range(lba, lba + nsec):
                f.seek(s * RAW + UOFF)
                out.extend(f.read(USZ))
        return bytes(out[:nsec * USZ])
    exe = _rd(EXE_LBA, EXE_SECTORS)
    for bid, foff in EXE_BLOCKS.items():
        end, bidw, hts, te, txe, unk = struct.unpack_from("<6I", exe, foff)
        if (bidw & 0xFFFF) == bid:
            cur[bid] = _block_meta(exe[foff:foff + end])
    # archive blocks (menu/facility family)
    for bid in (0x479, 0x47B, 0x47C, 0x47D):
        asec, aoff, ahdr = POR.find_block_anywhere(disc, bid)
        if asec is not None:
            cur[bid] = _block_meta(POR.read_block_bytes(disc, asec, aoff, ahdr[0]))
    # lineage = pristine copies of the same blocks
    base = None
    for cand in (os.path.join(os.path.dirname(ROOT),
                              "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"),
                 os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")):
        if os.path.exists(cand):
            base = cand
            break
    if base is None:
        print("  [WARN] pristine disc not found -- lineage rule degraded")
    else:
        bsec, boff, bhdr = PBO.find_block_048b(base)
        if bsec is not None:
            lin[0x48B] = _block_meta(POR.read_block_bytes(base, bsec, boff, bhdr[0]))
        with open(base, "rb") as f:
            f.seek(EXE_LBA * RAW + UOFF)
            raw = f.read(EXE_SECTORS * RAW)
        bexe = b"".join(raw[i * RAW + UOFF:i * RAW + UOFF + USZ]
                        for i in range(EXE_SECTORS))[:EXE_SECTORS * USZ]
        for bid, foff in EXE_BLOCKS.items():
            end, bidw, hts, te, txe, unk = struct.unpack_from("<6I", bexe, foff)
            if (bidw & 0xFFFF) == bid:
                try:
                    lin[bid] = _block_meta(bexe[foff:foff + end])
                except Exception:
                    pass
        for bid in (0x479, 0x47B, 0x47C, 0x47D):
            asec, aoff, ahdr = POR.find_block_anywhere(base, bid)
            if asec is not None:
                lin[bid] = _block_meta(POR.read_block_bytes(base, asec, aoff, ahdr[0]))
    return cur, lin


def classify(word, cur, lin):
    bid = word >> 20
    m = cur.get(bid)
    if m is None:
        return "OTHER-TID"
    bit = (word & 0xFFFFF) - m["c"]
    if bit < 0:
        # RC-2 (RAM_MINER_FORENSICS_006C_FREEZE §2/§8): a negative bit offset
        # after the hts*8 adjustment points INSIDE the Huffman tree header --
        # the railroaded-dispatch class that caused the 006C/Cynthia freeze
        # (0x48C00040 -> bit -128, 0x48C00080 -> bit -64). Structural FAIL.
        # NOTE: does not apply to 006C, whose dispatch words are text-relative
        # (sid 1 start = 0x006C0247 exactly); 006C is deliberately excluded
        # from MENU_TIDS.
        return "NEGATIVE-BIT"
    if bit >= m["end"]:
        return "PAST-END"
    if bit in m["starts"]:
        return "START"
    lm = lin.get(bid)
    if lm is not None and ((word & 0xFFFFF) - lm["c"]) in lm["starts"]:
        return "MID-LINEAGE-START"
    return "MID-noise"


def check_dump(path, cur, lin):
    data = open(path, "rb").read()
    name = os.path.basename(path)
    fails, notes = [], []
    # 1. thread clobber
    lo, hi = CLOBBER_ZONE
    if CLOBBER_SIG in data[lo:hi]:
        fails.append("THREAD-CLOBBER: file-thread signature in 0x%X-0x%X "
                     "(message module clobbered mid-DMA)" % (lo, hi))
    # 1c. freeze discriminator
    if data[FREEZE_DISCRIMINATOR_OFF:
           FREEZE_DISCRIMINATOR_OFF + len(FREEZE_DISCRIMINATOR)] \
            == FREEZE_DISCRIMINATOR:
        fails.append("FREEZE-DISCRIMINATOR: terminal slot 0x%X holds "
                     "FE06 FF06 3C07 (proven freeze signature)" %
                     FREEZE_DISCRIMINATOR_OFF)
    # module snapshot for the paired DMA-target guardrail (checked in main)
    module = data[MODULE_ZONE[0]:MODULE_ZONE[1]]
    # 2 + 3. census and structure
    counts = {t: 0 for t in MENU_TIDS}
    past, mids, negs = [], [], []
    for al in (0, 2):
        for o in range(al, len(data) - 4, 2):
            v = struct.unpack_from("<I", data, o)[0]
            bid = v >> 20
            if bid in counts and (v & 0xFFFFF):
                counts[bid] += 1
                if v in WHITELIST_RAM:
                    continue
                cls = classify(v, cur, lin)
                if cls == "NEGATIVE-BIT":
                    negs.append((o, v))
                elif cls == "PAST-END":
                    past.append((o, v))
                elif cls == "MID-LINEAGE-START":
                    mids.append((o, v))
    if counts[0x48C] == 0:
        fails.append("MENU-RESIDENCY: zero held 0x48C words -- not a menu state")
    else:
        notes.append("menu resident (48C=%d 479=%d 47B=%d 47C=%d 47D=%d)"
                     % (counts[0x48C], counts[0x479], counts[0x47B],
                        counts[0x47C], counts[0x47D]))
    if negs or past:
        # REPORT-ONLY telemetry: healthy talk/search states hold hundreds of
        # bare-table / module-code dwords that read as NEGATIVE-BIT or
        # PAST-END under the dispatch convention (measured on #173: 202 neg /
        # 782 past). Only MID+lineage-START is a proven missed remap (G6).
        notes.append("dispatch-word telemetry: NEG-BIT=%d PAST-END=%d "
                     "(ambient bare-table/module data, report-only)"
                     % (len(negs), len(past)))
    if mids:
        fails.append("MID-held lineage-START words: %d, e.g. %s" % (
            len(mids), "; ".join("@0x%06X 0x%08X" % w for w in mids[:5])))
    # 4. staging cursor -- report-only unless the freeze discriminator fired:
    # the pool tail always carries terminal residue (healthy #161 holds
    # 7D07 7E07 7F07), so "staged" alone is not a defect signal.
    staged = any(b != 0 for b in data[STAGE_LO:STAGE_HI])
    if staged:
        head = struct.pack("<I", STAGE_HEAD)
        nrefs = data.count(head)
        notes.append("pool tail non-zero, %d refs to staging head 0x%08X"
                     % (nrefs, STAGE_HEAD))
    return name, counts, fails, notes, module


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_sovereign_master.bin"))
    ap.add_argument("--ram", nargs="+", required=True, help="post-battle menu RAM dumps")
    ap.add_argument("--record", default=os.path.join(ROOT, "build", "G11_PASS.json"))
    args = ap.parse_args()

    print("=" * 70)
    print("  G11 MENU-MODULE RESIDENCY GATE: %d dumps" % len(args.ram))
    print("=" * 70)
    cur, lin = build_trees(args.disc)
    print("  trees built: current=%s lineage=%s" %
          (sorted(hex(k) for k in cur), sorted(hex(k) for k in lin)))
    overall = 0
    results = {}
    modules = {}
    for d in args.ram:
        name, counts, fails, notes, module = check_dump(d, cur, lin)
        modules[name] = module
        status = "PASS" if not fails else "FAIL"
        if fails:
            overall = 1
        results[name] = {"status": status, "fails": fails, "notes": notes,
                         "counts": {"0x%03X" % k: v for k, v in counts.items()}}
        print("  %s [%s] %s" % (name[:52], status,
                                " | ".join(notes) if notes else ""))
        for f_ in fails:
            print("    - %s" % f_)
    # 1b. DMA-target guardrail: paired module-slot comparison
    if len(modules) >= 2:
        ref_name = next(iter(modules))
        ref = modules[ref_name]
        for name, mod in modules.items():
            if name == ref_name:
                continue
            if mod != ref:
                ndiff = sum(1 for a, b in zip(ref, mod) if a != b) // 4
                overall = 1
                results[name]["fails"].append(
                    "DMA-TARGET GUARDRAIL: module slot 0x%X-0x%X diverges "
                    "from %s (%d dwords differ) -- a file-load thread wrote "
                    "into the resident module space" % (
                        MODULE_ZONE[0], MODULE_ZONE[1], ref_name, ndiff))
                print("  DMA-TARGET GUARDRAIL [FAIL] %s vs %s: %d dwords "
                      "differ in module slot" % (name, ref_name, ndiff))
            else:
                print("  DMA-TARGET GUARDRAIL [ok] %s == %s (module slot "
                      "static across captures)" % (name, ref_name))
    if overall == 0:
        rec = {"disc": os.path.abspath(args.disc),
               "disc_sha256_16": hashlib.sha256(open(args.disc, "rb").read())
               .hexdigest().upper()[:16],
               "generated": datetime.now().isoformat(timespec="seconds"),
               "dumps": results, "verdict": "PASS"}
        os.makedirs(os.path.dirname(args.record), exist_ok=True)
        with open(args.record, "w", encoding="utf-8") as f:
            json.dump(rec, f, ensure_ascii=False, indent=1)
        print("  [G11 PASS] recorded -> %s" % args.record)
    else:
        print("  [G11 FAIL] seal blocked")
    return overall


if __name__ == "__main__":
    sys.exit(main())
