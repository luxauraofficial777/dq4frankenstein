#!/usr/bin/env python3
"""remap_bare_pages.py â€” remap the 048B bare-offset page table (Class D fix).

Table: 94 rows, stride 8, user 0x4E8CCD8..0x4E8CFC4 (archive sec 40217,
disc LBA 40579). Row = (u32 bit_offset, u32 aux). bit_offset = leaf boundary
inside block 048B's code stream (engine composes (0x48B<<20)|(bit + hts*8)).
Most rows are PAGE STARTS (bit boundary right after the Nth control code of
the row's sid); some are exact sequence starts (N=0).

Fix: for each row, find (sid, N) in the PRISTINE encoding, then emit the bit
offset of the boundary right after the Nth control leaf of the SAME sid in
the WIP (re-encoded) block.
"""
import sys, os, struct, bisect, argparse
sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
sys.path.insert(0, os.path.join(ROOT, "psx_tools"))
import dq4_hbd_patcher as P
from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.node import NodeType
from dq4.textblock import TextBlock

RAW, UOFF, USZ = 2352, 24, 2048
PRISTINE = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
WIP = os.path.join(ROOT, "build", "dq4_rebuildC_wip.bin")
TBL_LO, TBL_HI = 0x4E8CCD8, 0x4E8CFC4  # inclusive first-row offset .. last-row offset
TBL_SECTOR = TBL_LO // USZ  # 40217 — the table lives in this user-data sector
EXPECTED_ROW_CHANGES = 18   # exactly 18 of 94 rows must remap for Chapter 1 stat-growth/level-up


def user_data(path):
    data = open(path, "rb").read()
    n = len(data) // RAW
    return b"".join(data[i * RAW + UOFF: i * RAW + UOFF + USZ] for i in range(n))


def get_048b(u):
    sig = struct.pack("<II", 0x48B, 24)
    idx = u.find(sig, 100000 * USZ)
    hdr_off = idx - 4
    end = struct.unpack_from("<I", u, hdr_off)[0]
    blk = u[hdr_off: hdr_off + end]
    tb = TextBlock(blk)
    sc = DQ4Schema()
    base, mid, _root = struct.unpack_from("<IIH", blk, tb.e)
    tlen = (mid - base + 1) * 2
    tree = sc.parse_tree(blk[base: base + tlen])
    leaves = sc.decode(blk[tb.c: tb.e], tree)
    seq_offs = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]
    return blk, tb, tree, leaves, seq_offs


def leaf_codes(tree):
    """DFS leaf -> bit string."""
    out = {}

    def walk(node, code):
        if node.node_type == NodeType.Branch:
            walk(node.children[0], code + "0")
            walk(node.children[1], code + "1")
        else:
            out[id(node)] = code
    walk(tree, "")
    return out


def leaf_bit_offsets(leaves, codes):
    offs = []
    pos = 0
    for lf in leaves:
        offs.append(pos)
        pos += len(codes[id(lf)])
    return offs


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--pristine", default=PRISTINE, help="pristine Japanese image")
    ap.add_argument("--disc", default=WIP, help="image holding the re-encoded 048B block")
    ap.add_argument("--standalone-words", action="store_true", default=True,
                    help="also remap standalone 0x48B data-table words missed by the sweep "
                         "(pristine-START -> new boundary by (sid, ctl) identity; G2 closure)")
    ap.add_argument("--no-words", dest="standalone_words", action="store_false")
    args = ap.parse_args()

    pr = user_data(args.pristine)
    wi = user_data(args.disc)
    blk_p, tb_p, tree_p, leaves_p, seq_p = get_048b(pr)
    blk_w, tb_w, tree_w, leaves_w, seq_w = get_048b(wi)
    print("pristine seqs %d, wip seqs %d" % (len(seq_p), len(seq_w)))
    if len(seq_w) == len(seq_p) + 1:
        seq_w = seq_w[: len(seq_p)]  # trailing padding artifact (patch-verified)
    if len(seq_p) != len(seq_w):
        raise SystemExit("[FAIL] sid count drift")
    cp = leaf_codes(tree_p)
    cw = leaf_codes(tree_w)
    lo_p = leaf_bit_offsets(leaves_p, cp)
    lo_w = leaf_bit_offsets(leaves_w, cw)
    off_p = {o: k for k, o in enumerate(lo_p)}
    off_w = {o: k for k, o in enumerate(lo_w)}
    end_bit_p = lo_p[-1] + len(cp[id(leaves_p[-1])])
    end_bit_w = lo_w[-1] + len(cw[id(leaves_w[-1])])
    print("pristine code bits %d, wip %d" % (end_bit_p, end_bit_w))

    rows = []
    o = TBL_LO
    while o <= TBL_HI:
        v, aux = struct.unpack_from("<II", pr, o)
        rows.append((o, v, aux))
        o += 8
    print("rows: %d" % len(rows))

    # map each pristine row value -> (sid, ctl_index)
    mapping = []
    bad = 0
    for o, v, aux in rows:
        if v == 0:
            mapping.append((o, v, aux, None, None))
            continue
        k = off_p.get(v)
        if k is None:
            print("  row @0x%X v=0x%X NOT a leaf boundary" % (o, v))
            bad += 1
            mapping.append((o, v, aux, None, None))
            continue
        sid = bisect.bisect_right(seq_p, v) - 1
        s_start_leaf = off_p[seq_p[sid]]
        s_end_leaf = off_p[seq_p[sid + 1]] if sid + 1 < len(seq_p) else len(leaves_p)
        ctl = sum(1 for j in range(s_start_leaf, k)
                  if leaves_p[j].node_type == NodeType.ControlCharacter)
        mapping.append((o, v, aux, sid, ctl))
    print("unmappable rows: %d" % bad)

    # new values
    changes = 0
    out = bytearray(wi)
    for o, v, aux, sid, ctl in mapping:
        if sid is None:
            continue
        w_start_leaf = off_w[seq_w[sid]]
        w_end_leaf = off_w[seq_w[sid + 1]] if sid + 1 < len(seq_w) else len(leaves_w)
        # find boundary after the ctl'th control leaf within sid (ctl=0 -> seq start)
        nv = None
        if ctl == 0:
            nv = seq_w[sid]
        else:
            c = 0
            for j in range(w_start_leaf, w_end_leaf):
                if leaves_w[j].node_type == NodeType.ControlCharacter:
                    c += 1
                    if c == ctl:
                        nv = lo_w[j + 1] if j + 1 < len(lo_w) else end_bit_w
                        break
            if nv is None:
                print("  row @0x%X sid %d ctl %d: not enough controls in wip sid" % (o, sid, ctl))
                continue
        cur = struct.unpack_from("<I", out, o)[0]
        if cur != nv:
            print("  row @0x%X sid %3d ctl %2d: 0x%05X -> 0x%05X (aux 0x%08X)"
                  % (o, sid, ctl, cur, nv, aux))
            struct.pack_into("<I", out, o, nv)
            changes += 1
    print("rows changed: %d / %d" % (changes, len(mapping)))
    row_changes = changes  # save before standalone words are added

    # Enforce 362-sector offset: table must be at LBA 40217, not 40579/40580.
    # A drift of +362 sectors would land writes in the wrong disc region.
    assert TBL_SECTOR == 40217, (
        "[FAIL] table sector drift: expected LBA 40217, got %d (offset base corrupted)"
        % TBL_SECTOR)

    # ---- standalone 0x48B data-table words (G2 closure: missed-remap population) ----
    if args.standalone_words:
        import patch_table_refs as R
        arch = bytes(wi)
        row_positions = {o for o, _v, _a, _s, _c in mapping}  # page-table rows: already handled
        blocks = R.hbd.scan_blocks(arch)
        subs = R.hbd.sub_blocks(blocks)
        TABLE_TYPES = {(10, 1280), (13, 1280), (25, 1280), (44, 1280), (44, 0), (40, 0), (26, 0), (42, 0)}
        subs_sorted = sorted((s["off"], s["dlen"], b, s) for b, s in subs)
        wchanges = 0
        for so, dl, b, s in subs_sorted:
            if (s["type"], s["flags"]) not in TABLE_TYPES:
                continue
            for pos in range(so, min(so + dl, len(wi)) - 4, 4):
                if pos in row_positions:
                    continue
                v = struct.unpack_from("<I", out, pos)[0]
                if (v >> 20) != 0x48B:
                    continue
                bit = v & 0xFFFFF
                if bit == 0:
                    continue
                # pristine-match guard: only remap untouched pristine words, never
                # values an earlier remap pass already rewrote (sweep precedent).
                if struct.unpack_from("<I", pr, pos)[0] != v:
                    continue
                # ONLY dangling words: pristine dispatch boundary (START) that now
                # decodes MID on the current tree. Words already START/PAST-END on
                # the new tree were remapped correctly (or are non-dispatch data).
                _k2 = bisect.bisect_left(seq_w, bit)
                if _k2 < len(seq_w) and seq_w[_k2] == bit:
                    continue  # already a valid boundary on the new tree
                if bit >= end_bit_w:
                    continue  # past-end tail: structural
                _k = off_p.get(bit)
                if _k is None:
                    continue  # not a pristine boundary -> non-dispatch data
                k = _k
                sid = bisect.bisect_right(seq_p, bit) - 1
                s_start_leaf = off_p[seq_p[sid]]
                s_end_leaf = off_p[seq_p[sid + 1]] if sid + 1 < len(seq_p) else len(leaves_p)
                ctl = sum(1 for j in range(s_start_leaf, k)
                          if leaves_p[j].node_type == NodeType.ControlCharacter)
                w_start_leaf = off_w[seq_w[sid]]
                w_end_leaf = off_w[seq_w[sid + 1]] if sid + 1 < len(seq_w) else len(leaves_w)
                nv = None
                if ctl == 0:
                    nv = seq_w[sid]
                else:
                    c = 0
                    for j in range(w_start_leaf, w_end_leaf):
                        if leaves_w[j].node_type == NodeType.ControlCharacter:
                            c += 1
                            if c == ctl:
                                nv = lo_w[j + 1] if j + 1 < len(lo_w) else end_bit_w
                                break
                if nv is None or nv == bit:
                    continue
                struct.pack_into("<I", out, pos, nv)
                print("  word @0x%X sid %3d ctl %2d: 0x%05X -> 0x%05X"
                      % (pos, sid, ctl, bit, nv))
                wchanges += 1
        print("standalone words changed: %d" % wchanges)
        changes += wchanges

    if not args.write:
        print("REPORT ONLY")
        return
    if changes == 0:
        print("nothing to write")
        return
    with open(args.disc, "r+b") as f:
        nsec = len(out) // USZ
        for s in range(nsec):
            old = wi[s * USZ: (s + 1) * USZ]
            new = out[s * USZ: (s + 1) * USZ]
            if old != new:
                # user_data() slices from disc sector 0: stream index == disc LBA
                f.seek(s * RAW + UOFF)
                f.write(new)
    print("written to", args.disc)

    # Readback verification: re-read each written sector and assert equality.
    written_sectors = []
    with open(args.disc, "r+b") as f:
        nsec = len(out) // USZ
        for s in range(nsec):
            old = wi[s * USZ: (s + 1) * USZ]
            new = out[s * USZ: (s + 1) * USZ]
            if old != new:
                f.seek(s * RAW + UOFF)
                rb = f.read(USZ)
                if rb != bytes(new):
                    print("[FAIL] readback mismatch at LBA %d" % s)
                    sys.exit(1)
                written_sectors.append(s)
    print("  [PASS] readback verified for %d sectors" % len(written_sectors))

    # Assert exactly 18 row remaps (Chapter 1 stat-growth and level-up tables).
    if row_changes != EXPECTED_ROW_CHANGES:
        print("[FAIL] expected %d row changes, got %d" % (EXPECTED_ROW_CHANGES, row_changes))
        sys.exit(1)
    print("  [PASS] row-change count verified: %d rows" % row_changes)


if __name__ == "__main__":
    main()

