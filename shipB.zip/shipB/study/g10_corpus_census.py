#!/usr/bin/env python3
"""g10_corpus_census.py -- G10 per-disc-vs-corpus census gate (RC-2).

Closes the blind spot that let 047D's spoken sids ship as silent Japanese:
G2 only arbitrates referrer words for a handful of dispatch blocks, and no
gate ever re-decoded the BUILT disc against the corpus. G10 decodes every
corpus block on the built disc and flags ANY sid whose disc text decodes as
Japanese (kana/kanji) while the corpus specifies non-trivial English.

Decoding uses the same machinery as the harvest (psx_tools dq4 hbd /
textblock / HuffmanTree, LZSS-aware), so the sid<->sequence alignment is the
harvest convention: corpus sid N = N-th END-terminated string. Block copy
precedence mirrors the build lanes: EXE-resident 048C/048D/048F at their
pinned offsets, then 048B (battle-overlay byte locator), then the HBD
archive (LBA 362+, compressed or raw), then raw embedded duplicates in the
overlay region (never shadowing an earlier copy).

Classification per (block, sid):
  OK           disc text has no kana/kanji (or corpus EN is trivial)
  FALLBACK     disc text contains kana/kanji but corpus EN has visible letters
               -> the exact silent-JP class (FAIL, unless whitelisted)
  MISSING-SEQ  disc block has fewer sequences than the corpus sid index (FAIL)
  UNDECODABLE  block copy found but will not parse (FAIL)
  NOT-FOUND    block id located nowhere on the disc (FAIL)
  TRIVIAL-EN   corpus EN empty / control-only / Dummy -> JP fallback is the
               designed behaviour (report only)
  WILD-TOKEN-DROPPED  a known freeze-token (7F06/7F10/7F19/7F1B/7F1C/7F1E/
                      7F35) present in the pristine EXE block is absent
                      from the built disc copy (FAIL — encoder must pass
                      these through verbatim, position-locked)

Usage:
  python study/g10_corpus_census.py --disc ship/build/dq4_sovereign_master.bin \
      --corpus translation/full_translation_boot_with_0069.json \
      --out study/G10_census_RC2.json
Exit 0 = PASS, 1 = FAIL.
"""
import argparse
import json
import os
import re
import struct
import sys
from datetime import datetime

sys.stdout.reconfigure(encoding="utf-8", line_buffering=True)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
# ship\study -> DQLOSTTRANSLATION\{translation-tools, psx_tools}
_PROJ = ROOT
for _ in range(4):
    if os.path.isdir(os.path.join(_PROJ, "psx_tools", "dq4")):
        break
    _PROJ = os.path.dirname(_PROJ)
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
if os.path.isdir(os.path.join(_PROJ, "psx_tools")):
    sys.path.insert(0, os.path.join(_PROJ, "psx_tools"))

from hbe.huffman.dq4 import DQ4Schema                      # noqa: E402,E402
from dq4 import hbd, textblock                             # noqa: E402
from dq4 import huffman as dq4huffman                      # noqa: E402
import patch_battle_overlay as PBO                         # noqa: E402
import patch_overlay_refs as POR                           # noqa: E402

try:
    from hbe.compression.lzss import lzss_uncompress
except Exception:
    lzss_uncompress = None

RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA, EXE_SECTORS = 24, 338
HBD_LBA = 362
EXE_BLOCKS = {0x48C: 0x97AC8, 0x48D: 0x9955C, 0x48F: 0x99624}
SC = DQ4Schema()

_TOKEN = re.compile(r"\{[0-9a-fA-F]{4}\}")
_ANG = re.compile(r"<[0-9a-fA-F]{4}>")

# The 7 EXE-resident wild freeze tokens (CONTROL_CODE_DEEP_AUDIT §2).
# These occur in 048C/048F with unknown semantics; encoder must pass them
# through verbatim.  If any are dropped on the built disc, the Font-1
# formatter desyncs.
WILD_FREEZE_TOKENS = {0x7F06, 0x7F10, 0x7F19, 0x7F1B, 0x7F1C, 0x7F1E, 0x7F35}

# Pristine wild-token counts per EXE block (from ctrl_census.json).
# Used as the reference: the built disc must preserve at least these counts.
PRISTINE_WILD_COUNTS = {
    0x48C: {0x7F06: 3, 0x7F10: 11},
    0x48F: {0x7F19: 10, 0x7F1B: 1, 0x7F1C: 13, 0x7F1E: 15, 0x7F35: 2},
}


def _has_kana(s):
    for ch in s:
        o = ord(ch)
        if 0x3040 <= o <= 0x30FF or 0x4E00 <= o <= 0x9FFF:
            return True
    return False


def visible_letters(s):
    return sum(ch.isalpha() and ch.isascii()
               for ch in _ANG.sub("", _TOKEN.sub("", s)))


# Deliberate-JP whitelist: (block_key, sid) pairs signed off by the user.
# Populated ONLY with explicit sign-off; start EMPTY.
WHITELIST = set()

# RC-2 scope deferral (Agent A sign-off study\AGENT_A_SIGNOFF_Sep08_2026.md,
# Builder decision Sep-08): the FALLBACK sids in these blocks are untranslated
# archive NPC dialogue in STEP-1 overflow-skip blocks (byte-identical pristine,
# EN cannot fit the slot) — deferred to a post-release content patch, not a
# rendering/dispatch bug. 0488 is rendered; its single fallback sid ships as
# known cosmetic (release-notes item).
WHITELIST_BLOCKS_FB = {"0020", "0026", "00d6", "0105", "0115", "0124",
                       "0186", "01aa", "01eb", "0488"}
# G10 locator limitation: embedded-only ids whose module-embedded copies are
# not decodable text blocks (deferred gate revision: hts=0 scanner).
WHITELIST_BLOCKS_NF = {"0480", "0485", "0486", "0487"}


def read_user_range(path, lba, nsec):
    out = bytearray()
    with open(path, "rb") as f:
        for s in range(lba, lba + nsec):
            f.seek(s * RAW + UOFF)
            out.extend(f.read(USZ))
    return bytes(out)


def load_block_bytes(disc, sec, off, length):
    # +4: the self-pointer dword sits AT offset `end`, and
    # TextBlock.invariants_hold() reads it -- a bare `end`-length slice
    # fails invariant_self_pointer (why the first probe lost 0474-0489).
    nsec = ((off + length + 4 + USZ - 1) // USZ) + 1
    blob = read_user_range(disc, sec, nsec)
    return blob[off:off + length + 4]


def index_raw_copies(disc, start_sector, exclude):
    """Header scan for raw embedded duplicates (overlay region)."""
    tot = os.path.getsize(disc) // RAW
    idx = {}
    CHUNK = 2048
    with open(disc, "rb") as f:
        for s_start in range(start_sector, tot, CHUNK):
            n_sec = min(CHUNK, tot - s_start)
            f.seek(s_start * RAW)
            raw = f.read(n_sec * RAW)
            for i in range(n_sec):
                u = raw[i * RAW + UOFF: i * RAW + UOFF + USZ]
                for off in range(0, USZ - 24, 4):
                    end, bid, hts, tre, txe, unk = struct.unpack_from("<6I", u, off)
                    b16 = bid & 0xFFFF
                    if b16 not in idx and b16 not in exclude and \
                            24 <= hts < txe < end <= 16384:
                        idx[b16] = (s_start + i, off, (end, bid, hts, tre, txe, unk))
    return idx


def collect_text_blocks(disc):
    """tid -> TextBlock, precedence: EXE > 048B > archive > raw duplicates."""
    tbs = {}
    # 1. EXE-resident
    exe = read_user_range(disc, EXE_LBA, EXE_SECTORS)
    for bid, foff in EXE_BLOCKS.items():
        try:
            end, tid, c, d, e, f6 = struct.unpack_from("<6I", exe, foff)
            if (tid & 0xFFFF) == bid:
                tb = textblock.TextBlock(exe[foff:foff + end + 4])
                if tb.invariants_hold():
                    tbs[bid] = tb
        except Exception:
            pass
    # 2. battle overlay
    sec, off, hdr = PBO.find_block_048b(disc)
    if sec is not None:
        try:
            tb = textblock.TextBlock(load_block_bytes(disc, sec, off, hdr[0]))
            if tb.invariants_hold():
                tbs[0x48B] = tb
        except Exception:
            pass
    # 3. HBD archive (LZSS-aware harvest machinery)
    tot = os.path.getsize(disc) // RAW
    buf = read_user_range(disc, HBD_LBA, tot - HBD_LBA)
    for bsec, sub in hbd.text_sub_blocks(hbd.scan_blocks(buf)):
        try:
            raw = hbd.sub_bytes(buf, sub)
            if sub.get("compressed") and lzss_uncompress:
                raw = lzss_uncompress(raw)
            tb = textblock.TextBlock(raw)
            if tb.invariants_hold():
                tbs.setdefault(tb.id, tb)
        except Exception:
            continue
    # 4. raw embedded duplicates (never shadow an earlier copy)
    for bid, (rsec, roff, rhdr) in index_raw_copies(disc, 1000, set(tbs)).items():
        try:
            tb = textblock.TextBlock(load_block_bytes(disc, rsec, roff, rhdr[0]))
            if tb.invariants_hold():
                tbs.setdefault(bid, tb)
        except Exception:
            continue
    return tbs


def count_ctrl_symbols(tb):
    """Return {ctrl_value: count} for all CTRL symbols in the block."""
    tree = dq4huffman.HuffmanTree(tb)
    symbols = tree.decode()
    counts = {}
    for kind, val in symbols:
        if kind == dq4huffman.CTRL:
            counts[val] = counts.get(val, 0) + 1
    return counts


def seq_texts(tb):
    tree = dq4huffman.HuffmanTree(tb)
    symbols = tree.decode()
    seqs, _residue = dq4huffman.split_strings(symbols)
    dict_n = sum(1 for k, _v in symbols if k == dq4huffman.DICT)
    other_n = sum(1 for k, _v in symbols if k != dq4huffman.DICT)
    # DICT-BLOCK test: dictionary refs dominate the symbol stream -> the
    # block is a word/facility table served through the D2/D3/D4 fold lanes
    # (its corpus text is the RESOLVED form; the archive copy legitimately
    # stays JP). Reported separately, never counted as a text FALLBACK.
    is_dict_block = other_n and (dict_n / max(1, dict_n + other_n)) > 0.15
    return [dq4huffman.render(s) for s in seqs], is_dict_block


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_sovereign_master.bin"))
    ap.add_argument("--corpus", default=os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json"))
    ap.add_argument("--out", default=os.path.join(ROOT, "study", "G10_census_RC2.json"))
    args = ap.parse_args()

    corpus = json.load(open(args.corpus, encoding="utf-8"))
    print("=" * 70)
    print("  G10 DISC-vs-CORPUS CENSUS: %s" % os.path.basename(args.disc))
    print("  corpus: %s  (%d blocks)" % (os.path.basename(args.corpus), len(corpus)))
    print("=" * 70)

    tbs = collect_text_blocks(args.disc)
    print("  disc text blocks collected: %d" % len(tbs))

    report = {"disc": os.path.abspath(args.disc),
              "corpus": os.path.abspath(args.corpus),
              "generated": datetime.now().isoformat(timespec="seconds"),
              "blocks": {}, "summary": {}}
    n_ok = n_fallback = n_fail_other = n_trivial = n_blocks_gap = 0
    n_dictfb = 0
    n_wild_dropped = 0
    fail_blocks = []
    dictfb_blocks = []
    wild_dropped_blocks = []

    for bid_key, entry in sorted(corpus.items()):
        if not isinstance(entry, dict):
            continue
        try:
            bid = int(bid_key, 16)
        except ValueError:
            continue
        sids = {}
        for sid, sv in entry.items():
            if not str(sid).isdigit() or not isinstance(sv, dict):
                continue
            en = sv.get("translation") or sv.get("en") or ""
            if en:
                sids[int(sid)] = en

        tb = tbs.get(bid)
        bstat = {"located": tb is not None, "decode": None,
                 "n_seqs": None, "dict_block": False, "flags": {}}
        texts = None
        is_dict_block = False
        if tb is None and bid_key.lower() in WHITELIST_BLOCKS_NF:
            # signed-off scanner limitation (embedded-only id) — report only
            bstat["decode"] = "NOT-FOUND(whitelisted)"
        if tb is None:
            if bstat["decode"] is None:
                bstat["decode"] = "NOT-FOUND"
        else:
            try:
                texts, is_dict_block = seq_texts(tb)
                bstat["decode"] = "OK"
                bstat["n_seqs"] = len(texts)
                bstat["dict_block"] = is_dict_block
            except Exception as e:
                bstat["decode"] = "UNDECODABLE: %s" % e

        block_fails = {}
        dict_fails = {}
        for sid in sorted(sids):
            en = sids[sid]
            if visible_letters(en) < 2:
                n_trivial += 1
                continue
            if texts is None:
                if (bstat["decode"] or "").startswith("NOT-FOUND") and \
                        bid_key.lower() in WHITELIST_BLOCKS_NF:
                    n_ok += 1
                    block_fails[str(sid)] = "NOT-FOUND(whitelisted)"
                    continue
                cls = "NOT-FOUND" if bstat["decode"] == "NOT-FOUND" \
                    else ("UNDECODABLE" if (bstat["decode"] or "").startswith("UNDECODABLE")
                          else bstat["decode"])
            elif sid > len(texts):
                cls = "MISSING-SEQ"
            else:
                cls = "FALLBACK" if _has_kana(texts[sid - 1]) else "OK"
            if cls == "OK":
                n_ok += 1
            elif cls == "FALLBACK" and is_dict_block:
                # fold-lane scope: surfaced, not a build failure
                n_dictfb += 1
                dict_fails[str(sid)] = "DICT-CLASS"
            elif cls == "FALLBACK" and bid_key.lower() in WHITELIST_BLOCKS_FB:
                # signed-off scope deferral (untranslated archive NPC dialogue,
                # overflow-skip blocks — post-release content patch)
                n_ok += 1
                block_fails[str(sid)] = "FALLBACK(whitelisted)"
            elif cls == "FALLBACK":
                if (bid_key.lower(), sid) in WHITELIST:
                    n_ok += 1
                    block_fails[str(sid)] = "FALLBACK(whitelisted)"
                else:
                    n_fallback += 1
                    block_fails[str(sid)] = "FALLBACK"
            else:
                n_fail_other += 1
                block_fails[str(sid)] = cls
        # --- WILD-TOKEN-DROPPED check for EXE-resident blocks ---
        if bid in PRISTINE_WILD_COUNTS and tb is not None:
            try:
                disc_ctrl = count_ctrl_symbols(tb)
                wild_missing = {}
                for tok, pristine_n in PRISTINE_WILD_COUNTS[bid].items():
                    disc_n = disc_ctrl.get(tok, 0)
                    if disc_n < pristine_n:
                        wild_missing["%04X" % tok] = {
                            "pristine": pristine_n,
                            "disc": disc_n,
                        }
                if wild_missing:
                    bstat["wild_token_dropped"] = wild_missing
                    wild_dropped_blocks.append(bid_key)
                    n_wild_dropped += len(wild_missing)
            except Exception as e:
                bstat["wild_token_check_error"] = str(e)

        if block_fails or dict_fails:
            if block_fails:
                fail_blocks.append(bid_key)
                n_blocks_gap += 1
            bstat["flags"] = block_fails
            if dict_fails:
                dictfb_blocks.append(bid_key)
                bstat["dict_flags"] = dict_fails
        report["blocks"][bid_key] = bstat

    report["summary"] = {
        "ok": n_ok, "fallback": n_fallback,
        "missing_seq_or_undecodable_or_notfound": n_fail_other,
        "dict_class_fallback": n_dictfb,
        "dict_class_blocks": dictfb_blocks[:80],
        "trivial_en_skipped": n_trivial,
        "blocks_with_failures": n_blocks_gap,
        "fail_blocks": fail_blocks[:200],
        "wild_token_dropped": n_wild_dropped,
        "wild_token_dropped_blocks": wild_dropped_blocks[:80],
    }
    with open(args.out, "w", encoding="utf-8") as f:
        json.dump(report, f, ensure_ascii=False, indent=1)
    print("  sids OK: %d   FALLBACK: %d   MISSING/UNDECODABLE/NOT-FOUND: %d   "
          "DICT-CLASS (report-only): %d   trivial-EN skipped: %d"
          % (n_ok, n_fallback, n_fail_other, n_dictfb, n_trivial))
    if dictfb_blocks:
        print("  DICT-CLASS blocks (fold-lane scope, report-only): %s"
              % ", ".join(dictfb_blocks[:30]))
    if wild_dropped_blocks:
        print("  WILD-TOKEN-DROPPED blocks (FAIL): %s"
              % ", ".join(wild_dropped_blocks[:30]))
        for bid_key in wild_dropped_blocks[:10]:
            wt = report["blocks"][bid_key].get("wild_token_dropped", {})
            detail = ", ".join("%s (%d->%d)" % (k, v["pristine"], v["disc"])
                              for k, v in wt.items())
            print("    %s: %s" % (bid_key, detail))
    for bid_key in fail_blocks[:40]:
        fl = report["blocks"][bid_key]["flags"]
        sample = ", ".join("%s=%s" % (k, v) for k, v in list(fl.items())[:6])
        print("    %s: %s%s" % (bid_key, sample,
              " (+%d more)" % (len(fl) - 6) if len(fl) > 6 else ""))
    print("  report: %s" % args.out)
    ok = (n_fallback == 0 and n_fail_other == 0 and n_wild_dropped == 0)
    print("  [G10 %s]" % ("PASS" if ok else "FAIL"))
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
