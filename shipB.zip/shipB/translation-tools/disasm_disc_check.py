#!/usr/bin/env python3
"""
disasm_disc_check.py — Disassemble DW7 EXE around disc-check addresses
to find the exact comparison instruction that rejects the HBD archive.

Targets the 6 known patch sites and surrounding code to identify:
- The handshake check point (beq/bne that branches to "Insert Disc")
- The expected value being compared against
- The actual value from our hybrid HBD
"""
import struct
import os
import sys

EXE_PATH = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "translation", "SLUSP012.06")

# MIPS register names
REG_NAMES = ["zero","at","v0","v1","a0","a1","a2","a3",
             "t0","t1","t2","t3","t4","t5","t6","t7",
             "s0","s1","s2","s3","s4","s5","s6","s7",
             "t8","t9","k0","k1","gp","sp","fp","ra"]

def reg(n):
    return f"${REG_NAMES[n]}" if 0 <= n < 32 else f"${n}"

def disasm_one(instr, pc):
    """Minimal MIPS disassembler for R/I/J types — enough for disc-check analysis."""
    op = (instr >> 26) & 0x3F
    rs = (instr >> 21) & 0x1F
    rt = (instr >> 16) & 0x1F
    rd = (instr >> 11) & 0x1F
    shamt = (instr >> 6) & 0x1F
    funct = instr & 0x3F
    imm = instr & 0xFFFF
    simm = imm if imm < 0x8000 else imm - 0x10000
    target = instr & 0x3FFFFFF

    if instr == 0:
        return "nop"

    if op == 0:  # R-type
        if funct == 0x08:
            return f"jr {reg(rs)}"
        if funct == 0x09:
            return f"jalr {reg(rd)}, {reg(rs)}"
        if funct == 0x0C:
            return f"syscall"
        if funct == 0x21:
            return f"addu {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x23:
            return f"subu {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x24:
            return f"and {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x25:
            return f"or {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x26:
            return f"xor {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x27:
            return f"nor {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x2A:
            return f"slt {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x2B:
            return f"sltu {reg(rd)}, {reg(rs)}, {reg(rt)}"
        if funct == 0x00:
            if shamt:
                return f"sll {reg(rd)}, {reg(rt)}, {shamt}"
            return f"nop  # sll zero,zero,0"
        if funct == 0x03:
            return f"sra {reg(rd)}, {reg(rt)}, {shamt}"
        if funct == 0x07:
            return f"srav {reg(rd)}, {reg(rt)}, {reg(rs)}"
        if funct == 0x04:
            return f"sllv {reg(rd)}, {reg(rt)}, {reg(rs)}"
        if funct == 0x06:
            return f"srlv {reg(rd)}, {reg(rt)}, {reg(rs)}"
        if funct == 0x10:
            return f"mfhi {reg(rd)}"
        if funct == 0x12:
            return f"mflo {reg(rd)}"
        if funct == 0x11:
            return f"mthi {reg(rs)}"
        if funct == 0x13:
            return f"mtlo {reg(rs)}"
        if funct == 0x18:
            return f"mult {reg(rs)}, {reg(rt)}"
        if funct == 0x19:
            return f"multu {reg(rs)}, {reg(rt)}"
        if funct == 0x1A:
            return f"div {reg(rs)}, {reg(rt)}"
        if funct == 0x1B:
            return f"divu {reg(rs)}, {reg(rt)}"
        return f".word 0x{instr:08X}  # R-type funct=0x{funct:02X}"

    if op == 0x01:  # REGIMM
        if rt == 0x00:
            return f"bltz {reg(rs)}, 0x{pc + 4 + simm*4 + 4:08X}"
        if rt == 0x01:
            return f"bgez {reg(rs)}, 0x{pc + 4 + simm*4 + 4:08X}"
        if rt == 0x10:
            return f"bltzal {reg(rs)}, 0x{pc + 4 + simm*4 + 4:08X}"
        if rt == 0x11:
            return f"bgezal {reg(rs)}, 0x{pc + 4 + simm*4 + 4:08X}"
        return f".word 0x{instr:08X}  # REGIMM rt=0x{rt:02X}"

    if op == 0x02:
        return f"j 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x03:
        return f"jal 0x{(pc & 0xF0000000) | (target << 2):08X}"
    if op == 0x04:
        return f"beq {reg(rs)}, {reg(rt)}, 0x{pc + 4 + simm*4 + 4:08X}"
    if op == 0x05:
        return f"bne {reg(rs)}, {reg(rt)}, 0x{pc + 4 + simm*4 + 4:08X}"
    if op == 0x06:
        return f"blez {reg(rs)}, 0x{pc + 4 + simm*4 + 4:08X}"
    if op == 0x07:
        return f"bgtz {reg(rs)}, 0x{pc + 4 + simm*4 + 4:08X}"
    if op == 0x08:
        return f"addi {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x09:
        return f"addiu {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x0A:
        return f"slti {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x0B:
        return f"sltiu {reg(rt)}, {reg(rs)}, {simm}"
    if op == 0x0C:
        return f"andi {reg(rt)}, {reg(rs)}, 0x{imm:04X}"
    if op == 0x0D:
        return f"ori {reg(rt)}, {reg(rs)}, 0x{imm:04X}"
    if op == 0x0E:
        return f"xori {reg(rt)}, {reg(rs)}, 0x{imm:04X}"
    if op == 0x0F:
        return f"lui {reg(rt)}, 0x{imm:04X}"
    if op == 0x20:
        return f"lb {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x21:
        return f"lh {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x23:
        return f"lw {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x24:
        return f"lbu {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x25:
        return f"lhu {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x28:
        return f"sb {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x29:
        return f"sh {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x2B:
        return f"sw {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x32:
        return f"lwc2 {reg(rt)}, {simm}({reg(rs)})"
    if op == 0x3A:
        return f"swc2 {reg(rt)}, {simm}({reg(rs)})"

    return f".word 0x{instr:08X}  # op=0x{op:02X}"

# DW7 EXE load address
LOAD_ADDR = 0x80017F00
EXE_HEADER = 0x800

# Patch sites from patch_dw7_exe.py (text offsets, file offset = text + 0x800)
PATCH_SITES = [
    {"name": "disc_check_force_success", "text_off": 0x610F4, "ram": 0x80078FF4},
    {"name": "cd_init_force_success", "text_off": 0x60FA4, "ram": 0x80078EA4},
    {"name": "nop_timeout_check", "text_off": 0x614A4, "ram": 0x800793A4},
    {"name": "nop_error_path", "text_off": 0x614F8, "ram": 0x800793F8},
    {"name": "neutralize_disc_change_handler", "text_off": 0x387CC, "ram": 0x800506CC},
    {"name": "redirect_disc_trap_to_success", "text_off": 0x7308C, "ram": 0x8008AF8C},
]

# Additional addresses of interest from study docs
EXTRA_SITES = [
    {"name": "cd_bios_wrapper", "text_off": 0x7F914, "ram": 0x80097814},  # CD BIOS wrapper
    {"name": "huffman_decompress", "text_off": 0x5B770, "ram": 0x80073670},  # Huffman decompressor
    {"name": "post_disc_verify", "text_off": 0x72FF4, "ram": 0x8008AEF4},  # post disc verify
    {"name": "disc_number_var", "text_off": None, "ram": 0x800E3D90},  # disc number variable (in BSS)
]

CONTEXT_INSTRS = 40  # disassemble 40 instructions before and after each site

def main():
    if not os.path.exists(EXE_PATH):
        print(f"ERROR: EXE not found at {EXE_PATH}")
        return 1

    with open(EXE_PATH, "rb") as f:
        exe = f.read()

    print(f"DW7 EXE size: {len(exe)} bytes")
    print(f"EXE header: {EXE_HEADER} bytes")
    print(f"Text size: {len(exe) - EXE_HEADER} bytes")
    print(f"Load address: 0x{LOAD_ADDR:08X}")
    print(f"EXE end (RAM): 0x{LOAD_ADDR + len(exe) - EXE_HEADER:08X}")
    print()

    # Search for beq/bne instructions in the disc-check function range
    # The disc check function is around 0x80078EA4-0x80079400
    # Text offset range: 0x60FA4 - 0x61500
    print("=" * 80)
    print("DISC-CHECK FUNCTION ANALYSIS (0x80078EA4 - 0x80079400)")
    print("=" * 80)

    start_text = 0x60F00
    end_text = 0x61600
    start_file = start_text + EXE_HEADER
    end_file = end_text + EXE_HEADER

    pc = LOAD_ADDR + start_text
    for off in range(start_file, min(end_file, len(exe)), 4):
        instr = struct.unpack_from("<I", exe, off)[0]
        asm = disasm_one(instr, pc)
        # Mark branches and comparisons
        marker = ""
        op = (instr >> 26) & 0x3F
        if op in (0x04, 0x05):  # beq, bne
            marker = "  <<< BRANCH"
        elif op == 0x06 or op == 0x07:  # blez, bgtz
            marker = "  <<< BRANCH"
        elif op == 0x01:  # REGIMM (bltz/bgez)
            marker = "  <<< BRANCH"
        elif op == 0x02 or op == 0x03:  # j, jal
            marker = "  <<< JUMP"
        elif op == 0x0F:  # lui
            marker = "  <<< LUI"
        elif op == 0x23:  # lw
            marker = "  <<< LOAD"
        elif op == 0x0D:  # ori
            marker = "  <<< ORI"
        print(f"  0x{pc:08X}: {instr:08X}  {asm}{marker}")
        pc += 4

    print()

    # Now disassemble around each patch site
    for site in PATCH_SITES:
        print("=" * 80)
        print(f"PATCH SITE: {site['name']} (RAM 0x{site['ram']:08X})")
        print("=" * 80)

        text_off = site["text_off"]
        file_off = text_off + EXE_HEADER
        start = max(EXE_HEADER, file_off - CONTEXT_INSTRS * 4)
        end = min(len(exe), file_off + CONTEXT_INSTRS * 4)

        # Calculate RAM address for start
        start_text_off = start - EXE_HEADER
        pc = LOAD_ADDR + start_text_off

        for off in range(start, end, 4):
            instr = struct.unpack_from("<I", exe, off)[0]
            asm = disasm_one(instr, pc)
            marker = ""
            if off == file_off:
                marker = "  *** PATCH POINT ***"
            op = (instr >> 26) & 0x3F
            if op in (0x04, 0x05, 0x06, 0x07, 0x01):
                marker += "  <<< BRANCH"
            elif op in (0x02, 0x03):
                marker += "  <<< JUMP"
            elif op == 0x0F:
                marker += "  <<< LUI"
            elif op == 0x23:
                marker += "  <<< LOAD"
            print(f"  0x{pc:08X}: {instr:08X}  {asm}{marker}")
        print()

    # Search for beq/bne with specific patterns in the broader disc-check area
    print("=" * 80)
    print("BRANCH INSTRUCTION SEARCH (0x80078E00 - 0x80079600)")
    print("Looking for beq/bne that could be the handshake check point")
    print("=" * 80)

    start_text = 0x60E00
    end_text = 0x61700
    start_file = start_text + EXE_HEADER
    end_file = end_text + EXE_HEADER

    pc = LOAD_ADDR + start_text
    branches = []
    for off in range(start_file, min(end_file, len(exe)), 4):
        instr = struct.unpack_from("<I", exe, off)[0]
        op = (instr >> 26) & 0x3F
        if op in (0x04, 0x05, 0x06, 0x07, 0x01):
            asm = disasm_one(instr, pc)
            rt = (instr >> 16) & 0x1F
            rs = (instr >> 21) & 0x1F
            imm = instr & 0xFFFF
            simm = imm if imm < 0x8000 else imm - 0x10000
            target = pc + 4 + simm*4 + 4
            branches.append((pc, instr, asm, target))
            print(f"  0x{pc:08X}: {instr:08X}  {asm}  -> target 0x{target:08X}")
        pc += 4

    print(f"\nTotal branches found: {len(branches)}")

    # Also search for the CD BIOS wrapper at 0x80097814
    print()
    print("=" * 80)
    print("CD BIOS WRAPPER (0x80097814)")
    print("=" * 80)

    text_off = 0x7F914
    file_off = text_off + EXE_HEADER
    start = max(EXE_HEADER, file_off - 20 * 4)
    end = min(len(exe), file_off + 30 * 4)
    start_text_off = start - EXE_HEADER
    pc = LOAD_ADDR + start_text_off

    for off in range(start, end, 4):
        instr = struct.unpack_from("<I", exe, off)[0]
        asm = disasm_one(instr, pc)
        marker = ""
        if off == file_off:
            marker = "  *** CD BIOS WRAPPER ***"
        op = (instr >> 26) & 0x3F
        if op in (0x04, 0x05, 0x06, 0x07, 0x01):
            marker += "  <<< BRANCH"
        elif op in (0x02, 0x03):
            marker += "  <<< JUMP"
        elif op == 0x0F:
            marker += "  <<< LUI"
        print(f"  0x{pc:08X}: {instr:08X}  {asm}{marker}")

    # Search for references to disc number variable 0x800E3D90
    print()
    print("=" * 80)
    print("SEARCH: References to disc number variable 0x800E3D90")
    print("=" * 80)

    target_hi = 0x800E  # upper 16 bits
    target_lo = 0x3D90  # lower 16 bits

    for off in range(EXE_HEADER, len(exe) - 4, 4):
        instr = struct.unpack_from("<I", exe, off)[0]
        op = (instr >> 26) & 0x3F

        # Check for lui rt, 0x800E followed by addiu/lw/sw with 0x3D90
        if op == 0x0F:  # lui
            rt = (instr >> 16) & 0x1F
            imm = instr & 0xFFFF
            if imm == target_hi:
                # Check next few instructions for matching offset
                for j in range(1, 5):
                    if off + j*4 >= len(exe):
                        break
                    next_instr = struct.unpack_from("<I", exe, off + j*4)[0]
                    next_op = (next_instr >> 26) & 0x3F
                    next_rt = (next_instr >> 16) & 0x1F
                    next_imm = next_instr & 0xFFFF
                    if next_op in (0x09, 0x08, 0x23, 0x2B, 0x21, 0x25, 0x20, 0x28, 0x29) and next_rt == rt:
                        if next_imm == target_lo:
                            text_off = off - EXE_HEADER
                            ram = LOAD_ADDR + text_off
                            print(f"  0x{ram:08X}: lui {reg(rt)}, 0x{imm:04X}  +{j} instrs: {disasm_one(next_instr, ram + j*4)}")

    # Search for the disc-change handler call sites (0x800506CC)
    print()
    print("=" * 80)
    print("SEARCH: jal to disc_change_handler (0x800506CC)")
    print("=" * 80)

    target_field = (0x800506CC >> 2) & 0x3FFFFFF
    for off in range(EXE_HEADER, len(exe) - 4, 4):
        instr = struct.unpack_from("<I", exe, off)[0]
        op = (instr >> 26) & 0x3F
        if op == 0x03:  # jal
            target = instr & 0x3FFFFFF
            if target == target_field:
                text_off = off - EXE_HEADER
                ram = LOAD_ADDR + text_off
                print(f"  0x{ram:08X}: jal 0x{0x800506CC:08X}")

    return 0

if __name__ == "__main__":
    sys.exit(main())
