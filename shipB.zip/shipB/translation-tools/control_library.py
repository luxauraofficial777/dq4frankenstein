"""control_library.py -- MASTER CONTROL CODE LIBRARY (canonical registry).

Single source of truth for every control code the engine can encounter in a
text stream. Established from the disc-wide ctrl census (cybergrime/
forensics/ctrl_census.json, Sep-08: 1,528 text sub-blocks + EXE-resident
048C/048F) cross-checked against the RAM freeze forensics
(RAM_MINER_FORENSICS_006C_FREEZE_Sep08_2026).

RULES ENCODED HERE (all re-encode paths must honor them):
  * Control codes are STRUCTURE, never text. No pass may delete, reorder,
    rewrite or "translate" them.
  * PAGINATOR codes: the paginator may INSERT breaks around them but must
    treat them as zero-width and let them reset/advance line state.
  * EXE-RESIDENT codes (the Sep-08 additions): pass-through, POSITION-LOCKED
    within their sequence (relative order vs neighbouring leaves immutable).
    7F06 in particular is the battle-wipe/freeze token (RAM incident 174/175:
    resident 0x48C0A059 -> 048C sid 775 carries {7f06}; exonerated by the
    staging-slot scan, but it must NEVER be stripped or reformatted by a
    re-encode).
  * INVALID-CHAR units (0x00xx staged pairs) are NOT control codes; they are
    the misalignment artifact of an off-rails decode and must abort, not park
    (engine-side; pipeline-side we only detect them in RAM via G11).
"""
import re

# ---- known in-library codes (present on pristine disc, ctrl_audit census) --
# Pagination / message-flow markers.
PAGINATOR_CTRL = frozenset((0x7F01, 0x7F02, 0x7F0A, 0x7F0B))

# EXE-resident codes, Sep-08 catalog (ctrl_census.json):
#   048C: 7F06 x3, 7F10 x11
#   048F: 7F19 x10, 7F1B x1, 7F1C x13, 7F1E x15, 7F35 x2
# Officially appended to the master library with pass-through freeze-token
# rules: never stripped, never misinterpreted, position-locked.
EXE_RESIDENT_CTRL = frozenset((0x7F06, 0x7F10, 0x7F19, 0x7F1B, 0x7F1C,
                               0x7F1E, 0x7F35))

IMMUTABLE_CTRL = PAGINATOR_CTRL | EXE_RESIDENT_CTRL

# Full census of codes observed on the pristine disc (archive + EXE). Any
# 7Fxx code outside this set in a corpus string is suspect and should be
# flagged by validate/audit tooling rather than silently encoded.
DISC_OBSERVED_CTRL = frozenset((
    0x7F01, 0x7F02, 0x7F04, 0x7F05, 0x7F06, 0x7F0A, 0x7F0B, 0x7F0C,
    0x7F10, 0x7F11, 0x7F12, 0x7F13, 0x7F14, 0x7F15, 0x7F16, 0x7F17,
    0x7F18, 0x7F19, 0x7F1A, 0x7F1B, 0x7F1C, 0x7F1E, 0x7F1F,
    0x7F20, 0x7F21, 0x7F22, 0x7F23, 0x7F24, 0x7F25, 0x7F26,
    0x7F28, 0x7F29, 0x7F2A, 0x7F2B, 0x7F2C, 0x7F2D, 0x7F2E, 0x7F2F,
    0x7F30, 0x7F31, 0x7F32, 0x7F33, 0x7F34, 0x7F35,
    0x7F42, 0x7F43, 0x7F44, 0x7F45, 0x7F47, 0x7F4B, 0x7F4C,
))

# Human-readable registry: code -> (name, rule class).
RULE_PAGINATOR = "paginator"
RULE_EXE_PASSTHROUGH = "exe-passthrough-position-locked"
RULE_VARIABLE = "variable-slot"
RULE_NAME_SUB = "name-substitution"

CONTROL_LIBRARY = {
    0x7F01: ("exe-ui newline", RULE_PAGINATOR),
    0x7F02: ("line break", RULE_PAGINATOR),
    0x7F04: ("speaker-box start", RULE_PAGINATOR),
    0x7F05: ("speaker-box end", RULE_PAGINATOR),
    0x7F06: ("battle-wipe / freeze token", RULE_EXE_PASSTHROUGH),
    0x7F0A: ("box advance (wait + clear)", RULE_PAGINATOR),
    0x7F0B: ("end of message", RULE_PAGINATOR),
    0x7F0C: ("archive ctrl (x6)", RULE_VARIABLE),
    0x7F10: ("variable slot (Font-1)", RULE_VARIABLE),
    0x7F11: ("variable: gold", RULE_VARIABLE),
    0x7F12: ("variable: hero name", RULE_NAME_SUB),
    0x7F13: ("variable", RULE_VARIABLE),
    0x7F14: ("variable", RULE_VARIABLE),
    0x7F15: ("variable: number/slot", RULE_VARIABLE),
    0x7F16: ("variable: number", RULE_VARIABLE),
    0x7F17: ("variable: item/number", RULE_VARIABLE),
    0x7F18: ("variable (048F x7)", RULE_VARIABLE),
    0x7F19: ("variable (EXE 048F x10)", RULE_EXE_PASSTHROUGH),
    0x7F1A: ("variable: name", RULE_VARIABLE),
    0x7F1B: ("variable (EXE 048F)", RULE_EXE_PASSTHROUGH),
    0x7F1C: ("variable (EXE 048F x13)", RULE_EXE_PASSTHROUGH),
    0x7F1E: ("variable (EXE 048F x15)", RULE_EXE_PASSTHROUGH),
    0x7F1F: ("variable: name slot", RULE_VARIABLE),
    0x7F34: ("variable: name-sub (short)", RULE_NAME_SUB),
    0x7F35: ("name-sub variant (EXE 048F)", RULE_EXE_PASSTHROUGH),
}

_TOKEN_RE = re.compile(r"\{([0-9a-fA-F]{4})\}")


def is_control_val(v):
    return v == 0 or (v & 0x7F00) == 0x7F00


def is_immutable(v):
    return v in IMMUTABLE_CTRL


def is_exe_resident(v):
    return v in EXE_RESIDENT_CTRL


def tokens_in(text):
    """All {XXXX} control values in a corpus string (as ints, {0000} incl.)."""
    return [int(m.group(1), 16) for m in _TOKEN_RE.finditer(text or "")]


def immutable_tokens_in(text):
    return [v for v in tokens_in(text) if v in IMMUTABLE_CTRL]
