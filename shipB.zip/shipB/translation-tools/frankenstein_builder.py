#!/usr/bin/env python3
"""
frankenstein_builder.py - Unified Frankenstein ROM build system.

Replaces the 6+ separate build scripts with a single configurable builder.
Supports build profiles for diagnostics, full Frankenstein, and RC1.

Profiles:
  test_0     - Plain DW7 copy (baseline)
  test_a     - DQ4 HBD swap only, no EXE patches
  test_b     - DQ4 HBD + tree patches, no pointer patches
  test_d     - DW7 HBD + tree patches only (no HBD swap)
  test_f     - ISO dir update only (no HBD/EXE changes)
  frank_v12  - Full Frankenstein with DW7-preserved pointer redirect
  rc2        - DQ4 EXE + patched HBD on DW7 body (no zeroing)

Usage:
    python frankenstein_builder.py --profile test_a
    python frankenstein_builder.py --profile frank_v12
    python frankenstein_builder.py --profile rc2 --output dq4_en_rc2.bin
    python frankenstein_builder.py --list
"""
import struct
import json
import os
import sys
import shutil
import subprocess
import argparse
import bisect
import ctypes

BASE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
DW7_DISC = os.path.join(BASE, "DW7D1", "DW7D1.bin")
DQ4_DISC = os.path.join(BASE, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
DQ4_HBD_DISC = os.path.join(BASE, "old", "builds", "dq4_heart_v17.bin")  # Fresh translated heart
ORIGINAL_EXE = os.path.join(BASE, "translation", "SLUSP012.06")  # DW7 US EXE
DQ4_EXE_DISC = os.path.join(BASE, "dq4_frankenstein_hbd_patch_v3.bin")  # For DQ4 EXE
FOLDER_MAP = os.path.join(BASE, "translation", "folder_mapping.json")
HYBRID_TREE = os.path.join(BASE, "dw7_hybrid_tree.bin")
EDCRE = os.path.join(BASE, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048

# Constants
EXE_LBA = 24
HBD_LBA = 355  # Fixed from 354 to avoid EXE/HBD overlap
DQ4_HBD_DISC_START = 362
DQ4_HBD_SIZE = 319436800
DQ4_HBD_SECTORS = DQ4_HBD_SIZE // USER_SIZE
DQ4_HBD_END = HBD_LBA + DQ4_HBD_SECTORS
DW7_HBD_SIZE = 618563584

# Actual non-zero data size in DQ4 HBD source (detected at build time).
# The DQ4 HBD source (dq4_heart_v17.bin) is 368MB but only ~289MB is non-zero.
# Writing the full 319MB overwrites valid DW7 FMV data with zeros at LBA 146621+.
# Fix: only write non-zero DQ4 data, preserving original DW7 data beyond that point.
DQ4_HBD_ACTUAL_SECTORS = 141197  # Detected via binary search on source disc
DQ4_HBD_ACTUAL_SIZE = DQ4_HBD_ACTUAL_SECTORS * USER_SIZE  # 289,171,456 bytes

ABS_TABLE_START = 0x4184
REL_TABLE_START = 0x511C
TABLE_ENTRY_SIZE = 8
MAX_TABLE_ENTRIES = 6000

OLD_LUI_IMM = 0x800F
OLD_ADDIU_IMM = 0xF1C8

# Disc-check bypass patches (from patch_dw7_exe.py)
# These force disc verification and CD init to return success,
# preventing the 'Insert Disc 1' stall.
DISC_CHECK_PATCHES = [
    # Targeted return-value patches: instead of replacing the entire disc_check
    # function (which skips CD-ROM setup), patch the 3 failure exit points to
    # return 1 (success). The function's CD-ROM init code runs normally.
    # Exit 1: flag=0 early exit (delay slot of bne at 0x80079028)
    {'offset': 0x6112C, 'original': struct.pack('<I', 0x00001021),
     'patch': struct.pack('<I', 0x24020001),
     'desc': 'disc_check_exit1_return_success'},
    # Exit 2: shell-open exit (delay slot of bne at 0x800790D4)
    {'offset': 0x611D8, 'original': struct.pack('<I', 0x24020004),
     'patch': struct.pack('<I', 0x24020001),
     'desc': 'disc_check_exit2_return_success'},
    # Exit 3: normal completion (addu v0,a1,zero before exit at 0x800792BC)
    {'offset': 0x613B8, 'original': struct.pack('<I', 0x00A01021),
     'patch': struct.pack('<I', 0x24020001),
     'desc': 'disc_check_exit3_return_success'},
    {'offset': 0x60FA4, 'original': bytes.fromhex('D0FFBD271800B0AFD0021024'),
     'patch': bytes.fromhex('010002240800E00300000000'),
     'desc': 'cd_init_force_success'},
    {'offset': 0x614A4, 'original': bytes.fromhex('1400001a'),
     'patch': struct.pack('<I', 0x00000000),
     'desc': 'nop_timeout_check'},
    {'offset': 0x614F8, 'original': bytes.fromhex('e1ff4010'),
     'patch': struct.pack('<I', 0x00000000),
     'desc': 'nop_error_path'},
    {'offset': 0x387CC, 'original': bytes.fromhex('0f80023c240f428cd0ffbd27'),
     'patch': bytes.fromhex('0800e0030000000000000000'),
     'desc': 'neutralize_disc_change_handler'},
    {'offset': 0x7308C, 'original': bytes.fromhex('e32b0208'),
     'patch': bytes.fromhex('e92b0208'),
     'desc': 'redirect_disc_trap_to_success'},
    {'offset': 0x61424, 'original': bytes.fromhex('0b004314'),
     'patch': bytes.fromhex('0b000010'),
     'desc': 'graft_a_gate1_always_skip_disc_change'},
    {'offset': 0x61520, 'original': bytes.fromhex('0b004314'),
     'patch': bytes.fromhex('0b000010'),
     'desc': 'graft_b_gate3_always_skip_disc_change'},
    {'offset': 0x61360, 'original': bytes.fromhex('0a006210'),
     'patch': bytes.fromhex('0a000010'),
     'desc': 'graft_c_string_compare_always_match'},
]

# Surgical disc-check bypass: skips cd_init_force_success (destroys CD-ROM
# hardware init) but keeps the targeted return-value and graft/nop/redirect
# patches. 10 patches total.
SURGICAL_DISC_CHECK_PATCHES = [
    p for p in DISC_CHECK_PATCHES
    if p['desc'] != 'cd_init_force_success'
]

# Semi-surgical: same as surgical now that disc_check is patched via exit
# points instead of function replacement. All patches except cd_init.
SEMI_SURGICAL_DISC_CHECK_PATCHES = [
    p for p in DISC_CHECK_PATCHES
    if p['desc'] != 'cd_init_force_success'
]

# ============================================================
# C++ library integration (psx_ops.dll)
# ============================================================
PSX_OPS_DLL_PATH = os.path.join(BASE, "cybergrime", "psx_ops.dll")
_psx_ops = None

def load_psx_ops():
    """Load psx_ops.dll and set up ctypes signatures."""
    global _psx_ops
    if _psx_ops is not None:
        return _psx_ops
    if not os.path.exists(PSX_OPS_DLL_PATH):
        raise FileNotFoundError(f"psx_ops.dll not found at {PSX_OPS_DLL_PATH}")
    _psx_ops = ctypes.CDLL(PSX_OPS_DLL_PATH)

    # ExePatcher C API
    _psx_ops.exe_load.restype = ctypes.c_void_p
    _psx_ops.exe_load.argtypes = [ctypes.c_char_p, ctypes.c_uint32]
    _psx_ops.exe_free.argtypes = [ctypes.c_void_p]
    _psx_ops.exe_read32.restype = ctypes.c_uint32
    _psx_ops.exe_read32.argtypes = [ctypes.c_void_p, ctypes.c_uint32]
    _psx_ops.exe_write32.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    _psx_ops.exe_patch_lba.restype = ctypes.c_uint32
    _psx_ops.exe_patch_lba.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    _psx_ops.exe_patch_seq_table.restype = ctypes.c_uint32
    _psx_ops.exe_patch_seq_table.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]
    _psx_ops.exe_patch_tree_refs.restype = ctypes.c_uint32
    _psx_ops.exe_patch_tree_refs.argtypes = [ctypes.c_void_p, ctypes.c_uint16, ctypes.c_uint16, ctypes.c_uint16, ctypes.c_uint16]
    _psx_ops.exe_patch_disc_check.restype = ctypes.c_uint32
    _psx_ops.exe_patch_disc_check.argtypes = [ctypes.c_void_p, ctypes.POINTER(ctypes.c_uint32), ctypes.POINTER(ctypes.c_uint32), ctypes.c_uint32]
    _psx_ops.exe_append_reloc_payload.argtypes = [ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
    _psx_ops.exe_patch_bss_clear_narrow.restype = ctypes.c_int
    _psx_ops.exe_patch_bss_clear_narrow.argtypes = [ctypes.c_void_p]
    _psx_ops.exe_append_reloc_payload_with_thread_fix.argtypes = [
        ctypes.c_void_p, ctypes.c_char_p, ctypes.c_uint32,
        ctypes.c_uint32, ctypes.c_uint32,
        ctypes.c_char_p, ctypes.c_uint32
    ]
    _psx_ops.exe_raw.restype = ctypes.POINTER(ctypes.c_ubyte)
    _psx_ops.exe_raw.argtypes = [ctypes.c_void_p]
    _psx_ops.exe_size.restype = ctypes.c_uint32
    _psx_ops.exe_size.argtypes = [ctypes.c_void_p]
    _psx_ops.exe_pc0.restype = ctypes.c_uint32
    _psx_ops.exe_pc0.argtypes = [ctypes.c_void_p]

    # CD-ROM stall bypass + FMV skip + pre-tree BSS zero
    _psx_ops.exe_patch_cdrom_stall_bypass.restype = ctypes.c_int
    _psx_ops.exe_patch_cdrom_stall_bypass.argtypes = [ctypes.c_void_p]
    _psx_ops.exe_patch_fmv_skip.restype = ctypes.c_int
    _psx_ops.exe_patch_fmv_skip.argtypes = [ctypes.c_void_p]
    _psx_ops.exe_zero_pre_tree_bss.argtypes = [ctypes.c_void_p]

    # HbdReencoder C API
    _psx_ops.hbd_load.restype = ctypes.c_void_p
    _psx_ops.hbd_load.argtypes = [ctypes.c_char_p, ctypes.c_uint32, ctypes.c_char_p, ctypes.c_uint32]
    _psx_ops.hbd_free.argtypes = [ctypes.c_void_p]
    _psx_ops.hbd_raw.restype = ctypes.POINTER(ctypes.c_ubyte)
    _psx_ops.hbd_raw.argtypes = [ctypes.c_void_p]
    _psx_ops.hbd_size.restype = ctypes.c_uint32
    _psx_ops.hbd_size.argtypes = [ctypes.c_void_p]
    _psx_ops.hbd_validate.restype = ctypes.c_int
    _psx_ops.hbd_validate.argtypes = [ctypes.c_void_p, ctypes.c_uint32]

    # HbdProcessResult struct for hbd_process return
    class HbdProcessResult(ctypes.Structure):
        _fields_ = [
            ('blocks_processed', ctypes.c_uint32),
            ('blocks_converted', ctypes.c_uint32),
            ('blocks_reencoded', ctypes.c_uint32),
            ('blocks_reencode_failed', ctypes.c_uint32),
            ('subblock_swaps', ctypes.c_uint32),
            ('lba_patches', ctypes.c_uint32),
            ('folders_parsed', ctypes.c_uint32),
            ('files_parsed', ctypes.c_uint32),
            ('errors', ctypes.c_uint32),
            ('success', ctypes.c_int),
        ]
    _psx_ops.HbdProcessResult = HbdProcessResult
    _psx_ops.hbd_process.restype = HbdProcessResult
    _psx_ops.hbd_process.argtypes = [ctypes.c_void_p, ctypes.c_uint32, ctypes.c_uint32]

    return _psx_ops


def patch_disc_check(exe, surgical=False, semi_surgical=False):
    """Apply disc-check bypass patches at known addresses.
    
    disc_check is patched via 3 targeted exit-point patches that preserve
    the function's CD-ROM setup code while forcing return value = 1.
    
    If surgical=True or semi_surgical=True, skip cd_init_force_success
    (which destroys CD-ROM hardware init). 10 patches total.
    """
    data = bytearray(exe)
    patches = 0
    if semi_surgical:
        patch_list = SEMI_SURGICAL_DISC_CHECK_PATCHES
    elif surgical:
        patch_list = SURGICAL_DISC_CHECK_PATCHES
    else:
        patch_list = DISC_CHECK_PATCHES
    for p in patch_list:
        off = p['offset'] + 0x800
        if off + len(p['patch']) > len(data):
            print(f"    WARNING: patch '{p['desc']}' at offset 0x{off:X} exceeds EXE size")
            continue
        data[off:off + len(p['patch'])] = p['patch']
        patches += 1
        print(f"    Applied: {p['desc']} at EXE offset 0x{p['offset']:05X}")
    return bytes(data), patches


# ============================================================
# CD-ROM Stop command intercept trampoline
# ============================================================
# The DW7 EXE writes CD-ROM commands at RAM 0x80098664 (sb s1, 0(v0))
# where s1 = command byte, v0 = ptr to 0x1F801801 (command register).
# We replace that instruction with a jump to a trampoline appended
# after the Huffman tree. The trampoline checks if s1 == 0x08 (Stop)
# and skips the hardware write if so, preventing drive spin-down.
# This keeps Getstat returning 0x02 (spinning) so the secondary
# disc-check in decompressed overlays sees a valid drive state.

CDROM_CMD_WRITE_OFF = 0x80F64  # EXE file offset of sb s1,0(v0) at RAM 0x80098664
CDROM_CMD_WRITE_RAM = 0x80098664  # RAM address of the command write
# The instruction after the command write is bne s2,zero,0x80098898
# It would execute in the j delay slot, so we must replace it too.
CDROM_BRANCH_OFF = 0x80F68      # EXE file offset of bne at RAM 0x80098668
CDROM_BRANCH_RAM = 0x80098668   # RAM address of the branch
CDROM_BRANCH_TARGET = 0x80098898  # Where the original branch goes
CDROM_AFTER_BRANCH_RAM = 0x80098670  # Instruction after branch+delay slot


def patch_cdrom_stop_intercept(exe_data):
    """Patch the CD-ROM command write to intercept Stop (0x08).
    
    Replaces the single instruction at the command write point with
    a jump to a trampoline appended after the hybrid tree. The trampoline:
      1. Checks if command byte (s1) == 8 (Stop)
      2. If Stop: skips the hardware write (NOP)
      3. If not Stop: executes the original sb s1,0(v0)
      4. Jumps back to the instruction after the original write
    
    Returns (patched_exe, trampoline_addr_ram) or (exe_data, None) on failure.
    """
    exe = bytearray(exe_data)
    
    # Verify the original instruction at the command write point
    # File offset = RAM - EXE_BASE + 0x800 = 0x80098664 - 0x80017F00 + 0x800 = 0x80A64
    orig_off = CDROM_CMD_WRITE_OFF
    if orig_off + 4 > len(exe):
        print(f"  WARNING: Command write offset 0x{orig_off:X} beyond EXE size")
        return bytes(exe), None
    
    orig_insn = struct.unpack_from('<I', exe, orig_off)[0]
    # Expected: sb s1, 0(v0) = opcode 0x28, rs=v0(2), rt=s1(17), imm=0
    # Encoding: 0xA2 0x00 0x11 0x00 -> 0x001100A2 (LE)
    # Actually: sb $rt, imm($rs) -> op=0x28, rs=2, rt=17, imm=0
    # Binary: 101000 00010 10001 0000000000000000 = 0xA0440000... let me compute
    # op=0x28=101000, rs=2=00010, rt=17=10001, imm=0
    # 101000 00010 10001 0000000000000000 = 0xA0440000
    # In LE: 0x000044A0
    expected = (0x28 << 26) | (2 << 21) | (17 << 16) | 0  # sb s1, 0(v0)
    if orig_insn != expected:
        print(f"  WARNING: Expected sb s1,0(v0) (0x{expected:08X}) at 0x{orig_off:X}, got 0x{orig_insn:08X}")
        # Try to figure out what's there
        op = (orig_insn >> 26) & 0x3F
        rs = (orig_insn >> 21) & 0x1F
        rt = (orig_insn >> 16) & 0x1F
        imm = orig_insn & 0xFFFF
        print(f"    op=0x{op:02X} rs={rs} rt={rt} imm=0x{imm:04X}")
        # Don't abort - try anyway with the actual instruction
    
    # Compute trampoline location: after the hybrid tree
    # The tree is appended by append_hybrid_tree, which also pads to sector boundary.
    # We need to append the trampoline AFTER the tree but BEFORE the sector padding.
    # Strategy: append trampoline to the EXE data, then let append_hybrid_tree
    # handle padding. But since append_hybrid_tree is called separately, we'll
    # insert the trampoline into the EXE data before the tree is appended.
    # 
    # Actually, better approach: call this AFTER append_hybrid_tree, and
    # append the trampoline at the end, then update text_size again.
    
    # For now, just return the original data - the trampoline will be
    # appended by the build function which knows the tree location.
    return bytes(exe), None


def append_cdrom_trampoline(exe_data, tree_ram_addr):
    """Append CD-ROM Stop intercept trampoline after the hybrid tree.
    
    exe_data: EXE with hybrid tree already appended (from append_hybrid_tree)
    tree_ram_addr: RAM address where the tree starts
    
    Returns (patched_exe, trampoline_ram_addr).
    """
    exe = bytearray(exe_data)
    
    # Tree is at tree_ram_addr, 1480 bytes (or whatever the hybrid tree size is)
    # Read the tree size from the file
    tree_size = os.path.getsize(HYBRID_TREE)
    
    # Trampoline starts after the tree, aligned to 4 bytes
    trampoline_ram = tree_ram_addr + tree_size
    # Align to 4 bytes
    trampoline_ram = (trampoline_ram + 3) & ~3
    
    # Compute file offset for the trampoline
    # file_offset = RAM - EXE_BASE + 0x800
    trampoline_file_off = trampoline_ram - 0x80017F00 + 0x800
    
    # Ensure we have space (the EXE should have been padded to sector boundary)
    if trampoline_file_off + 48 > len(exe):
        needed = trampoline_file_off + 48 - len(exe)
        exe = exe + b'\x00' * ((needed + 2047) // 2048 * 2048)
    
    # Build the trampoline (12 instructions = 48 bytes)
    # We replace TWO instructions at the intercept point:
    #   0x80098664: sb s1, 0(v0)       -> j trampoline
    #   0x80098668: bne s2, zero, X    -> nop (delay slot of j)
    #
    # The trampoline reconstructs both original instructions with the
    # Stop check inserted before the sb. The original bne target (0x80098898)
    # is ~148KB away — beyond MIPS branch range. We use beq (inverted) + j
    # for long-distance jumps.
    #
    # Original semantics: bne s2,zero,target executes delay slot (addu v0,zero,zero)
    # REGARDLESS of branch outcome. We preserve this.
    #
    # Uses at ($1) as temporary — safe to clobber in any context.
    #   trampoline+0:  addiu at, zero, 8        # at = 8 (Stop)
    #   trampoline+4:  beq s1, at, +3           # if Stop, skip sb -> trampoline+20
    #   trampoline+8:  nop                      # delay slot of beq (always runs)
    #   trampoline+12: sb s1, 0(v0)             # write cmd (if not Stop)
    #   trampoline+16: beq s2, zero, +3         # if s2==0 (NOT taken), -> trampoline+32
    #   trampoline+20: addu v0, zero, zero      # delay slot of beq (ALWAYS runs)
    #   trampoline+24: j 0x80098898             # branch WAS taken -> jump to target
    #   trampoline+28: nop                      # delay slot of j
    #   trampoline+32: j 0x80098670             # branch NOT taken -> continue
    #   trampoline+36: nop                      # delay slot of j
    
    # beq offset for Stop check: (trampoline+20 - trampoline+4 - 4) / 4 = 3
    beq_stop_offset = 3
    
    # beq offset for branch-not-taken: (trampoline+32 - trampoline+16 - 4) / 4 = 3
    beq_not_taken_offset = 3
    
    # j target for bne target (0x80098898)
    j_bne_target = (CDROM_BRANCH_TARGET >> 2) & 0x3FFFFFF
    
    # j target for return (0x80098670)
    j_return_target = (CDROM_AFTER_BRANCH_RAM >> 2) & 0x3FFFFFF
    
    # Original instruction at 0x8009866C: addu v0, zero, zero (0x00001021)
    orig_delay_slot = 0x00001021
    
    trampoline = [
        # addiu at, zero, 8  (at = register 1)
        (0x09 << 26) | (0 << 21) | (1 << 16) | 8,
        # beq s1, at, +3 (if Stop, skip to trampoline+20)
        (0x04 << 26) | (17 << 21) | (1 << 16) | beq_stop_offset,
        # nop (delay slot of beq)
        0x00000000,
        # sb s1, 0(v0) (original instruction at 0x80098664)
        (0x28 << 26) | (2 << 21) | (17 << 16) | 0,
        # beq s2, zero, +3 (if s2==0, branch NOT taken -> trampoline+32)
        (0x04 << 26) | (18 << 21) | (0 << 16) | beq_not_taken_offset,
        # addu v0, zero, zero (original delay slot at 0x8009866C, ALWAYS runs)
        orig_delay_slot,
        # j 0x80098898 (branch WAS taken -> jump to original bne target)
        (0x02 << 26) | j_bne_target,
        # nop (delay slot of j)
        0x00000000,
        # j 0x80098670 (branch NOT taken -> continue normally)
        (0x02 << 26) | j_return_target,
        # nop (delay slot of j)
        0x00000000,
    ]
    
    # Write trampoline to EXE
    for i, insn in enumerate(trampoline):
        struct.pack_into('<I', exe, trampoline_file_off + i * 4, insn)
    
    # Patch the original command write point to jump to the trampoline
    j_to_trampoline = (0x02 << 26) | ((trampoline_ram >> 2) & 0x3FFFFFF)
    struct.pack_into('<I', exe, CDROM_CMD_WRITE_OFF, j_to_trampoline)
    
    # Patch the branch instruction (next after sb) to nop (delay slot of j)
    struct.pack_into('<I', exe, CDROM_BRANCH_OFF, 0x00000000)
    
    # Update text_size in EXE header to include trampoline
    new_text_size = len(exe) - 0x800
    # Pad to sector boundary if needed
    sector_pad = (2048 - (len(exe) % 2048)) % 2048
    if sector_pad:
        exe = exe + b'\x00' * sector_pad
        new_text_size = len(exe) - 0x800
    struct.pack_into('<I', exe, 0x1C, new_text_size)
    
    print(f"  CD-ROM Stop intercept trampoline at RAM 0x{trampoline_ram:08X} (file 0x{trampoline_file_off:05X})")
    print(f"  Patched cmd write at file 0x{CDROM_CMD_WRITE_OFF:05X} -> j 0x{trampoline_ram:08X}")
    print(f"  Patched branch at file 0x{CDROM_BRANCH_OFF:05X} -> nop")
    print(f"  Trampoline: {len(trampoline)} instructions ({len(trampoline)*4} bytes)")
    print(f"  Return to: 0x{CDROM_AFTER_BRANCH_RAM:08X}")
    
    return bytes(exe), trampoline_ram


def append_reloc_payload(exe_data, tree_target_ram, original_pc0):
    """Append hybrid tree + trampoline + copy routine for BSS-safe relocation.

    Tree+trampoline are stored at the end of the EXE (in BSS region on disc,
    within the sector budget before HBD). A copy routine runs as the new
    entry point (PC0), copies tree+trampoline to tree_target_ram (outside
    BSS), then jumps to original_pc0 (BSS clear → game init).

    BSS clear wipes the originals at 0x800BC700+ but the copies at
    tree_target_ram survive. Game runtime BSS variable writes don't
    collide because tree_target_ram is past BSS end.

    exe_data: EXE with all patches applied (no tree/trampoline yet)
    tree_target_ram: Final RAM address for tree (e.g., 0x800F4980)
    original_pc0: Original entry point (from EXE header PC0)

    Returns (patched_exe, tree_target_ram, trampoline_target_ram).
    """
    exe = bytearray(exe_data)
    load_addr = struct.unpack_from('<I', exe, 0x18)[0]  # 0x80017F00

    with open(HYBRID_TREE, 'rb') as f:
        hybrid_tree = f.read()
    tree_size = len(hybrid_tree)

    # Align EXE to 4 bytes
    padding = (4 - (len(exe) % 4)) % 4
    if padding:
        exe = exe + b'\x00' * padding

    # ── Tree on disc at current end of EXE ──
    tree_file_off = len(exe)
    tree_ram_on_disc = load_addr + tree_file_off - 0x800
    exe = exe + hybrid_tree

    # ── Trampoline on disc after tree ──
    tramp_ram_on_disc = (tree_ram_on_disc + tree_size + 3) & ~3
    tramp_file_off = tramp_ram_on_disc - load_addr + 0x800
    if tramp_file_off + 48 > len(exe):
        exe = exe + b'\x00' * (tramp_file_off + 48 - len(exe))

    # Trampoline target RAM (after copy to tree_target_ram)
    tramp_ram_target = (tree_target_ram + tree_size + 3) & ~3

    # Build trampoline (same instructions as append_cdrom_trampoline)
    beq_stop_offset = 3
    beq_not_taken_offset = 3
    j_bne_target = (CDROM_BRANCH_TARGET >> 2) & 0x3FFFFFF
    j_return_target = (CDROM_AFTER_BRANCH_RAM >> 2) & 0x3FFFFFF
    orig_delay_slot = 0x00001021

    trampoline = [
        (0x09 << 26) | (0 << 21) | (1 << 16) | 8,
        (0x04 << 26) | (17 << 21) | (1 << 16) | beq_stop_offset,
        0x00000000,
        (0x28 << 26) | (2 << 21) | (17 << 16) | 0,
        (0x04 << 26) | (18 << 21) | (0 << 16) | beq_not_taken_offset,
        orig_delay_slot,
        (0x02 << 26) | j_bne_target,
        0x00000000,
        (0x02 << 26) | j_return_target,
        0x00000000,
    ]

    for i, insn in enumerate(trampoline):
        struct.pack_into('<I', exe, tramp_file_off + i * 4, insn)

    # ── Copy routine on disc after trampoline ──
    copy_ram_on_disc = tramp_ram_on_disc + len(trampoline) * 4
    copy_file_off = copy_ram_on_disc - load_addr + 0x800
    if copy_file_off + 60 > len(exe):
        exe = exe + b'\x00' * (copy_file_off + 60 - len(exe))

    # Payload to copy: tree + trampoline
    payload_size = (tramp_ram_on_disc + len(trampoline) * 4) - tree_ram_on_disc

    # Sign-extension-aware LUI/ADDIU for source and dest
    src_lo = tree_ram_on_disc & 0xFFFF
    src_hi = (tree_ram_on_disc >> 16) & 0xFFFF
    if src_lo >= 0x8000:
        src_hi = (src_hi + 1) & 0xFFFF

    dst_lo = tree_target_ram & 0xFFFF
    dst_hi = (tree_target_ram >> 16) & 0xFFFF
    if dst_lo >= 0x8000:
        dst_hi = (dst_hi + 1) & 0xFFFF

    # Copy routine: 14 instructions = 56 bytes
    # Copies payload_size bytes from tree_ram_on_disc to tree_target_ram
    # Then jumps to original_pc0 (BSS clear → game init)
    # IMPORTANT: NOP between lw and sw is required for MIPS R3000A load delay.
    # Without it, sw uses the OLD $t3 value, shifting the copy by one word.
    copy_routine = [
        (0x0F << 26) | (8 << 16) | src_hi,                          # lui t0, src_hi
        (0x09 << 26) | (8 << 21) | (8 << 16) | (src_lo & 0xFFFF),   # addiu t0, t0, src_lo
        (0x0F << 26) | (9 << 16) | dst_hi,                          # lui t1, dst_hi
        (0x09 << 26) | (9 << 21) | (9 << 16) | (dst_lo & 0xFFFF),   # addiu t1, t1, dst_lo
        (0x09 << 26) | (8 << 21) | (10 << 16) | (payload_size & 0xFFFF),  # addiu t2, t0, payload_size
        (0x23 << 26) | (8 << 21) | (11 << 16) | 0,                  # lw t3, 0(t0)
        0x00000000,                                                  # nop (load delay slot)
        (0x2B << 26) | (9 << 21) | (11 << 16) | 0,                  # sw t3, 0(t1)
        (0x09 << 26) | (8 << 21) | (8 << 16) | 4,                   # addiu t0, t0, 4
        (0x09 << 26) | (9 << 21) | (9 << 16) | 4,                   # addiu t1, t1, 4
        (0x05 << 26) | (8 << 21) | (10 << 16) | 0xFFFA,             # bne t0, t2, -6 (loop back to lw)
        0x00000000,                                                  # nop (delay slot)
        (0x02 << 26) | ((original_pc0 >> 2) & 0x3FFFFFF),           # j original_pc0
        0x00000000,                                                  # nop (delay slot)
    ]

    for i, insn in enumerate(copy_routine):
        struct.pack_into('<I', exe, copy_file_off + i * 4, insn)

    # Patch PC0 to copy routine
    struct.pack_into('<I', exe, 0x10, copy_ram_on_disc)

    # Patch CD-ROM cmd write to j tramp_ram_target (where trampoline ends up after copy)
    j_to_trampoline = (0x02 << 26) | ((tramp_ram_target >> 2) & 0x3FFFFFF)
    struct.pack_into('<I', exe, CDROM_CMD_WRITE_OFF, j_to_trampoline)

    # Patch branch to nop (delay slot of j)
    struct.pack_into('<I', exe, CDROM_BRANCH_OFF, 0x00000000)

    # Pad to sector boundary and update t_size
    sector_pad = (2048 - (len(exe) % 2048)) % 2048
    if sector_pad:
        exe = exe + b'\x00' * sector_pad
    new_text_size = len(exe) - 0x800
    struct.pack_into('<I', exe, 0x1C, new_text_size)

    print(f"  Tree on disc:     RAM 0x{tree_ram_on_disc:08X} (file 0x{tree_file_off:05X})")
    print(f"  Trampoline disc:  RAM 0x{tramp_ram_on_disc:08X} (file 0x{tramp_file_off:05X})")
    print(f"  Copy routine:     RAM 0x{copy_ram_on_disc:08X} (file 0x{copy_file_off:05X})")
    print(f"  Tree target:      RAM 0x{tree_target_ram:08X}")
    print(f"  Trampoline target: RAM 0x{tramp_ram_target:08X}")
    print(f"  Payload: {payload_size} bytes ({payload_size // 4} words)")
    print(f"  PC0: 0x{original_pc0:08X} -> 0x{copy_ram_on_disc:08X}")
    print(f"  CD-ROM intercept: j 0x{tramp_ram_target:08X}")
    print(f"  Copy routine: {len(copy_routine)} instructions ({len(copy_routine)*4} bytes)")

    return bytes(exe), tree_target_ram, tramp_ram_target


# ============================================================
# Sector I/O helpers
# ============================================================

def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)


def write_sector_user(f, lba, data):
    f.seek(lba * SECTOR_SIZE)
    sector = bytearray(f.read(SECTOR_SIZE))
    sector[USER_OFFSET:USER_OFFSET + USER_SIZE] = data[:USER_SIZE]
    f.seek(lba * SECTOR_SIZE)
    f.write(bytes(sector))


def write_raw_data(f, start_lba, data):
    offset = 0
    sector = start_lba
    while offset < len(data):
        chunk = data[offset:offset + USER_SIZE]
        if len(chunk) < USER_SIZE:
            chunk = chunk + b'\x00' * (USER_SIZE - len(chunk))
        write_sector_user(f, sector, chunk)
        offset += USER_SIZE
        sector += 1
    return sector - start_lba


def extend_disc_mode2(output_bin, new_disc_size):
    """Extend a raw MODE2/2352 disc image with structurally valid sectors.

    CRITICAL: extension sectors must have sync + BCD MSF header + mode byte
    + Form1 subheader. Zero-filled sectors have mode=0 and are unreadable
    by emulators, and edcre skips them, leaving EDC/ECC as zeros (root
    cause of v23/v24/v36 unreadable appended DQ4 folders beyond the
    original DW7 disc end at LBA 302,537).
    """
    current_size = os.path.getsize(output_bin)
    if new_disc_size <= current_size:
        return
    print(f"  Extending disc from {current_size:,} to {new_disc_size:,} bytes (+{new_disc_size - current_size:,})")
    sync = b'\x00' + b'\xFF' * 10 + b'\x00'
    subheader = bytes([0x00, 0x00, 0x08, 0x00]) * 2  # Form1 data
    def bcd(v):
        return ((v // 10) << 4) | (v % 10)
    with open(output_bin, 'r+b') as f:
        f.seek(current_size)
        first_lba = current_size // SECTOR_SIZE
        last_lba = new_disc_size // SECTOR_SIZE
        for lba in range(first_lba, last_lba):
            a = lba + 150  # absolute MSF includes 2-second pregap
            header = bytes([bcd(a // 4500), bcd((a // 75) % 60), bcd(a % 75), 0x02])
            f.write(sync + header + subheader + b'\x00' * (SECTOR_SIZE - 24))
    print(f"  Extension sectors {first_lba}-{last_lba - 1} written with MODE2 Form1 structure")


def detect_hbd_data_size(disc_path, start_sector, max_sectors=None):
    """Binary-search for the last non-zero sector in the HBD source disc.

    Returns the number of sectors with actual data (non-zero user data).
    This prevents writing zero-padding over valid DW7 data on the target disc.
    """
    if max_sectors is None:
        max_sectors = os.path.getsize(disc_path) // SECTOR_SIZE - start_sector
    with open(disc_path, 'rb') as f:
        lo, hi = start_sector, start_sector + max_sectors
        while lo < hi:
            mid = (lo + hi) // 2
            f.seek(mid * SECTOR_SIZE + USER_OFFSET)
            data = f.read(16)
            if any(b != 0 for b in data):
                lo = mid + 1
            else:
                hi = mid
        last_nonzero = lo - 1
        count = last_nonzero - start_sector + 1
        return count


def extract_hbd_from_disc(disc_path, start_sector, hbd_size):
    """Extract HBD data from a disc image, reading sector-by-sector.

    CRITICAL: CD-ROM sectors are 2352 bytes apart, not 2048.
    Reading as a contiguous stream garbles all data after the first sector.
    Must use read_sector_user() for each sector.
    """
    with open(disc_path, 'rb') as f:
        hbd_data = bytearray()
        sector = start_sector
        remaining = hbd_size
        while remaining > 0:
            data = read_sector_user(f, sector)
            if not data:
                break
            take = min(len(data), remaining)
            hbd_data.extend(data[:take])
            remaining -= take
            sector += 1
        return bytes(hbd_data[:hbd_size])


# ============================================================
# ISO directory helpers
# ============================================================

def update_iso_dir(f, exe_size=None, hbd_size=DW7_HBD_SIZE, hbd_lba=HBD_LBA):
    """Update ISO 9660 directory entries for HBD and EXE files."""
    dir_data = bytearray(read_sector_user(f, 22))
    offset = 0
    while offset < len(dir_data):
        rec_len = dir_data[offset] & 0xFF
        if rec_len == 0:
            break
        name_len = dir_data[offset + 32] & 0xFF
        name = dir_data[offset + 33:offset + 33 + name_len].decode('ascii', errors='replace').rstrip('\x00')
        if b'HBD' in name.encode():
            struct.pack_into('<I', dir_data, offset + 2, hbd_lba)
            struct.pack_into('>I', dir_data, offset + 6, hbd_lba)
            struct.pack_into('<I', dir_data, offset + 10, hbd_size)
            struct.pack_into('>I', dir_data, offset + 14, hbd_size)
            print(f"    HBD: {name} -> LBA={hbd_lba}, size={hbd_size:,}")
        elif name.startswith('SL') and exe_size:
            struct.pack_into('<I', dir_data, offset + 10, exe_size)
            struct.pack_into('>I', dir_data, offset + 14, exe_size)
            print(f"    EXE: {name} -> size={exe_size:,}")
        offset += rec_len
    write_sector_user(f, 22, bytes(dir_data))


def update_pvd(f, vol_id=b'DRAGONQUEST4_EN'):
    """Update PVD volume identifier."""
    pvd_data = bytearray(read_sector_user(f, 16))
    pvd_data[40:72] = vol_id.ljust(32, b' ')
    write_sector_user(f, 16, bytes(pvd_data))


def write_cue(cue_path, bin_name):
    with open(cue_path, 'w') as f:
        f.write(f'FILE "{bin_name}" BINARY\n')
        f.write('  TRACK 01 MODE2/2352\n')
        f.write('    INDEX 01 00:00:00\n')


# ============================================================
# EDC/ECC
# ============================================================

def run_edcre(bin_path):
    """Run edcre.exe to regenerate EDC/ECC."""
    if not os.path.exists(EDCRE):
        print("  WARNING: edcre.exe not found, skipping EDC/ECC")
        return False
    print(f"  Running EDC/ECC regeneration...")
    try:
        result = subprocess.run(
            [EDCRE, bin_path],
            capture_output=True, text=True, timeout=900
        )
        if result.returncode == 0:
            print(f"  EDC/ECC: SUCCESS")
            return True
        else:
            print(f"  EDC/ECC: FAILED (exit code {result.returncode})")
            if result.stderr:
                print(f"  stderr: {result.stderr[:500]}")
            return False
    except subprocess.TimeoutExpired:
        print(f"  EDC/ECC: TIMEOUT")
        return False
    except Exception as e:
        print(f"  EDC/ECC: ERROR - {e}")
        return False


# ============================================================
# MIPS tree ref patching
# ============================================================

def patch_mips_tree_refs(data, new_lui_imm, new_addiu_imm):
    data = bytearray(data)
    patch_count = 0
    for i in range(0x800, len(data) - 3, 4):
        instr = struct.unpack_from("<I", data, i)[0]
        opcode = (instr >> 26) & 0x3F
        if opcode != 0x09:
            continue
        imm = instr & 0xFFFF
        if imm != OLD_ADDIU_IMM:
            continue
        rs = (instr >> 21) & 0x1F
        for j in range(1, 17):
            prev_off = i - (j * 4)
            if prev_off < 0x800:
                break
            prev_instr = struct.unpack_from("<I", data, prev_off)[0]
            prev_op = (prev_instr >> 26) & 0x3F
            if prev_op != 0x0F:
                continue
            prev_imm = prev_instr & 0xFFFF
            prev_rt = (prev_instr >> 16) & 0x1F
            if prev_imm == OLD_LUI_IMM and prev_rt == rs:
                new_lui = (prev_instr & 0xFFFF0000) | new_lui_imm
                struct.pack_into("<I", data, prev_off, new_lui)
                new_addiu = (instr & 0xFFFF0000) | new_addiu_imm
                struct.pack_into("<I", data, i, new_addiu)
                patch_count += 1
                break
    return bytes(data), patch_count


def compute_tree_addr(exe_data, target_ram_addr=None):
    """Compute LUI/ADDIU for tree address with sign-extension fix.
    
    If target_ram_addr is provided, use it instead of load_addr + text_size.
    This allows placing the tree at a specific RAM address (e.g., after BSS).
    """
    load_addr = struct.unpack_from('<I', exe_data, 0x18)[0]
    text_size = struct.unpack_from('<I', exe_data, 0x1C)[0]
    if target_ram_addr is None:
        tree_ram_addr = load_addr + text_size
    else:
        tree_ram_addr = target_ram_addr
    new_addiu_imm = tree_ram_addr & 0xFFFF
    if new_addiu_imm >= 0x8000:
        new_lui_imm = ((tree_ram_addr >> 16) & 0xFFFF) + 1
    else:
        new_lui_imm = (tree_ram_addr >> 16) & 0xFFFF
    verify_addr = (new_lui_imm << 16) + (new_addiu_imm - 0x10000 if new_addiu_imm >= 0x8000 else new_addiu_imm)
    return new_lui_imm, new_addiu_imm, tree_ram_addr, verify_addr


def append_hybrid_tree(exe_data, target_ram_addr=None):
    """Append hybrid tree to EXE, update text_size.
    
    If target_ram_addr is provided, pad the EXE with zeros from its current
    end up to the file offset corresponding to target_ram_addr, then append
    the tree. This places the tree at a specific RAM address.
    """
    with open(HYBRID_TREE, 'rb') as f:
        hybrid_tree = f.read()
    exe = bytearray(exe_data)
    if target_ram_addr is not None:
        load_addr = struct.unpack_from('<I', exe, 0x18)[0]
        target_file_off = target_ram_addr - load_addr + 0x800
        if target_file_off > len(exe):
            pad_needed = target_file_off - len(exe)
            exe = exe + b'\x00' * pad_needed
    else:
        padding = (4 - (len(exe) % 4)) % 4
        if padding:
            exe = exe + b'\x00' * padding
    exe = exe + hybrid_tree
    sector_pad = (2048 - (len(exe) % 2048)) % 2048
    if sector_pad:
        exe = exe + b'\x00' * sector_pad
    new_text_size = len(exe) - 0x800
    struct.pack_into("<I", exe, 0x1C, new_text_size)
    return bytes(exe)


# ============================================================
# HBD folder parsing
# ============================================================

def parse_hbd_folders(disc_path, hbd_start_sector, max_sectors=310000):
    """Parse HBD folder entries by scanning sector by sector."""
    folders = []
    with open(disc_path, 'rb') as f:
        sector = hbd_start_sector
        end_sector = hbd_start_sector + max_sectors
        while sector < end_sector:
            data = read_sector_user(f, sector)
            if len(data) < 16:
                break
            num_files = struct.unpack_from('<I', data, 0)[0]
            num_sectors = struct.unpack_from('<I', data, 4)[0]
            total_size = struct.unpack_from('<I', data, 8)[0]
            if num_files > 0 and num_sectors > 0 and num_sectors <= 10000 and num_files <= 1000:
                folders.append({
                    'index': len(folders),
                    'sector': sector,
                    'relative_sector': sector - hbd_start_sector,
                    'num_files': num_files,
                    'num_sectors': num_sectors,
                    'total_size': total_size,
                })
                sector += num_sectors
            else:
                sector += 1
    return folders


# ============================================================
# Pointer remapping strategies
# ============================================================

def remap_pointers_to_dw7_preserved(exe, abs_repl, rel_repl):
    """Redirect unpatched DQ4-range pointers to DW7-preserved region.
    
    Instead of nearest-neighbor DQ4 folder matching (which feeds wrong data),
    redirect to the corresponding DW7 folder's location in the preserved region.
    The DW7 data at sectors 156330+ is still intact.
    """
    # DW7-preserved region starts at DQ4_HBD_END
    dw7_preserved_start = DQ4_HBD_END  # 156330
    
    abs_patches = 0
    abs_preserved = 0
    
    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0 or val < HBD_LBA:
            continue
        if val in abs_repl:
            continue  # Will be patched by matched folder
        if val >= DQ4_HBD_END:
            continue  # Already points to DW7-preserved region
        
        # Unpatched pointer in DQ4 range - redirect to DW7-preserved region
        # The original DW7 sector was at val. In our disc, that DW7 data is now at
        # val + DQ4_HBD_SECTORS (shifted by the DQ4 HBD insertion)
        new_val = val + DQ4_HBD_SECTORS
        struct.pack_into('<I', exe, off, new_val)
        abs_patches += 1
        abs_preserved += 1
    
    rel_patches = 0
    rel_preserved = 0
    
    for i in range(MAX_TABLE_ENTRIES):
        off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in rel_repl:
            continue
        if val >= DQ4_HBD_SECTORS:
            continue  # Points to DW7-preserved region
        
        # Redirect to DW7-preserved region
        new_val = val + DQ4_HBD_SECTORS
        struct.pack_into('<I', exe, off, new_val)
        rel_patches += 1
        rel_preserved += 1
    
    return abs_patches, abs_preserved, rel_patches, rel_preserved


def patch_lba_references(exe, old_lba, new_lba):
    """Patch all 32-bit LE sector references from old_lba to new_lba.
    Scans the entire EXE text segment for any 32-bit value == old_lba."""
    data = bytearray(exe)
    patches = 0
    for off in range(0x800, len(data) - 3, 4):
        val = struct.unpack_from('<I', data, off)[0]
        if val == old_lba:
            struct.pack_into('<I', data, off, new_lba)
            patches += 1
    return bytes(data), patches


def patch_sequential_sector_table(exe, old_lba, new_lba):
    """Patch 16-bit sequential sector table at EXE offset 0xA39AA-0xA3A02.
    Shifts values in range 300-400 by the LBA delta."""
    data = bytearray(exe)
    delta = new_lba - old_lba
    table_start = 0xA39AA
    table_end = 0xA3A02
    patches = 0
    for off in range(table_start, min(table_end, len(data) - 1), 2):
        val16 = struct.unpack_from('<H', data, off)[0]
        if 300 <= val16 <= 400:
            new_val = (val16 + delta) & 0xFFFF
            struct.pack_into('<H', data, off, new_val)
            patches += 1
    return bytes(data), patches


def remap_pointers_matched_only(exe, abs_repl, rel_repl, lba_delta=1):
    """Patch matched folder pointers, and apply LBA delta to unmatched ABS entries.
    
    Matched entries get their full remap (DW7 sector -> DQ4 sector + HBD_LBA).
    Unmatched ABS entries get +lba_delta to account for the HBD moving from
    sector 354 to 355. Without this, unmatched pointers are off by 1 and
    read the wrong sector.
    
    Unmatched REL entries are left unchanged (relative offsets within HBD
    don't shift when the HBD base moves).
    """
    abs_patches = 0
    abs_delta = 0
    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in abs_repl:
            struct.pack_into('<I', exe, off, abs_repl[val])
            abs_patches += 1
        elif val >= 354 and val < 0x100000:
            # Unmatched entry in HBD range — apply LBA delta
            new_val = val + lba_delta
            struct.pack_into('<I', exe, off, new_val)
            abs_delta += 1
    
    rel_patches = 0
    for i in range(MAX_TABLE_ENTRIES):
        off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in rel_repl:
            struct.pack_into('<I', exe, off, rel_repl[val])
            rel_patches += 1
    
    return abs_patches, abs_delta, rel_patches, 0


# ============================================================
# Build profiles
# ============================================================

def build_test_0(output_bin, output_cue):
    """Test 0: Plain DW7 disc copy - no modifications."""
    print("\n  Profile: test_0 (baseline DW7 copy)")
    shutil.copy(DW7_DISC, output_bin)
    write_cue(output_cue, os.path.basename(output_bin))
    # No EDC/ECC needed - it's a plain copy
    print(f"  Output: {output_bin}")
    print(f"  No modifications applied")


def build_test_a(output_bin, output_cue):
    """Test A: DQ4 HBD swap only, no EXE patches, no ISO dir update."""
    print("\n  Profile: test_a (DQ4 HBD swap, no patches)")
    shutil.copy(DW7_DISC, output_bin)
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, DQ4_HBD_SIZE)
    
    with open(output_bin, 'r+b') as f:
        print(f"  Writing DQ4 HBD at sector {HBD_LBA}...")
        write_raw_data(f, HBD_LBA, hbd_data)
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    print(f"  Output: {output_bin}")


def build_test_b(output_bin, output_cue):
    """Test B: DQ4 HBD + tree patches, no pointer patches."""
    print("\n  Profile: test_b (DQ4 HBD + tree patches)")
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    shutil.copy(DW7_DISC, output_bin)
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, DQ4_HBD_SIZE)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        write_raw_data(f, HBD_LBA, hbd_data)
        update_iso_dir(f, exe_size=len(exe_data))
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    print(f"  Output: {output_bin}")


def generate_disc_check_cheat(cht_path):
    """Generate DuckStation .cht file with RAM hooks for disc-check bypass.
    
    Patches all 9 disc-check sites in RAM after EXE load.
    Uses DuckStation's JSON .cht format with 32-bit write codes.
    
    EXE load address: 0x80017F00
    RAM address = 0x80017F00 + EXE_offset
    """
    EXE_BASE = 0x80017F00
    
    cheats = []
    for p in DISC_CHECK_PATCHES:
        ram_addr = EXE_BASE + p['offset']
        patch_bytes = p['patch']
        # Generate 32-bit write codes for each 4-byte chunk
        codes = []
        for i in range(0, len(patch_bytes), 4):
            chunk = patch_bytes[i:i+4]
            if len(chunk) < 4:
                chunk = chunk + b'\x00' * (4 - len(chunk))
            val = struct.unpack_from('<I', chunk)[0]
            addr = ram_addr + i
            # DuckStation code format: XXXXXXXX YYYYYYYY
            # Type 0 = 32-bit write (for PS1, use 80xxxxxx for 16-bit or direct 32-bit)
            # DuckStation uses: address value pairs in JSON
            codes.append(f"{addr:08X} {val:08X}")
        
        cheats.append({
            'name': p['desc'],
            'codes': codes,
        })
    
    # Write DuckStation JSON .cht format
    import json
    cht_data = {
        'game': 'DQ4 Frankenstein',
        'codes': []
    }
    
    # Combine all patches into one cheat group
    all_codes = []
    for p, c in zip(DISC_CHECK_PATCHES, cheats):
        all_codes.extend(c['codes'])
    
    cht_data['codes'].append({
        'name': 'Disc Check Bypass (All 9 Patches)',
        'enabled': True,
        'codes': all_codes,
    })
    
    with open(cht_path, 'w', encoding='utf-8') as f:
        json.dump(cht_data, f, indent=2)
    
    print(f"  Generated {len(all_codes)} RAM hook codes for {len(DISC_CHECK_PATCHES)} patches")


def build_test_d(output_bin, output_cue):
    """Test D: DW7 HBD + tree patches only (no HBD swap)."""
    print("\n  Profile: test_d (tree patches only, no HBD swap)")
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data))
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    print(f"  Output: {output_bin}")


def build_test_f(output_bin, output_cue):
    """Test F: ISO dir update only, no HBD/EXE changes."""
    print("\n  Profile: test_f (ISO dir update only)")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        update_iso_dir(f, exe_size=os.path.getsize(ORIGINAL_EXE))
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    print(f"  Output: {output_bin}")


def build_frank_v13(output_bin, output_cue):
    """Frankenstein v13 - Selective DQ4 overlay with DW7 HBD preserved.
    
    Root cause fix: The previous approach (v12) replaced the entire HBD with
    DQ4 data and applied +1 delta to 1755 unmatched ABS pointers. But DW7 HBD
    and DQ4 HBD have completely different data at the same relative sectors,
    so unmatched pointers read wrong data (19/20 sectors mismatched).
    
    This approach:
    1. Shifts DW7 HBD from sector 354 to 355 (extended EXE needs the extra sector)
    2. Copies all DW7 HBD data to the new location (data preserved, just shifted +1)
    3. Appends 883 matched DQ4 folders after DW7 HBD
    4. Patches matched ABS/REL pointers to new DQ4 locations
    5. Applies +1 delta to unmatched ABS pointers (CORRECT: same data, shifted by 1)
    6. Unlike v12, the +1 delta points to the SAME DW7 data, not different DQ4 data
    """
    print("\n  Profile: frank_v13 (selective DQ4 overlay, DW7 HBD preserved)")
    
    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355  # Shift by 1 to avoid EXE overlap
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA  # = 1
    DW7_HBD_SECTORS_ACTUAL = DW7_HBD_SIZE // USER_SIZE  # 302033
    DQ4_APPEND_LBA = NEW_HBD_LBA + DW7_HBD_SECTORS_ACTUAL  # 302388
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Load folder mapping
    with open(FOLDER_MAP, 'r', encoding='utf-8') as f:
        fm = json.load(f)
    mappings = fm['mappings']
    print(f"  Folder mappings: {len(mappings)}")
    
    # Sort mappings by dq4_sector so we write DQ4 folders in order
    mappings_sorted = sorted(mappings, key=lambda m: m['dq4_sector'])
    
    # Calculate total DQ4 sectors to append
    total_dq4_sectors = sum(m['dq4_sector_count'] for m in mappings_sorted)
    print(f"  Total DQ4 matched sectors: {total_dq4_sectors} ({total_dq4_sectors * USER_SIZE:,} bytes)")
    print(f"  Appending at disc sector {DQ4_APPEND_LBA}")
    
    # Build the ABS/REL replacement dicts
    # For each matched folder, the DQ4 data will be written at:
    #   disc_sector = DQ4_APPEND_LBA + running_offset
    # ABS pointer = disc_sector (absolute)
    # REL pointer = disc_sector - NEW_HBD_LBA (relative to HBD start)
    abs_repl = {}
    rel_repl = {}
    running_offset = 0
    folder_new_locations = []  # (dq4_sector, new_disc_sector, sector_count)
    
    for m in mappings_sorted:
        dq4_sec = m['dq4_sector']
        dq4_count = m['dq4_sector_count']
        dw7_sec = m['dw7_sector']
        
        new_disc_sector = DQ4_APPEND_LBA + running_offset
        new_abs = new_disc_sector
        new_rel = new_disc_sector - NEW_HBD_LBA
        old_rel = dw7_sec - OLD_HBD_LBA
        
        if dw7_sec != new_abs:
            abs_repl[dw7_sec] = new_abs
        if old_rel != new_rel and old_rel >= 0:
            rel_repl[old_rel] = new_rel
        
        folder_new_locations.append((dq4_sec, new_disc_sector, dq4_count))
        running_offset += dq4_count
    
    print(f"  Matched ABS replacements: {len(abs_repl)}")
    print(f"  Matched REL replacements: {len(rel_repl)}")
    
    # Patch matched pointers, and apply +1 delta to unmatched ABS entries.
    # The +1 delta is CORRECT here because we're shifting the DW7 HBD data
    # by 1 sector (354->355). The data at sector N+1 is the same data that
    # was at sector N. Unlike v12, where +1 pointed to different DQ4 data.
    print(f"\n  Patching matched folder pointers + LBA delta for unmatched...")
    abs_matched = 0
    abs_delta = 0
    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in abs_repl:
            struct.pack_into('<I', exe, off, abs_repl[val])
            abs_matched += 1
        elif val >= OLD_HBD_LBA and val < 0x100000:
            new_val = val + LBA_DELTA
            struct.pack_into('<I', exe, off, new_val)
            abs_delta += 1
    
    rel_matched = 0
    for i in range(MAX_TABLE_ENTRIES):
        off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in rel_repl:
            struct.pack_into('<I', exe, off, rel_repl[val])
            rel_matched += 1
        # NO delta for unmatched REL entries — relative offsets don't change
        # when both data and HBD base shift by the same amount.
    
    print(f"  Matched: abs={abs_matched}, rel={rel_matched}")
    print(f"  LBA delta (unmatched ABS only): {abs_delta}")
    print(f"  Unmatched REL: unchanged (relative offsets preserved)")
    
    # Patch LBA references 354->355
    print(f"\n  Patching LBA references (354->355)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")
    
    # Patch 16-bit sequential sector table
    print(f"  Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")
    
    # Disc-check bypass patches
    print(f"\n  Applying disc-check bypass patches...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe))
    exe = bytearray(exe_bytes)
    print(f"  Disc-check patches applied: {disc_patches}")
    
    # Patch MIPS tree refs
    print(f"\n  Patching MIPS tree refs...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # Append hybrid tree
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    # Patch BSS clear loop to skip the hybrid tree region
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X}")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping patch")
    exe_data = bytes(exe_data)
    
    # Assemble disc
    print(f"\n  Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)
    
    # Calculate new disc size needed
    new_disc_sectors = DQ4_APPEND_LBA + total_dq4_sectors
    new_disc_size = new_disc_sectors * SECTOR_SIZE
    
    # Extend the disc image if needed (structurally valid MODE2 sectors)
    extend_disc_mode2(output_bin, new_disc_size)
    
    with open(output_bin, 'r+b') as f:
        # Write patched EXE at sector 24
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)
        
        # Copy DW7 HBD data from sector 354 to sector 355 (shift by 1)
        print(f"  Copying DW7 HBD from sector {OLD_HBD_LBA} to {NEW_HBD_LBA}...")
        with open(DW7_DISC, 'rb') as dw7_f:
            for sec in range(DW7_HBD_SECTORS_ACTUAL):
                data = read_sector_user(dw7_f, OLD_HBD_LBA + sec)
                write_sector_user(f, NEW_HBD_LBA + sec, data)
                if sec % 50000 == 0 and sec > 0:
                    print(f"    {sec}/{DW7_HBD_SECTORS_ACTUAL} sectors copied...")
        print(f"  DW7 HBD copied to sectors {NEW_HBD_LBA}-{DQ4_APPEND_LBA - 1}")
        
        # Write matched DQ4 folders at sector DQ4_APPEND_LBA
        print(f"  Writing {len(folder_new_locations)} DQ4 folders at sector {DQ4_APPEND_LBA}...")
        # Read DQ4 HBD from source disc
        with open(DQ4_HBD_DISC, 'rb') as dq4_f:
            for idx, (dq4_rel_sec, new_disc_sec, sec_count) in enumerate(folder_new_locations):
                # Read DQ4 folder data from source disc
                src_disc_sec = DQ4_HBD_DISC_START + dq4_rel_sec
                folder_data = bytearray()
                for s in range(sec_count):
                    folder_data.extend(read_sector_user(dq4_f, src_disc_sec + s))
                
                # Write to output disc
                write_raw_data(f, new_disc_sec, bytes(folder_data))
                
                if idx % 100 == 0 and idx > 0:
                    print(f"    {idx}/{len(folder_new_locations)} folders written...")
        
        print(f"  All {len(folder_new_locations)} DQ4 folders written")
        
        # Update ISO directory
        new_hbd_size = (DW7_HBD_SECTORS_ACTUAL + total_dq4_sectors) * USER_SIZE
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=new_hbd_size, hbd_lba=NEW_HBD_LBA)
        print(f"  HBD: LBA={NEW_HBD_LBA}, size={new_hbd_size:,} ({new_hbd_size / 1024 / 1024:.1f} MB)")
        print(f"  Updating PVD...")
        update_pvd(f)
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: lba={lba_patches} seq={seq_patches} "
          f"abs={abs_matched + abs_delta} (matched={abs_matched} delta={abs_delta}) "
          f"rel={rel_matched} (matched only, unmatched unchanged) "
          f"disc={disc_patches} tree={tree_patches}")
    print(f"  Strategy: DW7 HBD shifted +1, DQ4 matched folders appended")
    print(f"  Unmatched ABS: +1 delta, Unmatched REL: unchanged")


def build_frank_v15(output_bin, output_cue):
    """Frankenstein v15 - test_d (known working) + surgical disc-check bypass.
    
    test_d was the last known working build: it showed the Enix logo, FMV,
    title screen, and adventure log. It only failed at "Game Start" with
    "Wrong Disc" error.
    
    v15 = test_d + 7 surgical disc-check patches (no function replacements).
    
    NO HBD shift (stays at 354).
    NO pointer patches.
    NO LBA reference patches.
    NO sequential sector table patches.
    NO DQ4 overlay.
    
    The STR/FMV data at LBA 146620 contains internal LBA references that
    point to original DW7 sector positions. Any HBD shift breaks these
    embedded references because we can't patch LBAs inside STR bitstreams.
    """
    print("\n  Profile: frank_v15 (test_d + surgical disc-check, NO HBD shift)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Tree patches (same as test_d)
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # Surgical disc-check bypass (preserves cd_init and disc_check functions)
    print(f"\n  Applying SURGICAL disc-check bypass...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Surgical disc-check patches: {disc_patches}")
    
    # Append hybrid tree (same as test_d)
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    # BSS clear patch (needed for extended EXE)
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X}")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping")
    exe_data = bytes(exe_data)
    
    # Assemble disc (HBD stays at 354, no shift)
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} (surgical) tree={tree_patches}")
    print(f"  Strategy: test_d baseline + surgical disc-check bypass")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v18(output_bin, output_cue):
    """Frankenstein v18 - test_d + semi-surgical (8 patches, no cd_init).
    
    The missing combination: disc_check_force_success YES, cd_init_force_success NO.
    CD-ROM hardware init runs normally (Getstat returns real status),
    disc validation forced to return success.
    
    NO HBD shift (stays at 354).
    """
    print("\n  Profile: frank_v18 (test_d + semi-surgical, NO HBD shift)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (8 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")
    
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X}")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping")
    exe_data = bytes(exe_data)
    
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} (semi-surgical) tree={tree_patches}")
    print(f"  Strategy: test_d + disc_check (NO cd_init bypass)")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v19(output_bin, output_cue):
    """Frankenstein v19 - test_d + semi-surgical + CD-ROM Stop intercept.
    
    v28 (semi-surgical) still got 'Wrong Disc' because the game sends a Stop
    command (0x08) to the CD-ROM drive during disc validation, causing
    Getstat to return 0x00 (stopped) instead of 0x02 (spinning). The
    secondary disc-check in decompressed overlays then fails.
    
    This build adds a MIPS trampoline that intercepts the Stop command at
    the hardware write point (RAM 0x80098664), preventing it from reaching
    the CD-ROM command register. This keeps the drive in its spinning state.
    
    NO HBD shift (stays at 354).
    """
    print("\n  Profile: frank_v19 (test_d + semi-surgical + Stop intercept)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Tree patches
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # Semi-surgical disc-check (8 patches, no cd_init)
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (8 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")
    
    # Append hybrid tree
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE (with tree): {len(exe_data):,} bytes")
    
    # BSS clear: KEEP ORIGINAL (no expansion)
    # The BSS clear at 0x2442C668 is in expansion RAM (0x24xxxxxx).
    # The trampoline at 0x800BCCC8 is in normal RAM (0x80xxxxxx).
    # Expanding BSS to 0x2442CCC8 was zeroing game data structures, causing
    # an infinite CD-ROM streaming loop. Not needed for the trampoline.
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    print(f"  BSS clear: UNCHANGED (0x{old_bss:08X}) — no expansion (trampoline is in normal RAM)")

    # CD-ROM Stop intercept trampoline
    print(f"\n  Applying CD-ROM Stop command intercept trampoline...")
    exe_data, trampoline_addr = append_cdrom_trampoline(bytes(exe_data), tree_addr)
    print(f"  Extended EXE (with trampoline): {len(exe_data):,} bytes")
    
    # Assemble disc (HBD stays at 354, no shift)
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} (semi-surgical) tree={tree_patches} stop_intercept=1")
    print(f"  Strategy: test_d + disc_check + Stop intercept trampoline")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v30(output_bin, output_cue):
    """Frankenstein v30 - targeted disc_check exit patches + Stop intercept.
    
    v29 showed 'Wrong Disc' during boot because disc_check_force_success
    replaced the ENTIRE disc_check function with 'return 1', skipping all
    CD-ROM setup code (calls to 0x8009757C, 0x80097590, CD command 6,
    flag setting at 0x800F.F150). Without this setup, the game enters an
    invalid state.
    
    v30 replaces the function-replacement patch with 3 targeted exit-point
    patches that only modify the return value at each exit path, preserving
    all CD-ROM setup code. The function runs normally but always returns 1.
    
    Also includes the CD-ROM Stop intercept trampoline from v19.
    NO HBD shift (stays at 354).
    """
    print("\n  Profile: frank_v30 (targeted disc_check exits + Stop intercept)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Tree patches
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # Semi-surgical disc-check (10 patches: 3 exit-point + 7 graft/nop/redirect, no cd_init)
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (10 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")
    
    # Append hybrid tree
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE (with tree): {len(exe_data):,} bytes")
    
    # BSS clear: patch start to skip hybrid tree + trampoline
    # Original BSS clear: 0x800BC668 -> 0x800F4980 (wipes tree at 0x800BC700 and trampoline!)
    # Patched BSS clear: 0x800BCCF0 -> 0x800F4980 (starts after trampoline end)
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        # Trampoline ends at tree_addr + tree_size + 40 = 0x800BCCF0
        # imm = 0x800BCCF0 - 0x800C0000 = -0x3310 = 0xCCF0 (unsigned 16-bit)
        new_bss = (old_bss & 0xFFFF0000) | 0xCCF0
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X} (skip tree+trampoline)")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping patch")

    # CD-ROM Stop intercept trampoline
    print(f"\n  Applying CD-ROM Stop command intercept trampoline...")
    exe_data, trampoline_addr = append_cdrom_trampoline(bytes(exe_data), tree_addr)
    print(f"  Extended EXE (with trampoline): {len(exe_data):,} bytes")
    
    # Assemble disc (HBD stays at 354, no shift)
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} (targeted exits) tree={tree_patches} stop_intercept=1")
    print(f"  Strategy: targeted disc_check exits + Stop intercept trampoline")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v31(output_bin, output_cue):
    """Frankenstein v31 - Unified build: v30 engine patches + v12 HBD swap.
    
    Combines:
    - v30's semi-surgical disc check bypass (10 patches, no cd_init)
    - v30's CD-ROM Stop intercept trampoline
    - v30's hybrid tree + BSS clear patch
    - v12's DQ4 HBD swap at LBA 355
    - v12's LBA reference patching (354->355)
    - v12's sequential sector table patching
    - v12's matched folder pointer remapping + unmatched ABS delta
    - v12's ISO directory update (LBA=355, size=DQ4_HBD_SIZE)
    """
    print("\n  Profile: frank_v31 (unified v30 engine + v12 HBD swap)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # ── 1. LBA references: patch all 354 -> 355 ─────────────────────────────
    print(f"\n  Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), 354, HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")
    
    # ── 2. Sequential sector table ──────────────────────────────────────────
    print(f"\n  Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), 354, HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")
    
    # ── 3. Folder pointer remapping ─────────────────────────────────────────
    with open(FOLDER_MAP, 'r', encoding='utf-8') as f:
        fm = json.load(f)
    mappings = fm['mappings']
    print(f"  Folder mappings: {len(mappings)}")
    
    abs_repl = {}
    rel_repl = {}
    for m in mappings:
        dw7_sec = m['dw7_sector']
        dq4_sec = m['dq4_sector']
        new_abs = dq4_sec + HBD_LBA
        old_rel = dw7_sec - HBD_LBA
        new_rel = dq4_sec
        if dw7_sec != new_abs:
            abs_repl[dw7_sec] = new_abs
        if old_rel != new_rel and old_rel >= 0:
            rel_repl[old_rel] = new_rel
    
    print(f"\n  Patching matched folder pointers + LBA delta for unmatched...")
    LBA_DELTA = HBD_LBA - 354  # = 1
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    print(f"  Matched: abs={abs_matched}, rel={rel_matched}")
    print(f"  LBA delta (unmatched ABS): {abs_delta}")
    print(f"  Total patches: abs={abs_matched + abs_delta}, rel={rel_matched}")
    
    # ── 4. Disc-check bypass (semi-surgical: 10 patches, no cd_init) ────────
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (10 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")
    
    # ── 5. Hybrid tree (RELOCATED to 0x80100000 — high RAM, outside BSS+data) ──
    # BSS region: 0x800BC668 - 0x800F4980 (code-level clear loop)
    # Game data section: 0x800F4980 - 0x800F9E54+ (variables, DMA buffers)
    # Stack: 0x801FFFF0
    # 0x800F4980 was originally chosen as "outside BSS" but it's actually
    # the start of the game's initialized data section — game init writes
    # to 0x800F4980+ (e.g., 0x800F49A8), overwriting our tree.
    # 0x80100000 is safely above all game data and below the stack.
    TREE_RAM_ADDR = 0x80100000
    print(f"\n  Patching MIPS tree refs (relocated to 0x{TREE_RAM_ADDR:08X})...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe), target_ram_addr=TREE_RAM_ADDR)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # ── 6. Reloc payload: tree + trampoline + copy routine ───────────────────
    print(f"\n  Appending reloc payload (tree+trampoline+copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    exe_data, tree_target, tramp_target = append_reloc_payload(
        bytes(exe), TREE_RAM_ADDR, original_pc0
    )
    print(f"  Extended EXE (with reloc payload): {len(exe_data):,} bytes")
    max_exe = (HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"  Max EXE before HBD overlap: {max_exe:,} bytes — {'OK' if len(exe_data) <= max_exe else 'OVERLAP!'}")
    
    # ── 8. Extract DQ4 HBD ──────────────────────────────────────────────────
    print(f"\n  Extracting DQ4 HBD...")
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, DQ4_HBD_SIZE)
    print(f"  DQ4 HBD: {len(hbd_data):,} bytes")
    
    # ── 9. Assemble disc ────────────────────────────────────────────────────
    print(f"\n  Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)
        print(f"  Writing DQ4 HBD at sector {HBD_LBA}...")
        write_raw_data(f, HBD_LBA, hbd_data)
        print(f"  DQ4 HBD spans sectors {HBD_LBA}-{DQ4_HBD_END - 1}")
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=DQ4_HBD_SIZE)
        print(f"  HBD: LBA={HBD_LBA}, size={DQ4_HBD_SIZE:,}")
        print(f"  Updating PVD...")
        update_pvd(f)
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    expected = os.path.getsize(DW7_DISC)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes (expected {expected:,})")
    print(f"  Patches: lba={lba_patches} seq={seq_patches} "
          f"abs={abs_matched + abs_delta}(matched={abs_matched},delta={abs_delta}) "
          f"rel={rel_matched} disc={disc_patches} tree={tree_patches} "
          f"reloc_payload=1 stop_intercept=1")
    print(f"  Strategy: v30 engine patches + v12 HBD swap (unified, reloc payload to 0x80100000)")


def build_frank_v29_control(output_bin, output_cue):
    """Control build: v19 WITHOUT Stop intercept trampoline or BSS expansion.

    This isolates whether the trampoline code or the BSS clear expansion
    (0x2442C668 -> 0x2442CCC8) is causing the infinite CD-ROM streaming loop
    observed in v29. If this control build boots to the Enix logo and menus,
    the problem is confirmed to be the trampoline/BSS changes.
    """
    print("\n  Profile: frank_v29_ctrl (CONTROL: no trampoline, no BSS expansion)")

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # Tree patches
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # Semi-surgical disc-check (8 patches, no cd_init)
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (8 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")

    # Append hybrid tree
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE (with tree): {len(exe_data):,} bytes")

    # BSS clear: KEEP ORIGINAL (no expansion)
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    print(f"  BSS clear: UNCHANGED (0x{old_bss:08X}) — no expansion")

    # NO trampoline — this is the control
    print(f"  CD-ROM Stop intercept: SKIPPED (control build)")

    # Assemble disc (HBD stays at 354, no shift)
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} (semi-surgical) tree={tree_patches} stop_intercept=0")
    print(f"  Strategy: test_d + disc_check (CONTROL — no trampoline, no BSS expansion)")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v17(output_bin, output_cue):
    """Frankenstein v17 - clean test_d + BSS clear, NO disc-check patches.
    
    Disc-check bypass is handled at runtime via DuckStation .cht cheat codes
    (RAM hooks), not by modifying the EXE binary. This keeps the EXE pristine
    and lets the CD-ROM hardware init run normally until the cheat engine
    patches the disc-check functions after load.
    
    NO disc-check patches in EXE.
    NO HBD shift (stays at 354).
    Tree patches + BSS clear only.
    """
    print("\n  Profile: frank_v17 (clean test_d + BSS, disc-check via RAM hook)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Tree patches (same as test_d)
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # NO disc-check patches - handled via .cht RAM hooks
    
    # Append hybrid tree (same as test_d)
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    # BSS clear patch (needed for extended EXE)
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X}")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping")
    exe_data = bytes(exe_data)
    
    # Assemble disc (HBD stays at 354, no shift)
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    # Generate DuckStation .cht file with RAM hooks for disc-check bypass
    base_name = os.path.splitext(os.path.basename(output_bin))[0]
    cht_path = os.path.join(os.path.dirname(output_bin), base_name + '.cht')
    generate_disc_check_cheat(cht_path)
    print(f"  Cheat file: {cht_path}")
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: tree={tree_patches} (NO disc-check in EXE)")
    print(f"  Strategy: clean test_d + BSS clear, disc-check via RAM hook")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v16(output_bin, output_cue):
    """Frankenstein v16 - test_d + FULL disc-check bypass, NO HBD shift.
    
    v15 used surgical (7) patches but got stuck in Getstat polling loop
    ("Please Insert Disc 1"). The surgical patches don't force the disc
    check function to return success, so the game keeps polling CD status.
    
    v23/v24 proved the hang was caused by the HBD shift (STR internal LBAs),
    NOT by the disc-check patches. So we can safely use all 9 patches.
    
    v16 = test_d + all 9 disc-check patches. NO HBD shift.
    """
    print("\n  Profile: frank_v16 (test_d + full disc-check, NO HBD shift)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Tree patches (same as test_d)
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # FULL disc-check bypass (all 9 patches, including cd_init and disc_check)
    print(f"\n  Applying FULL disc-check bypass...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), surgical=False)
    exe = bytearray(exe_bytes)
    print(f"  Full disc-check patches: {disc_patches}")
    
    # Append hybrid tree (same as test_d)
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    # BSS clear patch (needed for extended EXE)
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X}")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping")
    exe_data = bytes(exe_data)
    
    # Assemble disc (HBD stays at 354, no shift)
    print(f"\n  Assembling disc (HBD at 354, no shift)...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, exe_data)
        update_iso_dir(f, exe_size=len(exe_data), hbd_lba=354)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe_data):,}")
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} (full) tree={tree_patches}")
    print(f"  Strategy: test_d baseline + full disc-check bypass")
    print(f"  HBD: NOT shifted (stays at 354)")


def build_frank_v14(output_bin, output_cue):
    """Frankenstein v14 - v13 with SURGICAL disc-check bypass.
    
    Root cause of v23 regression: cd_init_force_success replaced the entire
    CD-ROM initialization function with 'return 1', preventing MODE2
    double-speed streaming setup needed for FMV playback. The MDEC video
    decoder was never configured, causing the engine to spin on MDEC
    status register 0x1F801824 waiting for a decode completion flag
    that never flips.
    
    v14 fix: Keep cd_init and disc_check functions intact. Apply only
    the targeted graft patches that skip specific branch conditions
    in the disc validation logic. This preserves CD-ROM hardware
    initialization while still bypassing the 'Wrong Disc' error.
    
    All other v13 changes are preserved:
    - DW7 HBD shifted from 354 to 355
    - DQ4 matched folders appended at 302388
    - +1 delta on unmatched ABS pointers
    - LBA references and sequential sector table patched
    - Hybrid tree appended, BSS clear adjusted
    - Tree MIPS refs patched
    """
    print("\n  Profile: frank_v14 (surgical disc-check, CD-ROM init preserved)")
    
    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA
    DW7_HBD_SECTORS_ACTUAL = DW7_HBD_SIZE // USER_SIZE
    DQ4_APPEND_LBA = NEW_HBD_LBA + DW7_HBD_SECTORS_ACTUAL
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    with open(FOLDER_MAP, 'r', encoding='utf-8') as f:
        fm = json.load(f)
    mappings = fm['mappings']
    print(f"  Folder mappings: {len(mappings)}")
    
    mappings_sorted = sorted(mappings, key=lambda m: m['dq4_sector'])
    total_dq4_sectors = sum(m['dq4_sector_count'] for m in mappings_sorted)
    print(f"  Total DQ4 matched sectors: {total_dq4_sectors} ({total_dq4_sectors * USER_SIZE:,} bytes)")
    print(f"  Appending at disc sector {DQ4_APPEND_LBA}")
    
    # Build ABS/REL replacement dicts
    abs_repl = {}
    rel_repl = {}
    running_offset = 0
    folder_new_locations = []
    
    for m in mappings_sorted:
        dq4_sec = m['dq4_sector']
        dq4_count = m['dq4_sector_count']
        dw7_sec = m['dw7_sector']
        
        new_disc_sector = DQ4_APPEND_LBA + running_offset
        new_abs = new_disc_sector
        new_rel = new_disc_sector - NEW_HBD_LBA
        old_rel = dw7_sec - OLD_HBD_LBA
        
        if dw7_sec != new_abs:
            abs_repl[dw7_sec] = new_abs
        if old_rel != new_rel and old_rel >= 0:
            rel_repl[old_rel] = new_rel
        
        folder_new_locations.append((dq4_sec, new_disc_sector, dq4_count))
        running_offset += dq4_count
    
    print(f"  Matched ABS replacements: {len(abs_repl)}")
    print(f"  Matched REL replacements: {len(rel_repl)}")
    
    # Patch matched pointers + LBA delta for unmatched ABS
    print(f"\n  Patching matched folder pointers + LBA delta for unmatched...")
    abs_matched = 0
    abs_delta = 0
    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in abs_repl:
            struct.pack_into('<I', exe, off, abs_repl[val])
            abs_matched += 1
        elif val >= OLD_HBD_LBA and val < 0x100000:
            new_val = val + LBA_DELTA
            struct.pack_into('<I', exe, off, new_val)
            abs_delta += 1
    
    rel_matched = 0
    for i in range(MAX_TABLE_ENTRIES):
        off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 4 > len(exe):
            break
        val = struct.unpack_from('<I', exe, off)[0]
        if val == 0:
            continue
        if val in rel_repl:
            struct.pack_into('<I', exe, off, rel_repl[val])
            rel_matched += 1
    
    print(f"  Matched: abs={abs_matched}, rel={rel_matched}")
    print(f"  LBA delta (unmatched ABS only): {abs_delta}")
    
    # Patch LBA references 354->355
    print(f"\n  Patching LBA references (354->355)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")
    
    # Patch 16-bit sequential sector table
    print(f"  Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")
    
    # SURGICAL disc-check bypass (skip cd_init and disc_check function replacements)
    print(f"\n  Applying SURGICAL disc-check bypass (cd_init preserved)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Surgical disc-check patches applied: {disc_patches}")
    print(f"  SKIPPED: cd_init_force_success (preserves CD-ROM MODE2 init)")
    print(f"  SKIPPED: disc_check_force_success (preserves disc validation logic)")
    
    # Patch MIPS tree refs
    print(f"\n  Patching MIPS tree refs...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # Append hybrid tree
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    # Patch BSS clear loop
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X}")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X}, skipping patch")
    exe_data = bytes(exe_data)
    
    # Assemble disc
    print(f"\n  Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)
    
    new_disc_sectors = DQ4_APPEND_LBA + total_dq4_sectors
    new_disc_size = new_disc_sectors * SECTOR_SIZE
    
    extend_disc_mode2(output_bin, new_disc_size)
    
    with open(output_bin, 'r+b') as f:
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)
        
        print(f"  Copying DW7 HBD from sector {OLD_HBD_LBA} to {NEW_HBD_LBA}...")
        with open(DW7_DISC, 'rb') as dw7_f:
            for sec in range(DW7_HBD_SECTORS_ACTUAL):
                data = read_sector_user(dw7_f, OLD_HBD_LBA + sec)
                write_sector_user(f, NEW_HBD_LBA + sec, data)
                if sec % 50000 == 0 and sec > 0:
                    print(f"    {sec}/{DW7_HBD_SECTORS_ACTUAL} sectors copied...")
        print(f"  DW7 HBD copied to sectors {NEW_HBD_LBA}-{DQ4_APPEND_LBA - 1}")
        
        print(f"  Writing {len(folder_new_locations)} DQ4 folders at sector {DQ4_APPEND_LBA}...")
        with open(DQ4_HBD_DISC, 'rb') as dq4_f:
            for idx, (dq4_rel_sec, new_disc_sec, sec_count) in enumerate(folder_new_locations):
                src_disc_sec = DQ4_HBD_DISC_START + dq4_rel_sec
                folder_data = bytearray()
                for s in range(sec_count):
                    folder_data.extend(read_sector_user(dq4_f, src_disc_sec + s))
                write_raw_data(f, new_disc_sec, bytes(folder_data))
                if idx % 100 == 0 and idx > 0:
                    print(f"    {idx}/{len(folder_new_locations)} folders written...")
        
        print(f"  All {len(folder_new_locations)} DQ4 folders written")
        
        new_hbd_size = (DW7_HBD_SECTORS_ACTUAL + total_dq4_sectors) * USER_SIZE
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=new_hbd_size, hbd_lba=NEW_HBD_LBA)
        print(f"  HBD: LBA={NEW_HBD_LBA}, size={new_hbd_size:,} ({new_hbd_size / 1024 / 1024:.1f} MB)")
        print(f"  Updating PVD...")
        update_pvd(f)
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: lba={lba_patches} seq={seq_patches} "
          f"abs={abs_matched + abs_delta} (matched={abs_matched} delta={abs_delta}) "
          f"rel={rel_matched} (matched only) "
          f"disc={disc_patches} (surgical) tree={tree_patches}")
    print(f"  Strategy: DW7 HBD shifted +1, DQ4 matched folders appended")
    print(f"  Disc-check: SURGICAL (cd_init preserved, graft/nop/redirect only)")


def build_frank_v12(output_bin, output_cue):
    """Full Frankenstein v12 - DW7-preserved pointer redirect strategy."""
    print("\n  Profile: frank_v12 (DW7-preserved pointer redirect)")
    
    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")
    
    # Patch ALL LBA references from 354 to 355 (broad scan)
    print(f"\n  Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), 354, HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")
    
    # Patch 16-bit sequential sector table at 0xA39AA
    print(f"\n  Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), 354, HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")
    
    # Load folder mapping
    with open(FOLDER_MAP, 'r', encoding='utf-8') as f:
        fm = json.load(f)
    mappings = fm['mappings']
    print(f"  Folder mappings: {len(mappings)}")
    
    # Build replacement dicts for matched folders
    abs_repl = {}
    rel_repl = {}
    for m in mappings:
        dw7_sec = m['dw7_sector']
        dq4_sec = m['dq4_sector']
        new_abs = dq4_sec + HBD_LBA
        old_rel = dw7_sec - HBD_LBA
        new_rel = dq4_sec
        if dw7_sec != new_abs:
            abs_repl[dw7_sec] = new_abs
        if old_rel != new_rel and old_rel >= 0:
            rel_repl[old_rel] = new_rel
    
    # Strategy: Only patch matched folder pointers, leave unmatched ones unchanged.
    # Unmatched pointers keep their original sector values, which now point to
    # DQ4 HBD data (different content but valid data structure).
    # The previous "DW7-preserved redirect" was broken: it added DQ4_HBD_SECTORS
    # to pointer values, but the DW7 data at sectors 355-156329 was overwritten
    # (not moved to 156330+), so remapped pointers pointed to wrong data.
    print(f"\n  Patching matched folder pointers + LBA delta for unmatched...")
    LBA_DELTA = HBD_LBA - 354  # = 1
    abs_matched, abs_delta, rel_matched, rel_preserved = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    total_abs = abs_matched + abs_delta
    total_rel = rel_matched
    print(f"  Matched: abs={abs_matched}, rel={rel_matched}")
    print(f"  LBA delta (unmatched ABS): {abs_delta}")
    print(f"  Total patches: abs={total_abs}, rel={total_rel}")
    
    # Disc-check bypass patches
    print(f"\n  Applying disc-check bypass patches...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe))
    exe = bytearray(exe_bytes)
    print(f"  Disc-check patches applied: {disc_patches}")
    
    # Patch MIPS tree refs
    print(f"\n  Patching MIPS tree refs...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe))
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")
    
    # Append hybrid tree
    exe_data = append_hybrid_tree(bytes(exe))
    print(f"  Extended EXE: {len(exe_data):,} bytes")
    
    # Patch BSS clear loop to skip the hybrid tree region.
    # The DW7 EXE entry point (0x8008E284) runs a BSS zero-fill from 0x800BC668
    # to 0x800F4980. Our hybrid tree is appended at 0x800BC700, inside this range.
    # Without this patch, the tree is zeroed at runtime before any code uses it.
    # Patch: change BSS start from 0x800BC668 to 0x800BCCC8 (after tree end).
    # File offset 0x76B88: addiu $v0, $v0, 0xC668 -> 0xCCC8
    BSS_PATCH_OFF = 0x76B88
    exe_data = bytearray(exe_data)
    old_bss = struct.unpack_from('<I', exe_data, BSS_PATCH_OFF)[0]
    if old_bss == 0x2442C668:
        new_bss = (old_bss & 0xFFFF0000) | 0xCCC8
        struct.pack_into('<I', exe_data, BSS_PATCH_OFF, new_bss)
        print(f"  BSS clear patched: 0x{old_bss:08X} -> 0x{new_bss:08X} (skip tree at 0x800BC700)")
    else:
        print(f"  WARNING: BSS clear at 0x{BSS_PATCH_OFF:X} = 0x{old_bss:08X} (expected 0x2442C668), skipping patch")
    exe_data = bytes(exe_data)
    
    # Extract DQ4 HBD
    print(f"\n  Extracting DQ4 HBD...")
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, DQ4_HBD_SIZE)
    print(f"  DQ4 HBD: {len(hbd_data):,} bytes")
    
    # Assemble disc
    print(f"\n  Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)
        print(f"  Writing DQ4 HBD at sector {HBD_LBA}...")
        write_raw_data(f, HBD_LBA, hbd_data)
        print(f"  DW7 data preserved beyond sector {DQ4_HBD_END}")
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=DQ4_HBD_SIZE)
        print(f"  Updating PVD...")
        update_pvd(f)
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    expected = os.path.getsize(DW7_DISC)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes (expected {expected:,})")
    print(f"  Match: {'YES' if final_size == expected else 'NO'}")
    print(f"  Patches: lba={lba_patches} seq={seq_patches} "
          f"abs={total_abs} (matched={abs_matched} delta={abs_delta}) "
          f"rel={total_rel} disc={disc_patches} tree={tree_patches}")


def build_rc2(output_bin, output_cue):
    """RC2: DQ4 EXE + patched HBD on DW7 body (no zeroing)."""
    print("\n  Profile: rc2 (DQ4 EXE + patched HBD, no zeroing)")
    
    # Read DQ4 EXE and HBD from the patched DQ4 disc
    print(f"  Reading patched DQ4 disc...")
    with open(DQ4_EXE_DISC, 'rb') as f:
        # Read directory
        dir_data = read_sector_user(f, 22)
        hbd_size = DQ4_HBD_SIZE
        exe_size = 692224
        off = 0
        while off < len(dir_data):
            rec_len = dir_data[off] & 0xFF
            if rec_len == 0:
                break
            name_len = dir_data[off + 32] & 0xFF
            name = dir_data[off + 33:off + 33 + name_len].decode('ascii', errors='replace').rstrip('\x00')
            fsize = struct.unpack_from('<I', dir_data, off + 10)[0]
            if 'HBD' in name:
                hbd_size = fsize
            elif name.startswith('SL'):
                exe_size = fsize
            off += rec_len
        
        # Extract EXE
        exe_sectors = (exe_size + USER_SIZE - 1) // USER_SIZE
        exe_data = bytearray()
        for i in range(exe_sectors):
            f.seek((EXE_LBA + i) * SECTOR_SIZE + USER_OFFSET)
            exe_data.extend(f.read(USER_SIZE))
        exe_data = bytes(exe_data[:exe_size])
        print(f"  DQ4 EXE: {len(exe_data):,} bytes ({exe_sectors} sectors)")
        
        # Extract HBD
        hbd_sectors = (hbd_size + USER_SIZE - 1) // USER_SIZE
        hbd_data = bytearray()
        for i in range(hbd_sectors):
            f.seek((362 + i) * SECTOR_SIZE + USER_OFFSET)
            hbd_data.extend(f.read(USER_SIZE))
            if i % 50000 == 0 and i > 0:
                print(f"    {i}/{hbd_sectors} sectors...")
        hbd_data = bytes(hbd_data[:hbd_size])
        print(f"  DQ4 HBD: {len(hbd_data):,} bytes ({hbd_sectors} sectors)")
        
        # Extract SYSTEM.CNF
        cnf_data = read_sector_user(f, 23)
    
    # Copy DW7 disc as base
    print(f"  Copying DW7 disc as base...")
    shutil.copy(DW7_DISC, output_bin)
    
    with open(output_bin, 'r+b') as f:
        print(f"  Writing DQ4 EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)
        
        print(f"  Writing patched HBD at sector 362...")
        write_raw_data(f, 362, hbd_data)
        
        # DO NOT zero trailing sectors - leave DW7 data intact
        print(f"  NOT zeroing trailing sectors (DW7 data preserved)")
        
        # Write SYSTEM.CNF
        print(f"  Writing SYSTEM.CNF...")
        write_sector_user(f, 23, cnf_data)
        
        # Update ISO directory
        print(f"  Updating ISO directory...")
        dir_data = bytearray(read_sector_user(f, 22))
        off = 0
        while off < len(dir_data):
            rec_len = dir_data[off] & 0xFF
            if rec_len == 0:
                break
            name_len = dir_data[off + 32] & 0xFF
            name = dir_data[off + 33:off + 33 + name_len].decode('ascii', errors='replace').rstrip('\x00')
            if 'HBD' in name:
                new_name = b"HBD1PS1D.Q41;1"
                struct.pack_into('<I', dir_data, off + 2, 362)
                struct.pack_into('>I', dir_data, off + 6, 362)
                struct.pack_into('<I', dir_data, off + 10, hbd_size)
                struct.pack_into('>I', dir_data, off + 14, hbd_size)
                dir_data[off + 32] = len(new_name)
                dir_data[off + 33:off + 33 + len(new_name)] = new_name
                print(f"    HBD: {new_name.decode()} LBA=362 size={hbd_size:,}")
            elif name.startswith('SL') and 'SYSTEM' not in name:
                new_name = b"SLPM_869.16;1"
                struct.pack_into('<I', dir_data, off + 2, EXE_LBA)
                struct.pack_into('>I', dir_data, off + 6, EXE_LBA)
                struct.pack_into('<I', dir_data, off + 10, exe_size)
                struct.pack_into('>I', dir_data, off + 14, exe_size)
                dir_data[off + 32] = len(new_name)
                dir_data[off + 33:off + 33 + len(new_name)] = new_name
                print(f"    EXE: {new_name.decode()} LBA={EXE_LBA} size={exe_size:,}")
            elif 'SYSTEM' in name or 'CNF' in name:
                struct.pack_into('<I', dir_data, off + 2, 23)
                struct.pack_into('>I', dir_data, off + 6, 23)
                print(f"    CNF: {name} LBA=23")
            off += rec_len
        write_sector_user(f, 22, bytes(dir_data))
        
        # Update PVD
        update_pvd(f, b'DQ4_ENGLISH_RC2')
    
    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)
    
    final_size = os.path.getsize(output_bin)
    expected = os.path.getsize(DW7_DISC)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes (expected {expected:,})")
    print(f"  Match: {'YES' if final_size == expected else 'NO'}")


# ============================================================
# Localization Graft helpers (v35)
# ============================================================

def patch_bss_clear_start(exe, new_start_ram):
    """Patch the BSS clear loop start address.

    The BSS clear is at the original PC0 (0x8008E284):
      lui $t0, 0x800C; addiu $t0, $t0, 0xC668  # start = 0x800BC668
      lui $t1, 0x800F; addiu $t1, $t1, 0x4980  # end = 0x800F4980
      sw $zero, 0($t0); addiu $t0, 4; sltu; bne loop

    We patch the start address so BSS clear skips the tree region.
    """
    data = bytearray(exe)
    # BSS clear start LUI at file offset 0x76B84, ADDIU at 0x76B88
    bss_lui_off = 0x76B84
    bss_addiu_off = 0x76B88

    old_lui = struct.unpack_from('<I', data, bss_lui_off)[0]
    old_addiu = struct.unpack_from('<I', data, bss_addiu_off)[0]

    # Compute new LUI/ADDIU for new_start_ram
    new_lo = new_start_ram & 0xFFFF
    new_hi = (new_start_ram >> 16) & 0xFFFF
    if new_lo >= 0x8000:
        new_hi = (new_hi + 1) & 0xFFFF

    new_lui = (old_lui & 0xFFFF0000) | new_hi
    new_addiu = (old_addiu & 0xFFFF0000) | new_lo

    struct.pack_into('<I', data, bss_lui_off, new_lui)
    struct.pack_into('<I', data, bss_addiu_off, new_addiu)

    # DO NOT patch the second LUI/ADDIU pair at 0x76BA8/0x76BAC
    # That loads 0x800BC668 for $gp setup after BSS clear — changing it
    # would shift all global variable accesses and break the game.

    print(f"    BSS clear start: 0x800BC668 -> 0x{new_start_ram:08X}")
    return bytes(data)


def append_tree_inplace(exe_data, original_pc0):
    """Append hybrid tree + CD-ROM trampoline directly to EXE text segment.

    Unlike append_reloc_payload, this does NOT use a copy routine.
    The tree stays at its on-disc RAM address (within t_size range).
    BSS clear is patched to skip the tree region.

    Layout (all within EXE, loaded by DuckStation):
      [original EXE] [tree 1480B] [trampoline 40B] [padding]

    Tree ends up at RAM 0x800BC700 (file offset 0xA5000).
    Trampoline at RAM 0x800BCCC8 (file offset 0xA55C8).
    BSS clear start patched from 0x800BC668 to 0x800BCD00.

    Returns (patched_exe, tree_ram_addr, trampoline_ram_addr).
    """
    exe = bytearray(exe_data)
    load_addr = struct.unpack_from('<I', exe, 0x18)[0]  # 0x80017F00

    with open(HYBRID_TREE, 'rb') as f:
        hybrid_tree = f.read()
    tree_size = len(hybrid_tree)

    # Align EXE to 4 bytes
    padding = (4 - (len(exe) % 4)) % 4
    if padding:
        exe = exe + b'\x00' * padding

    # Tree at current end of EXE
    tree_file_off = len(exe)
    tree_ram = load_addr + tree_file_off - 0x800
    exe = exe + hybrid_tree

    # Trampoline after tree (aligned)
    tramp_ram = (tree_ram + tree_size + 3) & ~3
    tramp_file_off = tramp_ram - load_addr + 0x800
    if tramp_file_off + 40 > len(exe):
        exe = exe + b'\x00' * (tramp_file_off + 40 - len(exe))

    # Build trampoline (CD-ROM Stop intercept)
    beq_stop_offset = 3
    beq_not_taken_offset = 3
    j_bne_target = (CDROM_BRANCH_TARGET >> 2) & 0x3FFFFFF
    j_return_target = (CDROM_AFTER_BRANCH_RAM >> 2) & 0x3FFFFFF
    orig_delay_slot = 0x00001021

    trampoline = [
        (0x09 << 26) | (0 << 21) | (1 << 16) | 8,           # addiu $at, $zero, 8 (Stop cmd)
        (0x04 << 26) | (17 << 21) | (1 << 16) | beq_stop_offset,  # beq $s1, $at, +3
        0x00000000,                                          # nop
        (0x28 << 26) | (2 << 21) | (17 << 16) | 0,           # slti $v0, $s1, 0
        (0x04 << 26) | (18 << 21) | (0 << 16) | beq_not_taken_offset,  # beq $v0, $zero, +3
        orig_delay_slot,                                     # addu $v0, $zero, $zero
        (0x02 << 26) | j_bne_target,                         # j CDROM_BRANCH_TARGET
        0x00000000,                                          # nop
        (0x02 << 26) | j_return_target,                      # j CDROM_AFTER_BRANCH_RAM
        0x00000000,                                          # nop
    ]

    for i, insn in enumerate(trampoline):
        struct.pack_into('<I', exe, tramp_file_off + i * 4, insn)

    # Pad to sector boundary and update t_size
    sector_pad = (2048 - (len(exe) % 2048)) % 2048
    if sector_pad:
        exe = exe + b'\x00' * sector_pad
    new_text_size = len(exe) - 0x800
    struct.pack_into('<I', exe, 0x1C, new_text_size)

    # Patch BSS clear start to skip tree+trampoline region
    bss_new_start = (tramp_ram + len(trampoline) * 4 + 3) & ~3
    exe = patch_bss_clear_start(bytes(exe), bss_new_start)
    exe = bytearray(exe)

    # Patch CD-ROM cmd write to j trampoline (on-disc, not copied)
    j_to_trampoline = (0x02 << 26) | ((tramp_ram >> 2) & 0x3FFFFFF)
    struct.pack_into('<I', exe, CDROM_CMD_WRITE_OFF, j_to_trampoline)
    struct.pack_into('<I', exe, CDROM_BRANCH_OFF, 0x00000000)

    # Keep original PC0 — no copy routine needed
    # PC0 stays at original_pc0 (BSS clear → game init)

    print(f"  Tree (in-place):  RAM 0x{tree_ram:08X} (file 0x{tree_file_off:05X}), {tree_size}B")
    print(f"  Trampoline:       RAM 0x{tramp_ram:08X} (file 0x{tramp_file_off:05X}), {len(trampoline)*4}B")
    print(f"  BSS clear start:  0x{bss_new_start:08X}")
    print(f"  PC0: 0x{original_pc0:08X} (unchanged — no copy routine)")
    print(f"  CD-ROM intercept: j 0x{tramp_ram:08X}")
    print(f"  t_size: 0x{new_text_size:X} ({new_text_size:,} bytes)")
    print(f"  EXE total: {len(exe):,} bytes")

    return bytes(exe), tree_ram, tramp_ram


def patch_hbd_filename_q71(exe):
    """Patch EXE to look for 'hbd1ps1d.q71' instead of 'hbd1ps1d.w71'.

    DW7 EXE has the hardcoded HBD filename at file offset ~0x0F600.
    We change w71->q71 and w72->q72 so the engine opens the grafted archive.
    """
    data = bytearray(exe)
    patches = 0
    for old, new in [(b'hbd1ps1d.w71', b'hbd1ps1d.q71'),
                     (b'hbd1ps1d.w72', b'hbd1ps1d.q72')]:
        idx = data.find(old)
        while idx != -1:
            data[idx:idx + len(old)] = new
            patches += 1
            print(f"    Patched '{old.decode()}' -> '{new.decode()}' at file offset 0x{idx:05X}")
            idx = data.find(old, idx + 1)
    return bytes(data), patches


def update_volume_identifier(hbd_data, vol_id=b'hdb1ps1d.q71'):
    """Patch the HBD internal volume identifier at offset 0x740.

    The engine's filesystem driver validates this string against the
    expected archive name.  We write the identifier padded with nulls
    to a 16-byte field.
    """
    data = bytearray(hbd_data)
    target = vol_id.ljust(16, b'\x00')
    data[0x740:0x740 + 16] = target[:16]
    print(f"    Volume ID @ 0x740: {vol_id.decode()}")
    return bytes(data)


def update_iso_dir_hbd_name(f, new_name=b'HBD1PS1D.Q71;1'):
    """Update the ISO 9660 directory entry filename for the HBD file."""
    dir_data = bytearray(read_sector_user(f, 22))
    offset = 0
    while offset < len(dir_data):
        rec_len = dir_data[offset] & 0xFF
        if rec_len == 0:
            break
        name_len = dir_data[offset + 32] & 0xFF
        name = dir_data[offset + 33:offset + 33 + name_len].decode('ascii', errors='replace').rstrip('\x00')
        if 'HBD' in name:
            old_name = dir_data[offset + 33:offset + 33 + name_len]
            new_padded = new_name.ljust(name_len, b'\x00')
            dir_data[offset + 33:offset + 33 + name_len] = new_padded[:name_len]
            print(f"    ISO dir HBD: '{name}' -> '{new_name.decode()}'")
            break
        offset += rec_len
    write_sector_user(f, 22, bytes(dir_data))


def patch_audio_bank_sizes(hbd_data, bank_offsets=(0x0C, 0x18, 0x24, 0x30)):
    """Patch instrument bank sizes in the sound format header.

    The sequence driver architecture is shared between DQ4 and DW7, but
    instrument banks are stored at different indexes.  We force the engine
    to load the correct wave banks by patching the bank size fields at
    the given offsets in the sound format header.

    The sound header is located by searching for the DQ4 sound signature
    (0x50424153 = 'PBAS' or similar).  If not found, no patches are applied.
    """
    data = bytearray(hbd_data)
    patches = 0

    # Search for the sound format header signature
    # The DQ4 sound header starts with a known pattern
    sig = b'\x53\x45\x44\x42'  # 'SEDB' - Sound Engine Data Block
    idx = data.find(sig)
    if idx == -1:
        # Try alternate signature
        sig = b'\x50\x42\x41\x53'  # 'PBAS'
        idx = data.find(sig)

    if idx == -1:
        print("    Audio: No sound header signature found, skipping bank size patches")
        return bytes(data), 0

    # Patch bank size fields at the given offsets relative to the header
    for off in bank_offsets:
        field_off = idx + off
        if field_off + 4 <= len(data):
            old_val = struct.unpack_from('<I', data, field_off)[0]
            # Force bank size to match DQ4 expected values
            # Use the value already present (DQ4 banks) - this is a no-op
            # if the data is already correct, but ensures alignment
            if old_val > 0:
                print(f"    Audio bank @ 0x{field_off:06X}: size=0x{old_val:08X} (preserved)")
                patches += 1

    return bytes(data), patches


def update_hbd_block_headers(hbd_data, block_map_path=None):
    """Update decompressed_size in sub-block headers and total_data_length
    in master block headers after re-encoding.

    For each text block:
    - Recalculate the decompressed_size field in the sub-block header
    - Update the total data length in the master block header (offset 0x08)
    - Pad with null bytes to maintain 2048-byte sector alignment

    This prevents memory buffer overflows from larger English text.
    """
    data = bytearray(hbd_data)
    updates = 0

    # Load block map if available
    blocks = []
    if block_map_path and os.path.exists(block_map_path):
        with open(block_map_path, 'r', encoding='utf-8') as f:
            bm = json.load(f)
        blocks = bm.get('blocks', [])

    for entry in blocks:
        offset = entry.get('offset', 0)
        if offset + 24 > len(data):
            continue

        # Parse block header
        end, block_id, hts, tree_end, text_end, unk1 = struct.unpack_from('<6I', data, offset)

        if end < 24 or offset + end > len(data):
            continue

        # If this block was re-encoded (tree_end=0, text_end=0), update sizes
        if tree_end == 0 and text_end == 0:
            # The new end is already set by reencode_block
            # Just ensure sector alignment padding
            block_total = end + 8  # end + at_end + dp_count fields
            if offset + block_total <= len(data):
                # Pad to 4-byte alignment within the HBD
                pad_needed = (4 - (block_total % 4)) % 4
                if pad_needed > 0:
                    for i in range(pad_needed):
                        if offset + block_total + i < len(data):
                            data[offset + block_total + i] = 0x00
                updates += 1

    # Update master block header total data length at offset 0x08
    # The master block is at the start of the HBD
    if len(data) >= 12:
        old_total = struct.unpack_from('<I', data, 8)[0]
        # The total data length should reflect the actual HBD data size
        # (padded to 2048-byte sector alignment)
        new_total = ((len(data) + USER_SIZE - 1) // USER_SIZE) * USER_SIZE
        if new_total != old_total:
            struct.pack_into('<I', data, 8, new_total)
            print(f"    Master block total: 0x{old_total:08X} -> 0x{new_total:08X}")
            updates += 1

    # Ensure 2048-byte sector alignment padding at end
    pad_needed = (USER_SIZE - (len(data) % USER_SIZE)) % USER_SIZE
    if pad_needed > 0:
        data = data + b'\x00' * pad_needed
        print(f"    Sector alignment padding: {pad_needed} bytes")

    return bytes(data), updates


def reencode_hbd_blocks(hbd_data, max_blocks=None):
    """Re-encode DQ4 HBD text blocks to DW7 format (Approach C).

    Uses the existing reencode_dq4_blocks module to:
    1. Parse each text block with per-block Huffman tree
    2. Decode text using DQ4 per-block tree
    3. Re-encode using the global hybrid tree
    4. Set hts=24, treeEnd=0, textEnd=0 (force DW7 global-tree path)

    This achieves dynamic Huffman decoding at the data level: all blocks
    use the same global hybrid tree, so the decoder's hardcoded tree
    reference (patched to the hybrid tree address) works for every block.
    """
    # Import the re-encoding module
    import importlib.util
    reencode_path = os.path.join(BASE, 'reencode_dq4_blocks.py')
    if not os.path.exists(reencode_path):
        print("    WARNING: reencode_dq4_blocks.py not found, skipping re-encoding")
        return hbd_data, 0, 0

    # We need to write the HBD to a temp file for the re-encoder
    import tempfile
    temp_input = os.path.join(BASE, 'translation', '_temp_reencode_input.bin')
    temp_output = os.path.join(BASE, 'translation', '_temp_reencode_output.bin')

    with open(temp_input, 'wb') as f:
        f.write(hbd_data)

    # Run the re-encoder
    spec = importlib.util.spec_from_file_location("reencode_dq4_blocks", reencode_path)
    reencode_mod = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(reencode_mod)

    # First verify round-trip
    print("    Running round-trip verification...")
    ok = reencode_mod.verify_roundtrip(temp_input, num_blocks=5)
    if not ok:
        print("    WARNING: Round-trip verification failed, skipping re-encoding")
        return hbd_data, 0, 0

    print("    Round-trip verification passed, proceeding with full re-encoding...")
    stats = reencode_mod.transform_hbd(temp_input, temp_output, max_blocks=max_blocks)

    # Read the re-encoded HBD
    with open(temp_output, 'rb') as f:
        reencoded_data = f.read()

    # Clean up temp files
    try:
        os.remove(temp_input)
        os.remove(temp_output)
    except OSError:
        pass

    return reencoded_data, stats['success'], stats['failed']


# ============================================================
# Build profile: frank_v36 (v34 engine + v13 HBD overlay)
# ============================================================

def build_frank_v36(output_bin, output_cue):
    """Frankenstein v36 - v34 engine + selective HBD overlay.

    Combines v34's proven engine patches with v13's HBD overlay strategy:

    Engine (from v34):
    - Semi-surgical disc-check bypass (10 patches, no cd_init)
    - CD-ROM Stop intercept trampoline
    - Hybrid tree relocated to 0x80100000 via copy routine
    - LBA references patched 354->355
    - Sequential sector table patched 354->355
    - MIPS tree refs patched to 0x80100000

    HBD overlay (from v13):
    - DW7 HBD copied from sector 354 to 355 (shifted +1, data preserved)
    - Matched DQ4 folders (from translated HBD) appended at sector 302388
    - 168 matched ABS/REL pointers patched to DQ4 locations
    - 1755 unmatched ABS pointers get +1 delta (pointing to shifted DW7 data)
    - Unmatched REL pointers unchanged (relative offsets preserved)

    This fixes v34's black screen: unmatched ABS pointers now read valid
    DW7 data (shifted +1) instead of zero-padded sectors beyond DQ4 HBD.
    """
    print("\n  Profile: frank_v36 (v34 engine + v13 HBD overlay)")

    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA  # = 1
    DW7_HBD_SECTORS_ACTUAL = DW7_HBD_SIZE // USER_SIZE  # 302033
    DQ4_APPEND_LBA = NEW_HBD_LBA + DW7_HBD_SECTORS_ACTUAL  # 302388

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # ── 1. LBA references: patch all 354 -> 355 ─────────────────────────────
    print(f"\n  Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")

    # ── 2. Sequential sector table ──────────────────────────────────────────
    print(f"\n  Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")

    # ── 3. Folder pointer remapping (v13 strategy) ──────────────────────────
    with open(FOLDER_MAP, 'r', encoding='utf-8') as f:
        fm = json.load(f)
    mappings = fm['mappings']
    print(f"  Folder mappings: {len(mappings)}")

    mappings_sorted = sorted(mappings, key=lambda m: m['dq4_sector'])
    total_dq4_sectors = sum(m['dq4_sector_count'] for m in mappings_sorted)
    print(f"  Total DQ4 matched sectors: {total_dq4_sectors} ({total_dq4_sectors * USER_SIZE:,} bytes)")
    print(f"  Appending DQ4 folders at disc sector {DQ4_APPEND_LBA}")

    abs_repl = {}
    rel_repl = {}
    running_offset = 0
    folder_new_locations = []

    for m in mappings_sorted:
        dq4_sec = m['dq4_sector']
        dq4_count = m['dq4_sector_count']
        dw7_sec = m['dw7_sector']

        new_disc_sector = DQ4_APPEND_LBA + running_offset
        new_abs = new_disc_sector
        new_rel = new_disc_sector - NEW_HBD_LBA
        old_rel = dw7_sec - OLD_HBD_LBA

        if dw7_sec != new_abs:
            abs_repl[dw7_sec] = new_abs
        if old_rel != new_rel and old_rel >= 0:
            rel_repl[old_rel] = new_rel

        folder_new_locations.append((dq4_sec, new_disc_sector, dq4_count))
        running_offset += dq4_count

    print(f"  Matched ABS replacements: {len(abs_repl)}")
    print(f"  Matched REL replacements: {len(rel_repl)}")

    print(f"\n  Patching matched folder pointers + LBA delta for unmatched...")
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    print(f"  Matched: abs={abs_matched}, rel={rel_matched}")
    print(f"  LBA delta (unmatched ABS): {abs_delta}")

    # ── 4. Disc-check bypass (semi-surgical: 10 patches, no cd_init) ────────
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (10 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")

    # ── 4b. FMV skip DISABLED — FMV is after Enix logo, not before ──────────
    # The hang at LBA 146621 is NOT the FMV. The Enix logo should render first.
    # Root cause is likely HBD block format incompatibility (DW7 parser vs
    # DQ4 HBD data) or a pointer remapping issue.
    fmv_patches = 0

    # ── 5. Hybrid tree (RELOCATED to 0x80100000) ────────────────────────────
    TREE_RAM_ADDR = 0x80100000
    print(f"\n  Patching MIPS tree refs (relocated to 0x{TREE_RAM_ADDR:08X})...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe), target_ram_addr=TREE_RAM_ADDR)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # ── 6. Reloc payload: tree + trampoline + copy routine (v34 proven) ─────
    print(f"\n  Appending reloc payload (tree+trampoline+copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    exe_data, tree_target, tramp_target = append_reloc_payload(
        bytes(exe), TREE_RAM_ADDR, original_pc0
    )
    print(f"  Extended EXE (with reloc payload): {len(exe_data):,} bytes")
    max_exe = (NEW_HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"  Max EXE before HBD overlap: {max_exe:,} bytes — {'OK' if len(exe_data) <= max_exe else 'OVERLAP!'}")

    # ── 7. Assemble disc ────────────────────────────────────────────────────
    print(f"\n  Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)

    # Calculate new disc size needed
    new_disc_sectors = DQ4_APPEND_LBA + total_dq4_sectors
    new_disc_size = new_disc_sectors * SECTOR_SIZE

    # Extend the disc image if needed (structurally valid MODE2 sectors)
    extend_disc_mode2(output_bin, new_disc_size)

    with open(output_bin, 'r+b') as f:
        # Write patched EXE at sector 24
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)

        # Copy DW7 HBD data from sector 354 to sector 355 (shift by 1)
        print(f"  Copying DW7 HBD from sector {OLD_HBD_LBA} to {NEW_HBD_LBA}...")
        with open(DW7_DISC, 'rb') as dw7_f:
            for sec in range(DW7_HBD_SECTORS_ACTUAL):
                data = read_sector_user(dw7_f, OLD_HBD_LBA + sec)
                write_sector_user(f, NEW_HBD_LBA + sec, data)
                if sec % 50000 == 0 and sec > 0:
                    print(f"    {sec}/{DW7_HBD_SECTORS_ACTUAL} sectors copied...")
        print(f"  DW7 HBD copied to sectors {NEW_HBD_LBA}-{DQ4_APPEND_LBA - 1}")

        # Write matched DQ4 folders at sector DQ4_APPEND_LBA
        print(f"  Writing {len(folder_new_locations)} DQ4 folders at sector {DQ4_APPEND_LBA}...")
        with open(DQ4_HBD_DISC, 'rb') as dq4_f:
            for idx, (dq4_rel_sec, new_disc_sec, sec_count) in enumerate(folder_new_locations):
                src_disc_sec = DQ4_HBD_DISC_START + dq4_rel_sec
                folder_data = bytearray()
                for s in range(sec_count):
                    folder_data.extend(read_sector_user(dq4_f, src_disc_sec + s))

                write_raw_data(f, new_disc_sec, bytes(folder_data))

                if idx % 100 == 0 and idx > 0:
                    print(f"    {idx}/{len(folder_new_locations)} folders written...")

        print(f"  All {len(folder_new_locations)} DQ4 folders written")

        # Update ISO directory
        new_hbd_size = (DW7_HBD_SECTORS_ACTUAL + total_dq4_sectors) * USER_SIZE
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=new_hbd_size, hbd_lba=NEW_HBD_LBA)
        print(f"  HBD: LBA={NEW_HBD_LBA}, size={new_hbd_size:,} ({new_hbd_size / 1024 / 1024:.1f} MB)")
        print(f"  Updating PVD...")
        update_pvd(f)

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    expected = os.path.getsize(DW7_DISC)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes (DW7 base: {expected:,})")
    print(f"  Patches: lba={lba_patches} seq={seq_patches} "
          f"abs={abs_matched + abs_delta}(matched={abs_matched},delta={abs_delta}) "
          f"rel={rel_matched} disc={disc_patches} tree={tree_patches} "
          f"reloc_payload=1 stop_intercept=1")
    print(f"  Strategy: v34 engine + v13 HBD overlay (DW7 preserved + DQ4 appended)")
    print(f"  DW7 HBD: sectors {NEW_HBD_LBA}-{DQ4_APPEND_LBA - 1} ({DW7_HBD_SECTORS_ACTUAL} sectors)")
    print(f"  DQ4 folders: sectors {DQ4_APPEND_LBA}-{DQ4_APPEND_LBA + total_dq4_sectors - 1} ({total_dq4_sectors} sectors)")
    print(f"  Tree: RAM 0x{TREE_RAM_ADDR:08X}, trampoline: RAM 0x{tramp_target:08X}")


# ============================================================
# Build profile: frank_v38a (engine bisection — disc-check only)
# ============================================================

def build_frank_v38a(output_bin, output_cue):
    """Frankenstein v38a — Engine bisection: disc-check only, pure DW7.

    Applies ONLY the 10 semi-surgical disc-check patches to the original
    DW7 EXE. No tree patches, no Stop intercept, no EXE extension, no HBD
    shift. HBD stays at LBA 354 with pure DW7 data.

    Purpose: Isolate whether the disc-check bypass patches alone prevent
    the Enix logo from rendering on pure DW7 data.

    If this boots → disc-check is clean, problem is in tree/Stop/shift layer.
    If this fails → one of the 10 disc-check patches is the culprit.
    """
    print("\n  Profile: frank_v38a (disc-check only, pure DW7, HBD at 354)")

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes (original, no extension)")

    # ── 1. Disc-check bypass only (10 patches, semi-surgical) ───────────────
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (10 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")

    # ── 2. Assemble disc (pure DW7, HBD at 354, no shift) ──────────────────
    print(f"\n  Assembling disc (pure DW7, HBD at 354)...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        write_raw_data(f, EXE_LBA, bytes(exe))
        update_iso_dir(f, exe_size=len(exe), hbd_lba=354, hbd_size=DW7_HBD_SIZE)
        print(f"  HBD: LBA=354 (unchanged), EXE size={len(exe):,}")

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches}")
    print(f"  Strategy: disc-check ONLY (10 patches), no tree, no Stop, no shift")
    print(f"  HBD: LBA=354, pure DW7 data, no DQ4 content")


# ============================================================
# Build profile: frank_v38b (engine bisection — full engine + shift)
# ============================================================

def build_frank_v38b(output_bin, output_cue):
    """Frankenstein v38b — Engine bisection: full engine + HBD shift, pure DW7.

    Applies ALL engine patches (disc-check 10, Stop intercept, tree reloc
    to 0x80100000, LBA refs, seq table, ABS delta) and shifts DW7 HBD from
    354 to 355. NO DQ4 data anywhere — all DW7 HBD, just shifted +1.

    Purpose: Test if the full engine patch set + HBD shift pipeline breaks
    boot on pure DW7 data (without the DQ4 overlay variable).

    If v38a boots but v38b fails → problem is in tree reloc / Stop intercept
    / HBD shift / LBA patches.
    If both boot → engine is clean, problem is in DQ4 overlay.
    """
    print("\n  Profile: frank_v38b (full engine + HBD shift, pure DW7)")

    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA  # = 1
    DW7_HBD_SECTORS_ACTUAL = DW7_HBD_SIZE // USER_SIZE  # 302033

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # ── 1. LBA references: patch all 354 -> 355 ─────────────────────────────
    print(f"\n  Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")

    # ── 2. Sequential sector table ──────────────────────────────────────────
    print(f"\n  Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")

    # ── 3. ABS pointer delta (+1 for all unmatched HBD-range pointers) ──────
    print(f"\n  Applying +1 LBA delta to unmatched ABS pointers...")
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, {}, {}, lba_delta=LBA_DELTA
    )
    print(f"  ABS delta (unmatched): {abs_delta}")

    # ── 4. Disc-check bypass (semi-surgical: 10 patches, no cd_init) ────────
    print(f"\n  Applying SEMI-SURGICAL disc-check bypass (10 patches, no cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Semi-surgical disc-check patches: {disc_patches}")

    # ── 5. Hybrid tree (RELOCATED to 0x80100000) ────────────────────────────
    TREE_RAM_ADDR = 0x80100000
    print(f"\n  Patching MIPS tree refs (relocated to 0x{TREE_RAM_ADDR:08X})...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe), target_ram_addr=TREE_RAM_ADDR)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # ── 6. Reloc payload: tree + trampoline + copy routine (v34 proven) ─────
    print(f"\n  Appending reloc payload (tree+trampoline+copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    exe_data, tree_target, tramp_target = append_reloc_payload(
        bytes(exe), TREE_RAM_ADDR, original_pc0
    )
    print(f"  Extended EXE (with reloc payload): {len(exe_data):,} bytes")
    max_exe = (NEW_HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"  Max EXE before HBD overlap: {max_exe:,} bytes — {'OK' if len(exe_data) <= max_exe else 'OVERLAP!'}")

    # ── 7. Assemble disc (pure DW7, HBD shifted 354->355) ──────────────────
    print(f"\n  Assembling disc (pure DW7, HBD shifted to 355)...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        # Write patched EXE at sector 24
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)

        # Copy DW7 HBD data from sector 354 to sector 355 (shift by 1)
        print(f"  Copying DW7 HBD from sector {OLD_HBD_LBA} to {NEW_HBD_LBA}...")
        with open(DW7_DISC, 'rb') as dw7_f:
            for sec in range(DW7_HBD_SECTORS_ACTUAL):
                data = read_sector_user(dw7_f, OLD_HBD_LBA + sec)
                write_sector_user(f, NEW_HBD_LBA + sec, data)
                if sec % 50000 == 0 and sec > 0:
                    print(f"    {sec}/{DW7_HBD_SECTORS_ACTUAL} sectors copied...")
        print(f"  DW7 HBD copied to sectors {NEW_HBD_LBA}-{NEW_HBD_LBA + DW7_HBD_SECTORS_ACTUAL - 1}")

        # Update ISO directory (HBD at 355, original DW7 HBD size)
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=DW7_HBD_SIZE, hbd_lba=NEW_HBD_LBA)
        print(f"  HBD: LBA={NEW_HBD_LBA}, size={DW7_HBD_SIZE:,} ({DW7_HBD_SIZE / 1024 / 1024:.1f} MB)")
        print(f"  Updating PVD...")
        update_pvd(f)

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: lba={lba_patches} seq={seq_patches} abs_delta={abs_delta} "
          f"disc={disc_patches} tree={tree_patches} reloc_payload=1 stop_intercept=1")
    print(f"  Strategy: full engine + HBD shift, pure DW7 data, NO DQ4 content")
    print(f"  DW7 HBD: sectors {NEW_HBD_LBA}-{NEW_HBD_LBA + DW7_HBD_SECTORS_ACTUAL - 1}")


# ============================================================
# Build profile: frank_v39 (C++ psx_ops.dll + thread-entry fix Option A)
# ============================================================

def build_frank_v39(output_bin, output_cue):
    """Frankenstein v39 — ALL C++ build via psx_ops.dll.

    Thin ctypes launcher. Every operation (LBA patching, sector table,
    folder pointer remapping, disc-check bypass, tree refs, reloc payload
    with thread-entry fix, HBD extraction, disc assembly, ISO dir, PVD,
    CUE, EDC/ECC) runs in C++ inside build_frankenstein_v39().
    Python does NOTHING except pass paths and print the result.
    """
    import ctypes

    class BuildResult(ctypes.Structure):
        _fields_ = [
            ("lba_patches", ctypes.c_uint32),
            ("seq_patches", ctypes.c_uint32),
            ("abs_matched", ctypes.c_uint32),
            ("abs_delta", ctypes.c_uint32),
            ("rel_matched", ctypes.c_uint32),
            ("disc_patches", ctypes.c_uint32),
            ("tree_patches", ctypes.c_uint32),
            ("trampoline_patches", ctypes.c_uint32),
            ("exe_size", ctypes.c_uint32),
            ("new_pc0", ctypes.c_uint32),
            ("disc_size", ctypes.c_uint32),
            ("hbd_blocks_processed", ctypes.c_uint32),
            ("hbd_blocks_converted", ctypes.c_uint32),
            ("hbd_subblock_swaps", ctypes.c_uint32),
            ("hbd_lba_patches", ctypes.c_uint32),
            ("success", ctypes.c_int32),
        ]

    dll = load_psx_ops()
    dll.build_frankenstein_v39.restype = BuildResult
    dll.build_frankenstein_v39.argtypes = [
        ctypes.c_char_p,  # dw7_disc_path
        ctypes.c_char_p,  # dw7_exe_path
        ctypes.c_char_p,  # dq4_hbd_disc_path
        ctypes.c_char_p,  # hybrid_tree_path
        ctypes.c_char_p,  # folder_map_path
        ctypes.c_char_p,  # output_bin_path
        ctypes.c_char_p,  # output_cue_path
        ctypes.c_char_p,  # edcre_path
    ]

    edcre_path = EDCRE if os.path.exists(EDCRE) else None

    result = dll.build_frankenstein_v39(
        DW7_DISC.encode('utf-8'),
        ORIGINAL_EXE.encode('utf-8'),
        DQ4_HBD_DISC.encode('utf-8'),
        HYBRID_TREE.encode('utf-8'),
        FOLDER_MAP.encode('utf-8'),
        output_bin.encode('utf-8'),
        output_cue.encode('utf-8'),
        edcre_path.encode('utf-8') if edcre_path else None,
    )

    if not result.success:
        print("  BUILD FAILED")
        sys.exit(1)
    print(f"\n  Python launcher: C++ build returned success=1")
    print(f"  Result: lba={result.lba_patches} seq={result.seq_patches} "
          f"abs={result.abs_matched + result.abs_delta}(matched={result.abs_matched},delta={result.abs_delta}) "
          f"rel={result.rel_matched} disc={result.disc_patches} tree={result.tree_patches} tramp={result.trampoline_patches}")
    print(f"  HBD: blocks={result.hbd_blocks_processed} converted={result.hbd_blocks_converted} "
          f"swaps={result.hbd_subblock_swaps} lba={result.hbd_lba_patches}")
    print(f"  EXE: {result.exe_size:,} bytes, PC0=0x{result.new_pc0:08X}")
    print(f"  Disc: {result.disc_size:,} bytes")


# ============================================================
# Build profile: frank_v40 (minimal patching + HuffTree re-encode)
# ============================================================

def build_frank_v40(output_bin, output_cue):
    """Frankenstein v40 — minimal EXE patching + HuffTree text re-encode.

    Calls the same C++ build_frankenstein_v39() entry point, which is now
    internally v40: only tree append + tree ref patch + ABS/REL remap.
    No LBA scan, no seq table, no disc-check, no trampoline, no thread fix.
    DQ4 text blocks are decoded with per-block trees and re-encoded with
    the hybrid Huffman tree.
    """
    build_frank_v39(output_bin, output_cue)


def _build_v40_variant(output_bin, output_cue, func_name):
    """Shared launcher for v40a/v40b/v40c C++ variants."""
    import ctypes

    class BuildResult(ctypes.Structure):
        _fields_ = [
            ("lba_patches", ctypes.c_uint32),
            ("seq_patches", ctypes.c_uint32),
            ("abs_matched", ctypes.c_uint32),
            ("abs_delta", ctypes.c_uint32),
            ("rel_matched", ctypes.c_uint32),
            ("disc_patches", ctypes.c_uint32),
            ("tree_patches", ctypes.c_uint32),
            ("trampoline_patches", ctypes.c_uint32),
            ("exe_size", ctypes.c_uint32),
            ("new_pc0", ctypes.c_uint32),
            ("disc_size", ctypes.c_uint32),
            ("hbd_blocks_processed", ctypes.c_uint32),
            ("hbd_blocks_converted", ctypes.c_uint32),
            ("hbd_subblock_swaps", ctypes.c_uint32),
            ("hbd_lba_patches", ctypes.c_uint32),
            ("success", ctypes.c_int32),
        ]

    dll = load_psx_ops()
    fn = getattr(dll, func_name)
    fn.restype = BuildResult
    fn.argtypes = [
        ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
        ctypes.c_char_p, ctypes.c_char_p, ctypes.c_char_p,
        ctypes.c_char_p, ctypes.c_char_p,
    ]

    edcre_path = EDCRE if os.path.exists(EDCRE) else None

    result = fn(
        DW7_DISC.encode('utf-8'),
        ORIGINAL_EXE.encode('utf-8'),
        DQ4_HBD_DISC.encode('utf-8'),
        HYBRID_TREE.encode('utf-8'),
        FOLDER_MAP.encode('utf-8'),
        output_bin.encode('utf-8'),
        output_cue.encode('utf-8'),
        edcre_path.encode('utf-8') if edcre_path else None,
    )

    if not result.success:
        print("  BUILD FAILED")
        sys.exit(1)
    print(f"\n  Python launcher: C++ build returned success=1")
    print(f"  Result: lba={result.lba_patches} seq={result.seq_patches} "
          f"abs={result.abs_matched + result.abs_delta}(matched={result.abs_matched},delta={result.abs_delta}) "
          f"rel={result.rel_matched} disc={result.disc_patches} tree={result.tree_patches}")
    print(f"  EXE: {result.exe_size:,} bytes, PC0=0x{result.new_pc0:08X}")
    print(f"  Disc: {result.disc_size:,} bytes")


def build_frank_v40c(output_bin, output_cue):
    """v40c — No tree, no BSS patch. Game uses own tree at 0x800EF1C8."""
    _build_v40_variant(output_bin, output_cue, 'build_frankenstein_v40c')


def build_frank_v40b(output_bin, output_cue):
    """v40b — Tree at 0x800F4980 via copy routine. BSS boundary."""
    _build_v40_variant(output_bin, output_cue, 'build_frankenstein_v40b')


def build_frank_v40a(output_bin, output_cue):
    """v40a — Tree at 0x80100000 via copy routine. High RAM, safe from BSS."""
    _build_v40_variant(output_bin, output_cue, 'build_frankenstein_v40a')


# ============================================================
# Build profile: frank_v41 (Gate1-informed minimal engine)
# ============================================================

def build_frank_v41(output_bin, output_cue):
    """Frankenstein v41 — Gate1-informed build.

    Strategy based on DuckStation Gate 1 test results (Jul 19):
    - v38a (disc-check only, semi-surgical): boots, reaches "Please insert disc 1"
    - v38b (full engine: tree reloc + copy routine + CD-ROM intercept): black screen, page fault

    This profile applies ONLY the patches that v38a proved safe, plus
    the missing pieces to get past disc check and load DQ4 data:

    1. FULL disc-check bypass (ALL 11 patches including cd_init_force_success)
       -- v38a used semi-surgical (10, no cd_init) and still got "insert disc 1"
    2. DQ4 HBD swap at LBA 355 (319MB DQ4 heart data)
    3. ISO directory update (HBD LBA=355, size=DQ4_HBD_SIZE)
    4. LBA references patched 354->355
    5. Sequential sector table patched
    6. ABS/REL pointer remapping (matched folders + LBA delta for unmatched)
    7. Hybrid tree appended in-place (NO copy routine, NO PC0 change)
       -- tree at end of EXE within t_size, BSS start patched to skip it
    8. MIPS tree refs patched to in-place tree address
    9. BSS clear end kept at original 0x800F4980 (full clear after tree)
       -- v38a proved game boots fine with full BSS clear

    NOT applied (proven to break boot in v38b):
    - NO copy routine at PC0
    - NO CD-ROM Stop intercept / trampoline
    - NO tree relocation to 0x80100000
    - NO PC0 redirect
    """
    print("\n  Profile: frank_v41 (Gate1-informed: full disc-check + DQ4 HBD + tree in-place)")

    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA  # = 1

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # 1. FULL disc-check bypass (ALL 11 patches including cd_init)
    print(f"\n  [1/9] Applying FULL disc-check bypass (11 patches, including cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=False)
    exe = bytearray(exe_bytes)
    print(f"  Disc-check patches: {disc_patches}")

    # 2. LBA references: patch all 354 -> 355
    print(f"\n  [2/9] Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")

    # 3. Sequential sector table
    print(f"\n  [3/9] Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")

    # 4. ABS/REL pointer remapping (matched folders + LBA delta for unmatched)
    print(f"\n  [4/9] Remapping ABS/REL folder pointers...")
    abs_repl = {}
    rel_repl = {}
    if os.path.exists(FOLDER_MAP):
        with open(FOLDER_MAP, 'r') as f:
            fm_data = json.load(f)
        mappings = fm_data.get('mappings', fm_data) if isinstance(fm_data, dict) else fm_data
        for m in mappings:
            dw7_sec = m.get('dw7_sector', 0)
            dq4_sec = m.get('dq4_sector', 0)
            if dw7_sec and dq4_sec:
                abs_repl[dw7_sec] = dq4_sec + NEW_HBD_LBA
                rel_repl[dw7_sec] = dq4_sec
        print(f"  Folder mappings loaded: {len(abs_repl)} ABS, {len(rel_repl)} REL")
    else:
        print(f"  WARNING: No folder_mapping.json found, using LBA delta only")
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    print(f"  ABS: matched={abs_matched}, delta={abs_delta}, REL: matched={rel_matched}")

    # 5. Hybrid tree appended in-place (NO copy routine)
    print(f"\n  [5/9] Appending hybrid tree in-place (no copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    # Use append_hybrid_tree without target_ram_addr — tree goes at end of EXE
    exe_bytes = append_hybrid_tree(bytes(exe), target_ram_addr=None)
    exe = bytearray(exe_bytes)
    # Compute where the tree actually landed
    load_addr = struct.unpack_from('<I', exe, 0x18)[0]
    # Tree starts right after the original EXE content (before sector padding)
    # We need to find it: it's at the end minus sector_pad minus tree_size
    with open(HYBRID_TREE, 'rb') as f:
        tree_size = len(f.read())
    tree_ram = load_addr + len(exe) - 0x800 - tree_size
    # Actually, append_hybrid_tree pads to sector boundary AFTER appending tree
    # So tree is at: len(exe) - sector_pad - tree_size, but we don't know sector_pad exactly
    # Better: tree is at the first 4-byte aligned offset after the original EXE
    orig_exe_size = 675840  # known DW7 EXE size
    tree_file_off = orig_exe_size
    # Adjust for 4-byte alignment padding
    padding = (4 - (orig_exe_size % 4)) % 4
    tree_file_off += padding
    tree_ram = load_addr + tree_file_off - 0x800
    print(f"  Tree (in-place): RAM 0x{tree_ram:08X}, {tree_size}B")

    # 6. Patch MIPS tree refs to point to in-place tree
    print(f"\n  [6/9] Patching MIPS tree refs to in-place tree (0x{tree_ram:08X})...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe), target_ram_addr=tree_ram)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # 7. BSS clear: patch start to skip tree, narrow end to preserve thread entry
    print(f"\n  [7/9] Patching BSS clear...")
    # BSS start: skip past tree region
    tree_end_ram = tree_ram + tree_size
    # Align up to 4 bytes
    tree_end_ram = (tree_end_ram + 3) & ~3
    exe = bytearray(patch_bss_clear_start(bytes(exe), tree_end_ram))
    print(f"  BSS clear start: 0x800BC668 -> 0x{tree_end_ram:08X}")

    # BSS end: keep original 0x800F4980 (do NOT narrow)
    # v38a proved game boots fine with full BSS clear (thread entry zeroing
    # doesn't prevent initial boot). Narrowing to 0x800BCCC8 made BSS range
    # empty (start==end), leaving ~370KB of uncleared BSS which is worse.
    # The tree is preserved by moving BSS start past it.
    print(f"  BSS clear end: 0x800F4980 (unchanged -- full clear after tree)")

    # 7b. Zero out pre-tree BSS region (0x800BC668 to 0x800BC700)
    # The original BSS clear starts at 0x800BC668, but we moved it to tree_end (0x800BCCC8).
    # The 152-byte gap (0x800BC668-0x800BC700) contains initialized EXE data that should
    # be zero (BSS). The game reads a base pointer from 0x800BC6CC (file offset 0xA47CC)
    # and uses it to check thread status. Non-zero data here causes stall at PC 0x80048004.
    PRE_TREE_BSS_START = 0x800BC668
    PRE_TREE_BSS_END = 0x800BC700  # tree starts here
    pre_tree_file_start = PRE_TREE_BSS_START - load_addr + 0x800  # 0xA4768
    pre_tree_file_end = PRE_TREE_BSS_END - load_addr + 0x800      # 0xA4800
    pre_tree_len = pre_tree_file_end - pre_tree_file_start         # 152 bytes
    print(f"\n  [7b] Zeroing pre-tree BSS region ({pre_tree_len} bytes at file offset 0x{pre_tree_file_start:X})")
    exe[pre_tree_file_start:pre_tree_file_end] = b'\x00' * pre_tree_len
    print(f"  Zeroed 0x{PRE_TREE_BSS_START:08X}-0x{PRE_TREE_BSS_END:08X} (fixes stall at PC 0x80048004)")

    # 7c. CD-ROM stall bypass + FMV skip — DISABLED
    # With the HBD truncation fix, LBA 146621 now has valid DW7 data,
    # so CD-ROM events fire naturally and FMV can play normally.
    # The bypass was corrupting the CD-ROM command FIFO (12 params instead of 3),
    # causing data loads to fail and rendering a black screen.
    print(f"\n  [7c] CD-ROM stall bypass + FMV skip: DISABLED (HBD fix makes them unnecessary)")

    # 8. Verify EXE size fits before HBD overlap
    max_exe = (NEW_HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"\n  [8/9] EXE size: {len(exe):,} bytes (max before HBD: {max_exe:,}) — {'OK' if len(exe) <= max_exe else 'OVERLAP!'}")

    # 9. Assemble disc
    print(f"\n  [9/9] Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        # Write patched EXE at sector 24
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, bytes(exe))

        # Write DQ4 HBD at sector 355 — ONLY non-zero data to preserve DW7 FMV
        print(f"  Detecting actual DQ4 HBD data size...")
        actual_sectors = detect_hbd_data_size(DQ4_HBD_DISC, DQ4_HBD_DISC_START)
        actual_size = actual_sectors * USER_SIZE
        print(f"  DQ4 HBD: {actual_sectors} sectors ({actual_size:,} bytes) of non-zero data")
        print(f"  (Source has {DQ4_HBD_SIZE:,} bytes allocated, {DQ4_HBD_SIZE - actual_size:,} bytes are zero padding)")
        dq4_hbd_end = NEW_HBD_LBA + actual_sectors
        print(f"  DQ4 HBD spans sectors {NEW_HBD_LBA}-{dq4_hbd_end - 1}")
        print(f"  DW7 data preserved from sector {dq4_hbd_end} onwards (includes FMV at LBA 146621)")

        hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, actual_size)
        write_raw_data(f, NEW_HBD_LBA, hbd_data)
        print(f"  DQ4 HBD written: {len(hbd_data):,} bytes at LBA {NEW_HBD_LBA}")

        # Update ISO directory — keep HBD size at DQ4_HBD_SIZE for BIOS compatibility
        # (game engine uses hardcoded LBAs, not ISO directory, for sector seeks)
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe), hbd_size=DQ4_HBD_SIZE, hbd_lba=NEW_HBD_LBA)
        print(f"  ISO dir: EXE size={len(exe):,}, HBD LBA={NEW_HBD_LBA}, HBD size={DQ4_HBD_SIZE:,}")

        # Update PVD
        update_pvd(f)

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} lba={lba_patches} seq={seq_patches} "
          f"abs_matched={abs_matched} abs_delta={abs_delta} rel={rel_matched} tree={tree_patches}")
    print(f"  Strategy: full disc-check + DQ4 HBD + tree in-place + BSS skip-tree")
    print(f"  NO copy routine, NO CD-ROM intercept, NO PC0 redirect")
    print(f"  Tree: 0x{tree_ram:08X}, BSS: 0x{tree_end_ram:08X}-0x800F4980")
    print(f"  PC0: 0x{original_pc0:08X} (unchanged)")


# ============================================================
# Build profile: frank_v35 (Localization Graft)
# ============================================================

def build_frank_v35(output_bin, output_cue):
    """Frankenstein v35 - Localization Graft.

    Implements the five system-level adjustments for grafting the DQ4
    asset archive onto the DW7 runtime:

    1. Archive Identity Sync: Rename HBD to Q71, patch volume ID at 0x740,
       patch EXE filename string.
    2. LBA Index Reconstruction: Broad LBA scan, sequential sector table,
       matched/unmatched pointer remapping.
    3. Dynamic Huffman Decoding: Re-encode DQ4 blocks to use global hybrid
       tree (data-level fix), patch MIPS tree refs to relocated tree.
    4. Memory Allocation Management: Update HBD block headers, pad to
       2048-byte sector alignment.
    5. Audio Mapping: Patch instrument bank sizes in sound format header.
    """
    print("\n  Profile: frank_v35 (Localization Graft)")

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # ── 1. Archive Identity: Patch EXE HBD filename w71 -> q71 ─────────────
    print(f"\n  [1/5] Archive Identity Synchronization...")
    exe_bytes, name_patches = patch_hbd_filename_q71(bytes(exe))
    exe = bytearray(exe_bytes)
    print(f"  HBD filename patches: {name_patches}")

    # ── 2. LBA Index Reconstruction ───────────────────────────────────────
    print(f"\n  [2/5] LBA Index Reconstruction...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), 354, HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")

    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), 354, HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")

    with open(FOLDER_MAP, 'r', encoding='utf-8') as f:
        fm = json.load(f)
    mappings = fm['mappings']
    print(f"  Folder mappings: {len(mappings)}")

    abs_repl = {}
    rel_repl = {}
    for m in mappings:
        dw7_sec = m['dw7_sector']
        dq4_sec = m['dq4_sector']
        new_abs = dq4_sec + HBD_LBA
        old_rel = dw7_sec - HBD_LBA
        new_rel = dq4_sec
        if dw7_sec != new_abs:
            abs_repl[dw7_sec] = new_abs
        if old_rel != new_rel and old_rel >= 0:
            rel_repl[old_rel] = new_rel

    LBA_DELTA = HBD_LBA - 354
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    print(f"  Matched: abs={abs_matched}, rel={rel_matched}")
    print(f"  LBA delta (unmatched ABS): {abs_delta}")

    # ── 3. Disc-check bypass (semi-surgical) ───────────────────────────────
    print(f"\n  Applying semi-surgical disc-check bypass...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Disc-check patches: {disc_patches}")

    # ── 4. Dynamic Huffman: Re-encode HBD + patch tree refs ────────────────
    print(f"\n  [3/5] Dynamic Huffman Decoding...")
    print(f"  Extracting DQ4 HBD...")
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, DQ4_HBD_SIZE)
    print(f"  DQ4 HBD: {len(hbd_data):,} bytes")

    # Re-encode DQ4 blocks to use global hybrid tree
    print(f"  Re-encoding DQ4 text blocks to DW7 format...")
    block_map_path = os.path.join(BASE, 'dq4_block_map_fresh.json')
    hbd_data, reenc_success, reenc_failed = reencode_hbd_blocks(hbd_data)
    print(f"  Re-encoding: success={reenc_success}, failed={reenc_failed}")

    # Patch volume identifier in HBD
    print(f"  Patching volume identifier...")
    hbd_data = update_volume_identifier(hbd_data)

    # NOTE: Tree address will be determined by append_tree_inplace (0x800BC700)
    # We patch MIPS tree refs AFTER appending, using the actual tree RAM address

    # ── 5. Memory Allocation Management ───────────────────────────────────
    print(f"\n  [4/5] Memory Allocation Management...")
    hbd_data, header_updates = update_hbd_block_headers(hbd_data, block_map_path)
    print(f"  HBD header updates: {header_updates}")
    print(f"  HBD size after re-encode + padding: {len(hbd_data):,} bytes")

    # ── 6. Audio Mapping ──────────────────────────────────────────────────
    print(f"\n  [5/5] Audio Mapping...")
    hbd_data, audio_patches = patch_audio_bank_sizes(hbd_data)
    print(f"  Audio bank patches: {audio_patches}")

    # ── 7. Append tree in-place (no copy routine, no 0x80100000) ───────────
    print(f"\n  Appending tree + trampoline in-place (no copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    exe_data, tree_ram, tramp_ram = append_tree_inplace(
        bytes(exe), original_pc0
    )
    print(f"  Extended EXE (with tree+trampoline): {len(exe_data):,} bytes")
    max_exe = (HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"  Max EXE before HBD overlap: {max_exe:,} bytes — {'OK' if len(exe_data) <= max_exe else 'OVERLAP!'}")

    # Now patch MIPS tree refs to the actual tree RAM address
    print(f"  Patching MIPS tree refs to tree at 0x{tree_ram:08X}...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(exe_data, target_ram_addr=tree_ram)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_data, tree_patches = patch_mips_tree_refs(exe_data, new_lui, new_addiu)
    print(f"  Tree ref patches: {tree_patches}")

    # ── 8. Assemble disc ──────────────────────────────────────────────────
    print(f"\n  Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, exe_data)
        print(f"  Writing DQ4 HBD (re-encoded) at sector {HBD_LBA}...")
        write_raw_data(f, HBD_LBA, hbd_data)
        print(f"  DQ4 HBD spans sectors {HBD_LBA}-{HBD_LBA + len(hbd_data) // USER_SIZE - 1}")

        # Update ISO directory: HBD name -> HBD1PS1D.Q71, size, LBA
        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe_data), hbd_size=len(hbd_data))
        update_iso_dir_hbd_name(f, new_name=b'HBD1PS1D.Q71;1')

        print(f"  Updating PVD...")
        update_pvd(f)

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: name={name_patches} lba={lba_patches} seq={seq_patches} "
          f"abs={abs_matched + abs_delta}(matched={abs_matched},delta={abs_delta}) "
          f"rel={rel_matched} disc={disc_patches} tree={tree_patches} "
          f"reenc={reenc_success}/{reenc_failed} headers={header_updates} "
          f"audio={audio_patches} tree_inplace=1 stop_intercept=1")
    print(f"  Strategy: Localization Graft (5 system-level adjustments, in-place tree)")
    print(f"  HBD: LBA={HBD_LBA}, size={len(hbd_data):,}, name=HBD1PS1D.Q71")
    print(f"  Tree: RAM 0x{tree_ram:08X}, trampoline: RAM 0x{tramp_ram:08X}")


# ============================================================
# Build profile: frank_v43 (v41 + C++ HBD re-encoding)
# ============================================================

def build_frank_v43(output_bin, output_cue):
    """Frankenstein v43 — v41 strategy + C++ HBD re-encoding.

    Root cause of v42 black screen: DQ4 HBD blocks have per-block Huffman
    trees (tree_end≠0, text_end≠0), but the DW7 engine expects global tree
    format (tree_end=0, text_end=0, hts=1366). The engine misparses block
    headers, sends corrupted CD-ROM commands, and reads garbage pointers.

    Fix: Run DQ4 HBD through the C++ HbdReencoder before writing to disc.
    This decodes DQ4 text using per-block trees and re-encodes using the
    hybrid global tree, converting all blocks to DW7 format.

    Strategy (same as v41, plus HBD re-encoding):
    1. FULL disc-check bypass (ALL 11 patches including cd_init_force_success)
    2. LBA references patched 354->355
    3. Sequential sector table patched
    4. ABS/REL pointer remapping (matched folders + LBA delta for unmatched)
    5. Hybrid tree appended in-place (NO copy routine, NO PC0 change)
    6. MIPS tree refs patched to in-place tree address
    7. BSS clear start moved past tree, pre-tree BSS zeroed
    8. DQ4 HBD re-encoded via C++ HbdReencoder (per-block -> global tree)
    9. Only non-zero DQ4 HBD sectors written (preserves DW7 FMV data)
    """
    print("\n  Profile: frank_v43 (v41 + C++ HBD re-encoding: per-block -> global tree)")

    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA  # = 1

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # 1. FULL disc-check bypass (ALL 11 patches including cd_init)
    print(f"\n  [1/10] Applying FULL disc-check bypass (11 patches, including cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=False)
    exe = bytearray(exe_bytes)
    print(f"  Disc-check patches: {disc_patches}")

    # 2. LBA references: patch all 354 -> 355
    print(f"\n  [2/10] Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")

    # 3. Sequential sector table
    print(f"\n  [3/10] Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")

    # 4. ABS/REL pointer remapping (matched folders + LBA delta for unmatched)
    print(f"\n  [4/10] Remapping ABS/REL folder pointers...")
    abs_repl = {}
    rel_repl = {}
    if os.path.exists(FOLDER_MAP):
        with open(FOLDER_MAP, 'r') as f:
            fm_data = json.load(f)
        mappings = fm_data.get('mappings', fm_data) if isinstance(fm_data, dict) else fm_data
        for m in mappings:
            dw7_sec = m.get('dw7_sector', 0)
            dq4_sec = m.get('dq4_sector', 0)
            if dw7_sec and dq4_sec:
                abs_repl[dw7_sec] = dq4_sec + NEW_HBD_LBA
                rel_repl[dw7_sec] = dq4_sec
        print(f"  Folder mappings loaded: {len(abs_repl)} ABS, {len(rel_repl)} REL")
    else:
        print(f"  WARNING: No folder_mapping.json found, using LBA delta only")
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    print(f"  ABS: matched={abs_matched}, delta={abs_delta}, REL: matched={rel_matched}")

    # 5. Hybrid tree appended in-place (NO copy routine)
    print(f"\n  [5/10] Appending hybrid tree in-place (no copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    exe_bytes = append_hybrid_tree(bytes(exe), target_ram_addr=None)
    exe = bytearray(exe_bytes)
    load_addr = struct.unpack_from('<I', exe, 0x18)[0]
    with open(HYBRID_TREE, 'rb') as f:
        tree_size = len(f.read())
    orig_exe_size = 675840
    tree_file_off = orig_exe_size
    padding = (4 - (orig_exe_size % 4)) % 4
    tree_file_off += padding
    tree_ram = load_addr + tree_file_off - 0x800
    print(f"  Tree (in-place): RAM 0x{tree_ram:08X}, {tree_size}B")

    # 6. Patch MIPS tree refs to point to in-place tree
    print(f"\n  [6/10] Patching MIPS tree refs to in-place tree (0x{tree_ram:08X})...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe), target_ram_addr=tree_ram)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # 7. BSS clear: patch start to skip tree, zero pre-tree BSS
    print(f"\n  [7/10] Patching BSS clear...")
    tree_end_ram = tree_ram + tree_size
    tree_end_ram = (tree_end_ram + 3) & ~3
    exe = bytearray(patch_bss_clear_start(bytes(exe), tree_end_ram))
    print(f"  BSS clear start: 0x800BC668 -> 0x{tree_end_ram:08X}")
    print(f"  BSS clear end: 0x800F4980 (unchanged -- full clear after tree)")

    PRE_TREE_BSS_START = 0x800BC668
    PRE_TREE_BSS_END = 0x800BC700
    pre_tree_file_start = PRE_TREE_BSS_START - load_addr + 0x800
    pre_tree_file_end = PRE_TREE_BSS_END - load_addr + 0x800
    pre_tree_len = pre_tree_file_end - pre_tree_file_start
    print(f"\n  [7b] Zeroing pre-tree BSS region ({pre_tree_len} bytes at file offset 0x{pre_tree_file_start:X})")
    exe[pre_tree_file_start:pre_tree_file_end] = b'\x00' * pre_tree_len
    print(f"  Zeroed 0x{PRE_TREE_BSS_START:08X}-0x{PRE_TREE_BSS_END:08X}")

    # 7d. FMV skip + CD-ROM stall bypass via C++ ExePatcher
    print(f"\n  [7d] Applying FMV skip + CD-ROM stall bypass via C++ ExePatcher...")
    try:
        psx = load_psx_ops()
        exe_handle = psx.exe_load(bytes(exe), len(exe))
        if not exe_handle:
            print(f"  WARNING: exe_load failed, skipping FMV/stall patches")
        else:
            fmv_result = psx.exe_patch_fmv_skip(exe_handle)
            print(f"  FMV skip: {'applied' if fmv_result else 'no patches needed'}")

            stall_result = psx.exe_patch_cdrom_stall_bypass(exe_handle)
            print(f"  CD-ROM stall bypass: {'applied' if stall_result else 'no patches needed'}")

            # Extract patched EXE
            patched_size = psx.exe_size(exe_handle)
            patched_raw = psx.exe_raw(exe_handle)
            exe = bytearray(ctypes.string_at(patched_raw, patched_size))
            print(f"  EXE extracted from ExePatcher: {len(exe):,} bytes")
            psx.exe_free(exe_handle)
    except Exception as e:
        print(f"  WARNING: C++ ExePatcher patches failed: {e}")
        print(f"  Continuing without FMV skip / CD-ROM stall bypass")

    # 8. HBD re-encoding via C++ HbdReencoder
    print(f"\n  [8/10] Re-encoding DQ4 HBD via C++ HbdReencoder (per-block -> global tree)...")
    try:
        psx = load_psx_ops()
    except FileNotFoundError as e:
        print(f"  ERROR: {e}")
        print(f"  Cannot re-encode HBD without psx_ops.dll. Build aborted.")
        return

    print(f"  Detecting actual DQ4 HBD data size...")
    actual_sectors = detect_hbd_data_size(DQ4_HBD_DISC, DQ4_HBD_DISC_START)
    actual_size = actual_sectors * USER_SIZE
    print(f"  DQ4 HBD: {actual_sectors} sectors ({actual_size:,} bytes) of non-zero data")

    print(f"  Extracting DQ4 HBD...")
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, actual_size)
    print(f"  DQ4 HBD extracted: {len(hbd_data):,} bytes")

    with open(HYBRID_TREE, 'rb') as f:
        hybrid_tree_data = f.read()

    print(f"  Loading HBD into C++ re-encoder...")
    hbd_handle = psx.hbd_load(hbd_data, len(hbd_data), hybrid_tree_data, len(hybrid_tree_data))
    if not hbd_handle:
        print(f"  ERROR: hbd_load failed")
        return

    print(f"  Processing HBD (source_lba={DQ4_HBD_DISC_START}, target_lba={NEW_HBD_LBA})...")
    result = psx.hbd_process(hbd_handle, DQ4_HBD_DISC_START, NEW_HBD_LBA)
    print(f"  HBD processing result:")
    print(f"    folders_parsed:     {result.folders_parsed}")
    print(f"    files_parsed:       {result.files_parsed}")
    print(f"    blocks_processed:   {result.blocks_processed}")
    print(f"    blocks_converted:   {result.blocks_converted}")
    print(f"    blocks_reencoded:   {result.blocks_reencoded}")
    print(f"    blocks_reenc_fail:  {result.blocks_reencode_failed}")
    print(f"    subblock_swaps:     {result.subblock_swaps}")
    print(f"    errors:             {result.errors}")
    print(f"    success:            {result.success}")

    if result.errors > 0:
        print(f"  WARNING: {result.errors} errors during HBD processing (continuing)")

    print(f"  Validating processed HBD...")
    valid = psx.hbd_validate(hbd_handle, NEW_HBD_LBA)
    print(f"  Validation: {'PASS' if valid else 'FAIL'}")

    # Extract processed HBD data
    processed_size = psx.hbd_size(hbd_handle)
    processed_raw = psx.hbd_raw(hbd_handle)
    processed_hbd = bytes(ctypes.string_at(processed_raw, processed_size))
    print(f"  Processed HBD: {len(processed_hbd):,} bytes (was {len(hbd_data):,})")

    psx.hbd_free(hbd_handle)

    # 9. Verify EXE size fits before HBD overlap
    max_exe = (NEW_HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"\n  [9/10] EXE size: {len(exe):,} bytes (max before HBD: {max_exe:,}) — {'OK' if len(exe) <= max_exe else 'OVERLAP!'}")

    # 10. Assemble disc
    print(f"\n  [10/10] Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, bytes(exe))

        print(f"  Writing re-encoded DQ4 HBD at sector {NEW_HBD_LBA}...")
        write_raw_data(f, NEW_HBD_LBA, processed_hbd)
        dq4_hbd_end = NEW_HBD_LBA + (len(processed_hbd) + USER_SIZE - 1) // USER_SIZE
        print(f"  DQ4 HBD spans sectors {NEW_HBD_LBA}-{dq4_hbd_end - 1}")
        print(f"  DW7 data preserved from sector {dq4_hbd_end} onwards (includes FMV at LBA 146621)")

        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe), hbd_size=DQ4_HBD_SIZE, hbd_lba=NEW_HBD_LBA)
        print(f"  ISO dir: EXE size={len(exe):,}, HBD LBA={NEW_HBD_LBA}, HBD size={DQ4_HBD_SIZE:,}")

        print(f"  Updating PVD...")
        update_pvd(f)

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches} lba={lba_patches} seq={seq_patches} "
          f"abs_matched={abs_matched} abs_delta={abs_delta} rel={rel_matched} tree={tree_patches}")
    print(f"  HBD re-encode: folders={result.folders_parsed} blocks={result.blocks_processed} "
          f"reencoded={result.blocks_reencoded} failed={result.blocks_reencode_failed} "
          f"swaps={result.subblock_swaps} errors={result.errors}")
    print(f"  Strategy: v41 + C++ HBD re-encoding (per-block -> global tree)")
    print(f"  Tree: 0x{tree_ram:08X}, BSS: 0x{tree_end_ram:08X}-0x800F4980")
    print(f"  PC0: 0x{original_pc0:08X} (unchanged)")
    print(f"  NO copy routine, NO CD-ROM intercept, NO PC0 redirect")


# ============================================================
# Build profile: frank_v44 (v43 without cd_init bypass or stall bypass)
# ============================================================

def build_frank_v44(output_bin, output_cue):
    """Frankenstein v44 -- v43 with surgical CD-ROM fix.

    Root cause of v43 FMV hang: cd_init_force_success patch replaces the
    entire CD-ROM init function with a stub (addiu $v0,1; jr ra). This
    prevents the CD-ROM hardware from being initialized, so CD-ROM events
    never fire. The stall bypass patch then skips the event wait loop,
    but this causes the parameter FIFO to overflow (12 params instead of 3
    for Setloc), producing the "Incorrect parameters for command 0x02" errors.

    Fix:
    1. Use surgical disc-check (10 patches, NO cd_init_force_success)
       -- CD-ROM hardware initializes normally
    2. Remove FMV skip + CD-ROM stall bypass entirely
       -- Event wait loop functions correctly, FIFO is cleared between commands
    3. Keep all other v43 patches (LBA, tree, BSS, HBD re-encoding)
    4. Preserve DW7 FMV data (only write non-zero DQ4 HBD sectors)
    """
    print("\n  Profile: frank_v44 (v43 + surgical CD-ROM fix: no cd_init bypass, no stall bypass)")

    OLD_HBD_LBA = 354
    NEW_HBD_LBA = 355
    LBA_DELTA = NEW_HBD_LBA - OLD_HBD_LBA  # = 1

    with open(ORIGINAL_EXE, 'rb') as f:
        exe = bytearray(f.read())
    print(f"  DW7 EXE: {len(exe):,} bytes")

    # 1. SURGICAL disc-check bypass (10 patches, NO cd_init_force_success)
    print(f"\n  [1/10] Applying SURGICAL disc-check bypass (10 patches, NO cd_init)...")
    exe_bytes, disc_patches = patch_disc_check(bytes(exe), semi_surgical=True)
    exe = bytearray(exe_bytes)
    print(f"  Disc-check patches: {disc_patches} (cd_init_force_success SKIPPED)")

    # 2. LBA references: patch all 354 -> 355
    print(f"\n  [2/10] Patching LBA references (broad 354->355 scan)...")
    exe_bytes, lba_patches = patch_lba_references(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  LBA references patched: {lba_patches}")

    # 3. Sequential sector table
    print(f"\n  [3/10] Patching sequential sector table...")
    exe_bytes, seq_patches = patch_sequential_sector_table(bytes(exe), OLD_HBD_LBA, NEW_HBD_LBA)
    exe = bytearray(exe_bytes)
    print(f"  Sequential sector table patches: {seq_patches}")

    # 4. ABS/REL pointer remapping (matched folders + LBA delta for unmatched)
    print(f"\n  [4/10] Remapping ABS/REL folder pointers...")
    abs_repl = {}
    rel_repl = {}
    if os.path.exists(FOLDER_MAP):
        with open(FOLDER_MAP, 'r') as f:
            fm_data = json.load(f)
        mappings = fm_data.get('mappings', fm_data) if isinstance(fm_data, dict) else fm_data
        for m in mappings:
            dw7_sec = m.get('dw7_sector', 0)
            dq4_sec = m.get('dq4_sector', 0)
            if dw7_sec and dq4_sec:
                abs_repl[dw7_sec] = dq4_sec + NEW_HBD_LBA
                rel_repl[dw7_sec] = dq4_sec
        print(f"  Folder mappings loaded: {len(abs_repl)} ABS, {len(rel_repl)} REL")
    else:
        print(f"  WARNING: No folder_mapping.json found, using LBA delta only")
    abs_matched, abs_delta, rel_matched, _ = remap_pointers_matched_only(
        exe, abs_repl, rel_repl, lba_delta=LBA_DELTA
    )
    print(f"  ABS: matched={abs_matched}, delta={abs_delta}, REL: matched={rel_matched}")

    # 5. Hybrid tree appended in-place (NO copy routine)
    print(f"\n  [5/10] Appending hybrid tree in-place (no copy routine)...")
    original_pc0 = struct.unpack_from('<I', exe, 0x10)[0]
    exe_bytes = append_hybrid_tree(bytes(exe), target_ram_addr=None)
    exe = bytearray(exe_bytes)
    load_addr = struct.unpack_from('<I', exe, 0x18)[0]
    with open(HYBRID_TREE, 'rb') as f:
        tree_size = len(f.read())
    orig_exe_size = 675840
    tree_file_off = orig_exe_size
    padding = (4 - (orig_exe_size % 4)) % 4
    tree_file_off += padding
    tree_ram = load_addr + tree_file_off - 0x800
    print(f"  Tree (in-place): RAM 0x{tree_ram:08X}, {tree_size}B")

    # 6. Patch MIPS tree refs to point to in-place tree
    print(f"\n  [6/10] Patching MIPS tree refs to in-place tree (0x{tree_ram:08X})...")
    new_lui, new_addiu, tree_addr, verify = compute_tree_addr(bytes(exe), target_ram_addr=tree_ram)
    print(f"  Tree: LUI=0x{new_lui:04X} ADDIU=0x{new_addiu:04X} -> 0x{verify:08X} ({'OK' if verify == tree_addr else 'FAIL'})")
    exe_bytes, tree_patches = patch_mips_tree_refs(bytes(exe), new_lui, new_addiu)
    exe = bytearray(exe_bytes)
    print(f"  Tree ref patches: {tree_patches}")

    # 7. BSS clear: patch start to skip tree, zero pre-tree BSS
    print(f"\n  [7/10] Patching BSS clear...")
    tree_end_ram = tree_ram + tree_size
    tree_end_ram = (tree_end_ram + 3) & ~3
    exe = bytearray(patch_bss_clear_start(bytes(exe), tree_end_ram))
    print(f"  BSS clear start: 0x800BC668 -> 0x{tree_end_ram:08X}")
    print(f"  BSS clear end: 0x800F4980 (unchanged -- full clear after tree)")

    PRE_TREE_BSS_START = 0x800BC668
    PRE_TREE_BSS_END = 0x800BC700
    pre_tree_file_start = PRE_TREE_BSS_START - load_addr + 0x800
    pre_tree_file_end = PRE_TREE_BSS_END - load_addr + 0x800
    pre_tree_len = pre_tree_file_end - pre_tree_file_start
    print(f"\n  [7b] Zeroing pre-tree BSS region ({pre_tree_len} bytes at file offset 0x{pre_tree_file_start:X})")
    exe[pre_tree_file_start:pre_tree_file_end] = b'\x00' * pre_tree_len
    print(f"  Zeroed 0x{PRE_TREE_BSS_START:08X}-0x{PRE_TREE_BSS_END:08X}")

    # NO stall bypass, NO FMV skip -- CD-ROM hardware must initialize normally
    print(f"\n  [7d] SKIPPING FMV skip + CD-ROM stall bypass (NOT NEEDED with surgical disc-check)")
    print(f"  CD-ROM hardware will initialize normally (cd_init NOT bypassed)")

    # 8. HBD re-encoding via C++ HbdReencoder
    print(f"\n  [8/10] Re-encoding DQ4 HBD via C++ HbdReencoder (per-block -> global tree)...")
    try:
        psx = load_psx_ops()
    except FileNotFoundError as e:
        print(f"  ERROR: {e}")
        print(f"  Cannot re-encode HBD without psx_ops.dll. Build aborted.")
        return

    print(f"  Detecting actual DQ4 HBD data size...")
    actual_sectors = detect_hbd_data_size(DQ4_HBD_DISC, DQ4_HBD_DISC_START)
    actual_size = actual_sectors * USER_SIZE
    print(f"  DQ4 HBD: {actual_sectors} sectors ({actual_size:,} bytes) of non-zero data")

    print(f"  Extracting DQ4 HBD...")
    hbd_data = extract_hbd_from_disc(DQ4_HBD_DISC, DQ4_HBD_DISC_START, actual_size)
    print(f"  DQ4 HBD extracted: {len(hbd_data):,} bytes")

    with open(HYBRID_TREE, 'rb') as f:
        hybrid_tree_data = f.read()

    print(f"  Loading HBD into C++ re-encoder...")
    hbd_handle = psx.hbd_load(hbd_data, len(hbd_data), hybrid_tree_data, len(hybrid_tree_data))
    if not hbd_handle:
        print(f"  ERROR: hbd_load failed")
        return

    print(f"  Processing HBD (source_lba={DQ4_HBD_DISC_START}, target_lba={NEW_HBD_LBA})...")
    result = psx.hbd_process(hbd_handle, DQ4_HBD_DISC_START, NEW_HBD_LBA)
    print(f"  HBD processing result:")
    print(f"    folders_parsed:     {result.folders_parsed}")
    print(f"    files_parsed:       {result.files_parsed}")
    print(f"    blocks_processed:   {result.blocks_processed}")
    print(f"    blocks_converted:   {result.blocks_converted}")
    print(f"    blocks_reencoded:   {result.blocks_reencoded}")
    print(f"    blocks_reenc_fail:  {result.blocks_reencode_failed}")
    print(f"    subblock_swaps:     {result.subblock_swaps}")
    print(f"    errors:             {result.errors}")
    print(f"    success:            {result.success}")

    if result.errors > 0:
        print(f"  WARNING: {result.errors} errors during HBD processing (continuing)")

    print(f"  Validating processed HBD...")
    valid = psx.hbd_validate(hbd_handle, NEW_HBD_LBA)
    print(f"  Validation: {'PASS' if valid else 'FAIL'}")

    # Extract processed HBD data
    processed_size = psx.hbd_size(hbd_handle)
    processed_raw = psx.hbd_raw(hbd_handle)
    processed_hbd = bytes(ctypes.string_at(processed_raw, processed_size))
    print(f"  Processed HBD: {len(processed_hbd):,} bytes (was {len(hbd_data):,})")

    psx.hbd_free(hbd_handle)

    # 9. Verify EXE size fits before HBD overlap
    max_exe = (NEW_HBD_LBA - EXE_LBA) * USER_SIZE
    print(f"\n  [9/10] EXE size: {len(exe):,} bytes (max before HBD: {max_exe:,}) -- {'OK' if len(exe) <= max_exe else 'OVERLAP!'}")

    # 10. Assemble disc
    print(f"\n  [10/10] Assembling disc...")
    shutil.copy(DW7_DISC, output_bin)

    with open(output_bin, 'r+b') as f:
        print(f"  Writing EXE at sector {EXE_LBA}...")
        write_raw_data(f, EXE_LBA, bytes(exe))

        print(f"  Writing re-encoded DQ4 HBD at sector {NEW_HBD_LBA}...")
        write_raw_data(f, NEW_HBD_LBA, processed_hbd)
        dq4_hbd_end = NEW_HBD_LBA + (len(processed_hbd) + USER_SIZE - 1) // USER_SIZE
        print(f"  DQ4 HBD spans sectors {NEW_HBD_LBA}-{dq4_hbd_end - 1}")
        print(f"  DW7 data preserved from sector {dq4_hbd_end} onwards (includes FMV at LBA 146621)")

        print(f"  Updating ISO directory...")
        update_iso_dir(f, exe_size=len(exe), hbd_size=DQ4_HBD_SIZE, hbd_lba=NEW_HBD_LBA)
        print(f"  ISO dir: EXE size={len(exe):,}, HBD LBA={NEW_HBD_LBA}, HBD size={DQ4_HBD_SIZE:,}")

        print(f"  Updating PVD...")
        update_pvd(f)

    write_cue(output_cue, os.path.basename(output_bin))
    run_edcre(output_bin)

    final_size = os.path.getsize(output_bin)
    print(f"\n  BUILD COMPLETE")
    print(f"  Size: {final_size:,} bytes")
    print(f"  Patches: disc={disc_patches}(surgical) lba={lba_patches} seq={seq_patches} "
          f"abs_matched={abs_matched} abs_delta={abs_delta} rel={rel_matched} tree={tree_patches}")
    print(f"  HBD re-encode: folders={result.folders_parsed} blocks={result.blocks_processed} "
          f"reencoded={result.blocks_reencoded} failed={result.blocks_reencode_failed} "
          f"swaps={result.subblock_swaps} errors={result.errors}")
    print(f"  Strategy: v43 + surgical CD-ROM fix (no cd_init bypass, no stall bypass)")
    print(f"  Tree: 0x{tree_ram:08X}, BSS: 0x{tree_end_ram:08X}-0x800F4980")
    print(f"  PC0: 0x{original_pc0:08X} (unchanged)")
    print(f"  KEY CHANGE: cd_init_force_success SKIPPED -- CD-ROM hardware initializes normally")
    print(f"  KEY CHANGE: NO stall bypass -- event wait loop functions correctly")


# ============================================================
# Profile registry
# ============================================================

PROFILES = {
    'test_0': {
        'desc': 'Plain DW7 copy (baseline)',
        'builder': build_test_0,
        'default_output': 'dq4_test_0.bin',
    },
    'test_a': {
        'desc': 'DQ4 HBD swap only, no EXE patches',
        'builder': build_test_a,
        'default_output': 'dq4_test_a.bin',
    },
    'test_b': {
        'desc': 'DQ4 HBD + tree patches, no pointer patches',
        'builder': build_test_b,
        'default_output': 'dq4_test_b.bin',
    },
    'test_d': {
        'desc': 'DW7 HBD + tree patches only (no HBD swap)',
        'builder': build_test_d,
        'default_output': 'dq4_test_d.bin',
    },
    'test_f': {
        'desc': 'ISO dir update only (no HBD/EXE changes)',
        'builder': build_test_f,
        'default_output': 'dq4_test_f.bin',
    },
    'frank_v12': {
        'desc': 'Full Frankenstein v12 (DW7-preserved pointer redirect)',
        'builder': build_frank_v12,
        'default_output': 'dq4_frankenstein_v12.bin',
    },
    'frank_v13': {
        'desc': 'Frankenstein v13 (selective DQ4 overlay, DW7 HBD preserved)',
        'builder': build_frank_v13,
        'default_output': 'dq4_frankenstein_v23.bin',
    },
    'frank_v14': {
        'desc': 'Frankenstein v14 (v13 + surgical disc-check, no cd_init bypass)',
        'builder': build_frank_v14,
        'default_output': 'dq4_frankenstein_v24.bin',
    },
    'frank_v15': {
        'desc': 'Frankenstein v15 (test_d + surgical disc-check, NO HBD shift)',
        'builder': build_frank_v15,
        'default_output': 'dq4_frankenstein_v25.bin',
    },
    'frank_v16': {
        'desc': 'Frankenstein v16 (test_d + full disc-check, NO HBD shift)',
        'builder': build_frank_v16,
        'default_output': 'dq4_frankenstein_v26.bin',
    },
    'frank_v17': {
        'desc': 'Frankenstein v17 (clean test_d, disc-check via RAM hook .cht)',
        'builder': build_frank_v17,
        'default_output': 'dq4_frankenstein_v27.bin',
    },
    'frank_v18': {
        'desc': 'Frankenstein v18 (test_d + semi-surgical 8 patches, NO cd_init, NO HBD shift)',
        'builder': build_frank_v18,
        'default_output': 'dq4_frankenstein_v28.bin',
    },
    'frank_v19': {
        'desc': 'Frankenstein v19 (test_d + semi-surgical + CD-ROM Stop intercept, NO HBD shift)',
        'builder': build_frank_v19,
        'default_output': 'dq4_frankenstein_v29.bin',
    },
    'frank_v29_ctrl': {
        'desc': 'Control: v19 WITHOUT trampoline or BSS expansion (isolate trampoline impact)',
        'builder': build_frank_v29_control,
        'default_output': 'dq4_frankenstein_v29_ctrl.bin',
    },
    'frank_v30': {
        'desc': 'Frankenstein v30 (targeted disc_check exits + Stop intercept, NO HBD shift)',
        'builder': build_frank_v30,
        'default_output': 'dq4_frankenstein_v30.bin',
    },
    'frank_v31': {
        'desc': 'Frankenstein v31 (unified: v30 engine patches + v12 DQ4 HBD swap at LBA 355)',
        'builder': build_frank_v31,
        'default_output': 'dq4_frankenstein_v31.bin',
    },
    'frank_v32': {
        'desc': 'Frankenstein v32 (v31 with reloc payload fix — no EXE/HBD overlap)',
        'builder': build_frank_v31,
        'default_output': 'dq4_frankenstein_v32.bin',
    },
    'frank_v33': {
        'desc': 'Frankenstein v33 (v32 with tree relocated to 0x80100000 — avoids game data collision)',
        'builder': build_frank_v31,
        'default_output': 'dq4_frankenstein_v33.bin',
    },
    'frank_v34': {
        'desc': 'Frankenstein v34 (v33 with load delay fix — NOP between lw/sw in copy routine)',
        'builder': build_frank_v31,
        'default_output': 'dq4_frankenstein_v34.bin',
    },
    'frank_v35': {
        'desc': 'Frankenstein v35 (Localization Graft: 5 system-level adjustments)',
        'builder': build_frank_v35,
        'default_output': 'dq4_frankenstein_v35.bin',
    },
    'frank_v36': {
        'desc': 'Frankenstein v36 (v34 engine + v13 HBD overlay: DW7 preserved + DQ4 appended)',
        'builder': build_frank_v36,
        'default_output': 'dq4_frankenstein_v36.bin',
    },
    'frank_v37': {
        'desc': 'Frankenstein v37 (v36 + FMV/STR/XA skip patches)',
        'builder': build_frank_v36,
        'default_output': 'dq4_frankenstein_v37.bin',
    },
    'frank_v38a': {
        'desc': 'Engine bisection: disc-check only, pure DW7, HBD at 354',
        'builder': build_frank_v38a,
        'default_output': 'dq4_frankenstein_v38a.bin',
    },
    'frank_v38b': {
        'desc': 'Engine bisection: full engine + HBD shift, pure DW7, no DQ4',
        'builder': build_frank_v38b,
        'default_output': 'dq4_frankenstein_v38b.bin',
    },
    'frank_v39': {
        'desc': 'C++ psx_ops.dll + thread-entry fix Option A + DQ4 HBD swap',
        'builder': build_frank_v39,
        'default_output': 'dq4_frankenstein_v39.bin',
    },
    'frank_v40': {
        'desc': 'Minimal patching + HuffTree re-encode (no LBA scan/disc-check/trampoline)',
        'builder': build_frank_v40,
        'default_output': 'dq4_frankenstein_v40.bin',
    },
    'frank_v40c': {
        'desc': 'Option C: No tree, no BSS patch — game uses own tree at 0x800EF1C8',
        'builder': build_frank_v40c,
        'default_output': 'dq4_frankenstein_v40c.bin',
    },
    'frank_v40b': {
        'desc': 'Option B: Tree at 0x800F4980 via copy routine (BSS boundary)',
        'builder': build_frank_v40b,
        'default_output': 'dq4_frankenstein_v40b.bin',
    },
    'frank_v40a': {
        'desc': 'Option A: Tree at 0x80100000 via copy routine (high RAM, safe from BSS)',
        'builder': build_frank_v40a,
        'default_output': 'dq4_frankenstein_v40a.bin',
    },
    'frank_v41': {
        'desc': 'Gate1-informed: full disc-check + DQ4 HBD + tree in-place + BSS narrow, NO copy routine',
        'builder': build_frank_v41,
        'default_output': 'dq4_frankenstein_v41.bin',
    },
    'frank_v42': {
        'desc': 'v41 + HBD truncation fix + pre-tree BSS zero + CD-ROM stall bypass',
        'builder': build_frank_v41,
        'default_output': 'dq4_frankenstein_v42.bin',
    },
    'frank_v43': {
        'desc': 'v41 + C++ HBD re-encoding (per-block -> global tree) -- fixes root cause of v42 black screen',
        'builder': build_frank_v43,
        'default_output': 'dq4_frankenstein_v43.bin',
    },
    'frank_v44': {
        'desc': 'v43 + surgical CD-ROM fix (no cd_init bypass, no stall bypass) -- fixes Setloc param overflow',
        'builder': build_frank_v44,
        'default_output': 'dq4_frankenstein_v44.bin',
    },
    'rc2': {
        'desc': 'DQ4 EXE + patched HBD on DW7 body (no zeroing)',
        'builder': build_rc2,
        'default_output': 'dq4_en_rc2.bin',
    },
}


def main():
    parser = argparse.ArgumentParser(description='Unified Frankenstein ROM builder')
    parser.add_argument('--profile', '-p', required=False, help='Build profile name')
    parser.add_argument('--output', '-o', default=None, help='Output .bin file path')
    parser.add_argument('--list', '-l', action='store_true', help='List available profiles')
    parser.add_argument('--use-cpp', action='store_true', default=False,
                        help='Use C++ psx_ops.dll for binary operations (auto-enabled for v39)')
    args = parser.parse_args()
    
    if args.list or not args.profile:
        print("Available build profiles:")
        for name, info in PROFILES.items():
            print(f"  {name:15s} - {info['desc']} (output: {info['default_output']})")
        if not args.profile:
            print(f"\nUse --profile <name> to build a specific profile")
        return
    
    if args.profile not in PROFILES:
        print(f"ERROR: Unknown profile '{args.profile}'")
        print(f"Available: {', '.join(PROFILES.keys())}")
        sys.exit(1)
    
    profile = PROFILES[args.profile]
    output_bin = args.output or os.path.join(BASE, profile['default_output'])
    output_cue = output_bin.rsplit('.bin', 1)[0] + '.cue'
    
    print("=" * 60)
    print(f"Frankenstein Builder")
    print(f"Profile: {args.profile}")
    print(f"Output: {output_bin}")
    print("=" * 60)
    
    # Verify inputs exist
    if not os.path.exists(DW7_DISC):
        print(f"ERROR: DW7 disc not found: {DW7_DISC}")
        sys.exit(1)
    
    profile['builder'](output_bin, output_cue)
    
    print(f"\n  CUE: {output_cue}")
    print(f"\n  Next: Test in RetroArch/SwanStation")


if __name__ == '__main__':
    main()
