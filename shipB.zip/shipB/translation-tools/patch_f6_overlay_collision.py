#!/usr/bin/env python3
"""
patch_f6_overlay_collision.py

F6 Cynthia speech freeze fix: redirect archive header load away from
resident message module (Theory B — overlay-residency collision).

ROOT CAUSE (confirmed by DuckStation log at 237.0538):
  The async archive loader (hbd1ps1d.q41) calls the KSEG0 allocator at
  0x8009B138 with a0=0x80011F00 (the resident message module's base address)
  and a1=0x200 (512 bytes = 1 CD sector). The allocator blindly writes the
  archive header directly over the message module's code at 0x80011F00–0x80012EFF,
  destroying the module. The message-queue shift loop at 0x80090308 then reads
  a corrupted pointer from 0x800C06B8 (BSS start, message-queue base) and
  crashes with "Invalid word read at address 0xFFFFFFF6".

  The VSync timeout patch (Theory A) was masking a symptom — the panic was
  a secondary effect of the module code being destroyed.

FIX:
  Redirect the archive header load from 0x80011F00 to 0x80014000 — a free
  region between the message module end (0x80012EFF) and the EXE load
  address (0x80017F00). Also redirect the 16-byte metadata copy source from
  0x80012300 to 0x80014400 (offset 0x400 into the new load address).

  The message module's own code at 0x8006C6xx continues to reference
  0x80011F00 as its base — those references are NOT changed because the
  module is no longer being clobbered.

PATCH SITES (2 instructions):
  1. RAM 0x8005DC00 (EXE offset 0x46500):
     ori $a0, $a0, 0x1F00  (0x34841F00) -> ori $a0, $a0, 0x4000  (0x34844000)
     Changes load target from 0x80011F00 to 0x80014000

  2. RAM 0x8005DC14 (EXE offset 0x46514):
     ori $a1, $a1, 0x2300  (0x34A52300) -> ori $a1, $a1, 0x4400  (0x34A54400)
     Changes metadata copy source from 0x80012300 to 0x80014400

MEMORY MAP:
  0x80011F00 – 0x80012EFF : resident message module (PROTECTED)
  0x80014000 – 0x80017EFF : free scratch space (0x3F00 bytes, we need 0x200)
  0x80017F00              : PS-X EXE load address
  0x800C06B8              : BSS start (message-queue pointer)
"""
import struct
import sys
import os
import subprocess

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# Disc sector geometry (matches patch_exe_blocks.py)
RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA, EXE_SECTORS = 24, 338
EXE_SIZE = EXE_SECTORS * USZ

# PSX EXE load address (from header at offset 0x18)
RAM_BASE = 0x80017700

# Patch targets
PATCH1_RAM = 0x8005DC00  # ori $a0, $a0, 0x1F00 -> 0x4000
PATCH1_OFF = PATCH1_RAM - RAM_BASE  # 0x46500

PATCH2_RAM = 0x8005DC14  # ori $a1, $a1, 0x2300 -> 0x4400
PATCH2_OFF = PATCH2_RAM - RAM_BASE  # 0x46514

# Expected original bytes
EXPECTED_ORIG_1 = 0x34841F00  # ori $a0, $a0, 0x1F00
EXPECTED_ORIG_2 = 0x34A52300  # ori $a1, $a1, 0x2300

# Patch bytes
PATCH_NEW_1 = 0x34844000     # ori $a0, $a0, 0x4000  (0x80014000)
PATCH_NEW_2 = 0x34A54400     # ori $a1, $a1, 0x4400  (0x80014400)

EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")


def is_disc_image(path):
    with open(path, "rb") as f:
        head = f.read(16)
    return head[:8] != b"PS-X EXE"


def read_exe_from_disc(disc_path):
    exe = bytearray()
    with open(disc_path, "rb") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            exe.extend(f.read(USZ))
    return exe[:EXE_SIZE]


def write_exe_to_disc(disc_path, exe_data):
    with open(disc_path, "r+b") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            f.write(bytes(exe_data[i * USZ:(i + 1) * USZ]))


def apply_patch(disc_path, verify_only=False):
    disc = is_disc_image(disc_path)
    if disc:
        print("  Mode: disc image (MODE2/2352, LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))
        exe = read_exe_from_disc(disc_path)
    else:
        print("  Mode: raw PS-X EXE")
        with open(disc_path, "rb") as f:
            exe = bytearray(f.read())

    print("  EXE size: %d bytes (0x%X)" % (len(exe), len(exe)))

    # Verify patch site 1
    if PATCH1_OFF + 4 > len(exe):
        print("[FAIL] Patch offset 1 (0x%X) beyond EXE size" % PATCH1_OFF)
        sys.exit(1)

    orig1 = struct.unpack_from("<I", exe, PATCH1_OFF)[0]
    print("  Patch site 1: RAM 0x%08X, EXE offset 0x%X" % (PATCH1_RAM, PATCH1_OFF))
    print("    Original: 0x%08X (expected 0x%08X)" % (orig1, EXPECTED_ORIG_1))

    if orig1 != EXPECTED_ORIG_1:
        if orig1 == PATCH_NEW_1:
            print("    [SKIP] Already patched")
        else:
            print("[FAIL] Unexpected byte at patch site 1")
            sys.exit(1)
    else:
        print("    [OK] Verified: ori $a0, $a0, 0x1F00 (load to 0x80011F00)")

    # Verify patch site 2
    orig2 = struct.unpack_from("<I", exe, PATCH2_OFF)[0]
    print("  Patch site 2: RAM 0x%08X, EXE offset 0x%X" % (PATCH2_RAM, PATCH2_OFF))
    print("    Original: 0x%08X (expected 0x%08X)" % (orig2, EXPECTED_ORIG_2))

    if orig2 != EXPECTED_ORIG_2:
        if orig2 == PATCH_NEW_2:
            print("    [SKIP] Already patched")
        else:
            print("[FAIL] Unexpected byte at patch site 2")
            sys.exit(1)
    else:
        print("    [OK] Verified: ori $a1, $a1, 0x2300 (copy from 0x80012300)")

    if verify_only:
        print("  [VERIFY] Patch not applied (verify-only mode)")
        return

    # Apply patches
    if orig1 == EXPECTED_ORIG_1:
        print("  Patching site 1: 0x%08X -> 0x%08X" % (orig1, PATCH_NEW_1))
        struct.pack_into("<I", exe, PATCH1_OFF, PATCH_NEW_1)
        v = struct.unpack_from("<I", exe, PATCH1_OFF)[0]
        if v != PATCH_NEW_1:
            print("[FAIL] Patch site 1 verification failed")
            sys.exit(1)
        print("    [OK] Patched: ori $a0, $a0, 0x4000 (redirect to 0x80014000)")

    if orig2 == EXPECTED_ORIG_2:
        print("  Patching site 2: 0x%08X -> 0x%08X" % (orig2, PATCH_NEW_2))
        struct.pack_into("<I", exe, PATCH2_OFF, PATCH_NEW_2)
        v = struct.unpack_from("<I", exe, PATCH2_OFF)[0]
        if v != PATCH_NEW_2:
            print("[FAIL] Patch site 2 verification failed")
            sys.exit(1)
        print("    [OK] Patched: ori $a1, $a1, 0x4400 (copy from 0x80014400)")

    # Write back
    if disc:
        write_exe_to_disc(disc_path, exe)
        print("  EXE written back to disc (LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))
        if os.path.exists(EDCRE):
            print("  Regenerating EDC/ECC...")
            r = subprocess.run([EDCRE, disc_path], capture_output=True, text=True, timeout=900)
            ok = r.returncode == 0
            print("  EDC/ECC: %s" % ("PASS" if ok else "FAIL"))
            if not ok:
                print("  stderr: %s" % r.stderr[-400:])
                sys.exit(1)
        else:
            print("  [WARN] edcre not found -- EDC/ECC not regenerated")
    else:
        with open(disc_path, "wb") as f:
            f.write(exe)
        print("  EXE written back")

    print("  [DONE] Archive header load redirected from 0x80011F00 to 0x80014000")
    print("  [DONE] Message module at 0x80011F00-0x80012EFF is now protected from clobber")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(
        description="F6 overlay-residency collision patch (Cynthia freeze fix — Theory B)")
    ap.add_argument("--disc", required=True, help="Path to master disc binary or raw EXE")
    ap.add_argument("--verify", action="store_true", help="Verify only, don't patch")
    args = ap.parse_args()

    print("F6 Overlay-Residency Collision Patch (Theory B)")
    print("  Disc: %s" % args.disc)
    apply_patch(args.disc, verify_only=args.verify)
