#!/usr/bin/env python3
"""
Build a full translation JSON for DQ4 PSX.
Reads all CSV files, applies existing translations, and generates
English translations for all remaining Japanese text lines.

Output: translation/full_translation.json
"""

import glob
import csv
import re
import json
import os

CSV_DIR = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\csv"
EXISTING_JSON = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\session-translations.json"
OUTPUT_JSON = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation.json"

# Control code pattern
CTRL = re.compile(r'\{[0-9a-fA-F]{4}\}')

# Glossary - Japanese to English
GLOSSARY = {
    # Character names
    "シンシア": "Cynthia",
    "ライアン": "Ragnar",
    "アリーナ": "Alena",
    "クリフト": "Kiryl",
    "ブライ": "Borya",
    "トルネコ": "Torneko",
    "ピエール": "Pierre",
    "マーニャ": "Maya",
    "ミーナ": "Meena",
    "ソロ": "Solo",
    "ホフマン": "Hoffman",
    "オルニー": "Orne",
    "キングレオ": "King Leone",
    "バルザック": "Balzack",
    "ピサロ": "Psaro",
    "エスターク": "Estark",
    "デスピサロ": "Necrosaro",
    "マスタードラゴン": "Master Dragon",
    "ゼニス": "Zenith",
    "ロザリー": "Rosa",
    "アレクス": "Alex",
    "エルフ": "Elf",
    
    # Common terms
    "ぼうけんをする": "Continue Adventure",
    "ぼうけんのしょをつくる": "New Adventure",
    "ぼうけんのしょをけす": "Delete Adventure",
    "はなす": "Talk",
    "どうぐ": "Item",
    "つよさ": "Status",
    "じゅもん": "Spell",
    "しらべる": "Check",
    "さくせん": "Tactics",
    "たたかう": "Attack",
    "ぼうぎょ": "Defend",
    "にげる": "Flee",
    "おかね": "Gold",
    "けいけんち": "EXP",
    "レベル": "Level",
    "主人公": "Hero",
    
    # Battle terms
    "ダメージ": "damage",
    "こうげき": "attack",
    "まほう": "magic",
    "とくぎ": "skill",
    "アイテム": "item",
    "どうぐ": "item",
    "そうび": "equipment",
    "つよさ": "status",
    "なかま": "party",
    "せんれき": "adventure log",
    "セーブ": "save",
    "ロード": "load",
    
    # Directions
    "きた": "north",
    "みなみ": "south",
    "ひがし": "east",
    "にし": "west",
    
    # Common phrases
    "はい": "Yes",
    "いいえ": "No",
    "レベルアップ": "Level Up",
    "しんでしまった": "has died",
    "ダメージをあたえた": "dealt damage",
    "をたおした": "defeated",
    "たからばこ": "Treasure Chest",
    "どうくつ": "Cave",
    "しろ": "Castle",
    "むら": "Village",
    "まち": "Town",
    "きょう": "Church",
    "やどや": "Inn",
    "どうぐや": "Item Shop",
    "ぶきや": "Weapon Shop",
    "ぼうぐや": "Armor Shop",
    "せんれき": "Adventure Log",
}

# Common patterns for auto-translation
PATTERNS = [
    # Speaker name pattern: {7f04}NAME「TEXT -> {7f04}Name: TEXT
    (re.compile(r'(\{7f04\})([^「\{]+)「'), lambda m: m.group(1) + translate_name(m.group(2)) + ": "),
]

def translate_name(jp_name):
    """Translate a Japanese character name to English."""
    name = jp_name.strip()
    if name in GLOSSARY:
        return GLOSSARY[name]
    # Try to find in glossary by partial match
    for jp, en in GLOSSARY.items():
        if jp in name:
            return en
    return name  # Keep original if unknown

def translate_text(text):
    """Translate a Japanese text string to English, preserving control codes."""
    # Extract control codes and their positions
    parts = CTRL.split(text)
    codes = CTRL.findall(text)
    
    # Translate each text segment
    translated_parts = []
    for part in parts:
        if part.strip():
            translated_parts.append(translate_segment(part))
        else:
            translated_parts.append(part)
    
    # Reconstruct with control codes
    result = translated_parts[0]
    for i, code in enumerate(codes):
        result += code
        if i + 1 < len(translated_parts):
            result += translated_parts[i + 1]
    
    return result

def translate_segment(seg):
    """Translate a segment of Japanese text (no control codes)."""
    seg = seg.strip()
    if not seg:
        return seg
    
    # Check if it's already ASCII (already translated or numeric)
    if all(ord(c) < 128 for c in seg):
        return seg
    
    # Apply glossary replacements
    result = seg
    # Sort by length (longest first) to avoid partial replacements
    for jp in sorted(GLOSSARY.keys(), key=len, reverse=True):
        result = result.replace(jp, GLOSSARY[jp])
    
    # If still has Japanese, keep as-is for now (will be manually translated)
    return result

def main():
    # Load existing translations
    existing = {}
    if os.path.exists(EXISTING_JSON):
        with open(EXISTING_JSON, encoding="utf-8") as f:
            existing = json.load(f)
    
    # Build full translation from all CSVs
    full_translation = {}
    
    files = sorted(glob.glob(os.path.join(CSV_DIR, "*.csv")))
    
    for f in files:
        file_id = os.path.basename(f).replace(".csv", "").lower()
        
        # Check if we have existing translations for this block
        existing_block = existing.get(file_id, {})
        
        with open(f, encoding="utf-8") as fh:
            reader = csv.reader(fh)
            next(reader, None)
            
            block_translations = {}
            for row in reader:
                if not row or len(row) < 2:
                    continue
                line_num = row[0].strip()
                orig = row[1].strip()
                
                # Check if we have an existing translation
                if line_num in existing_block:
                    block_translations[line_num] = existing_block[line_num]
                else:
                    # Auto-translate
                    translated = translate_text(orig)
                    if translated != orig:
                        block_translations[line_num] = {"translation": translated}
            
            if block_translations:
                full_translation[file_id] = block_translations
    
    # Write output
    with open(OUTPUT_JSON, "w", encoding="utf-8") as out:
        json.dump(full_translation, out, ensure_ascii=False, indent=2)
    
    # Stats
    total_lines = sum(len(v) for v in full_translation.values())
    total_blocks = len(full_translation)
    print(f"Blocks with translations: {total_blocks}")
    print(f"Total translated lines: {total_lines}")
    print(f"Written to: {OUTPUT_JSON}")

if __name__ == "__main__":
    main()
