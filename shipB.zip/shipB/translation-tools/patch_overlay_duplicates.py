#!/usr/bin/env python3
"""
patch_overlay_duplicates.py -- Decompress, patch duplicate facility/battle text blocks,
remap internal referrers, recompress, and write back to all type-46 overlay modules.

Handles Class B duplicates:
  0x048B (battle overlay - 93 occurrences)
  0x047B (shop facility  - 70 occurrences)
  0x047C (inn facility   - 65 occurrences)
  0x047D (church/priest  - 55 occurrences)
  0x0477 (church facility - 4 occurrences)
  0x0478 (church facility - 3 occurrences)
  0x0479 (vault facility  - 2 occurrences)

Invariants:
  - Recompressed module must strictly fit within original dlen (len(rec) <= dlen).
  - Padded with 0x00 to exactly original dlen (zero sector shift).
  - Internal direct words and split-immediates remapped using verified omaps.
"""

import argparse
import json
import os
import re
import struct
import sys
import time

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE) if "translation-tools" in HERE else HERE
sys.path.insert(0, HERE)
_psx = ROOT
for _ in range(4):
    if os.path.isdir(os.path.join(_psx, "psx_tools", "dq4")):
        sys.path.insert(0, os.path.join(_psx, "psx_tools"))
        break
    _psx = os.path.dirname(_psx)
sys.stdout.reconfigure(encoding="utf-8")

from hbe.compression.lzss import lzss_uncompress
from hbe.compression.dqlzs import compress_to_slot
from hbe.huffman.dq4 import DQ4Schema
from dq4 import huffman as PH
import dq4_hbd_patcher as P
import patch_overlay_refs as POR
from patch_overlay_refs import (
    build_omaps, scan_split_pairs, halves, compose, writes,
    locate_battle_block, find_block_anywhere, read_block_bytes,
    parse_block_pristine, parse_block_master,
    WINDOW, LUI, ORI, ADDIU
)

RAW, UOFF, USZ = 2352, 24, 2048
HBD_LBA = 362
FLAG_LZS = 0x0500

# Lane 2 (Sep-06) dirskip closure instrumentation: classification of every
# skipped direct-referrer candidate across all modules, plus the records of
# the residual context-fails (noise passes, no neighbours, no +-44 boundary).
DIRSKIP_KINDS = {"noise": 0, "context": 0, "boundary_caught": 0}
DIRSKIP_RECORDS = []
REMAP_USE_BOUNDARY = True  # disabled on the 'full-noboundary' ladder rung

TARGET_IDS = {
    0x048B,  # Battle overlay (817 sequences)
    0x047B,  # Shop dialogue (251 sequences)
    0x047C,  # Inn dialogue (20 sequences)
    0x047D,  # Church/priest dialogue (291 sequences)
    0x0477,  # Church facility (30 sequences)
    0x0478,  # Church facility (17 sequences)
    0x0479,  # Vault facility (23 sequences)
    # Phase C additions (corpus completion, embedded copies)
    0x0480,  # Casino counter clerk (x4)
    0x0483,  # Memory-card integrity flow (x2)
    0x0484,  # Memory-card titles (x55)
    0x0485,  # Save-confirm flow (x1)
    0x0486,  # Shop-flow dialogue (x1)
    0x0487,  # Shop/vault keeper (x1)
    0x0488,  # Casino rules UI (linear only; harmless here)
    0x047F,  # Player titles table (linear, single copy)
}


def load_archive(path, lba=HBD_LBA, chunk_secs=1024):
    """Reads user-data stream of HBD archive in chunks."""
    buf = bytearray()
    with open(path, "rb") as f:
        f.seek(0, 2)
        total_sectors = f.tell() // RAW
        end_sec = total_sectors
        cur = lba
        while cur < end_sec:
            n = min(chunk_secs, end_sec - cur)
            f.seek(cur * RAW)
            raw = f.read(n * RAW)
            for i in range(n):
                chunk = raw[i * RAW + UOFF : i * RAW + UOFF + USZ]
                if len(chunk) < USZ:
                    break
                buf.extend(chunk)
            cur += n
    return bytes(buf)


def parse_block(buf, off):
    """Block header + sub table at a sector boundary."""
    if off + 16 > len(buf):
        return None
    nsub, nsec, tlen, zero = struct.unpack_from("<4I", buf, off)
    if zero != 0 or nsub == 0 or nsec == 0 or nsub > 4096:
        return None
    hdr = 16 + nsub * 16
    if off + hdr > len(buf):
        return None
    subs = []
    data = off + hdr
    run = 0
    for i in range(nsub):
        so = off + 16 + i * 16
        dlen, ulen, unk = struct.unpack_from("<3I", buf, so)
        flags, stype = struct.unpack_from("<2H", buf, so + 12)
        subs.append(dict(idx=i, dlen=dlen, ulen=ulen, flags=flags, type=stype, off=data))
        data += dlen
        run += dlen
    if run != tlen:
        return None
    if (hdr + tlen + USZ - 1) // USZ != nsec:
        return None
    return dict(sector=off // USZ, nsub=nsub, nsec=nsec, tlen=tlen, subs=subs)


def scan_archive(buf):
    """Locates all archive block headers."""
    out = {}
    n = len(buf) // USZ
    for s in range(n):
        o = s * USZ
        b = buf[o : o + 4]
        if b[1] or b[2] or b[3] or not b[0]:
            continue
        blk = parse_block(buf, o)
        if blk is not None:
            out[s] = blk
    return out


def locate_text_blocks(img):
    """Structural locator: 6-u32 header + self-pointer test."""
    out = []
    n = len(img)
    o = 0
    while o + 28 <= n:
        a, tid, c, d, e, f6 = struct.unpack_from("<6I", img, o)
        ok = (0x001 <= (tid & 0xFFFF) <= 0x600) and (24 < a < 0x40000) and (o + a + 4 <= n)
        if ok:
            if f6 == 0:
                ok = (c == 24)
            elif f6 == 24:
                ok = (24 < c < a)
            else:
                ok = False
        if ok:
            ok = bool(e) and 24 < e <= a and c < e and (d == 0 or e < d <= a)
        if ok:
            ok = struct.unpack_from("<I", img, o + a)[0] == a
        if ok:
            out.append((o, a, tid & 0xFFFF, c, d, e, f6))
            o += a
            continue
        o += 4
    return out


def write_disc_user_data(f, archive_offset, data):
    """Writes bytes into disc user data area handling sector bridging."""
    cur_off = archive_offset
    rem = data
    while rem:
        sec = HBD_LBA + (cur_off // USZ)
        uoff = cur_off % USZ
        n = min(len(rem), USZ - uoff)
        f.seek(sec * RAW + UOFF + uoff)
        f.write(rem[:n])
        cur_off += n
        rem = rem[n:]


def main():
    global REMAP_USE_BOUNDARY
    parser = argparse.ArgumentParser(
        description="Patch type-46 overlay duplicates and remap internal referrers"
    )
    parser.add_argument(
        "--disc",
        default=os.path.join(ROOT, "build", "dq4_sovereign_master.bin"),
        help="Master disc to patch",
    )
    parser.add_argument(
        "--base",
        default=os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"),
        help="Pristine base disc",
    )
    parser.add_argument(
        "--corpus",
        default=os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json"),
        help="Canonical corpus (used by the opt-in module-borne synthesis path)",
    )
    parser.add_argument(
        "--report",
        action="store_true",
        help="Dry-run scan without writing to disc",
    )
    parser.add_argument(
        "--synthesize-ids",
        nargs="*",
        default=[],
        help="Target ids with NO linear master for which to synthesize an EN "
             "master from the corpus + first pristine module occurrence "
             "(047D no longer needs this -- it has linear masters). Opt-in: "
             "the synthesized block's in-module ref remap is untested for "
             "0480/0485-0487, so they stay JP by default.",
    )
    args = parser.parse_args()

    if not os.path.exists(args.disc):
        raise SystemExit(f"[FAIL] Disc not found: {args.disc}")
    if not os.path.exists(args.base):
        raise SystemExit(f"[FAIL] Base disc not found: {args.base}")

    print("=" * 75)
    print("  TYPE-46 OVERLAY DUPLICATES PATCHER (Class B)")
    print("=" * 75)
    t0 = time.time()

    # 1. Build omaps from pristine vs master
    print("\n1) Building sequence omaps...")
    omaps, hts_by, pos_by, seq_count_by = build_omaps(args.base, args.disc)
    if not omaps:
        raise SystemExit("[FAIL] No target blocks could be parsed")

    target_luis = set()
    for bid in omaps:
        target_luis.add(bid << 4)
        target_luis.add((bid << 4) + 1)

    def resolve_val(val, lo_op=None):
        bid = val >> 20
        if bid not in omaps:
            return None
        rel = (val & 0xFFFFF) - hts_by[bid] * 8
        if rel not in omaps[bid]:
            return None
        seq_idx = pos_by[bid].get(rel)
        if seq_idx is None or seq_idx + 1 >= seq_count_by[bid]:
            return None
        new_rel = omaps[bid][rel] + hts_by[bid] * 8
        return (bid << 20) | (new_rel & 0xFFFFF)

    # 2. Extract master English block bytes for all target blocks
    # Lane 1 (Sep-06): embedded-only target ids (0x0480/0x0485-0x0488/0x047F
    # live ONLY inside type-46 modules; no linear master block exists until
    # the STEP 4d container-discovery lane) have no English bytes to graft.
    # Skip them with a note instead of aborting the build -- their embedded
    # copies stay Japanese (tracked Phase C leftovers), while the ids that DO
    # have master blocks (0x0474/0477-047D/0483/0484/048B/048C) still graft.
    print("\n2) Extracting patched master English blocks...")
    master_blocks = {}
    for bid in sorted(TARGET_IDS):
        if bid == 0x048B:
            sec, uoff, hdr = locate_battle_block(args.disc, bid)
        else:
            sec, uoff, hdr = find_block_anywhere(args.disc, bid)
        if sec is None or hdr is None:
            print(f"  Block 0x{bid:04X}: no linear master block (embedded-only id)"
                  f" -- embedded copies stay JP until Phase C container lane; SKIPPED")
            continue
        b_bytes = read_block_bytes(args.disc, sec, uoff, hdr[0])
        master_blocks[bid] = b_bytes
        print(f"  Block 0x{bid:04X}: sec {sec}+{uoff}, len={len(b_bytes)} bytes")

    # 3. Load archive from base disc to identify all type-46 modules
    print("\n3) Loading HBD archive structure...")
    arch_p = load_archive(args.base)
    blocks_p = scan_archive(arch_p)
    print(f"  Archive scanned: {len(blocks_p)} blocks")

    # 4. Group type-46 occurrences by distinct image hash
    print("\n4) Finding type-46 modules containing target blocks...")
    distinct_modules = {}  # hash -> dict
    for s, b in blocks_p.items():
        for sb in b["subs"]:
            if sb["type"] != 46:
                continue
            raw = arch_p[sb["off"] : sb["off"] + sb["dlen"]]
            h = hash(raw)
            if h in distinct_modules:
                distinct_modules[h]["sites"].append(
                    (s, sb["idx"], sb["off"], sb["dlen"], sb["ulen"], sb["flags"])
                )
                continue

            img = raw
            if sb["flags"] == FLAG_LZS:
                try:
                    img = lzss_uncompress(raw, expected_size=sb["ulen"])
                except Exception:
                    continue

            tb = locate_text_blocks(img)
            tids = [t[2] for t in tb if t[2] in TARGET_IDS]
            if tids:
                distinct_modules[h] = {
                    "raw": raw,
                    "img": bytearray(img),
                    "dlen": sb["dlen"],
                    "ulen": sb["ulen"],
                    "flags": sb["flags"],
                    "tb": tb,
                    "tids": tids,
                    "sites": [(s, sb["idx"], sb["off"], sb["dlen"], sb["ulen"], sb["flags"])],
                }

    total_sites = sum(len(m["sites"]) for m in distinct_modules.values())
    print(f"  Found {len(distinct_modules)} distinct type-46 images across {total_sites} occurrence sites.")

    # 4b. RC-2 (B9): synthesize master EN blocks for MODULE-BOURNE ids.
    # 0x047D (church/priest, 291 seqs) exists ONLY inside compressed type-46
    # modules -- no linear copy exists on disc, so STEP 1 can never see it and
    # the find_block_anywhere scan above always misses it ("embedded copies
    # stay JP"). Synthesize the master EN block from the FIRST pristine
    # module occurrence + the canonical corpus, register its omap so the
    # graft/remap/recompress flow below handles it like any other lane.
    corpus_path = args.corpus
    corpus = {}
    if os.path.exists(corpus_path):
        with open(corpus_path, encoding="utf-8") as f:
            corpus = json.load(f)
    else:
        print(f"  [WARN] corpus not found at {corpus_path} -- synthesis skipped")
    synthesized = []
    synth_ids = set(args.synthesize_ids)
    for bid in sorted(TARGET_IDS):
        if bid in master_blocks or bid not in synth_ids:
            continue
        blk_corpus = corpus.get("%04x" % bid)
        if not isinstance(blk_corpus, dict) or not blk_corpus:
            continue
        src_mod = src_t = None
        for mh, mod in distinct_modules.items():
            if bid not in mod["tids"]:
                continue
            for t in mod["tb"]:
                if t[2] == bid:
                    src_mod, src_t = mod, t
                    break
            if src_t:
                break
        if src_t is None:
            continue
        o, a, tid = src_t[0], src_t[1], src_t[2]
        orig_blk = bytes(src_mod["img"][o:o + a])
        block_dict = {"offset": o, "end": a, "hts": src_t[3],
                      "text_end": src_t[5], "tree_end": src_t[4],
                      "block_id": tid}
        patched, info = P.patch_block(bytes(src_mod["img"]), block_dict,
                                      blk_corpus, SC, fullwidth=False,
                                      paginate=False)
        if patched is None:
            print(f"  Block 0x{bid:04X}: synthesis FAILED ({info.get('reason')}) -- skipped")
            continue
        if len(patched) != a:
            print(f"  Block 0x{bid:04X}: synthesis size {len(patched)} != {a} -- skipped")
            continue
        # register the omap (same structures build_omaps produces)
        try:
            p_hts, p_n, p_offs = POR.parse_block_pristine(orig_blk, bid)
            m_hts, m_n, m_offs = POR.parse_block_master(bytes(patched), bid)
        except Exception as e:
            print(f"  Block 0x{bid:04X}: omap build failed ({e}) -- skipped")
            continue
        if m_n > p_n:
            m_offs = m_offs[:p_n]
            m_n = p_n
        elif p_n > m_n:
            # F2-fold prefix-bind: the EN re-encode may drop artifact tail
            # seqs; bind only the prefix, and only when the unbound pristine
            # tail is small and artifact-like (empty / punctuation / controls).
            bindable = p_n - m_n <= 2
            if bindable:
                try:
                    sc_t = DQ4Schema()
                    ts, tmid, nn = struct.unpack_from("<IIH", orig_blk, src_t[5])
                    tree = sc_t.parse_tree(orig_blk[ts:ts + 4 * nn + 6])
                    leaves = sc_t.decode(orig_blk[src_t[3]:src_t[5]], tree)
                    texts, _res = PH.split_strings(
                        [s for s in tree.decode()])
                    for extra in texts[m_n:] + [_res] if _res else texts[m_n:]:
                        vis = re.sub(r"<[0-9A-Fa-f]{4}>|\{[0-9A-Fa-f]{4}\}|<END>",
                                     "", PH.render(extra)).strip().strip("\u3000")
                        if vis not in ("", "!", "\uff01"):
                            bindable = False
                            break
                except Exception:
                    bindable = False
            if not bindable:
                print(f"  Block 0x{bid:04X}: seq drift {p_n}!={m_n} (tail not artifact) -- skipped")
                continue
            p_offs = p_offs[:m_n]
            p_n = m_n
        omaps[bid] = {p_offs[i]: m_offs[i] for i in range(p_n)
                      if p_offs[i] != m_offs[i]}
        hts_by[bid] = p_hts
        pos_by[bid] = {p_offs[i]: i for i in range(p_n)}
        seq_count_by[bid] = p_n
        target_luis.add(bid << 4)
        target_luis.add((bid << 4) + 1)
        master_blocks[bid] = bytes(patched)
        synthesized.append(bid)
        print(f"  Block 0x{bid:04X}: SYNTHESIZED master EN ({p_n} seqs, "
              f"omaps {len(omaps[bid])} shifted) from module "
              f"{src_mod['sites'][0][0] if src_mod['sites'] else '?'}")
    if synthesized:
        print(f"  Synthesized module-borne masters: "
              + ", ".join("0x%04X" % b for b in synthesized))

    # 5. Process each distinct module: patch text -> remap refs -> recompress
    print("\n5) Patching, remapping, and recompressing distinct modules...")
    patched_images = {}  # hash -> recompressed_bytes (exactly dlen bytes)
    total_direct_remaps = 0
    total_split_remaps = 0
    max_margin = 0

    idx = 0
    for h, mod in sorted(
        distinct_modules.items(),
        key=lambda kv: (-len(kv[1]["sites"]), kv[1]["dlen"]),
    ):
        idx += 1
        img = bytearray(mod["img"])
        orig_dlen = mod["dlen"]
        flags = mod["flags"]
        tb = mod["tb"]
        tids_present = mod["tids"]

        # A. Patch target text blocks (deterministic, identical every rung)
        protected_ranges = []
        textpatched = bytearray(mod["img"])
        for t in tb:
            o, a, tid = t[0], t[1], t[2]
            protected_ranges.append((o, o + a))
            if tid in master_blocks:
                m_bytes = master_blocks[tid]
                if len(m_bytes) != a:
                    raise RuntimeError(
                        f"[FAIL] Block 0x{tid:04X} size mismatch: master={len(m_bytes)}, overlay={a}"
                    )
                textpatched[o : o + a] = m_bytes

        def is_protected(pos, length=4):
            for p_start, p_end in protected_ranges:
                if not (pos + length <= p_start or pos >= p_end):
                    return True
            return False

        # B-2. Remap DIRECT 32-bit packed referrer words outside text blocks.
        # Surgical, replacing the blanket "section B" that corrupted ~1,100
        # instructions in the 0x047C inn module (inn-exit crash). A word is
        # remapped ONLY when ALL of the following hold:
        #   (a) w>>20 is a target id and (w&0xFFFFF) - hts*8 resolves to a
        #       PRISTINE sequence start of that block;
        #   (b) 1-bit-shift noise control: flipping any of the low 20 bits
        #       must NOT still resolve (random instruction collisions usually
        #       still pass this, so it is necessary, not sufficient);
        #   (c) TABLE CONTEXT: 2+ referrer-shaped neighbours at +-4/+-8 (dense
        #       tables) or +-44 (strided 44-byte record tables -- the battle
        #       module's message-pointer layout, mine_battle_18). Executed
        #       MIPS streams do not carry referrer-shaped neighbours.
        #   (d) outside every embedded text block (is_protected).
        # LADDER: the remapped image must still fit its LZS slot. If the full
        # context set overflows, fall back to the dense-only set (the set that
        # provably fit in the REBUILD #2 first pass); if even that overflows,
        # fall back to no direct remaps; if THAT overflows the gate aborts the
        # build as before. Fallen-back modules are logged so the remaining
        # stale words stay visible.
        starts_by = {}
        for bid in omaps:
            starts_by[bid] = set(pos_by[bid].keys())
        pristine = bytes(mod["img"])  # immutable view for neighbor/context reads

        def resolves(bid, rel):
            return rel in starts_by.get(bid, ())

        def _boundary_ok(o, bid):
            """Lane 2 (Sep-06): a +-44 neighbour slot is a valid RECORD BOUNDARY
            when it is zero or a referrer-shaped word of a known target block."""
            for no in (o - 44, o + 44):
                if no < 0 or no + 4 > len(pristine) or is_protected(no, 4):
                    return False
                nw = struct.unpack_from("<I", pristine, no)[0]
                if nw == 0:
                    continue
                nb = nw >> 20
                if nb not in omaps:
                    return False
                nrel = (nw & 0xFFFFF) - hts_by[nb] * 8
                if not resolves(nb, nrel):
                    return False
            return True

        def remap_direct(context_offsets):
            """Filtered direct-word remap over the pristine image.
            Returns (work, remapped, skipped). Skipped words are classified
            into DIRSKIP_KINDS for the Lane 2 closure report."""
            work = bytearray(pristine)
            remapped = skipped = 0
            for o in range(0, len(work) - 3, 4):
                if is_protected(o, 4):
                    continue
                w = struct.unpack_from("<I", pristine, o)[0]
                bid = w >> 20
                if bid not in omaps:
                    continue
                rel = (w & 0xFFFFF) - hts_by[bid] * 8
                if not resolves(bid, rel):
                    continue
                # Lane A.2 (Sep-06): TABLE CONTEXT FIRST for the battle module.
                # The 1-bit-shift noise test has a ~5% false-positive rate inside
                # 0x048B's packed pointer bands (817 seq starts in 84k bits: some
                # single bit-flip of a GENUINE word lands on a neighbouring start).
                # It silently killed 75 genuine 0x048B referrers per module copy --
                # 64 of the 68 RAM-proven stale words behind the "takes N damage"
                # freeze (study/mine_battle_43/44: all byte-for-byte stale on the
                # sealed master). A word with resolving table-mates at +-4/+-8
                # (dense) or +-12/+-16/+-44 (record strides observed in the battle
                # module) is a table entry by construction, so for bid 0x048B --
                # and ONLY inside a module that carries the 0x048B text block (the
                # battle module; all 68 proven-stale words live there) -- the noise
                # guard now runs ONLY on the context-fail path. Every other block
                # and every other module keeps the original order (noise first, no
                # 12/16 strides): the inn/shop modules behind the section-B inn
                # crash are byte-identical to the previous rung.
                relaxed = (bid == 0x048B and 0x048B in tids_present)
                nbr_dense = nbr_stride = 0
                for d in context_offsets:
                    if d in (12, 16, 24, 36) and not relaxed:
                        continue
                    for no in (o - d, o + d):
                        if no < 0 or no + 4 > len(pristine) or is_protected(no, 4):
                            continue
                        nw = struct.unpack_from("<I", pristine, no)[0]
                        nrel = (nw & 0xFFFFF) - hts_by[bid] * 8
                        if (nw >> 20) == bid and resolves(bid, nrel):
                            if d >= 12:
                                nbr_stride += 1
                            else:
                                nbr_dense += 1
                has_ctx = (nbr_stride >= 1 or nbr_dense >= 2)
                if not (relaxed and has_ctx):
                    noise = False
                    for b in range(20):
                        if resolves(bid, ((w & 0xFFFFF) ^ (1 << b)) - hts_by[bid] * 8):
                            noise = True
                            break
                    if noise:
                        skipped += 1
                        DIRSKIP_KINDS["noise"] += 1
                        continue
                # Strided 44-byte record tables (the battle message-pointer layout,
                # mine_battle_18): a SINGLE genuine table-mate qualifies -- edge
                # entries of the table have only one neighbour, which left ~41 stale
                # stragglers = the residual battle-message garble on REBUILD #2
                # ("ライアン attacks!" ok, next line salad). Dense +-4/+-8 tables keep
                # the stricter 2-neighbour rule, so the inn/shop modules behind the
                # section-B inn crash are UNCHANGED. The per-word 1-bit-shift noise
                # control remains the primary false-positive guard for every block
                # except 0x048B, where it applies only to context-fails (see above).
                if not has_ctx:
                    # Lane 2 narrow catch: an ISOLATED pointer that still passed
                    # the 1-bit-shift noise control, whose +-44 slots on BOTH
                    # sides are valid 44-byte record boundaries (zero or another
                    # block's resolving referrer). This is the battle module's
                    # single-entry table edge; code streams never sit between
                    # two such boundaries. Never a blanket remap.
                    if not REMAP_USE_BOUNDARY or not _boundary_ok(o, bid):
                        skipped += 1
                        DIRSKIP_KINDS["context"] += 1
                        DIRSKIP_RECORDS.append({
                            "off": o, "word": "0x%08X" % w, "bid": "0x%04X" % bid,
                            "rel": rel,
                        })
                        continue
                    DIRSKIP_KINDS["boundary_caught"] += 1
                new_val = resolve_val(w)
                if new_val is None or new_val == w:
                    continue
                struct.pack_into("<I", work, o, new_val)
                remapped += 1
            return work, remapped, skipped

        # Ladder rungs: (context offsets, label). None = no direct remaps.
        # 'full-noboundary' = proven REBUILD#2/F19823DB behavior (context-only,
        # Lane 2 boundary catch disabled) -- protects tight 0x047C slots from
        # overflowing just because the boundary rule added remaps.
        if flags == FLAG_LZS:
            ladder = (((4, 8, 12, 16, 24, 36, 44), "full"), ((4, 8, 12, 16, 24, 36, 44), "full-noboundary"),
                      ((4, 8), "dense"), (None, "none"))
        else:
            ladder = (((4, 8, 12, 16, 24, 36, 44), "full"), ((4, 8, 12, 16, 24, 36, 44), "full-noboundary"))

        last_err = None
        _snap = dict(DIRSKIP_KINDS)
        _nrec = len(DIRSKIP_RECORDS)
        for context_offsets, rung in ladder:
            img = bytearray(textpatched)
            if context_offsets is None:
                mod_direct = 0
                mod_direct_skipped = 0
            else:
                _b_save = DIRSKIP_KINDS["boundary_caught"]
                use_boundary = (rung != "full-noboundary")
                _save_flag = REMAP_USE_BOUNDARY
                REMAP_USE_BOUNDARY = use_boundary
                work, mod_direct, mod_direct_skipped = remap_direct(context_offsets)
                REMAP_USE_BOUNDARY = _save_flag
                for o in range(0, len(img) - 3, 4):
                    if is_protected(o, 4):
                        continue
                    if struct.unpack_from("<I", work, o)[0] != \
                       struct.unpack_from("<I", img, o)[0]:
                        struct.pack_into("<I", img, o, struct.unpack_from("<I", work, o)[0])

            # C. Remap split-immediate pairs outside text blocks
            mod_split = 0
            pairs = scan_split_pairs(img, resolve_val, target_luis, window=32)
            for sh in pairs:
                lui_off, lo_off, op, old_val, new_val = sh
                if is_protected(lui_off, 4) or is_protected(lo_off, 4):
                    continue
                hi_val, lo_val = halves(new_val, op)
                lui_w = struct.unpack_from("<I", img, lui_off)[0]
                lo_w = struct.unpack_from("<I", img, lo_off)[0]
                new_lui = (lui_w & 0xFFFF0000) | (hi_val & 0xFFFF)
                new_lo = (lo_w & 0xFFFF0000) | (lo_val & 0xFFFF)
                struct.pack_into("<I", img, lui_off, new_lui)
                struct.pack_into("<I", img, lo_off, new_lo)
                mod_split += 1

            total_direct_remaps += mod_direct * len(mod["sites"])
            total_split_remaps += mod_split * len(mod["sites"])

            # D. Recompress into the slot with NO zero padding. The DQ4 LZS
            # decoder reads flag bytes until the input (dlen) is exhausted, so
            # trailing 0x00 padding is decoded as extra tokens -> real bytes
            # written PAST ulen (measured +3..+4764 -> the church-exit RAM
            # clobber). compress_to_slot fills the slot with a VALID stream
            # that decodes to img (+<=3 filler), so the whole slot decodes
            # cleanly with no runaway overrun.
            if flags != FLAG_LZS:
                rec_len = len(img)
                if rec_len > orig_dlen:
                    raise RuntimeError(
                        f"[FAIL] Uncompressed overlay overflow: {rec_len} > {orig_dlen} budget!"
                    )
                margin = orig_dlen - rec_len
                rec_padded = bytes(img) + b"\x00" * margin
                overrun = 0
                break
            img_bytes = bytes(img)
            try:
                rec_padded = compress_to_slot(img_bytes, orig_dlen, max_slack=3)
            except ValueError as e:
                last_err = e
                # Lane A.2 hard gate: the battle module's name/message pointer
                # tables are only complete on the 'full' rung (12/16/24/36/44
                # strides). Descending to 'dense'/'none' would silently
                # re-stale them and bring back the "takes N damage" freeze as
                # a mere [NOTE]. Fail loudly instead; a human shortens 0x048B
                # text or widens the slot.
                if 0x048B in tids_present:
                    raise RuntimeError(
                        f"[FAIL] battle module (0x048B) does not fit its LZS slot "
                        f"{orig_dlen} on rung '{rung}' ({e}); refusing to descend "
                        f"the ladder (Lane A.2 freeze gate)"
                    )
                print(
                    f"  [FALLBACK] module slot {orig_dlen} overflow with context "
                    f"rung '{rung}' ({e}); descending ladder"
                )
                continue
            # GATE (RadMage gate-20): the whole slot must decode to img plus at
            # most +3 (pristine overrun parity), never a real +N runaway. A
            # gate failure ABORTS the build -- it is exactly the church-clobber
            # defect.
            dec = lzss_uncompress(rec_padded, expected_size=len(img_bytes) + 8)
            overrun = len(dec) - len(img_bytes)
            if dec[:len(img_bytes)] != img_bytes or not (0 <= overrun <= 3):
                tids_dbg = ",".join(f"0x{x:04X}" for x in sorted(set(tids_present)))
                raise RuntimeError(
                    f"[FAIL] LZS slot-fill gate: TIDs [{tids_dbg}] slot={orig_dlen} "
                    f"overrun={overrun} content_ok={dec[:len(img_bytes)] == img_bytes}"
                )
            rec_len = orig_dlen
            margin = overrun
            max_margin = max(max_margin, margin)
            break
        else:
            raise RuntimeError(
                f"[FAIL] Overlay module overflow for slot {orig_dlen}: {last_err}"
            )
        if rung != "full":
            tids_dbg = ",".join(f"0x{x:04X}" for x in sorted(set(tids_present)))
            print(
                f"  [NOTE] module slot {orig_dlen} TIDs [{tids_dbg}] shipped with "
                f"direct-remap rung '{rung}' -- some referrer words may remain stale"
            )
        # keep only the ACCEPTED rung's contribution in the Lane 2 counters
        for _k in DIRSKIP_KINDS:
            DIRSKIP_KINDS[_k] -= _snap[_k]
        del DIRSKIP_RECORDS[:_nrec]

        patched_images[h] = rec_padded
        tids_str = ",".join(f"0x{x:04X}" for x in sorted(set(tids_present)))
        if idx <= 10 or idx % 10 == 0 or idx == len(distinct_modules):
            print(
                f"  [{idx:02d}/{len(distinct_modules):02d}] TIDs [{tids_str}] "
                f"sites={len(mod['sites']):2d} dlen={orig_dlen} rec={rec_len} "
                f"(margin=+{margin}B) rung={rung} dir={mod_direct} "
                f"dirskip={mod_direct_skipped} split={mod_split}"
            )

    print(
        f"\n  All {len(distinct_modules)} distinct modules fit within budget! "
        f"(max margin: +{max_margin} bytes)"
    )
    print(f"  Total direct referrers remapped across sites: {total_direct_remaps}")
    print(f"  Total split referrers remapped across sites:  {total_split_remaps}")

    # 6. Write patched modules back to disc at all occurrence sites
    if args.report:
        print("\n[REPORT MODE] No bytes written to disc.")
    else:
        print(f"\n6) Writing {total_sites} patched overlay module sites to disc...")
        with open(args.disc, "r+b") as f_disc:
            for h, mod in distinct_modules.items():
                data = patched_images[h]
                for s, sb_idx, off, dlen, ulen, flags in mod["sites"]:
                    write_disc_user_data(f_disc, off, data)

        print("  Successfully written all occurrence sites to disc!")
        print("  NOTE: Run edcre (STEP 5) after this pass to recalculate EDC/ECC.")

    elapsed = time.time() - t0
    print(f"\nDone in {elapsed:.1f}s.")

    # Lane 2 dirskip closure report
    print("\n  DIRSKIP classification: noise=%d boundary_caught=%d residual_context=%d"
          % (DIRSKIP_KINDS["noise"], DIRSKIP_KINDS["boundary_caught"],
             DIRSKIP_KINDS["context"]))
    try:
        import json as _json
        rep = os.path.join(os.path.dirname(os.path.abspath(__file__)),
                           os.pardir, "build", "dirskip_report.json")
        with open(rep, "w", encoding="utf-8") as _f:
            _json.dump({"kinds": DIRSKIP_KINDS, "records": DIRSKIP_RECORDS}, _f, indent=1)
        print("  report -> build/dirskip_report.json")
    except Exception as _e:
        print("  (report write failed: %s)" % _e)
    return 0


if __name__ == "__main__":
    sys.exit(main())
