#!/usr/bin/env python3
"""patch_exe_blocks.py — FINALIZATION BLUEPRINT LANE B (STEP 1e).

Patch the EXE-resident church/system text block 0x048F (SLPM_869.16,
LBA 24-361) inside the sealed master disc. Same-size (EXE cannot grow),
END-fill padding (Q7), GTE-safe surgical referrer remap, master-EXE rebase
(never pristine), EDC/ECC regeneration for the EXE LBAs.

Gates (all must pass, else ABORT exit 1):
  G1  block header located: id=0x048F end=7440 hts=648 txe=5820
  G2  patch_block success (same-size, round-trip verified internally)
  G3  decoded 0x048F == corpus per-seq controls + visible text, 0 JP
  G4  referrer remaps: every rewrite passes resolve+noise+context filters
  G5  all untouched bytes identical to the master EXE (prior lane deltas preserved)
  G6  EXE written back per-sector; EDC/ECC regenerated (LBA 24-361)

Usage:
  python patch_exe_blocks.py --disc build/dq4_sovereign_master.bin [--corpus translation/full_translation_boot_with_0069.json]
"""
import argparse
import hashlib
import json
import os
import re
import struct
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

import dq4_hbd_patcher as P
from hbe.huffman.dq4 import DQ4Schema

RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA, EXE_SECTORS = 24, 338          # SLPM_869.16;1  (692,224 B)
EXE_SIZE = EXE_SECTORS * USZ
BLOCK_048F_OFF = 0x99624                # verified (mine_battle_37 / ship-gate report)
BLOCK_048C_OFF, BLOCK_048C_SIZE = 0x97AC8, 6796
BLOCK_048D_OFF, BLOCK_048D_SIZE = 0x9955C, 192
BLOCK_ID = 0x048F
EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")

SCHEMA = DQ4Schema()
CTRL = re.compile(r"\{[0-9A-Fa-f]{4}\}")
DIRSKIP = {"noise": 0, "context": 0, "protected": 0, "not_start": 0}


def is_jp(ch):
    return 0x3040 <= ord(ch) <= 0x30FF or 0x4E00 <= ord(ch) <= 0x9FFF


def sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1 << 20), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def read_exe(disc_path):
    with open(disc_path, "rb") as f:
        exe = bytearray()
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            exe.extend(f.read(USZ))
    return exe[:EXE_SIZE]


def locate_048f(exe):
    a, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe, BLOCK_048F_OFF)
    assert (bid & 0xFFFF) == BLOCK_ID, "G1 FAIL: id=0x%04X at 0x%X" % (bid & 0xFFFF, BLOCK_048F_OFF)
    # end/hts are engine-locked; txe varies — STEP 4g re-encodes 048F against
    # the corpus (337 -> 536 strings, txe 5820 -> 6820), so accept the sane
    # range instead of a pinned snapshot value on pipeline re-runs.
    assert a == 7440 and hts == 648, "G1 FAIL: end=%d hts=%d" % (a, hts)
    assert hts < txe < a, "G1 FAIL: txe=%d out of range (%d..%d)" % (txe, hts, a)
    assert struct.unpack_from("<I", exe, BLOCK_048F_OFF + a)[0] == a, "G1 FAIL: size echo"
    return {
        "offset": BLOCK_048F_OFF, "end": a, "hts": hts, "text_end": txe,
        "tree_end": te, "block_id": bid & 0xFFFF,
    }


def decode_block(exe, blk):
    off, hts = blk["offset"], blk["hts"]
    buf = bytes(exe)
    end, bid, hts2, te2, txe, unk = struct.unpack_from("<6I", buf, off)
    ts, tmid, nn = struct.unpack_from("<IIH", buf, off + txe)
    tree = SCHEMA.parse_tree(buf[off + ts:off + ts + 4 * nn + 6])
    leaves = SCHEMA.decode(buf[off + hts:off + txe], tree)
    return P.leaves_to_text(leaves)


def build_offset_maps(orig_leaves, new_leaves, new_tree, orig_tree):
    old = P.compute_sequence_bit_offsets(orig_leaves, orig_tree)
    new = P.compute_sequence_bit_offsets(new_leaves, new_tree)
    if len(old) > len(new) and len(old) - len(new) <= 8:
        # STEP 3's Q7 end-fill pad lives inside the code-stream region and
        # decodes as one trailing junk seq under the final tree ('aaaat ot
        # ot...' with FE01 markers). It is fill, never referenced by any
        # referrer, so drop it from the map instead of failing G4.
        import re as _re
        seqs_txt, cur = [], []
        for lf in orig_leaves:
            cur.append(lf)
            if ((lf.content[0] << 8) | lf.content[1]) == 0x0000:
                seqs_txt.append(P.leaves_to_text(cur))
                cur = []
        if cur:
            seqs_txt.append(P.leaves_to_text(cur))
        dropped = 0
        while len(old) > len(new) and seqs_txt:
            clean = _re.sub(r"\{[0-9A-Fa-f]{4}\}", "", seqs_txt[-1])
            if not (clean and set(clean) <= set("\uff41\uff4f\uff54")):
                break
            seqs_txt.pop()
            old = old[:-1]
            dropped += 1
        if dropped:
            print("  G4: dropped %d trailing end-fill pad seqs (%d vs %d)"
                  % (dropped, len(old) + dropped, len(new)))
    assert len(old) == len(new), "G4 FAIL: seq count mismatch %d vs %d" % (len(old), len(new))
    pos_by = {}
    omap = {}
    for (oi, oo), (ni, no) in zip(old, new):
        pos_by[oo] = oi
        omap[oo] = no
    return omap, pos_by


def boundary_ok(exe, o, protected):
    for no in (o - 44, o + 44):
        if no < 0 or no + 4 > len(exe):
            return False
        if any(not (no + 4 <= s or no >= e) for s, e in protected):
            return False
        nw = struct.unpack_from("<I", exe, no)[0]
        if nw == 0:
            continue
        if (nw >> 20) != BLOCK_ID:
            return False
    return True


def remap_direct_words(exe, pristine, omap, pos_by, hts, protected):
    """GTE-safe surgical remap of direct 0x48F words across the EXE."""
    starts = set(pos_by.keys())
    work = bytearray(exe)
    remapped = []
    for o in range(0, len(work) - 3, 4):
        if any(not (o + 4 <= s or o >= e) for s, e in protected):
            DIRSKIP["protected"] += 1
            continue
        w = struct.unpack_from("<I", pristine, o)[0]
        if (w >> 20) != BLOCK_ID:
            continue
        rel = (w & 0xFFFFF) - hts * 8
        if rel not in starts:
            DIRSKIP["not_start"] += 1
            continue
        noise = False
        for b in range(20):
            if (((w & 0xFFFFF) ^ (1 << b)) - hts * 8) in starts:
                noise = True
                break
        if noise:
            DIRSKIP["noise"] += 1
            continue
        nbr_dense = nbr_stride = 0
        for d in (4, 8, 44):
            for no in (o - d, o + d):
                if no < 0 or no + 4 > len(pristine):
                    continue
                if any(not (no + 4 <= s or no >= e) for s, e in protected):
                    continue
                nw = struct.unpack_from("<I", pristine, no)[0]
                if (nw >> 20) == BLOCK_ID and ((nw & 0xFFFFF) - hts * 8) in starts:
                    if d >= 44:
                        nbr_stride += 1
                    else:
                        nbr_dense += 1
        if nbr_stride < 1 and nbr_dense < 2:
            if not boundary_ok(pristine, o, protected):
                DIRSKIP["context"] += 1
                continue
        nbit = omap.get(rel)
        if nbit is None:
            DIRSKIP["not_start"] += 1
            continue
        new_w = (BLOCK_ID << 20) | (nbit + hts * 8)
        if new_w == w:
            continue
        struct.pack_into("<I", work, o, new_w)
        remapped.append((o, "0x%08X" % w, "0x%08X" % new_w))
    return work, remapped


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", required=True)
    ap.add_argument("--corpus", default=os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json"))
    ap.add_argument("--no-edc", action="store_true")
    args = ap.parse_args()

    print("== STEP 1e: EXE block 0x048F (church/system) ==")
    corpus = json.load(open(args.corpus, encoding="utf-8"))
    assert "048f" in corpus, "corpus lacks 048f"
    seqs = {k: {"translation": v["en"]} for k, v in corpus["048f"].items()}
    print("  corpus 048f: %d seqs" % len(seqs))

    exe = read_exe(args.disc)
    print("  master EXE: %d B (LBA %d..%d)" % (len(exe), EXE_LBA, EXE_LBA + EXE_SECTORS - 1))

    blk = locate_048f(exe)
    print("  G1 PASS: 0x048F @exe+0x%X end=%d hts=%d txe=%d" %
          (blk["offset"], blk["end"], blk["hts"], blk["text_end"]))

    # original leaves + tree
    orig_text = exe[blk["offset"] + blk["hts"]:blk["offset"] + blk["text_end"]]
    te = blk["tree_end"] if blk["tree_end"] else blk["end"]
    ts, tmid, nn = struct.unpack_from("<IIH", exe, blk["offset"] + blk["text_end"])
    orig_tree_bytes = bytes(exe[blk["offset"] + ts:blk["offset"] + ts + 4 * nn + 6])
    orig_tree = SCHEMA.parse_tree(orig_tree_bytes)
    orig_leaves = SCHEMA.decode(orig_text, orig_tree)

    # patch (reuses the HBD lane encoder: same-size, END-fill, retry ladder)
    # NOTE: fullwidth=True was tested (Sep 08) and REJECTED — the hbe tree
    # writer cannot store 0x82xx (roundtrip_failed: parse out of bounds), and
    # pristine 048C strings are stored stripped yet render correctly through
    # Font-1, proving the engine ORs 0x8000. Code family is NOT the garble.
    patched, info = P.patch_block(bytes(exe), dict(blk), seqs, SCHEMA, paginate=False)
    if patched is None:
        print("  G2 FAIL: patch_block skipped: %s" % info)
        raise SystemExit(1)
    assert len(patched) == blk["end"] + 4, "G2 FAIL: size %d != %d plus echo" % (len(patched), blk["end"])
    print("  G2 PASS: %s" % {k: info[k] for k in ("seq_count", "num_branches")})

    # decode patched and gate on corpus parity + 0 JP
    work = bytearray(exe)
    work[blk["offset"]:blk["offset"] + blk["end"] + 4] = patched
    ptext = decode_block(work, blk)
    jp = sum(1 for c in ptext if is_jp(c))
    assert jp == 0, "G3 FAIL: %d JP chars in decoded 0x048F" % jp
    pseqs = ptext.split("{0000}")
    assert len(pseqs) >= len(seqs), "G3 FAIL: %d seqs < %d" % (len(pseqs), len(seqs))
    mismatched = []
    import unicodedata

    def norm(s):
        s = unicodedata.normalize("NFKC", s).replace("\u2010", "-").replace("\u2019", "")
        return CTRL.sub("", s).replace(" ", "").lower()

    # expected text = exactly what patch_block encoded (normalized seqs + paginate)
    expected = "".join(corpus["048f"][k]["en"].replace("{0000}", "") + "{0000}"
                       for k in sorted(corpus["048f"], key=int))
    expected = expected  # F5 fold: 048F encodes unpaginated (pristine break skeleton)
    eseqs = expected.split("{0000}")
    for k, v in corpus["048f"].items():
        i = int(k) - 1
        if i >= len(pseqs) or i >= len(eseqs):
            mismatched.append((k, "missing"))
            continue
        got, want = pseqs[i], eseqs[i]
        # no token may be lost by encoding; pagination may only add breaks
        gc = [c.upper() for c in CTRL.findall(got)]
        wc = [c.upper() for c in CTRL.findall(want)]
        if [c for c in wc if c not in gc]:
            mismatched.append((k, "lost tokens " + str([c for c in wc if c not in gc])))
        elif norm(got) != norm(want):
            mismatched.append((k, got[:50]))
    assert not mismatched, "G3 FAIL: %d seqs differ, e.g. %s" % (len(mismatched), mismatched[:5])
    print("  G3 PASS: 0 JP, %d seqs == corpus" % len(pseqs))

    # referrer remap (surgical, GTE-safe)
    text_end_new = struct.unpack_from("<I", patched, 16)[0]
    new_tree = SCHEMA.parse_tree(patched[text_end_new + 10:blk["end"]])
    new_leaves = P.text_to_leaves(expected, fullwidth=False)  # view must match the encoded (stripped) tree
    omap, pos_by = build_offset_maps(orig_leaves, new_leaves, new_tree, orig_tree)
    protected = [
        (BLOCK_048C_OFF, BLOCK_048C_OFF + BLOCK_048C_SIZE),
        (BLOCK_048D_OFF, BLOCK_048D_OFF + BLOCK_048D_SIZE),
        (blk["offset"], blk["offset"] + blk["end"] + 4),
    ]
    work, remapped = remap_direct_words(work, bytes(exe), omap, pos_by, blk["hts"], protected)
    print("  G4 PASS: %d direct words remapped | skipped: %s" % (len(remapped), DIRSKIP))

    # G5: untouched bytes identical to master EXE
    touched = set()
    for o in range(blk["offset"], blk["offset"] + blk["end"] + 4):
        touched.add(o)
    for (o, _a, _b) in remapped:
        for d in range(4):
            touched.add(o + d)
    drift = [o for o in range(len(exe)) if o not in touched and work[o] != exe[o]]
    assert not drift, "G5 FAIL: %d bytes drifted outside touched set, first 0x%X" % (len(drift), drift[0])
    print("  G5 PASS: %d touched bytes, 0 drift (prior lane deltas preserved)" % len(touched))

    # write back per-sector
    with open(args.disc, "r+b") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            f.write(bytes(work[i * USZ:(i + 1) * USZ]))
    print("  G6a PASS: EXE written back (LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))

    if not args.no_edc and os.path.exists(EDCRE):
        r = subprocess.run([EDCRE, args.disc], capture_output=True, text=True, timeout=600)
        ok = r.returncode == 0
        print("  G6b %s: edcre EDC/ECC (rc=%d)" % ("PASS" if ok else "FAIL", r.returncode))
        assert ok, "G6b FAIL: edcre rc=%d %s" % (r.returncode, r.stderr[-400:])
    else:
        print("  G6b SKIPPED (--no-edc or edcre missing)")

    report = {
        "step": "1e", "disc": args.disc, "disc_sha256_before": None,
        "block": "0x048F", "exe_offset": "0x%X" % blk["offset"],
        "seqs": len(seqs), "remapped_words": remapped, "dirskip": DIRSKIP,
    }
    os.makedirs(os.path.join(ROOT, "build"), exist_ok=True)
    with open(os.path.join(ROOT, "build", "step1e_report.json"), "w", encoding="utf-8") as f:
        json.dump(report, f, indent=1)
    print("== STEP 1e DONE: report -> build/step1e_report.json ==")


if __name__ == "__main__":
    main()
