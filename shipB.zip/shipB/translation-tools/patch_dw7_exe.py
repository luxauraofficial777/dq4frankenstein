#!/usr/bin/env python3
"""
patch_dw7_exe.py - Surgical EXE patcher for the DW7 engine transplant.

This tool directly modifies the DW7 executable in a PSX disc image so that it
can navigate a substituted HBD payload and bypasses the disc-swap integrity
trap.

Operations performed on the extracted DW7 EXE:
  1. LBA reference normalization: every hard-coded reference to the original
     DW7 HBD start sector is shifted to the new HBD start sector.
  2. HBD branch pointer remapping: absolute/relative pointer tables in the EXE
     data segment are rewritten for the new HBD layout.
  3. Disc-check bypass: the EXE routine that queries CD status and decides
     "wrong disc -> insert Disc 1" is patched to return Disc 1 (0x01).
  4. Optional hybrid tree re-linking.

Usage:
    python patch_dw7_exe.py <in_dw7_iso.bin> <out_iso.bin> [options]

Options:
    --hbd-lba N          New HBD start sector (default: 356 to avoid EXE overlap)
    --old-hbd-lba N      Original DW7 HBD sector (default: 354)
    --disc-check-sig HEX Hex signature of disc-check routine entry
    --hybrid-tree FILE   Append a hybrid tree and patch MIPS refs
"""
import struct
import os
import sys
import shutil
import subprocess
import argparse

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048
EXE_LBA = 24
EDCRE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\edcre\edcre-v1.1.0-windows-x86_64-static\edcre.exe"
CLEAN_DW7_EXE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\SLUSP012.06"


def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)


def write_sector_user(f, lba, data):
    f.seek(lba * SECTOR_SIZE)
    sector = bytearray(f.read(SECTOR_SIZE))
    sector[USER_OFFSET:USER_OFFSET + len(data)] = data
    f.seek(lba * SECTOR_SIZE)
    f.write(bytes(sector))


def write_raw_data(f, start_lba, data):
    offset = 0
    sector = start_lba
    while offset < len(data):
        chunk = data[offset:offset + USER_SIZE]
        if len(chunk) < USER_SIZE:
            chunk = chunk + b'\x00' * (USER_SIZE - len(chunk))
        write_sector_user(f, sector, chunk)
        offset += USER_SIZE
        sector += 1
    return sector - start_lba


def extract_exe(f):
    # Use the clean DW7 EXE file (translation/SLUSP012.06) as the source.
    # Extracting from the DW7D1.bin disc image produces an EXE body that crashes
    # during early init (PC=0x8008AF24), so the clean EXE is the only viable
    # base for surgical patching.
    if os.path.exists(CLEAN_DW7_EXE):
        with open(CLEAN_DW7_EXE, 'rb') as ef:
            return ef.read()
    # Fallback: extract from disc image
    f.seek(EXE_LBA * SECTOR_SIZE + USER_OFFSET)
    header = f.read(0x800)
    text_size = struct.unpack_from('<I', header, 0x1C)[0]
    exe_size = 0x800 + text_size
    f.seek(EXE_LBA * SECTOR_SIZE + USER_OFFSET)
    return f.read(exe_size)


def patch_lba_references(exe, old_lba, new_lba):
    """Patch 32-bit LE sector references from old_lba to new_lba."""
    data = bytearray(exe)
    patches = 0
    for off in range(0x800, len(data) - 3, 4):
        val = struct.unpack_from('<I', data, off)[0]
        if val == old_lba:
            struct.pack_into('<I', data, off, new_lba)
            patches += 1
    return bytes(data), patches


def patch_abs_pointer_table(exe, old_lba, new_lba):
    """
    Patch the absolute sector pointer table at EXE offset 0x4184.
    Each entry is 8 bytes: [sector (4B), RAM_address (4B)].
    When the HBD block moves by (new_lba - old_lba), shift every sector
    value in this table by the same delta.  RAM addresses must NOT change.
    """
    data = bytearray(exe)
    table_start = 0x4184
    table_end = 0x511C
    delta = new_lba - old_lba
    patches = 0
    for off in range(table_start, table_end, 8):
        sec = struct.unpack_from('<I', data, off)[0]
        ram = struct.unpack_from('<I', data, off + 4)[0]
        if sec == 0 and ram == 0:
            break
        # Only patch sectors that are plausibly inside the original HBD range
        # (folders start a bit after the HBD file start).
        if old_lba <= sec < 0x100000:
            struct.pack_into('<I', data, off, sec + delta)
            patches += 1
    return bytes(data), patches


def patch_sequential_sector_table(exe, old_lba, new_lba):
    """
    Patch the packed 16-bit sequential sector table found at EXE offset
    0xA39AA-0xA3A02 in the DW7 EXE.  The table stores consecutive sector
    numbers (350..370) as 16-bit values.  When the HBD is relocated by
    a delta, shift every value in that table by the same delta.
    """
    data = bytearray(exe)
    delta = new_lba - old_lba
    table_start = 0xA39AA
    table_end = 0xA3A02
    patches = 0
    for off in range(table_start, min(table_end, len(data) - 1), 2):
        val16 = struct.unpack_from('<H', data, off)[0]
        # Only shift values that look like they're in the HBD neighborhood
        # (original DW7 HBD starts at 354; preserve values outside 300-400).
        if 300 <= val16 <= 400:
            new_val = (val16 + delta) & 0xFFFF
            struct.pack_into('<H', data, off, new_val)
            patches += 1
    return bytes(data), patches


def patch_relative_sector_refs(exe, old_lba, new_lba):
    """
    DISABLED.  The previous broad remap (any 32-bit value in old_lba..
    old_lba+200000) corrupted non-sector data in the EXE and caused a
    crash at PC=0x8008AF24 during early init.

    A safe relative remap must operate only on the known pointer tables
    (ABS at 0x4184, REL at 0x511C) or on values that are proven to be
    sector numbers by surrounding disassembly context.
    """
    return exe, 0


def patch_mips_lui_addiu(exe, old_lui, old_addiu, new_lui, new_addiu):
    """Patch LUI/ADDIU pairs that form the old tree address."""
    data = bytearray(exe)
    patches = 0
    for i in range(0x800, len(data) - 3, 4):
        instr = struct.unpack_from("<I", data, i)[0]
        opcode = (instr >> 26) & 0x3F
        if opcode != 0x09:  # ADDIU
            continue
        imm = instr & 0xFFFF
        if imm != old_addiu:
            continue
        rs = (instr >> 21) & 0x1F
        for j in range(1, 17):
            prev_off = i - (j * 4)
            if prev_off < 0x800:
                break
            prev_instr = struct.unpack_from("<I", data, prev_off)[0]
            prev_op = (prev_instr >> 26) & 0x3F
            if prev_op != 0x0F:  # LUI
                continue
            prev_imm = prev_instr & 0xFFFF
            prev_rt = (prev_instr >> 16) & 0x1F
            if prev_imm == old_lui and prev_rt == rs:
                new_lui_instr = (prev_instr & 0xFFFF0000) | new_lui
                new_addiu_instr = (instr & 0xFFFF0000) | new_addiu
                struct.pack_into("<I", data, prev_off, new_lui_instr)
                struct.pack_into("<I", data, i, new_addiu_instr)
                patches += 1
                break
    return bytes(data), patches


def append_hybrid_tree(exe, tree_path):
    """Append hybrid tree to EXE and update text_size header."""
    with open(tree_path, 'rb') as f:
        tree = f.read()
    data = bytearray(exe)
    padding = (4 - (len(data) % 4)) % 4
    if padding:
        data += b'\x00' * padding
    data += tree
    sector_pad = (2048 - (len(data) % 2048)) % 2048
    if sector_pad:
        data += b'\x00' * sector_pad
    new_text_size = len(data) - 0x800
    struct.pack_into("<I", data, 0x1C, new_text_size)
    return bytes(data)


# Disc check bypass patches (from PROGRESS_Jul10_2026_348am.md)
# These are targeted MIPS patches at the exact addresses of the disc check routines.
DISC_CHECK_PATCHES = [
    # Patch 1: disc_check_force_success — RAM 0x80078FF4, EXE offset 0x610F4
    # Original: addiu $sp,-72; sw $s7,60($sp); addu $s7,$a0,$zero
    # Patch: li $v0, 1; jr $ra; nop  (function always returns 1)
    {'offset': 0x610F4, 'original': bytes.fromhex('B8FFBD27 3C00B7AF 21B88000'.replace(' ', '')),
     'patch': bytes.fromhex('01000224 0800E003 00000000'.replace(' ', '')),
     'desc': 'disc_check_force_success'},
    # Patch 2: cd_init_force_success — RAM 0x80078EA4, EXE offset 0x60FA4
    # Original: addiu $sp,-48; sw $s0,24($sp); addiu $s0,720
    # Patch: li $v0, 1; jr $ra; nop
    {'offset': 0x60FA4, 'original': bytes.fromhex('D0FFBD27 1800B0AF D0021024'.replace(' ', '')),
     'patch': bytes.fromhex('01000224 0800E003 00000000'.replace(' ', '')),
     'desc': 'cd_init_force_success'},
    # Patch 3: nop_timeout_check — RAM 0x800793A4, EXE offset 0x614A4
    # Original: blez $s0, 0x800793F8 (little-endian bytes: 14 00 00 1a)
    # Patch: nop
    {'offset': 0x614A4, 'original': bytes.fromhex('1400001a'),
     'patch': struct.pack('<I', 0x00000000),
     'desc': 'nop_timeout_check'},
    # Patch 4: nop_error_path — RAM 0x800793F8, EXE offset 0x614F8
    # Original: beq $v0, $zero, 0x80079380 (little-endian bytes: e1 ff 40 10)
    # Patch: nop
    {'offset': 0x614F8, 'original': bytes.fromhex('e1ff4010'),
     'patch': struct.pack('<I', 0x00000000),
     'desc': 'nop_error_path'},
    # NOTE: Patches 5 and 6 (nop_s1_check_caller1/2) were REMOVED.
    # They nop'd `beq $s1, $zero, skip_disc_change` which caused the code to
    # always call the disc-change handler at 0x800506CC, triggering the
    # 'Insert Disc 1' loop.
    # Patch 5 (NEW): neutralize_disc_change_handler — RAM 0x800506CC, EXE text offset 0x387CC
    # File offset = 0x387CC + 0x800 = 0x38FCC
    # Replaces first 3 instructions with jr $ra; nop; nop
    # This neutralizes ALL 8 call sites at once.
    {'offset': 0x387CC, 'original': bytes.fromhex('0f80023c240f428cd0ffbd27'),
     'patch': bytes.fromhex('0800e0030000000000000000'),
     'desc': 'neutralize_disc_change_handler'},
    # Patch 6: redirect_disc_trap_to_success — RAM 0x8008AF8C, EXE text offset 0x7308C
    # File offset = 0x7308C + 0x800 = 0x7388C
    # Redirects the infinite loop trap (j 0x8008AF8C) to the success path (j 0x8008AFA4).
    # Single-byte change: E3 → E9. The function still runs but can't trap.
    {'offset': 0x7308C, 'original': bytes.fromhex('e32b0208'),
     'patch': bytes.fromhex('e92b0208'),
     'desc': 'redirect_disc_trap_to_success'},
    # === TRI-GATE GRAFT (Metadata Graft — WinRAR Doctrine) ===
    # These patches override the archiver's disc-identity validation logic.
    # They convert conditional branches that check disc identity into
    # unconditional branches, forcing the archiver to always skip the
    # disc-change path and treat the hybrid HBD as trusted.
    # Graft A: Gate 1 — RAM 0x80079324, EXE text offset 0x61424
    # Original: bne $v0, $v1, 0x80079358 (branch if disc_id != 1)
    # Grafted:  beq $zero, $zero, 0x80079358 (always skip disc change)
    {'offset': 0x61424, 'original': bytes.fromhex('0b004314'),
     'patch': bytes.fromhex('0b000010'),
     'desc': 'graft_a_gate1_always_skip_disc_change'},
    # Graft B: Gate 3 — RAM 0x80079420, EXE text offset 0x61520
    # Original: bne $v0, $v1, 0x80079454 (branch if disc_id != 1)
    # Grafted:  beq $zero, $zero, 0x80079454 (always skip disc change)
    {'offset': 0x61520, 'original': bytes.fromhex('0b004314'),
     'patch': bytes.fromhex('0b000010'),
     'desc': 'graft_b_gate3_always_skip_disc_change'},
    # Graft C: String comparison — RAM 0x80079260, EXE text offset 0x61360
    # Original: beq $v1, $v0, 0x80079290 (branch if bytes match)
    # Grafted:  beq $zero, $zero, 0x80079290 (always match)
    {'offset': 0x61360, 'original': bytes.fromhex('0a006210'),
     'patch': bytes.fromhex('0a000010'),
     'desc': 'graft_c_string_compare_always_match'},
]


def patch_disc_check(exe):
    """
    Apply targeted disc-check bypass patches at the 6 known addresses.
    These force the disc verification and CD init functions to always
    return success (0x01), preventing the 'Insert Disc 1' stall.
    """
    data = bytearray(exe)
    patches = 0
    for p in DISC_CHECK_PATCHES:
        off = p['offset'] + 0x800  # Convert text offset to file offset
        if off + len(p['patch']) > len(data):
            print(f"    WARNING: patch '{p['desc']}' at offset 0x{off:X} exceeds EXE size")
            continue
        original = bytes(data[off:off + len(p['original'])])
        if original != p['original']:
            print(f"    WARNING: patch '{p['desc']}' original mismatch at 0x{off:X}")
            print(f"      Expected: {p['original'].hex()}")
            print(f"      Got:      {original.hex()}")
            # Apply anyway — the EXE might have been modified by a prior patch
        data[off:off + len(p['patch'])] = p['patch']
        patches += 1
        print(f"    Applied: {p['desc']} at EXE offset 0x{p['offset']:05X} (file 0x{off:05X})")
    return bytes(data), patches


def patch_hbd_filename(exe, new_name=b'hbd1ps1d.q41'):
    """
    Patch the HBD filename string in the DW7 EXE.
    DW7 checks for 'hbd1ps1d.w71' at RAM 0x80026D00 (file offset 0x0F600).
    Change it to match the DQ4 HBD filename so the EXE finds the right file.
    """
    data = bytearray(exe)
    old_name = b'hbd1ps1d.w71'
    old_name2 = b'hbd1ps1d.w72'
    patches = 0

    for name, replacement in [(old_name, new_name), (old_name2, new_name.replace(b'q41', b'q42'))]:
        idx = data.find(name)
        while idx != -1:
            # Pad with nulls if replacement is shorter
            padded = replacement + b'\x00' * (len(name) - len(replacement))
            data[idx:idx + len(name)] = padded[:len(name)]
            patches += 1
            print(f"    Patched HBD filename '{name.decode()}' -> '{replacement.decode()}' at file offset 0x{idx:05X}")
            idx = data.find(name, idx + 1)

    return bytes(data), patches


def update_iso_dir(f, hbd_lba, hbd_size, exe_size):
    dir_data = bytearray(read_sector_user(f, 22))
    offset = 0
    while offset < len(dir_data):
        rec_len = dir_data[offset] & 0xFF
        if rec_len == 0:
            break
        name_len = dir_data[offset + 32] & 0xFF
        name = dir_data[offset + 33:offset + 33 + name_len].decode('ascii', errors='replace').rstrip('\x00')
        if 'HBD' in name:
            struct.pack_into('<I', dir_data, offset + 2, hbd_lba)
            struct.pack_into('>I', dir_data, offset + 6, hbd_lba)
            struct.pack_into('<I', dir_data, offset + 10, hbd_size)
            struct.pack_into('>I', dir_data, offset + 14, hbd_size)
        elif name.startswith('SL') and exe_size:
            struct.pack_into('<I', dir_data, offset + 10, exe_size)
            struct.pack_into('>I', dir_data, offset + 14, exe_size)
        offset += rec_len
    write_sector_user(f, 22, bytes(dir_data))


def run_edcre(bin_path):
    if os.path.exists(EDCRE):
        subprocess.run([EDCRE, bin_path], check=False)


def main():
    parser = argparse.ArgumentParser(description='DW7 EXE surgical patcher')
    parser.add_argument('input', help='Input DW7 ISO .bin')
    parser.add_argument('output', help='Output patched ISO .bin')
    parser.add_argument('--hbd-lba', type=int, default=356,
                        help='New HBD start sector (default 356)')
    parser.add_argument('--old-hbd-lba', type=int, default=354,
                        help='Original DW7 HBD start sector (default 354)')
    parser.add_argument('--hybrid-tree', default=None,
                        help='Path to hybrid tree to append')
    parser.add_argument('--disc-check-sig', default=None,
                        help='Hex signature of disc-check routine entry (not yet implemented)')
    parser.add_argument('--dq4-hbd', default=None,
                        help='Path to translated DQ4 HBD file to swap in (default: keep DW7 HBD)')
    parser.add_argument('--keep-hbd-name', action='store_true',
                        help='Keep HBD filename as hbd1ps1d.w71 (do not patch to q41)')
    args = parser.parse_args()

    print(f"DW7 EXE Patcher")
    print(f"  Input: {args.input}")
    print(f"  Output: {args.output}")
    print(f"  Old HBD LBA: {args.old_hbd_lba}")
    print(f"  New HBD LBA: {args.hbd_lba}")

    if not os.path.exists(args.input):
        print("ERROR: input ISO not found")
        return 1

    shutil.copy(args.input, args.output)

    with open(args.output, 'r+b') as f:
        # Extract original EXE
        exe = extract_exe(f)
        print(f"  Original EXE size: {len(exe):,} bytes")

        # 1. LBA reference normalization
        exe, lba_patches = patch_lba_references(exe, args.old_hbd_lba, args.hbd_lba)
        print(f"  LBA reference patches (exact {args.old_hbd_lba}->{args.hbd_lba}): {lba_patches}")

        # 2. Absolute pointer table at 0x4184 (HBD folder start sectors)
        exe, abs_patches = patch_abs_pointer_table(exe, args.old_hbd_lba, args.hbd_lba)
        print(f"  ABS pointer table patches: {abs_patches}")

        # 3. Sequential packed sector table at 0xA39AA
        exe, seq_patches = patch_sequential_sector_table(exe, args.old_hbd_lba, args.hbd_lba)
        print(f"  Sequential sector table patches: {seq_patches}")

        # 4. Relative sector remapping for values inside HBD region
        exe, rel_patches = patch_relative_sector_refs(exe, args.old_hbd_lba, args.hbd_lba)
        print(f"  Relative sector remaps: {rel_patches}")

        # 5. Hybrid tree append + MIPS re-link if requested
        tree_patches = 0
        if args.hybrid_tree and os.path.exists(args.hybrid_tree):
            load_addr = struct.unpack_from('<I', exe, 0x18)[0]
            old_lui = 0x800F
            old_addiu = 0xF1C8
            new_addr = load_addr + len(exe) - 0x800
            new_addiu = new_addr & 0xFFFF
            new_lui = ((new_addr >> 16) & 0xFFFF) + (1 if new_addiu >= 0x8000 else 0)
            exe, tree_patches = patch_mips_lui_addiu(exe, old_lui, old_addiu, new_lui, new_addiu)
            exe = append_hybrid_tree(exe, args.hybrid_tree)
            print(f"  Hybrid tree appended, MIPS ref patches: {tree_patches}")

        # 6. Disc-check bypass (targeted MIPS patches)
        exe, disc_patches = patch_disc_check(exe)
        print(f"  Disc-check bypass patches: {disc_patches}")

        # 7. HBD filename patch (make DW7 EXE look for DQ4 HBD filename)
        if not args.keep_hbd_name:
            exe, name_patches = patch_hbd_filename(exe)
        else:
            name_patches = 0
        print(f"  HBD filename patches: {name_patches}")

        # Write patched EXE
        write_raw_data(f, EXE_LBA, exe)

        # Write HBD data — either translated DQ4 HBD or relocated DW7 HBD
        if args.dq4_hbd and os.path.exists(args.dq4_hbd):
            print(f"  Loading translated DQ4 HBD: {args.dq4_hbd}")
            with open(args.dq4_hbd, 'rb') as hbd_f:
                hbd_data = hbd_f.read()
            hbd_size = len(hbd_data)
            print(f"  DQ4 HBD size: {hbd_size:,} bytes")
            # Write HBD data to disc at the target LBA
            write_raw_data(f, args.hbd_lba, hbd_data)
            print(f"  DQ4 HBD written to sector {args.hbd_lba}")
        else:
            # Copy original DW7 HBD to new location
            hbd_size = 618563584
            hbd_data = bytearray()
            for i in range(hbd_size // USER_SIZE):
                hbd_data.extend(read_sector_user(f, args.old_hbd_lba + i))
            write_raw_data(f, args.hbd_lba, bytes(hbd_data))
            print(f"  DW7 HBD relocated to sector {args.hbd_lba}")

        # Update ISO directory
        update_iso_dir(f, args.hbd_lba, hbd_size, len(exe))

    # Regenerate EDC/ECC
    print("  Regenerating EDC/ECC...")
    run_edcre(args.output)

    print(f"  Done: {args.output}")
    return 0


if __name__ == '__main__':
    sys.exit(main())
