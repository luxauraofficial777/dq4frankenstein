import struct
import sys

# Simple MIPS disassembler for verification
def sign_ext16(x):
    if x & 0x8000:
        return x - 0x10000
    return x

def disasm(word, addr):
    op = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm = word & 0xFFFF
    target = word & 0x3FFFFFF
    signed_imm = sign_ext16(imm)
    branch_target = addr + 4 + (signed_imm << 2)
    jump_target = (addr & 0xF0000000) | (target << 2)
    
    regs = ['zero','at','v0','v1','a0','a1','a2','a3','t0','t1','t2','t3','t4','t5','t6','t7','s0','s1','s2','s3','s4','s5','s6','s7','t8','t9','k0','k1','gp','sp','fp','ra']
    
    if op == 0:
        if word == 0:
            return 'nop'
        if funct == 0x00:
            return f'sll ${regs[rd]}, ${regs[rt]}, {shamt}'
        if funct == 0x02: return f'srl ${regs[rd]}, ${regs[rt]}, {shamt}'
        if funct == 0x03: return f'sra ${regs[rd]}, ${regs[rt]}, {shamt}'
        if funct == 0x04: return f'sllv ${regs[rd]}, ${regs[rt]}, ${regs[rs]}'
        if funct == 0x06: return f'srlv ${regs[rd]}, ${regs[rt]}, ${regs[rs]}'
        if funct == 0x08: return f'jr ${regs[rs]}'
        if funct == 0x09: return f'jalr ${regs[rd]}, ${regs[rs]}'
        if funct == 0x0C: return f'syscall'
        if funct == 0x0D: return f'break'
        if funct == 0x10: return f'mfhi ${regs[rd]}'
        if funct == 0x11: return f'mthi ${regs[rs]}'
        if funct == 0x12: return f'mflo ${regs[rd]}'
        if funct == 0x13: return f'mtlo ${regs[rs]}'
        if funct == 0x18: return f'mult ${regs[rs]}, ${regs[rt]}'
        if funct == 0x19: return f'multu ${regs[rs]}, ${regs[rt]}'
        if funct == 0x1A: return f'div ${regs[rs]}, ${regs[rt]}'
        if funct == 0x1B: return f'divu ${regs[rs]}, ${regs[rt]}'
        if funct == 0x20: return f'add ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x21: return f'addu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x22: return f'sub ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x23: return f'subu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x24: return f'and ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x25: return f'or ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x26: return f'xor ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x27: return f'nor ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x2A: return f'slt ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        if funct == 0x2B: return f'sltu ${regs[rd]}, ${regs[rs]}, ${regs[rt]}'
        return f'(special funct=0x{funct:02x})'
    if op == 1:
        if rt == 0: return f'bltz ${regs[rs]}, 0x{branch_target:08X}'
        if rt == 1: return f'bgez ${regs[rs]}, 0x{branch_target:08X}'
        if rt == 16: return f'bltzal ${regs[rs]}, 0x{branch_target:08X}'
        if rt == 17: return f'bgezal ${regs[rs]}, 0x{branch_target:08X}'
        return f'(regimm rt={rt})'
    
    opcodes = {
        2: ('j', jump_target), 3: ('jal', jump_target),
        4: ('beq', rs, rt, branch_target), 5: ('bne', rs, rt, branch_target),
        6: ('blez', rs, branch_target), 7: ('bgtz', rs, branch_target),
        8: 'addi', 9: 'addiu', 10: 'slti', 11: 'sltiu',
        12: 'andi', 13: 'ori', 14: 'xori', 15: 'lui',
        32: 'lb', 33: 'lh', 34: 'lwl', 35: 'lw',
        36: 'lbu', 37: 'lhu', 38: 'lwr', 40: 'sb', 41: 'sh', 42: 'swl', 43: 'sw',
        46: 'swr', 49: 'lwc1', 50: 'lwc2', 51: 'lwc3',
        53: 'ldc1', 54: 'ldc2', 56: 'swc1', 57: 'swc2',
        59: 'sdc1', 60: 'sdc2',
    }
    
    if op in (2,3):
        name, t = opcodes[op]
        return f'{name} 0x{t:08X}'
    if op in (4,5):
        name, rs, rt, t = opcodes[op]
        return f'{name} ${regs[rs]}, ${regs[rt]}, 0x{t:08X}'
    if op in (6,7):
        name, rs, t = opcodes[op]
        return f'{name} ${regs[rs]}, 0x{t:08X}'
    if op in (8,9,10,11):
        name = opcodes[op]
        return f'{name} ${regs[rt]}, ${regs[rs]}, 0x{imm:X}'
    if op in (12, 13, 14):
        name = opcodes[op]
        return f'{name} ${regs[rt]}, ${regs[rs]}, 0x{imm:04X}'
    if op == 15:
        return f'lui ${regs[rt]}, 0x{imm:04X}'
    if op in (32,33,34,35,36,37,38,40,41,42,43,46):
        name = opcodes[op]
        return f'{name} ${regs[rt]}, 0x{signed_imm:X}(${regs[rs]})'
    if op in (49,50,51,53,54,56,57,59,60):
        name = opcodes[op]
        return f'{name} ${rt}, 0x{signed_imm:X}(${regs[rs]})'
    
    return f'(op=0x{op:02X})'

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: python disasm_dw7.py <file> [base_addr_hex]')
        sys.exit(1)
    path = sys.argv[1]
    base = int(sys.argv[2], 16) if len(sys.argv) > 2 else 0x80010000
    with open(path, 'rb') as f:
        data = f.read()
    for i in range(0, len(data), 4):
        addr = base + i
        word = struct.unpack_from('<I', data, i)[0]
        print(f'0x{addr:08X}: 0x{word:08X}  {disasm(word, addr)}')
