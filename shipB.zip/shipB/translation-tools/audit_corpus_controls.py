#!/usr/bin/env python3
"""
audit_corpus_controls.py -- control-code audit across EVERY live injection surface.

Extends validate_corpus.py (which only checks '{'/'}' well-formedness of the
dialogue corpus) with the classes that ALSO mis-encode silently:

  BARE      a control code with NO brackets ("7F02", "0000", "FE0A") -> text_to_leaves
            encodes it as 4 literal glyphs; the line break / wait / terminator is LOST.
  WRONGBR   <7F34> or [7F34] -> six literal glyphs (encoder only accepts {XXXX}).
  FWBRACE   fullwidth braces / brackets around a code.
  UNCLOSED / NOT4 / NOTHEX / STRAY  (validate_corpus parity: block silently skipped / glyph)
  PARITY    structural codes present in the JP source but missing from the EN (or extra):
            speaker/wait/name-sub/variable/fragment codes. Line breaks {7F01}/{7F02} and
            {0000} are excluded (paginator / patcher-normalised).
  EMPTY     JP non-empty but EN empty (seq silently stays Japanese).

Surfaces audited (the ones the build actually consumes, per tools/native_build.py):
  translation/full_translation_boot_with_0069.json      STEP 1 / 1c / 1e   (JP from translation/csv/<id>.csv)
  translation/block_048b_battle_overlay_translated.json STEP 4              (jp/en inline)
  translation/exe_block_048c_translated_full.json + _truncated/_master/_translated  STEP 2 (jp/en inline)
  translation/block_0474_save_menu.json                 STEP 3
  patch_font1_ourway.FONT1_COMMANDS / FONT1_HEROES      STEP 2 inline labels

Usage: python translation-tools/audit_corpus_controls.py [--out study/AUDIT_....md]
Exit 1 if any FATAL class (BARE / WRONGBR / UNCLOSED / NOT4 / NOTHEX) is found.
"""
import argparse
import csv
import json
import os
import re
import sys
from collections import Counter, defaultdict

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

GOOD = re.compile(r"\{([0-9a-fA-F]{4})\}")
# bare 7Fxx / 0000 anywhere; bare FExx only when not part of a longer hex/alpha run
BARE_7F = re.compile(r"(?<![0-9A-Za-z{<\[])(7[fF][0-9a-fA-F]{2}|0000)(?![0-9A-Za-z}>\]])")
BARE_FE = re.compile(r"(?<![0-9A-Za-z{<\[])([fF][eE][0-9a-fA-F]{2})(?![0-9A-Za-z}>\]])")
WRONGBR = re.compile(r"[<\[]([0-9a-fA-F]{4})[>\]]")
FWBRACE = re.compile(r"[｛｝［］＜＞]")
ENGLISH_FE_WORDS = {"feed", "fees", "feel", "feeb", "fead", "fede"}  # never flag as bare FExx

# structural codes that must survive translation (multiset parity vs JP).
# RC-2: extended with the EXE-resident wild tokens catalogued by
# cybergrime/forensics/ctrl_audit (7F06, 7F1B, 7F1C, 7F1E, 7F35 -- 7F10/7F19
# were already tracked). An EN string that DROPS one of these now fails
# PARITY_VAR_MISSING instead of silently stalling the Font-1 formatter.
STRUCTURAL = {"7f04", "7f07", "7f0a", "7f0b", "7f3c", "7f3d", "7f3e", "7f3f",
              "7f47", "7f4c", "7f34", "7f10", "7f11", "7f15", "7f16", "7f17",
              "7f18", "7f19", "7f1a", "7f1f",
              "7f06", "7f1b", "7f1c", "7f1e", "7f35"}


def codes_of(s):
    return [m.group(1).lower() for m in GOOD.finditer(s or "")]


def structural(s):
    return Counter(c for c in codes_of(s) if c in STRUCTURAL or c.startswith("fe"))


def scan(text):
    """Return list of (CLASS, detail) for one EN string."""
    out = []
    if not text:
        return out
    # brace grammar exactly as text_to_leaves
    i, n = 0, len(text)
    while i < n:
        c = text[i]
        if c == "{":
            j = text.find("}", i)
            if j < 0:
                out.append(("UNCLOSED", text[i:i + 10]))
                break
            inner = text[i + 1:j]
            if len(inner) != 4:
                out.append(("NOT4", "{%s}" % inner))
            elif not all(ch in "0123456789abcdefABCDEF" for ch in inner):
                out.append(("NOTHEX", "{%s}" % inner))
            i = j + 1
            continue
        if c == "}":
            out.append(("STRAY", "col %d" % i))
        i += 1
    stripped = GOOD.sub(" ", text)
    for m in BARE_7F.finditer(stripped):
        out.append(("BARE", m.group(1)))
    for m in BARE_FE.finditer(stripped):
        if m.group(1).lower() not in ENGLISH_FE_WORDS:
            out.append(("BARE", m.group(1)))
    for m in WRONGBR.finditer(text):
        out.append(("WRONGBR", m.group(0)))
    if FWBRACE.search(text):
        out.append(("FWBRACE", FWBRACE.search(text).group(0)))
    return out


def load_csv_jp(bid):
    p = os.path.join(ROOT, "translation", "csv", "%s.csv" % bid)
    if not os.path.exists(p):
        return None
    jp = {}
    with open(p, encoding="utf-8", newline="") as f:
        for row in csv.DictReader(f):
            try:
                jp[str(int(row["lineNumber"]))] = row.get("original") or ""
            except Exception:
                continue
    return jp


WAIT_CODES = {"7f0a", "7f0b"}          # page-advance / wait: paginator-adjustable, engine-tolerant
DW7_TOKEN = re.compile(r"\{7[eE][0-9a-fA-F]{2}\}")   # CSV-side undecoded DW7 kana/dictionary tokens


def visible(s):
    return GOOD.sub("", s or "")


def audit_pairs(label, pairs, findings, parity_on=True):
    """pairs: iterable of (block, seq, jp, en)."""
    n = 0
    for bid, seq, jp, en in pairs:
        n += 1
        loc = "%s %s#%s" % (label, bid, seq)
        if (jp or "").strip() and not (en or "").strip():
            findings["EMPTY"].append((loc, (jp or "")[:50]))
            continue
        for cls, det in scan(en):
            findings[cls].append((loc, det, (en or "")[:70]))
        # SKELETON: the EN carries a mid-string {0000} and everything after it is
        # only control codes + punctuation -> the dialogue text was lost; renders as
        # a near-blank box in-game (topic word, then ". " / "! " pages).
        is_skel = False
        segs = (en or "").split("{0000}")
        if len(segs) > 2:
            for s in segs[1:]:
                if s.count("{") >= 2 and sum(ch.isalpha() for ch in visible(s)) < 2:
                    is_skel = True
                    break
        if is_skel:
            findings["SKELETON"].append((loc, (en or "")[:70], len(DW7_TOKEN.findall(jp or ""))))
        elif jp:
            # GUTTED: JP is a long line but the EN carries almost no text at all.
            jl = len(visible(jp).replace("　", "").replace(" ", ""))
            el = sum(ch.isalpha() for ch in visible(en))
            if jl >= 30 and el <= 12:
                findings["GUTTED"].append((loc, (en or "")[:60], "jp_len=%d" % jl))
        if parity_on and jp:
            sj, se = structural(jp), structural(en)
            missing = sj - se
            extra = se - sj
            m_var = {k: v for k, v in missing.items() if k not in WAIT_CODES}
            m_wait = {k: v for k, v in missing.items() if k in WAIT_CODES}
            e_var = {k: v for k, v in extra.items() if k not in WAIT_CODES}
            if m_var:
                findings["PARITY_VAR_MISSING"].append((loc, m_var, (en or "")[:60]))
            if m_wait:
                findings["PARITY_WAIT_MISSING"].append((loc, m_wait, (en or "")[:60]))
            if e_var:
                findings["PARITY_VAR_EXTRA"].append((loc, e_var, (en or "")[:60]))
    return n


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default=os.path.join(ROOT, "study", "AUDIT_CORPUS_CONTROL_CODES_Sep06_2026.md"))
    args = ap.parse_args()
    findings = defaultdict(list)
    counts = {}

    # 1. canonical dialogue corpus (STEP 1/1c/1e) + CSV JP
    p = os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json")
    corpus = json.load(open(p, encoding="utf-8"))
    pairs = []
    csv_missing = 0
    sample_pairs = []
    for bid, entry in corpus.items():
        if not isinstance(entry, dict):
            continue
        jpmap = load_csv_jp(bid)
        if jpmap is None:
            csv_missing += 1
        for seq, sv in entry.items():
            if isinstance(sv, dict):
                en = sv.get("translation") or sv.get("en") or ""
                jp = sv.get("jp") or (jpmap.get(seq, "") if jpmap else "")
            else:
                en, jp = (sv or ""), (jpmap.get(seq, "") if jpmap else "")
            if jpmap and len(sample_pairs) < 3 and jp and en:
                sample_pairs.append((bid, seq, jp[:40], en[:40]))
            pairs.append((bid, seq, jp, en))
    counts["canonical"] = audit_pairs("corpus", pairs, findings)
    counts["canonical_blocks_without_csv"] = csv_missing

    # 2. battle overlay (STEP 4)
    p = os.path.join(ROOT, "translation", "block_048b_battle_overlay_translated.json")
    bat = json.load(open(p, encoding="utf-8"))
    counts["048b"] = audit_pairs("048b", [("048b", e.get("index"), e.get("jp"), e.get("en")) for e in bat], findings)
    # battle/exe patchers do NOT normalise terminators -> en must end with {0000} when jp does
    for e in bat:
        if (e.get("jp") or "").endswith("{0000}") and not (e.get("en") or "").endswith("{0000}"):
            findings["TERM_MISSING"].append(("048b #%s" % e.get("index"), (e.get("en") or "")[-30:]))

    # 3. Font 1 JSONs (STEP 2) -- only SIDs with an 'en' matter
    for fn in ("exe_block_048c_translated_full.json", "exe_block_048c_truncated.json",
               "exe_block_048c_master.json", "exe_block_048c_translated.json"):
        p = os.path.join(ROOT, "translation", fn)
        if not os.path.exists(p):
            continue
        d = json.load(open(p, encoding="utf-8"))
        if not isinstance(d, dict):
            continue
        prs = [(fn.replace("exe_block_", "").replace(".json", ""), k, v.get("jp") or v.get("original"), v.get("en"))
               for k, v in d.items() if str(k).isdigit() and isinstance(v, dict) and (v.get("en") or "").strip()]
        counts[fn] = audit_pairs("font1", prs, findings)

    # 4. save menu (STEP 3)
    p = os.path.join(ROOT, "translation", "block_0474_save_menu.json")
    if os.path.exists(p):
        d = json.load(open(p, encoding="utf-8"))
        prs = []
        items = d.items() if isinstance(d, dict) else enumerate(d)
        for k, v in items:
            if isinstance(v, dict):
                prs.append(("0474", k, v.get("jp") or v.get("original"), v.get("en") or v.get("translation")))
            elif isinstance(v, str):
                prs.append(("0474", k, None, v))
        counts["0474"] = audit_pairs("0474", prs, findings)

    # 5. inline Font 1 labels
    try:
        import patch_font1_ourway as F
        prs = [("FONT1_COMMANDS", k, None, v) for k, v in F.FONT1_COMMANDS.items()]
        prs += [("FONT1_HEROES", k, None, v) for k, v in F.FONT1_HEROES.items()]
        counts["font1_inline"] = audit_pairs("font1-inline", prs, findings, parity_on=False)
    except Exception as e:
        findings["NOTE"].append(("font1 import", str(e)))

    # ---- report
    FATAL = ("BARE", "WRONGBR", "UNCLOSED", "NOT4", "NOTHEX")
    BLOCKER = ("SKELETON",)   # content loss: ships as near-blank dialogue
    lines = ["# AUDIT — control-code + content integrity across all live injection surfaces",
             "**Date:** 2026-09-06  **Tool:** `translation-tools/audit_corpus_controls.py`", "",
             "Severity: FATAL = mis-encodes silently (block skipped / literal glyphs); "
             "BLOCKER = translation text lost (renders blank); WARN = check by hand; "
             "INFO = engine-tolerant (never observed in play).", ""]
    lines.append("## Surfaces scanned")
    for k, v in counts.items():
        lines.append("- %s: %s" % (k, v))
    if sample_pairs:
        lines.append("")
        lines.append("CSV↔corpus key alignment spot-check (JP from csv lineNumber == corpus seq key):")
        for bid, seq, jp, en in sample_pairs:
            lines.append("- %s#%s  JP `%s`  EN `%s`" % (bid, seq, jp, en))
    lines.append("")
    # per-block table for content loss
    skel_by = Counter(it[0].split()[1].split("#")[0] for it in findings.get("SKELETON", []))
    gut_by = Counter(it[0].split()[1].split("#")[0] for it in findings.get("GUTTED", []))
    if skel_by or gut_by:
        lines.append("## Content loss by block (SKELETON / GUTTED)")
        lines.append("| block | SKELETON | GUTTED |")
        lines.append("|---|---|---|")
        for b, _n in (skel_by + gut_by).most_common(25):
            lines.append("| %s | %d | %d |" % (b, skel_by.get(b, 0), gut_by.get(b, 0)))
        lines.append("")
    lines.append("## Findings by class")
    total_fatal = total_blocker = 0
    order = list(FATAL) + list(BLOCKER) + ["GUTTED", "PARITY_VAR_MISSING", "PARITY_VAR_EXTRA",
                                           "STRAY", "FWBRACE", "TERM_MISSING", "EMPTY",
                                           "PARITY_WAIT_MISSING", "NOTE"]
    INFO = ("PARITY_WAIT_MISSING",)
    for cls in order:
        items = findings.get(cls, [])
        sev = "FATAL" if cls in FATAL else "BLOCKER" if cls in BLOCKER else "INFO" if cls in INFO else "WARN"
        if cls in FATAL:
            total_fatal += len(items)
        if cls in BLOCKER:
            total_blocker += len(items)
        lines.append("")
        lines.append("### %s — %s (%d)" % (cls, sev, len(items)))
        for it in items[:60]:
            lines.append("- " + " | ".join("`%s`" % str(x) for x in it))
        if len(items) > 60:
            lines.append("- ... %d more" % (len(items) - 60))
    lines.append("")
    lines.append("## Verdict")
    lines.append("FATAL total: **%d** (%s)" % (total_fatal, "CLEAN" if total_fatal == 0 else "FIX BEFORE BUILD"))
    lines.append("BLOCKER total: **%d** (%s)" % (total_blocker, "CLEAN" if total_blocker == 0 else "RE-TRANSLATE BEFORE V1.0"))
    lines.append("WARN total: %d" % sum(len(findings.get(c, [])) for c in order if c not in FATAL + BLOCKER + INFO))
    total_fatal += total_blocker
    txt = "\n".join(lines)
    with open(args.out, "w", encoding="utf-8") as f:
        f.write(txt + "\n")
    # console summary
    print("scanned:", counts)
    for cls in order:
        if findings.get(cls):
            print("%-15s %s %d" % (cls, "FATAL" if cls in FATAL else "warn ", len(findings[cls])))
    print("FATAL total:", total_fatal, "->", args.out)
    return 1 if total_fatal else 0


if __name__ == "__main__":
    sys.exit(main())
