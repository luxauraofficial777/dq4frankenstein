#!/usr/bin/env python3
"""
Extract text from DQ4 HBD blocks of all types (23, 24, 25, 27, 40, 42)
by scanning raw HBD bytes for the Huffman text pattern.

This bypasses the Java HeartBeatDataFolderEntryReader which assumes all
text blocks share the same 24-byte header format. Types 23/24/25/27
have a different file structure but contain the same Huffman-encoded
text with per-block trees.

Outputs JSON in the same format as full_translation.json:
{
  "text_id_hex": {
    "1": {"translation": "decoded text{0000}"},
    "2": {"translation": "second sequence{0000}"},
    ...
  },
  ...
}
"""
import struct, os, sys, json, time, re

WORKSPACE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(WORKSPACE, 'translation-tools'))
from hbe.huffman.dq4 import DQ4Schema

RAW_SECTOR = 2352
USER_OFFSET = 24
USER_SIZE = 2048
DQ4_DISC = os.path.join(WORKSPACE, 'Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin')
DQ4_HBD_LBA = 362


def leaves_to_text(leaves):
    chars = []
    for leaf in leaves:
        if leaf is None:
            continue
        if leaf.is_control():
            content = leaf.content
            val = (content[0] << 8) | content[1]
            if val == 0x0000:
                chars.append('{0000}')
            elif (val & 0x7F00) == 0x7F00:
                chars.append('{%04X}' % val)
            else:
                chars.append('{%04X}' % val)
        elif leaf.is_character():
            content = leaf.content
            hi = content[0] | 0x80
            lo = content[1]
            try:
                chars.append(bytes([hi, lo]).decode('sjis'))
            except:
                val = (hi << 8) | lo
                if 0x8260 <= val <= 0x829A:
                    chars.append(chr(val - 0x8200))
                elif 0x824F <= val <= 0x8258:
                    chars.append(chr(val - 0x824F + ord('0')))
                else:
                    chars.append('{%04X}' % val)
    return ''.join(chars)


def is_garbage_seq(text_part):
    """Check if a single sequence (without {0000}) is padding garbage."""
    clean = re.sub(r'\{[0-9A-Fa-f]{4}\}', '', text_part)
    if not clean:
        return True
    if len(set(clean)) == 1 and len(clean) >= 3:
        return True
    return False


def split_sequences(text):
    """Split decoded text on {0000} markers into individual sequences.
    Only trailing garbage sequences are trimmed — matching the Java decoder's
    backward search for the last real {0000} pair. Middle sequences are kept
    even if short, since they may be legitimate text."""
    parts = text.split('{0000}')
    sequences = []
    for p in parts:
        if not p:
            continue
        sequences.append(p + '{0000}')
    # Trim trailing garbage: remove from end while last seq is garbage
    while sequences:
        last = sequences[-1].replace('{0000}', '')
        clean = re.sub(r'\{[0-9A-Fa-f]{4}\}', '', last)
        if not clean:
            # Control-code only — garbage
            sequences.pop()
        elif len(clean) <= 2:
            # 1-2 chars at the end — likely padding
            sequences.pop()
        elif len(set(clean)) == 1 and len(clean) >= 3:
            # Repeated single char — padding
            sequences.pop()
        else:
            break
    return sequences


def main():
    print("=== DQ4 HBD Text Extractor (all types) ===")
    t_start = time.time()

    # Read HBD
    print("Reading HBD from disc at LBA %d..." % DQ4_HBD_LBA)
    hbd = bytearray()
    with open(DQ4_DISC, 'rb') as f:
        for i in range(200000):
            f.seek((DQ4_HBD_LBA + i) * RAW_SECTOR + USER_OFFSET)
            chunk = f.read(USER_SIZE)
            if not chunk or len(chunk) < USER_SIZE:
                break
            hbd.extend(chunk)
    hbd = bytes(hbd)
    print("  HBD: %d bytes (%d MB)" % (len(hbd), len(hbd) // 1048576))

    # Find all text blocks by scanning for the pattern
    print("Scanning for text blocks (hts=24 pattern)...")
    blocks = []
    for off in range(0, len(hbd) - 24, 4):
        end, block_id, hts, tree_end, text_end, unk = struct.unpack_from('<6I', hbd, off)
        if hts != 24:
            continue
        if tree_end == 0 or text_end == 0:
            continue
        if end < 24 or end > 1048576:
            continue
        if block_id == 0:
            continue
        if tree_end > end or text_end > end:
            continue
        text_id = block_id & 0xFFFF
        blocks.append({
            'offset': off, 'end': end, 'block_id': block_id,
            'text_id': '%04x' % text_id, 'hts': hts,
            'tree_end': tree_end, 'text_end': text_end,
        })
    print("  Found %d text blocks" % len(blocks))

    # Decode all blocks
    results = {}
    decoded = 0
    failed = 0
    total_seqs = 0

    for block in blocks:
        off = block['offset']
        hts = block['hts']
        tree_end = block['tree_end']
        text_end = block['text_end']
        end = block['end']
        text_id = block['text_id']

        text_bytes = hbd[off + hts:off + text_end]
        if off + text_end + 8 > len(hbd):
            failed += 1
            continue
        tree_start = struct.unpack_from('<I', hbd, off + text_end)[0]
        correct_tree_end = tree_end if tree_end != 0 else end
        tree_bytes = hbd[off + tree_start:off + correct_tree_end]

        if len(tree_bytes) < 4 or len(text_bytes) < 1:
            failed += 1
            continue

        schema = DQ4Schema()
        try:
            tree = schema.parse_tree(tree_bytes)
            leaves = schema.decode(text_bytes, tree)
            text = leaves_to_text(leaves)
            if text and len(text.strip()) > 0:
                seqs = split_sequences(text)
                if seqs:
                    if text_id not in results:
                        results[text_id] = {}
                    for i, seq in enumerate(seqs):
                        seq_key = str(i + 1)
                        results[text_id][seq_key] = {
                            'translation': seq,
                        }
                    decoded += 1
                    total_seqs += len(seqs)
                else:
                    failed += 1
            else:
                failed += 1
        except Exception as e:
            failed += 1

    elapsed = time.time() - t_start
    print("  Decoded: %d blocks, %d sequences" % (decoded, total_seqs))
    print("  Failed/skipped: %d blocks" % failed)
    print("  Unique text IDs: %d" % len(results))
    print("  Time: %.1fs" % elapsed)

    # Write JSON output
    out_json = os.path.join(WORKSPACE, 'translation', 'text_all_types_extracted.json')
    with open(out_json, 'w', encoding='utf-8') as f:
        json.dump(results, f, indent=2, ensure_ascii=False)
    print("Output: %s (%d bytes)" % (out_json, os.path.getsize(out_json)))

    # Compare with existing full_translation.json
    existing_path = os.path.join(WORKSPACE, 'translation', 'full_translation.json')
    if os.path.exists(existing_path):
        with open(existing_path, 'r', encoding='utf-8') as f:
            existing = json.load(f)
        existing_ids = set(existing.keys())
        new_ids = set(results.keys())
        only_in_new = new_ids - existing_ids
        only_in_existing = existing_ids - new_ids
        in_both = existing_ids & new_ids
        print("\nComparison with full_translation.json:")
        print("  In both: %d" % len(in_both))
        print("  Only in new extract: %d" % len(only_in_new))
        print("  Only in existing: %d" % len(only_in_existing))
        if only_in_new:
            print("  New IDs (first 20): %s" % ', '.join(sorted(only_in_new)[:20]))

    print("\nDONE")


if __name__ == '__main__':
    main()
