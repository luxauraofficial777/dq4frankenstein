#!/usr/bin/env python3
"""
validate_corpus.py -- PRE-FLIGHT corpus validator for the sovereign build.

The dialogue patcher (dq4_hbd_patcher.py) wraps text_to_leaves() in a try/except:
a single malformed control code -- an unclosed '{', a non-hex code, a code that
is not exactly 4 hex digits, a literal brace, or a stray {0000} that desyncs the
sequence count -- does NOT crash the build. It SILENTLY skips the whole block,
which then falls back to Japanese while the build still exits 0. You only find
out by spotting Japanese in-game.

This tool scans a corpus JSON the SAME way the patcher parses it and reports
every problem up front, with block id + sequence key + the offending string, so
a bad Gemini/merge edit is caught in seconds instead of after a 30-minute build.

Exit code: 0 = clean, 1 = at least one FATAL issue (would skip a block).

Usage:
  python validate_corpus.py [corpus.json]
  python validate_corpus.py translation/full_translation_boot_with_0069.json --strict
"""
import argparse
import json
import os
import re
import sys

sys.stdout.reconfigure(encoding="utf-8")

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
DEFAULT = os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json")

# A well-formed control code is exactly '{' + 4 hex + '}'. This is the ONLY
# thing text_to_leaves() accepts; anything else is a parse error or a silent
# mis-encode.
GOOD_CODE = re.compile(r"\{[0-9a-fA-F]{4}\}")
ANY_BRACE = re.compile(r"[{}]")

# Variable slots that must be preserved verbatim (never translated / altered).
VARIABLE_SLOTS = {"7f1f", "7f10", "7f15", "7f1a", "7f34"}

# RC-2: EXE-resident control codes (ctrl_audit census, Sep-08). These are
# VALID structural tokens in 048C/048F strings -- text_to_leaves encodes them
# as control leaves and the Font-1 / EXE formatters consume them. They must
# NEVER be "corrected" away: dropping one silently stalls formatting or
# misaligns later SIDs' bit offsets (the 7F06 freeze-token class). Documented
# here so a {7F06} in a corpus string reads as structure, not as a typo.
EXE_RESIDENT_CTRL = {"7f06", "7f10", "7f19", "7f1b", "7f1c", "7f1e", "7f35"}


def scan_string(s):
    """Return a list of (severity, message) problems for one translation string.

    Emulates text_to_leaves(): walk left to right, and at every '{' require a
    matching '}' with exactly 4 hex digits in between. Also flags stray '}' and
    non-ASCII / apostrophes that this font renders wrong.
    """
    problems = []
    i = 0
    n = len(s)
    while i < n:
        c = s[i]
        if c == "{":
            j = s.find("}", i)
            if j == -1:
                problems.append(("FATAL", "unclosed '{' (no matching '}'): ...%s" % repr(s[i:i + 8])))
                break
            inner = s[i + 1:j]
            if len(inner) != 4:
                problems.append(("FATAL", "control code not 4 chars: {%s}" % inner))
            elif not all(ch in "0123456789abcdefABCDEF" for ch in inner):
                problems.append(("FATAL", "control code not hex: {%s}" % inner))
            i = j + 1
            continue
        if c == "}":
            problems.append(("FATAL", "stray '}' with no opening '{' at col %d" % i))
        i += 1
    # Apostrophe: this font maps ' -> the Japanese open-quote glyph, renders as garbage.
    if "'" in s or "’" in s:
        problems.append(("WARN", "apostrophe present (font maps ' -> corrupt glyph): %s" % repr(s[:40])))
    # Non-ASCII outside control codes (e.g. leftover Japanese, smart quotes).
    visible = GOOD_CODE.sub("", s)
    for ch in visible:
        if ord(ch) > 0x7E and ch not in ("　",):
            problems.append(("WARN", "non-ASCII char %r (leftover JP / smart punct): %s" % (ch, repr(s[:40]))))
            break
    return problems


def seq_terminator_count(s):
    """How many {0000} the patcher will emit for this seq after its normalize.

    patch_block strips every {0000} then appends exactly one, so a well-formed
    seq contributes exactly one terminator. We only need to confirm the string
    is parseable; the count desync risk is when the WHOLE block's seq count
    changes -- reported per block below.
    """
    return len(re.findall(r"\{0{4}\}", s, re.IGNORECASE))


def main():
    ap = argparse.ArgumentParser(description="Pre-flight validator for the DQ4 dialogue corpus")
    ap.add_argument("corpus", nargs="?", default=DEFAULT)
    ap.add_argument("--strict", action="store_true", help="treat WARN (apostrophe/non-ASCII) as failures too")
    args = ap.parse_args()

    with open(args.corpus, "r", encoding="utf-8") as f:
        corpus = json.load(f)

    fatal = 0
    warn = 0
    fatal_blocks = set()
    print("=== PRE-FLIGHT CORPUS VALIDATION: %s ===" % os.path.basename(args.corpus))
    print("blocks: %d" % len(corpus))

    for bid, entry in corpus.items():
        if isinstance(entry, dict):
            seqs = entry
        elif isinstance(entry, str):
            seqs = {"1": entry}
        else:
            continue
        for seqkey, sv in seqs.items():
            if isinstance(sv, dict):
                text = sv.get("translation") or sv.get("en") or sv.get("text") or ""
            elif isinstance(sv, str):
                text = sv
            else:
                continue
            if not text:
                continue
            for sev, msg in scan_string(text):
                if sev == "FATAL":
                    fatal += 1
                    fatal_blocks.add(bid)
                    print("  [FATAL] %s#%s: %s" % (bid, seqkey, msg))
                else:
                    warn += 1
                    if warn <= 40:
                        print("  [warn]  %s#%s: %s" % (bid, seqkey, msg))

    print("\n" + "=" * 60)
    print("FATAL (would SILENTLY skip the block -> Japanese): %d  across %d blocks" % (fatal, len(fatal_blocks)))
    print("WARN  (apostrophe / non-ASCII, renders wrong)    : %d" % warn)
    if fatal_blocks:
        print("fatal blocks: %s" % ", ".join(sorted(fatal_blocks)))
    ok = (fatal == 0) and (not args.strict or warn == 0)
    print("RESULT: %s" % ("PASS" if ok else "FAIL"))
    print("=" * 60)
    return 0 if ok else 1


if __name__ == "__main__":
    sys.exit(main())
