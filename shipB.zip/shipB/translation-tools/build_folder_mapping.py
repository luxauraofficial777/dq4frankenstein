#!/usr/bin/env python3
"""Build folder mapping between DQ4 and DW7 HBD structures."""
import json, sys, os

def load_folders(path):
    with open(path, 'r', encoding='utf-8') as f:
        entries = json.load(f)
    return [e for e in entries if e['type'] == 'folder']

def folder_signature(folder):
    # Use list of (type, block_id) tuples as signature
    sig = []
    for f in folder['files']:
        sig.append((f['type'], f['block_id']))
    return tuple(sig)

def main():
    dq4_path = sys.argv[1]
    dw7_path = sys.argv[2]
    out_path = sys.argv[3]
    
    dq4_folders = load_folders(dq4_path)
    dw7_folders = load_folders(dw7_path)
    
    print(f"DQ4 folders: {len(dq4_folders)}")
    print(f"DW7 folders: {len(dw7_folders)}")
    
    # Build block ID -> folder index maps
    dq4_block_to_idx = {}
    for idx, folder in enumerate(dq4_folders):
        for f in folder['files']:
            bid = f['block_id']
            if bid is not None:
                if bid in dq4_block_to_idx:
                    print(f"WARNING: DQ4 block {bid:08X} appears in multiple folders: {dq4_block_to_idx[bid]} and {idx}")
                dq4_block_to_idx[bid] = idx
    
    dw7_block_to_idx = {}
    for idx, folder in enumerate(dw7_folders):
        for f in folder['files']:
            bid = f['block_id']
            if bid is not None:
                if bid in dw7_block_to_idx:
                    print(f"WARNING: DW7 block {bid:08X} appears in multiple folders: {dw7_block_to_idx[bid]} and {idx}")
                dw7_block_to_idx[bid] = idx
    
    print(f"DQ4 unique block IDs: {len(dq4_block_to_idx)}")
    print(f"DW7 unique block IDs: {len(dw7_block_to_idx)}")
    
    # Find common block IDs
    common_blocks = set(dq4_block_to_idx.keys()) & set(dw7_block_to_idx.keys())
    print(f"Common block IDs: {len(common_blocks)}")
    
    # Match DW7 folders to DQ4 folders by block ID
    mappings = []
    matched_dw7 = set()
    matched_dq4 = set()
    
    for dw7_idx, folder in enumerate(dw7_folders):
        dq4_candidates = set()
        for f in folder['files']:
            bid = f['block_id']
            if bid is not None and bid in dq4_block_to_idx:
                dq4_candidates.add(dq4_block_to_idx[bid])
        
        if len(dq4_candidates) == 1:
            dq4_idx = dq4_candidates.pop()
            dq4_folder = dq4_folders[dq4_idx]
            mappings.append({
                'dw7_folder_index': dw7_idx,
                'dw7_sector': folder['sector'],
                'dw7_sector_count': folder['sector_count'],
                'dw7_num_files': folder['num_files'],
                'dq4_folder_index': dq4_idx,
                'dq4_sector': dq4_folder['sector'],
                'dq4_sector_count': dq4_folder['sector_count'],
                'dq4_num_files': dq4_folder['num_files'],
                'match_type': 'block_id',
                'common_block_ids': [f['block_id'] for f in folder['files'] if f['block_id'] in dq4_block_to_idx]
            })
            matched_dw7.add(dw7_idx)
            matched_dq4.add(dq4_idx)
        elif len(dq4_candidates) > 1:
            print(f"WARNING: DW7 folder {dw7_idx} matches multiple DQ4 folders: {dq4_candidates}")
    
    # Try to match remaining folders by file type signature
    dq4_sig_to_idx = {}
    for idx, folder in enumerate(dq4_folders):
        if idx not in matched_dq4:
            sig = folder_signature(folder)
            if sig not in dq4_sig_to_idx:
                dq4_sig_to_idx[sig] = []
            dq4_sig_to_idx[sig].append(idx)
    
    unmatched_dw7 = [idx for idx in range(len(dw7_folders)) if idx not in matched_dw7]
    for dw7_idx in unmatched_dw7:
        sig = folder_signature(dw7_folders[dw7_idx])
        if sig in dq4_sig_to_idx and len(dq4_sig_to_idx[sig]) == 1:
            dq4_idx = dq4_sig_to_idx[sig][0]
            dq4_folder = dq4_folders[dq4_idx]
            mappings.append({
                'dw7_folder_index': dw7_idx,
                'dw7_sector': dw7_folders[dw7_idx]['sector'],
                'dw7_sector_count': dw7_folders[dw7_idx]['sector_count'],
                'dw7_num_files': dw7_folders[dw7_idx]['num_files'],
                'dq4_folder_index': dq4_idx,
                'dq4_sector': dq4_folder['sector'],
                'dq4_sector_count': dq4_folder['sector_count'],
                'dq4_num_files': dq4_folder['num_files'],
                'match_type': 'signature',
                'signature': [list(t) for t in sig]
            })
            matched_dw7.add(dw7_idx)
            matched_dq4.add(dq4_idx)
            dq4_sig_to_idx[sig].remove(dq4_idx)
            if not dq4_sig_to_idx[sig]:
                del dq4_sig_to_idx[sig]
    
    print(f"Matched by block ID: {sum(1 for m in mappings if m['match_type'] == 'block_id')}")
    print(f"Matched by signature: {sum(1 for m in mappings if m['match_type'] == 'signature')}")
    print(f"Unmatched DW7 folders: {len(dw7_folders) - len(matched_dw7)}")
    print(f"Unmatched DQ4 folders: {len(dq4_folders) - len(matched_dq4)}")
    
    # Sort by DW7 sector
    mappings.sort(key=lambda m: m['dw7_sector'])
    
    result = {
        'metadata': {
            'dq4_total_folders': len(dq4_folders),
            'dw7_total_folders': len(dw7_folders),
            'dq4_unique_blocks': len(dq4_block_to_idx),
            'dw7_unique_blocks': len(dw7_block_to_idx),
            'common_blocks': len(common_blocks),
            'matched_by_block_id': sum(1 for m in mappings if m['match_type'] == 'block_id'),
            'matched_by_signature': sum(1 for m in mappings if m['match_type'] == 'signature'),
            'unmatched_dw7': len(dw7_folders) - len(matched_dw7),
            'unmatched_dq4': len(dq4_folders) - len(matched_dq4)
        },
        'mappings': mappings
    }
    
    with open(out_path, 'w', encoding='utf-8') as f:
        json.dump(result, f, indent=2)
    
    print(f"Wrote {out_path}")

if __name__ == '__main__':
    main()
