#!/usr/bin/env python3
"""
validate_exe.py - PSX EXE header and hybrid tree validation.

Validates:
- EXE magic bytes and header fields
- text_size matches actual file size
- Load address + text_size doesn't overlap critical RAM regions
- Hybrid tree (if appended) falls within text_size
- MIPS LUI/ADDIU tree references point to correct address

Usage:
    python validate_exe.py <exe_file> [--tree-file <hybrid_tree.bin>]
"""
import struct
import os
import sys
import argparse

# PSX EXE header offsets
EXE_MAGIC_OFFSET = 0
EXE_MAGIC = b'PS-X EXE'
EXE_LOAD_ADDR_OFFSET = 0x18
EXE_TEXT_SIZE_OFFSET = 0x1C
EXE_HEADER_SIZE = 0x800  # 2048 bytes

# Known RAM regions to check for overlaps
RAM_REGIONS = [
    (0x80000000, 0x00010000, "Kernel/BIOS region"),
    (0x80010000, 0x0000F000, "BIOS event/control block"),
    (0x8001F000, 0x00010000, "BIOS stack/heap"),
    (0x1F000000, 0x00800000, "Parallel I/O / Expansion Region 1"),
    (0x1F800000, 0x00000400, "Scratchpad RAM"),
    (0x1F801000, 0x00004000, "Hardware registers (I/O ports)"),
    (0x1F802000, 0x00002000, "Expansion Region 2"),
    (0x1FA00000, 0x00080000, "Expansion Region 3"),
    (0x1FC00000, 0x00080000, "BIOS ROM"),
]

# MIPS opcodes
OP_LUI = 0x0F
OP_ADDIU = 0x09

# Expected MIPS tree ref values (DW7 EXE)
OLD_LUI_IMM = 0x800F
OLD_ADDIU_IMM = 0xF1C8


def validate_exe_header(exe_data):
    """Validate PSX EXE header fields."""
    errors = []
    warnings = []
    
    if len(exe_data) < EXE_HEADER_SIZE:
        errors.append(f"File too small for EXE header: {len(exe_data)} bytes (need {EXE_HEADER_SIZE})")
        return errors, warnings, {}
    
    # Check magic
    magic = exe_data[EXE_MAGIC_OFFSET:EXE_MAGIC_OFFSET + len(EXE_MAGIC)]
    if magic != EXE_MAGIC:
        errors.append(f"EXE magic mismatch: got {magic!r} (expected {EXE_MAGIC!r})")
    
    # Read header fields
    load_addr = struct.unpack_from('<I', exe_data, EXE_LOAD_ADDR_OFFSET)[0]
    text_size = struct.unpack_from('<I', exe_data, EXE_TEXT_SIZE_OFFSET)[0]
    
    info = {
        'magic': magic.decode('ascii', errors='replace'),
        'load_addr': load_addr,
        'text_size': text_size,
        'file_size': len(exe_data),
    }
    
    # Validate text_size
    expected_text_size = len(exe_data) - EXE_HEADER_SIZE
    if text_size != expected_text_size:
        errors.append(f"text_size mismatch: header says {text_size:,} (0x{text_size:X}), "
                      f"but file size - header = {expected_text_size:,} (0x{expected_text_size:X})")
    
    # Validate load address is in valid RAM range
    if not (0x80000000 <= load_addr <= 0x807FFFFF):
        warnings.append(f"Load address 0x{load_addr:08X} is outside main RAM (0x80000000-0x807FFFFF)")
    
    # Check for RAM region overlaps
    exe_start = load_addr
    exe_end = load_addr + text_size
    for region_start, region_size, region_name in RAM_REGIONS:
        region_end = region_start + region_size
        if exe_start < region_end and exe_end > region_start:
            if region_start < 0x80000000:  # Hardware regions
                warnings.append(f"EXE range 0x{exe_start:08X}-0x{exe_end:08X} overlaps {region_name} "
                                f"(0x{region_start:08X}-0x{region_end:08X})")
            elif load_addr != region_start:  # Don't warn if load_addr IS the region start
                warnings.append(f"EXE range 0x{exe_start:08X}-0x{exe_end:08X} overlaps {region_name} "
                                f"(0x{region_start:08X}-0x{region_end:08X})")
    
    return errors, warnings, info


def validate_mips_tree_refs(exe_data):
    """Find and validate MIPS LUI/ADDIU pairs that reference the tree address."""
    refs = []
    errors = []
    
    for i in range(0x800, len(exe_data) - 3, 4):
        instr = struct.unpack_from("<I", exe_data, i)[0]
        opcode = (instr >> 26) & 0x3F
        if opcode != OP_ADDIU:
            continue
        imm = instr & 0xFFFF
        if imm != OLD_ADDIU_IMM:
            continue
        
        rs = (instr >> 21) & 0x1F
        rt = (instr >> 16) & 0x1F
        
        # Search backwards for matching LUI
        for j in range(1, 17):
            prev_off = i - (j * 4)
            if prev_off < 0x800:
                break
            prev_instr = struct.unpack_from("<I", exe_data, prev_off)[0]
            prev_op = (prev_instr >> 26) & 0x3F
            if prev_op != OP_LUI:
                continue
            prev_imm = prev_instr & 0xFFFF
            prev_rt = (prev_instr >> 16) & 0x1F
            if prev_imm == OLD_LUI_IMM and prev_rt == rs:
                refs.append({
                    'lui_offset': prev_off,
                    'addiu_offset': i,
                    'lui_imm': prev_imm,
                    'addiu_imm': imm,
                    'reg': rs,
                    'distance': j,
                })
                break
    
    return refs, errors


def validate_hybrid_tree(exe_data, tree_data):
    """Validate that the hybrid tree is properly appended to the EXE."""
    errors = []
    warnings = []
    
    load_addr = struct.unpack_from('<I', exe_data, EXE_LOAD_ADDR_OFFSET)[0]
    text_size = struct.unpack_from('<I', exe_data, EXE_TEXT_SIZE_OFFSET)[0]
    
    # Tree should be at the end of the EXE text region
    expected_tree_offset = len(exe_data) - len(tree_data)
    # Account for sector padding
    tree_padding = (2048 - ((len(exe_data) - len(tree_data)) % 2048)) % 2048
    actual_tree_offset = len(exe_data) - len(tree_data) - tree_padding
    
    # Check if tree data matches at the end
    tree_at_end = exe_data[-len(tree_data):] == tree_data
    if not tree_at_end:
        errors.append("Hybrid tree data not found at end of EXE")
    else:
        # Verify tree RAM address
        tree_ram_addr = load_addr + text_size
        # Check alignment
        if tree_ram_addr % 4 != 0:
            warnings.append(f"Tree RAM address 0x{tree_ram_addr:08X} is not 4-byte aligned")
        
        # Verify the tree is within the text_size region
        tree_end_offset = EXE_HEADER_SIZE + text_size
        if tree_end_offset > len(exe_data):
            errors.append(f"text_size ({text_size:,}) extends beyond file ({len(exe_data):,})")
        
        if tree_ram_addr < load_addr or tree_ram_addr + len(tree_data) > load_addr + text_size:
            errors.append(f"Tree at 0x{tree_ram_addr:08X}-0x{tree_ram_addr + len(tree_data):08X} "
                          f"outside EXE text region 0x{load_addr:08X}-0x{load_addr + text_size:08X}")
    
    # Check tree structure (basic sanity)
    if len(tree_data) >= 4:
        # Try to parse first few bytes as tree header
        first_word = struct.unpack_from('<I', tree_data, 0)[0]
        # Huffman trees for DQ/DW games typically have node counts
        if first_word > 0x10000:
            warnings.append(f"Tree first word 0x{first_word:08X} seems large for a node count")
    
    return errors, warnings


def main():
    parser = argparse.ArgumentParser(description='Validate PSX EXE header and hybrid tree')
    parser.add_argument('exe_file', help='Path to EXE file')
    parser.add_argument('--tree-file', default=None, help='Path to hybrid tree file (optional)')
    args = parser.parse_args()
    
    if not os.path.exists(args.exe_file):
        print(f"ERROR: File not found: {args.exe_file}")
        sys.exit(1)
    
    with open(args.exe_file, 'rb') as f:
        exe_data = f.read()
    
    print(f"Validating EXE: {args.exe_file}")
    print(f"  File size: {len(exe_data):,} bytes")
    
    all_errors = []
    all_warnings = []
    
    # Validate header
    print(f"\n  EXE Header:")
    hdr_errors, hdr_warnings, info = validate_exe_header(exe_data)
    all_errors.extend(hdr_errors)
    all_warnings.extend(hdr_warnings)
    
    if info:
        print(f"    Magic: '{info['magic']}'")
        print(f"    Load address: 0x{info['load_addr']:08X}")
        print(f"    Text size: {info['text_size']:,} (0x{info['text_size']:X})")
        print(f"    File size: {info['file_size']:,}")
        print(f"    Expected text_size: {info['file_size'] - EXE_HEADER_SIZE:,}")
        print(f"    RAM end: 0x{info['load_addr'] + info['text_size']:08X}")
    
    # Validate MIPS tree refs
    print(f"\n  MIPS Tree References:")
    refs, ref_errors = validate_mips_tree_refs(exe_data)
    all_errors.extend(ref_errors)
    
    if refs:
        for ref in refs:
            print(f"    LUI at offset 0x{ref['lui_offset']:X} (imm=0x{ref['lui_imm']:04X}), "
                  f"ADDIU at offset 0x{ref['addiu_offset']:X} (imm=0x{ref['addiu_imm']:04X}), "
                  f"reg=r{ref['reg']}, distance={ref['distance']} instrs")
    else:
        print(f"    No tree references found (searching for LUI=0x{OLD_LUI_IMM:04X} + ADDIU=0x{OLD_ADDIU_IMM:04X})")
        all_warnings.append("No MIPS tree references found - EXE may not have tree patches applied")
    
    # Validate hybrid tree if provided
    if args.tree_file:
        print(f"\n  Hybrid Tree:")
        if not os.path.exists(args.tree_file):
            print(f"    ERROR: Tree file not found: {args.tree_file}")
            all_errors.append(f"Tree file not found: {args.tree_file}")
        else:
            with open(args.tree_file, 'rb') as f:
                tree_data = f.read()
            print(f"    Tree file: {args.tree_file}")
            print(f"    Tree size: {len(tree_data):,} bytes")
            
            tree_errors, tree_warnings = validate_hybrid_tree(exe_data, tree_data)
            all_errors.extend(tree_errors)
            all_warnings.extend(tree_warnings)
            
            if not tree_errors:
                print(f"    Tree found at end of EXE: OK")
    
    # Report
    print(f"\n  {'='*40}")
    if all_errors:
        print(f"  ERRORS ({len(all_errors)}):")
        for e in all_errors:
            print(f"    [ERROR] {e}")
    else:
        print(f"  No errors found")
    
    if all_warnings:
        print(f"  WARNINGS ({len(all_warnings)}):")
        for w in all_warnings:
            print(f"    [WARN] {w}")
    
    passed = len(all_errors) == 0
    print(f"\n  RESULT: {'PASS' if passed else 'FAIL'}")
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
