#!/usr/bin/env python3
"""patch_d4_splitimm.py — D4 priest menu fix: EXE split-immediates + direct
words + type-39 script remaps for 0x048C and 0x048F.

This closes the D4 defect by handling the three sites that patch_table_refs.py
cannot reach:

1. EXE split-immediate pairs (lui + ori/addiu) that compose stale 048C/048F
   words. Uses RadMage's splitimm.py (WINDOW=32, full clobber/orphan model).
   patch_font1_ourway.py used WINDOW=15 and missed 4+8 pairs.

2. EXE direct words that were wrongly remapped by a previous lane (wm != wp
   but wm is still a stale word). patch_table_refs.py skips these because
   it only touches words where wm == wp.

3. Type-39 script sub-blocks containing 3-byte command + stale 048C/048F
   words. patch_table_refs.py only scans type-26/44, not type-39.

Usage:
  python patch_d4_splitimm.py --disc MASTER --base PRISTINE [--write]
"""
import argparse, os, struct, sys
sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
# Fallback: if psx_tools not at ROOT, check parent (ship subdir layout)
if not os.path.isdir(os.path.join(ROOT, "psx_tools")):
    _parent = os.path.dirname(ROOT)
    if os.path.isdir(os.path.join(_parent, "psx_tools")):
        ROOT = _parent
sys.path.insert(0, os.path.join(ROOT, "psx_tools"))
sys.path.insert(0, HERE)  # hbe lives inside translation-tools/

from dq4 import hbd, huffman, mips, referrers, splitimm
from dq4.iso import RawISO
from hbe.compression.lzss import lzss_uncompress
from hbe.compression.dqlzs import compress_to_slot

RAW, UOFF, USZ = 2352, 24, 2048
HBD_LBA = 362
EXE_LBA = 24
EXE_SECTORS = 338
SCRIPT_CMD = referrers.SCRIPT_CMD

def read_exe_from_disc(path):
    acc = bytearray()
    with open(path, "rb") as f:
        for s in range(EXE_LBA, EXE_LBA + EXE_SECTORS):
            f.seek(s * RAW + UOFF)
            acc.extend(f.read(USZ))
    return bytes(acc)

def load_arch(path):
    with RawISO(path) as disc:
        return disc.read(HBD_LBA, (disc.sector_count - HBD_LBA) * 2048)

def build_omap(exe_p, exe_s, tid):
    load_p, _, tsize_p, toff_p = mips.exe_mapping(exe_p)
    load_s, _, tsize_s, toff_s = mips.exe_mapping(exe_s)
    bp = referrers.exe_blocks(exe_p, load_p, toff_p, tsize_p)
    bm = referrers.exe_blocks(exe_s, load_s, toff_s, tsize_s)
    blocks_p = [(va, tb) for va, tb in bp if tb.id == tid]
    blocks_s = [(va, tb) for va, tb in bm if tb.id == tid]
    if not blocks_p or not blocks_s:
        return {}, set(), 0
    tb_p, tb_s = blocks_p[0][1], blocks_s[0][1]
    offs_p = huffman.string_offsets(tb_p)
    offs_s = huffman.string_offsets(tb_s)
    c_bits_p = tb_p.c * 8
    c_bits_s = tb_s.c * 8
    starts_p = set(off + c_bits_p for off in offs_p)
    omap = {}
    for i in range(min(len(offs_p), len(offs_s))):
        if offs_p[i] == offs_s[i]:
            continue
        old_word = (tid << 20) | (offs_p[i] + c_bits_p)
        new_word = (tid << 20) | (offs_s[i] + c_bits_s)
        omap[old_word] = new_word
    return omap, starts_p, c_bits_p

def scan_type39_words(img):
    out = []
    o = img.find(SCRIPT_CMD)
    while o >= 0:
        p = o + len(SCRIPT_CMD)
        if p + 4 <= len(img):
            out.append((p, struct.unpack_from("<I", img, p)[0]))
        o = img.find(SCRIPT_CMD, o + 1)
    return out

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", required=True)
    ap.add_argument("--base", required=True)
    ap.add_argument("--write", action="store_true")
    args = ap.parse_args()

    print("=" * 70)
    print("  D4 SPLIT-IMM + DIRECT + TYPE-39 FIX (048C/048F)")
    print("=" * 70)

    exe_p = read_exe_from_disc(args.base)
    exe_s = read_exe_from_disc(args.disc)
    load_s, _, tsize_s, toff_s = mips.exe_mapping(exe_s)

    # Build ordinal maps
    omap_c, starts_c_p, cbits_c_p = build_omap(exe_p, exe_s, 0x048C)
    omap_f, starts_f_p, cbits_f_p = build_omap(exe_p, exe_s, 0x048F)
    all_omap = {}
    all_omap.update(omap_c)
    all_omap.update(omap_f)
    print("  stale words: 048C=%d, 048F=%d" % (len(omap_c), len(omap_f)))

    # Block ranges (to exclude block data from direct word scan)
    block_ranges = []
    for va, tb in referrers.exe_blocks(exe_s, load_s, toff_s, tsize_s):
        if tb.id in (0x048C, 0x048F):
            start = va - load_s + toff_s
            block_ranges.append((start, start + tb.a + 4))

    # === 1. EXE split-immediates ===
    print("\n--- EXE split-immediates (splitimm.py WINDOW=32) ---")
    exe_text = exe_s[toff_s:]
    exe_text_len = min(tsize_s, len(exe_s) - toff_s)

    sites_c = splitimm.find_word_refs(exe_text[:exe_text_len], 0x048C, starts_c_p, base=toff_s)
    stale_c = [(s, all_omap[s.value]) for s in sites_c if s.value in all_omap]
    print("  048C: %d stale split-imm" % len(stale_c))

    sites_f = splitimm.find_word_refs(exe_text[:exe_text_len], 0x048F, starts_f_p, base=toff_s)
    stale_f = [(s, all_omap[s.value]) for s in sites_f if s.value in all_omap]
    print("  048F: %d stale split-imm" % len(stale_f))

    # === 2. EXE direct words (including wrongly remapped) ===
    print("\n--- EXE direct words ---")
    direct_writes = []
    for o in range(0x800, min(tsize_s, len(exe_s) - 4), 4):
        w = struct.unpack_from("<I", exe_s, o)[0]
        if w in all_omap:
            if not any(s <= o < e for s, e in block_ranges):
                direct_writes.append((o, w, all_omap[w]))
    print("  stale direct words: %d" % len(direct_writes))

    # === 3. Type-39 script sub-blocks ===
    print("\n--- Type-39 script sub-blocks ---")
    march = load_arch(args.disc)
    blocks_m = hbd.scan_blocks(march)
    subs = sorted(hbd.sub_blocks(blocks_m), key=lambda p: (p[0], p[1]["idx"]))
    t39_plan = {}
    for sec, sb in subs:
        if sb["type"] != 39:
            continue
        if sb["compressed"]:
            try:
                img = bytearray(lzss_uncompress(hbd.sub_bytes(march, sb), expected_size=sb["ulen"]))
            except:
                continue
        else:
            img = bytearray(hbd.sub_bytes(march, sb))
        writes = [(o, all_omap[w]) for o, w in scan_type39_words(img) if w in all_omap]
        if writes:
            t39_plan[(sec, sb["idx"])] = (sb, img, writes)
    t39_total = sum(len(w) for _, _, w in t39_plan.values())
    print("  type-39 sub-blocks: %d, words: %d" % (len(t39_plan), t39_total))

    if not args.write:
        total = len(stale_c) + len(stale_f) + len(direct_writes) + t39_total
        print("\n  REPORT ONLY: %d total fixes needed" % total)
        return 0

    # === WRITE ===
    # BUGFIX (v2.3 black-screen root cause): find() already folds `base` into
    # every site offset (it was given exe_text = exe_s[toff_s:] with
    # base=toff_s, so s.hi_off/s.lo_off are ABSOLUTE exe_s offsets).
    # rewrite() must therefore be called with base=0 over the full buffer.
    # The old base=toff_s double-subtracted 0x800, landing every write 2048
    # bytes early and corrupting 24 innocent instruction words (the v2.3
    # black screen at PC 0x800630F8). Sentinel: site 0x800638F8/0x80063900.
    print("\n--- Applying ---")
    exe_buf = bytearray(exe_s)
    exe_changed = set()

    for s, new_word in stale_c + stale_f:
        assert s.lo_off >= toff_s, "site offset below toff_s: %r" % (s,)
        if s.hi_off is not None:
            assert s.hi_off >= toff_s, "site hi below toff_s: %r" % (s,)
        result, _, low_only = splitimm.rewrite(exe_buf, [s], new_word, base=0)
        exe_buf[:] = result
        if s.hi_off is not None:
            exe_changed.add((s.hi_off) // USZ)
        exe_changed.add((s.lo_off) // USZ)

    for o, _, new_w in direct_writes:
        struct.pack_into("<I", exe_buf, o, new_w)
        exe_changed.add(o // USZ)

    print("  EXE: %d split-imm + %d direct (%d sectors)" %
          (len(stale_c) + len(stale_f), len(direct_writes), len(exe_changed)))

    with open(args.disc, "r+b") as f:
        for i in sorted(exe_changed):
            if i >= EXE_SECTORS:
                continue
            chunk = bytes(exe_buf[i * USZ:(i + 1) * USZ])
            old = exe_s[i * USZ:(i + 1) * USZ]
            if chunk != old:
                f.seek((EXE_LBA + i) * RAW + UOFF)
                f.write(chunk)

    # Type-39 sub-blocks
    with open(args.disc, "r+b") as f:
        for (sec, idx), (sb, img, writes) in sorted(t39_plan.items()):
            for o, w in writes:
                struct.pack_into("<I", img, o, w)
            data = bytes(img)
            if sb["compressed"]:
                data = compress_to_slot(data, sb["dlen"], max_slack=3)
            assert len(data) == sb["dlen"]
            off = sb["off"]
            while data:
                s = off // USZ
                inoff = off % USZ
                n = min(USZ - inoff, len(data))
                f.seek((HBD_LBA + s) * RAW + UOFF + inoff)
                f.write(data[:n])
                off += n
                data = data[n:]
            print("    sec %d sub %d (%d words)" % (sec, idx, len(writes)))

    print("  DONE — re-run edcre after this step")
    return 0

if __name__ == "__main__":
    sys.exit(main())
