#!/usr/bin/env python3
"""
remap_external_refs.py -- archive-wide referrer remap (post-pass).

THE GAP THIS CLOSES
-------------------
dq4_hbd_patcher.py rebuilds each text block with a new Huffman tree, which MOVES
every string's bit offset, and it remaps only the block's OWN trailing dialog
pointer table. But strings are also referenced from OTHER blocks -- cutscene
scripts and index tables carry (text_id << 20 | bit_offset + hts*8) words. After
a rebuild those external words point at stale offsets, so the opening cutscene
triggers the wrong (or no) string. Measured: block 0x006C, the opening scene,
has 3 such external referrers. Markus's June Java patcher remapped these; the
Python reimplementation omitted them. This restores that behaviour.

METHOD (memory-safe, no 319MB word list)
----------------------------------------
1. Read pristine and built HBD archives.
2. For every text id, compute old string-start offsets (pristine) and new
   (built). Build {old_word: new_word} only for ids whose offsets changed.
3. One bounded pass over the built archive: for each 4-aligned word in the map,
   rewrite it -- EXCEPT words that fall inside a text block's own body (those
   were already handled by the in-block remap and must not be touched twice).
4. EDC/ECC.
"""

import os
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from hbe.huffman.dq4 import DQ4Schema
import dq4_hbd_patcher as P

RAW, UOFF, USZ, HBD_LBA = 2352, 24, 2048, 362
EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")
PRISTINE = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")


def read_hbd(path):
    b = bytearray()
    with open(path, "rb") as f:
        for i in range(200000):
            f.seek((HBD_LBA + i) * RAW + UOFF)
            c = f.read(USZ)
            if not c or len(c) < USZ:
                break
            b.extend(c)
    return bytes(b)


def text_blocks(h):
    """{off: (id, hts, text_end, tree_end_abs)} for every text block."""
    out = {}
    for off in range(0, len(h) - 24, 4):
        e, bid, hts, te, txe, unk = struct.unpack_from("<6I", h, off)
        if hts != 24 or te == 0 or txe == 0 or e < 24 or e > 1048576 or bid == 0:
            continue
        if te > e or txe > e:
            continue
        out[off] = (bid & 0xFFFF, hts, txe, off + (te if te else e), e)
    return out


def offsets_for(h, off, meta, sc):
    tid, hts, txe, tend, e = meta
    tree = sc.parse_tree(h[off + txe + 10:tend])
    lv = sc.decode(h[off + hts:off + txe], tree)
    return tid, hts, [bo for _i, bo in P.compute_sequence_bit_offsets(lv, tree)]


def main():
    disc = sys.argv[1] if len(sys.argv) > 1 else os.path.join(ROOT, "build", "dq4_dialogue_en.bin")
    report = "--report" in sys.argv
    sc = DQ4Schema()

    print("[+] reading pristine + built archives...")
    jp = read_hbd(PRISTINE)
    en = read_hbd(disc)

    JB = text_blocks(jp)
    EB = text_blocks(en)

    print("[+] building offset map for changed blocks...")
    word_map = {}
    block_ranges = []          # (start,end) byte ranges of text-block bodies in EN
    changed_ids = 0
    for off in sorted(set(JB) & set(EB)):
        jtid, jhts, joffs = offsets_for(jp, off, JB[off], sc)
        etid, ehts, eoffs = offsets_for(en, off, EB[off], sc)
        block_ranges.append((off, off + EB[off][4]))
        if jtid != etid or joffs == eoffs:
            continue
        changed_ids += 1
        n = min(len(joffs), len(eoffs))
        for i in range(n):
            ow = (jtid << 20) | ((joffs[i] + jhts * 8) & 0xFFFFF)
            nw = (etid << 20) | ((eoffs[i] + ehts * 8) & 0xFFFFF)
            if ow != nw:
                word_map[ow] = nw
    print("    changed blocks: %d   remappable external words: %d" % (changed_ids, len(word_map)))

    if not word_map:
        print("    nothing to remap.")
        return 0

    # sort block ranges for fast 'inside a block body' test
    block_ranges.sort()

    def inside_block(o):
        import bisect
        idx = bisect.bisect_right(block_ranges, (o, 1 << 62)) - 1
        return idx >= 0 and block_ranges[idx][0] <= o < block_ranges[idx][1]

    print("[+] scanning archive for external referrers (bounded)...")
    buf = bytearray(en)
    hits = 0
    inside_skipped = 0
    try:
        # Fast path: one C-speed pass to find the few 4-aligned words that hold a
        # mappable value, instead of 80M pure-Python iterations (which took 330s+
        # and could be killed mid-scan). np.isin flags candidate positions; only
        # those (typically a handful) reach the Python loop for the in-block test.
        import numpy as np
        usable = (len(buf) // 4) * 4
        arr = np.frombuffer(bytes(buf[:usable]), dtype="<u4")
        keys = np.fromiter(word_map.keys(), dtype="<u4", count=len(word_map))
        cand = np.where(np.isin(arr, keys))[0]
        for wi in cand:
            o = int(wi) * 4
            if inside_block(o):
                inside_skipped += 1          # its own in-block pointer, already done
                continue
            nw = word_map[int(arr[wi])]
            if not report:
                struct.pack_into("<I", buf, o, nw)
            hits += 1
    except ImportError:
        n = len(buf) - 3
        o = 0
        while o < n:
            w = buf[o] | (buf[o + 1] << 8) | (buf[o + 2] << 16) | (buf[o + 3] << 24)
            nw = word_map.get(w)
            if nw is not None:
                if inside_block(o):
                    inside_skipped += 1      # its own in-block pointer, already done
                else:
                    if not report:
                        struct.pack_into("<I", buf, o, nw)
                    hits += 1
            o += 4
    print("    external referrers rewritten: %d   (in-block skipped: %d)" % (hits, inside_skipped))

    if report:
        print("    REPORT ONLY -- nothing written")
        return 0

    print("[+] writing archive back into disc + EDC/ECC...")
    with open(disc, "r+b") as f:
        for i in range(0, len(buf), USZ):
            chunk = bytes(buf[i:i + USZ])
            if len(chunk) < USZ:
                chunk = chunk + b"\x00" * (USZ - len(chunk))
            f.seek((HBD_LBA + i // USZ) * RAW + UOFF)
            f.write(chunk)
    if os.path.exists(EDCRE):
        r = subprocess.run([EDCRE, disc], capture_output=True, text=True, timeout=900)
        print("    EDC/ECC: %s" % ("PASS" if r.returncode == 0 else "FAIL"))
    print("    done: %s" % disc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
