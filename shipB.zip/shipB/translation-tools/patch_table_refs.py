#!/usr/bin/env python3
"""LANE C/D: remap stale TABLE (type-26) / ROSTER (type-44) / EXE-table referrer
words whose TARGET text blocks were re-encoded by STEP 1.

The referrer word format is the same 32-bit word everywhere:
    (text id << 20) | bit offset from block base
(STEP 1 re-encode may shift strings inside a block, so the low 20 bits go stale.)

Safety discipline (pristine-compare, per patch_overlay_refs.py):
  * stale map built ONLY for block pairs that pass a CONTENT-CONSISTENCY gate:
    for every string index, the string decoded at the pristine offset must equal
    the string decoded at the master offset (same logical copy, merely shifted).
    Duplicate-copy tids whose first archive copies differ in text are skipped
    and reported (never guessed).
  * the trailing-residue offset is excluded (same rule as referrers._resolve).
  * a word is rewritten ONLY if it matches old_word exactly AND the pristine
    word at the same site equals it (EXE). Words equal to new_word are already
    correct. Anything else is untouched (COP2 collision safety).
  * EXE-resident re-encoded blocks (e.g. 0x0020 map names) are parsed with
    referrers.exe_blocks on both EXEs and folded into the same stale map.
  * LZS sub-blocks: decompress -> patch -> compress_to_slot (same slot) ->
    round-trip verify; raw sub-blocks patched in place. Any fit failure
    ABORTS the write.

--report (default): scan and prove, write nothing.
--write:            apply to --disc (edcre/STEP 5 must be re-run afterwards).

Gate for REBUILD C: a second --report run must find 0 stale words.
"""
import argparse
import os
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
# Fallback: if psx_tools not at ROOT, check parent (ship subdir layout)
if not os.path.isdir(os.path.join(ROOT, "psx_tools")):
    _parent = os.path.dirname(ROOT)
    if os.path.isdir(os.path.join(_parent, "psx_tools")):
        ROOT = _parent
sys.path.insert(0, os.path.join(ROOT, "psx_tools"))
sys.path.insert(0, HERE)  # hbe lives inside translation-tools/

from dq4 import hbd, huffman, mips, referrers
from dq4.iso import RawISO
from hbe.compression.lzss import lzss_uncompress
from hbe.compression.dqlzs import compress_to_slot

PRISTINE_DEFAULT = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
MASTER_DEFAULT = os.path.join(ROOT, "build", "dq4_sovereign_master.bin")
HBD_LBA = 362
RAW = 2352
USZ = 2048
UOFF = 24
T26_RECORD_WORDS = referrers.T26_RECORD_WORDS
T26_REF_WORDS = referrers.T26_REF_WORDS

# blocks whose referrers have dedicated context-gated lanes (A.1 / STEP 1e /
# A.2). Blind ordinal remap of these is FORBIDDEN (COP collisions, artifact
# pads, the 048B runaway class). Lane C/D scope = every other re-encoded tid.
EXCLUDED_TARGETS = {0x048B}


def load_arch(path):
    with RawISO(path) as disc:
        return disc.read(HBD_LBA, (disc.sector_count - HBD_LBA) * 2048)


def load_exe_bytes(disc):
    found = disc.find("SLPM_869.16")
    if not found:
        raise SystemExit("[FAIL] SLPM_869.16 not found on disc")
    return disc.extract(*found)


def decode_at(tb, bit_off, tree, n=512):
    """Decode one string starting at bit offset (from block code start)."""
    pos = tb.c + bit_off // 8
    bit = bit_off % 8
    out = []
    nn = tree.root
    while len(out) < n and pos < tb.e:
        b = (tb.raw[pos] >> bit) & 1
        bit += 1
        if bit == 8:
            bit = 0
            pos += 1
        idx = tree.slot(nn, b)
        if idx >= tree.n:
            break
        kind, val = tree.entry(idx)
        if kind == huffman.NODE:
            nn = val
        else:
            out.append((kind, val))
            nn = tree.root
    return huffman.render(out)


class BlockPair:
    __slots__ = ("tb_p", "tb_m", "offs_p", "offs_m", "trees")

    def __init__(self, tb_p, offs_p, tb_m, offs_m):
        self.tb_p, self.tb_m = tb_p, tb_m
        self.offs_p, self.offs_m = offs_p, offs_m
        self.trees = (huffman.HuffmanTree(tb_p), huffman.HuffmanTree(tb_m))


def norm_decode(txt):
    """Normalize a fullwidth huffman render to corpus EN form."""
    out = []
    for ch in txt:
        o = ord(ch)
        if 0xFF01 <= o <= 0xFF5E:
            out.append(chr(o - 0xFEE0))
        else:
            out.append(ch)
    s = "".join(out)
    s = s.replace("<END>", "{0000}")
    import re
    s = re.sub(r"<7F([0-9A-Fa-f]{2})>", r"{7f\1}", s)
    s = re.sub(r"\{7E[0-9A-Fa-f]{2}\}", "", s)
    s = re.sub(r"<7E[0-9A-Fa-f]{2}>", "", s)
    return s


def load_corpus():
    import json
    p = os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json")
    with open(p, "r", encoding="utf-8") as f:
        return json.load(f)


def corpus_blob(seqs):
    """All shipped EN for a block, normalized, as one searchable blob."""
    parts = []
    for v in seqs.values():
        t = v.get("translation") if isinstance(v, dict) else v
        if isinstance(t, str):
            parts.append(norm_decode(t.replace("{0000}", " ")))
    return "".join(parts)


def build_stale_map(parch, march, corpus=None):
    """{old_word: (new_word, tid, i)} — ordinal pairing, corpus-verified.

    Every candidate pair (tid, i) is accepted ONLY if the master block's
    string #i decodes (normalized) to exactly the shipped corpus EN for
    (block, seq=i+1). This proves the ordinal pairing against the very text
    the game will show, and automatically rejects container-block garbage.
    """
    blocks_p = hbd.scan_blocks(parch)
    blocks_m = hbd.scan_blocks(march)
    index_p = referrers.block_index(parch, blocks_p)
    index_m = referrers.block_index(march, blocks_m)

    # distinct content copies per tid on the master (ambiguity guard)
    copies_m = {}
    for sector, sub in sorted(hbd.text_sub_blocks(blocks_m),
                              key=lambda p: (p[0], p[1]["idx"])):
        tb = None
        try:
            from dq4 import textblock
            tb = textblock.TextBlock(hbd.sub_bytes(march, sub))
        except Exception:
            continue
        copies_m.setdefault(tb.id, {})[hash(tb.raw.tobytes() if hasattr(tb.raw, "tobytes") else tb.raw)] = None

    stale = {}
    n_reenc = n_pairs = n_ambiguous = n_shrunk = n_cfail = 0
    cf_details = {}
    for tid, (tb_p, offs_p, _pos) in index_p.items():
        if tid in EXCLUDED_TARGETS:
            continue
        ent_m = index_m.get(tid)
        if ent_m is None:
            continue
        tb_m, offs_m, _posm = ent_m
        if tb_p.raw == tb_m.raw:
            continue
        n_reenc += 1
        if len(copies_m.get(tid, {})) > 1:
            n_ambiguous += 1
            continue
        p_n, m_n = len(offs_p), len(offs_m)
        if m_n < p_n:
            n_shrunk += 1
            continue
        use = offs_m[:p_n] if m_n > p_n else offs_m
        blk = "%04x" % tid
        seqs = corpus.get(blk, {}) if corpus else None
        blob = corpus_blob(seqs) if seqs else None
        tree_m = huffman.HuffmanTree(tb_m)
        words = {}
        n_str_fail = 0
        n_str_try = 0
        for i in range(p_n - 1):  # exclude trailing residue (referrers._resolve rule)
            op, om = offs_p[i], use[i]
            if op == om:
                continue
            n_str_try += 1
            if blob is not None:
                try:
                    dec = norm_decode(decode_at(tb_m, om, tree_m))
                except Exception:
                    n_str_fail += 1
                    continue
                probe = dec[:8].replace("{0000}", " ").strip()
                if len(probe) >= 4 and probe not in blob:
                    n_str_fail += 1
                    continue
            wp = (tid << 20) | (tb_p.c * 8 + op)
            wm = (tid << 20) | (tb_m.c * 8 + om)
            words[wp] = (wm, tid, i)
        if n_str_try and n_str_fail * 5 > n_str_try:
            n_cfail += 1
            cf_details[tid] = n_str_fail
            continue  # block-level exclusion: pairing unreliable
        if words:
            stale.update(words)
            n_pairs += 1
    return stale, n_reenc, n_pairs, n_ambiguous, n_shrunk, n_cfail, cf_details, index_p, index_m


def exe_block_pairs(pexe, mexe):
    """stale words for EXE-resident re-encoded blocks."""
    load, _pc, tsize, toff = mips.exe_mapping(pexe)
    load_m, _pcm, tsize_m, toff_m = mips.exe_mapping(mexe)
    if load != load_m or tsize != tsize_m:
        print("  [WARN] EXE load/tsize differ pristine vs master -- EXE-resident handling skipped")
        return {}, (0, 0)
    bp = referrers.exe_blocks(pexe, load, toff, tsize)
    bm = referrers.exe_blocks(mexe, load, toff, tsize)
    by_id_p = {tb.id: (va, tb) for va, tb in bp}
    by_id_m = {tb.id: (va, tb) for va, tb in bm}
    stale = {}
    n_reenc = n_skipped = 0
    for bid, (va_p, tb_p) in by_id_p.items():
        if bid in EXCLUDED_TARGETS:
            continue
        ent = by_id_m.get(bid)
        if ent is None:
            continue
        va_m, tb_m = ent
        if tb_p.raw == tb_m.raw:
            continue
        n_reenc += 1
        offs_p = huffman.string_offsets(tb_p)
        offs_m = huffman.string_offsets(tb_m)
        p_n, m_n = len(offs_p), len(offs_m)
        print("    exe block 0x%04X: strings %d -> %d" % (bid, p_n, m_n))
        if m_n < p_n:
            n_skipped += 1
            continue
        use = offs_m[:p_n] if m_n > p_n else offs_m
        words = {}
        for i in range(p_n - 1):
            op, om = offs_p[i], use[i]
            if op == om:
                continue
            wp = (bid << 20) | (tb_p.c * 8 + op)
            wm = (bid << 20) | (tb_m.c * 8 + om)
            words[wp] = (wm, bid, i)
        if words:
            stale.update(words)
    return stale, (n_reenc, n_skipped)


def word_offsets_for(stype):
    if stype == 26:
        return ("record", T26_RECORD_WORDS, T26_REF_WORDS)
    if stype == 44:
        return ("aligned", 0, 0)
    return None


def scan_words(img, stype):
    kind, rec, refw = word_offsets_for(stype)
    out = []
    if kind == "aligned":
        for o in range(0, len(img) - 3, 4):
            out.append((o, struct.unpack_from("<I", img, o)[0]))
    else:
        n_rec = len(img) // (rec * 4)
        for r in range(n_rec):
            base = r * rec * 4
            for k in range(refw):
                o = base + 4 * k
                out.append((o, struct.unpack_from("<I", img, o)[0]))
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=MASTER_DEFAULT)
    ap.add_argument("--base", default=PRISTINE_DEFAULT)
    ap.add_argument("--write", action="store_true", help="apply (default is report-only)")
    args = ap.parse_args()

    print("=" * 70)
    print("  LANE C/D: TABLE/ROSTER/EXE stale-ref remap (content-gated)")
    print("=" * 70)

    parch = load_arch(args.base)
    march = load_arch(args.disc)
    print("  pristine %d B, master %d B" % (len(parch), len(march)))

    stale, n_reenc, n_pairs, n_amb, n_shr, n_cfail, cf_details, index_p, index_m = build_stale_map(
        parch, march, corpus=load_corpus())
    print("  archive: %d re-encoded, %d corpus-verified pairs, %d ambiguous, %d shrunk, %d corpus-fail"
          % (n_reenc, n_pairs, n_amb, n_shr, n_cfail))
    if cf_details:
        top = sorted(cf_details.items(), key=lambda kv: -kv[1])[:10]
        print("    corpus-fail tids (top): %s" % ["0x%04X(%d)" % (t, c) for t, c in top])
    print("  archive distinct stale words: %d" % len(stale))

    # EXE
    with RawISO(args.base) as dp:
        pexe = load_exe_bytes(dp)
    with RawISO(args.disc) as dm:
        mexe = load_exe_bytes(dm)
        exe_lba, _exe_len = dm.find("SLPM_869.16")
    exe_stale, (er, esk) = exe_block_pairs(pexe, mexe)
    print("  exe-resident: %d re-encoded, %d skipped; stale words: %d" % (er, esk, len(exe_stale)))

    all_stale = {}
    for w, v in stale.items():
        all_stale.setdefault(w, v)
    for w, v in exe_stale.items():
        if w in all_stale and all_stale[w][0] != v[0]:
            print("  [CONFLICT] word 0x%08X maps two ways -- skipped" % w)
            continue
        all_stale[w] = v

    blocks_m = hbd.scan_blocks(march)
    subs = sorted(hbd.sub_blocks(blocks_m), key=lambda p: (p[0], p[1]["idx"]))

    # ---------------- EXE scan -------------------------------------------
    tsize = struct.unpack_from("<I", pexe, 0x1C)[0]
    exe_writes = []
    for o in range(0x800, min(tsize, len(mexe) - 4), 4):
        wm = struct.unpack_from("<I", mexe, o)[0]
        wp = struct.unpack_from("<I", pexe, o)[0]
        if wm != wp:
            continue  # changed by another lane / code -- never touch
        hit = all_stale.get(wm)
        if hit is None:
            continue
        exe_writes.append((o, hit[0]))

    # ---------------- archive scan ---------------------------------------
    plan = {}
    skipped = []
    for sec, sb in subs:
        if sb["type"] not in (26, 44):
            continue
        if sb["compressed"]:
            try:
                img = bytearray(lzss_uncompress(hbd.sub_bytes(march, sb), expected_size=sb["ulen"]))
            except Exception as e:
                skipped.append((sec, sb["idx"], sb["type"], "decompress fail: %s" % e))
                continue
        else:
            img = bytearray(hbd.sub_bytes(march, sb))
        writes = []
        for o, w in scan_words(img, sb["type"]):
            hit = all_stale.get(w)
            if hit is None:
                continue
            writes.append((o, hit[0]))
        if writes:
            plan[(sec, sb["idx"])] = (sb, img, writes)

    print()
    print("  EXE words to rewrite       : %d" % len(exe_writes))
    print("  archive sub-blocks w/writes: %d (of %d type-26/44 scanned)"
          % (len(plan), sum(1 for _s, sb in subs if sb["type"] in (26, 44))))
    bt = {26: 0, 44: 0}
    wc = {26: 0, 44: 0}
    per_tid = {}
    for (sec, idx), (sb, _img, writes) in plan.items():
        bt[sb["type"]] += 1
        wc[sb["type"]] += len(writes)
        for _o, w in writes:
            per_tid[w >> 20] = per_tid.get(w >> 20, 0) + 1
    print("    type-26: %d blocks / %d words | type-44: %d blocks / %d words"
          % (bt[26], wc[26], bt[44], wc[44]))
    print("    archive hits by target tid (top 15): %s"
          % sorted(per_tid.items(), key=lambda kv: -kv[1])[:15])
    ex_tid = {}
    for _o, w in exe_writes:
        ex_tid[w >> 20] = ex_tid.get(w >> 20, 0) + 1
    print("    EXE hits by target tid: %s" % sorted(ex_tid.items(), key=lambda kv: -kv[1]))

    # sample decodes: prove old word = salad, new word = correct string
    def sample(label, items, want):
        print("    --- %s samples ---" % label)
        shown = 0
        for o, w in items:
            hit = all_stale.get(w if isinstance(w, int) else w)
            pass
        for site, w in [(s, w) for s, w in items]:
            hit = all_stale.get(w)
            if hit is None:
                continue
            new_w, tid, i = hit
            ent_p = index_p.get(tid)
            ent_m = index_m.get(tid)
            if ent_p is None or ent_m is None:
                continue
            tbp, offsp, _ = ent_p
            tbm, offsm, _ = ent_m
            if i >= len(offsm):
                continue
            try:
                old_txt = decode_at(tbp, w & 0xFFFFF - tbp.c * 8, huffman.HuffmanTree(tbp), n=60)
                new_txt = decode_at(tbm, new_w & 0xFFFFF - tbm.c * 8, huffman.HuffmanTree(tbm), n=60)
            except Exception as e:
                old_txt = new_txt = "decode error %s" % e
            print("      site %s word 0x%08X -> 0x%08X (tid 0x%04X #%d)" % (site, w, new_w, tid, i))
            print("        OLD: %r" % old_txt[:70])
            print("        NEW: %r" % new_txt[:70])
            shown += 1
            if shown >= want:
                break

    sample("EXE", [(hex(o), w) for o, w in exe_writes], 6)
    arch_items = []
    for (sec, idx), (sb, img, writes) in sorted(plan.items()):
        for o, w in writes:
            arch_items.append(("sec %d sub %d +0x%X" % (sec, idx, o), w))
    sample("ARCHIVE", arch_items, 6)

    for sec, idx, stype, why in skipped:
        print("    [SKIP] sec %d sub %d type %d: %s" % (sec, idx, stype, why))

    # fit gate
    fit_fail = []
    for (sec, idx), (sb, img, writes) in sorted(plan.items()):
        if not sb["compressed"]:
            continue
        for o, w in writes:
            struct.pack_into("<I", img, o, w)
        try:
            rec = compress_to_slot(bytes(img), sb["dlen"], max_slack=3)
            chk = lzss_uncompress(rec, expected_size=sb["ulen"])
            if chk[:len(img)] != bytes(img):
                fit_fail.append((sec, idx, "roundtrip mismatch"))
        except Exception as e:
            fit_fail.append((sec, idx, str(e)))
    if fit_fail:
        print("  [ABORT] %d compressed sub-blocks failed fit/roundtrip:" % len(fit_fail))
        for sec, idx, why in fit_fail:
            print("    sec %d sub %d: %s" % (sec, idx, why))
        return 2
    print("  fit gate: %s" % ("ALL PASS" if plan else "n/a"))

    if not args.write:
        print("  REPORT ONLY -- nothing written. Re-run with --write to apply.")
        return 0

    # ---------------- apply EXE -------------------------------------------
    for o, w in exe_writes:
        struct.pack_into("<I", mexe, o, w)
    with open(args.disc, "r+b") as f:
        for i in range((len(mexe) + USZ - 1) // USZ):
            chunk = mexe[i * USZ:(i + 1) * USZ]
            if len(chunk) < USZ:
                chunk = chunk + b"\x00" * (USZ - len(chunk))
            f.seek((exe_lba + i) * RAW + UOFF)
            f.write(chunk)

    # ---------------- apply archive ---------------------------------------
    def arch_write(f, off, data):
        while data:
            sec = off // USZ
            inoff = off % USZ
            n = min(USZ - inoff, len(data))
            f.seek((HBD_LBA + sec) * RAW + UOFF + inoff)
            f.write(data[:n])
            off += n
            data = data[n:]

    with open(args.disc, "r+b") as f:
        for (sec, idx), (sb, img, writes) in sorted(plan.items()):
            for o, w in writes:
                struct.pack_into("<I", img, o, w)
            data = bytes(img)
            if sb["compressed"]:
                data = compress_to_slot(data, sb["dlen"], max_slack=3)
            assert len(data) == sb["dlen"], "slot size drift sec %d sub %d" % (sec, idx)
            arch_write(f, sb["off"], data)

    print("  wrote EXE words: %d | archive sub-blocks patched: %d" % (len(exe_writes), len(plan)))
    print("  NOTE: re-run edcre (STEP 5) -- EXE sectors and archive sectors changed.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
