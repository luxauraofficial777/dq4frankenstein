#!/usr/bin/env python3
"""
patch_save_menu.py -- Injects English Save Menu & Memory Card text (Block 0x0474).

Block 0x0474 has 27 sequences, original size 1,620 bytes (tre=1008, dataDA=612).
Re-encoded English text + tree fits within 850 bytes (budget 974 bytes).
Preserves the 612 trailing bytes of dataDA tables and writes in-place to the disc.
"""

import argparse
import json
import os
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.length_limited import build_tree_length_limited
import dq4_hbd_patcher as P

RAW, UOFF, USZ = 2352, 24, 2048
EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")
JSON_PATH = os.path.join(ROOT, "translation", "block_0474_save_menu.json")
BLOCK_ID = 0x0474


def find_block_0474(disc_path):
    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        tot = f.tell() // RAW
        CHUNK = 2048
        for s_start in range(100000, tot, CHUNK):
            n_sec = min(CHUNK, tot - s_start)
            f.seek(s_start * RAW)
            raw = f.read(n_sec * RAW)
            for i in range(n_sec):
                sec = s_start + i
                u = raw[i * RAW + UOFF : i * RAW + UOFF + USZ]
                for off in range(0, USZ - 24, 4):
                    end, bid, hts, tre, txe, unk = struct.unpack_from("<6I", u, off)
                    if (bid & 0xFFFF) == BLOCK_ID and hts == 24 and 24 < txe < end <= 4096:
                        return sec, off, (end, bid, hts, tre, txe, unk)
    return None, None, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_playability_master.bin"))
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.disc):
        raise SystemExit(f"[FAIL] Disc not found: {args.disc}")

    sec, off, hdr = find_block_0474(args.disc)
    if sec is None:
        raise SystemExit("[FAIL] Block 0x0474 not found on disc")

    end, bid, hts, tre, txe, unk = hdr
    print(f"  Found Block 0x0474 at Sector {sec}, offset 0x{off:04X} (end={end}, tre={tre})")

    # Read original block
    sectors_needed = ((off + end + USZ - 1) // USZ) + 1
    raw_data = bytearray()
    with open(args.disc, "rb") as f:
        for s in range(sec, sec + sectors_needed):
            f.seek(s * RAW + UOFF)
            raw_data.extend(f.read(USZ))
    orig_blk = bytes(raw_data[off : off + end])

    # Load translated sequences
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        trans = json.load(f)

    sc = DQ4Schema()
    new_leaves = []
    for item in trans:
        txt = item.get("en") or item["jp"]
        # 0x0474 renders through the Font-1 (menu) engine, but fullwidth=True
        # writes 0x82xx values that hbe's parser reads as BRANCH ids
        # (0x828E -> branch 654 -> "Tree parse out of bounds"). Stripped
        # codes are the only storable form; the renderer ORs 0x80 back.
        new_leaves.extend(P.text_to_leaves(txt, fullwidth=False))

    freq = {}
    for l in new_leaves:
        freq[l.content] = freq.get(l.content, 0) + 1

    budget = tre - hts - 10
    best = None
    for ml in (12, 11, 13, 10, 14):
        try:
            t = build_tree_length_limited(freq, schema=None, max_len=ml)
            tb = sc.write_tree(t)
            tx = sc.encode(new_leaves, t)
        except Exception:
            continue
        tot = len(tx) + len(tb)
        if tot <= budget and (best is None or tot < best[0]):
            best = (tot, t, tx, tb)

    if best is None:
        raise SystemExit(f"[FAIL] Could not fit Block 0x0474 in {budget} bytes")

    tot, ntree, ntext, ntreeb = best
    ntext_pad = ntext + b"\x00" * (budget - len(ntext) - len(ntreeb))
    new_txe = hts + len(ntext_pad)
    new_tree_start = new_txe + 10
    new_tree_mid = new_tree_start + (len(ntreeb) // 2) - 1
    num_branches = len(ntree.branch_nodes())

    blk = bytearray()
    blk += struct.pack("<6I", end, bid, hts, tre, new_txe, unk)
    blk += ntext_pad
    blk += struct.pack("<IIH", new_tree_start, new_tree_mid, num_branches)
    blk += ntreeb
    blk += orig_blk[tre:end]
    assert len(blk) == end, f"Block length mismatch: {len(blk)} != {end}"

    print(f"  Re-encoded 0x0474: text={len(ntext)}B, tree={len(ntreeb)}B, total={tot}/{budget}B (left: {budget - tot}B)")

    if args.report:
        print("  REPORT ONLY -- nothing written")
        return 0

    # Write block to disc across sectors
    with open(args.disc, "r+b") as f:
        written = 0
        cur_sec = sec
        cur_off = off
        while written < len(blk):
            chunk_len = min(len(blk) - written, USZ - cur_off)
            f.seek(cur_sec * RAW + UOFF + cur_off)
            f.write(blk[written : written + chunk_len])
            written += chunk_len
            cur_sec += 1
            cur_off = 0

    print(f"  Injected Block 0x0474 into {args.disc}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
