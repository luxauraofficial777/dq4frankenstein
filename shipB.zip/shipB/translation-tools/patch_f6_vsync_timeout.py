#!/usr/bin/env python3
"""
patch_f6_vsync_timeout.py

F6 Cynthia speech freeze fix: VSync timeout panic -> graceful return.

ROOT CAUSE:
  During Cynthia's speech, an overlay load triggers IntDisable (0x8007A05C)
  via the overlay remap function at 0x8007FE38. If the VSync interrupt is
  missed for too long, the VSync counter at 0x800BA294 stops incrementing.
  The timeout loop at 0x80099F18 detects this and panics with "VSync: timeout",
  calling BIOS exit and freezing the game.

FIX:
  Replace the panic path at 0x80099F60 (10 instructions) with a direct jump
  to the function epilogue at 0x80099FA0. This converts the fatal timeout
  into a graceful return, allowing the game to continue without freezing.

  The VSync wait will simply return early if the counter hasn't reached the
  target, causing at most a minor visual desync (one skipped frame) instead
  of a hard freeze.

PATCH:
  File offset 0x82860 (RAM 0x80099F60):
    0x080267E8  j 0x80099FA0   (jump to epilogue)
    0x00000000  nop             (delay slot)

  The remaining 8 instructions (0x82868-0x82884) become dead code, never reached.
"""
import struct
import sys
import os
import subprocess

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# Disc sector geometry (matches patch_exe_blocks.py)
RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA, EXE_SECTORS = 24, 338
EXE_SIZE = EXE_SECTORS * USZ

# PSX EXE load address (from header at offset 0x18)
RAM_BASE = 0x80017700

# Patch target
PANIC_RAM = 0x80099F60
PANIC_EXE_OFFSET = PANIC_RAM - RAM_BASE  # 0x82860

# Expected original bytes at panic site
EXPECTED_ORIG = (0x3C048002, 0x0C029728)  # lui $a0, 0x8002 ; jal 0x800a5ca0

# Patch bytes: j 0x80099FA0 + nop
J_TARGET = 0x08000000 | ((0x80099FA0 & 0x0FFFFFFF) >> 2)  # 0x080267E8
NOP = 0x00000000

EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")


def is_disc_image(path):
    """Detect if the file is a MODE2/2352 disc image or a raw PS-X EXE."""
    with open(path, "rb") as f:
        head = f.read(16)
    return head[:8] != b"PS-X EXE"


def read_exe_from_disc(disc_path):
    """Read the EXE from a MODE2/2352 disc image (LBA 24-361)."""
    exe = bytearray()
    with open(disc_path, "rb") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            exe.extend(f.read(USZ))
    return exe[:EXE_SIZE]


def write_exe_to_disc(disc_path, exe_data):
    """Write the EXE back to a MODE2/2352 disc image per-sector."""
    with open(disc_path, "r+b") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            f.write(bytes(exe_data[i * USZ:(i + 1) * USZ]))


def apply_patch(disc_path, verify_only=False):
    """Apply the VSync timeout patch to the master binary."""

    disc = is_disc_image(disc_path)
    if disc:
        print("  Mode: disc image (MODE2/2352, LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))
        exe = read_exe_from_disc(disc_path)
    else:
        print("  Mode: raw PS-X EXE")
        with open(disc_path, "rb") as f:
            exe = bytearray(f.read())

    print("  EXE size: %d bytes (0x%X)" % (len(exe), len(exe)))

    if PANIC_EXE_OFFSET + 8 > len(exe):
        print("[FAIL] Patch offset 0x%X is beyond EXE size" % PANIC_EXE_OFFSET)
        sys.exit(1)

    orig = struct.unpack_from("<II", exe, PANIC_EXE_OFFSET)
    print("  Patch target: RAM 0x%08X, EXE offset 0x%X" % (PANIC_RAM, PANIC_EXE_OFFSET))
    print("  Original bytes: 0x%08X 0x%08X" % orig)

    if orig != EXPECTED_ORIG:
        print("[FAIL] Expected %08X %08X but found %08X %08X" % (EXPECTED_ORIG[0], EXPECTED_ORIG[1], orig[0], orig[1]))
        print("  This doesn't look like the VSync timeout panic site.")
        sys.exit(1)
    print("  [OK] Verified: this is the VSync timeout panic site")

    if verify_only:
        print("  [VERIFY] Patch not applied (verify-only mode)")
        return

    print("  Patching: j 0x80099FA0 = 0x%08X, nop = 0x%08X" % (J_TARGET, NOP))
    struct.pack_into("<II", exe, PANIC_EXE_OFFSET, J_TARGET, NOP)

    patched = struct.unpack_from("<II", exe, PANIC_EXE_OFFSET)
    print("  Verify: 0x%08X 0x%08X" % patched)
    if patched != (J_TARGET, NOP):
        print("[FAIL] Patch verification failed!")
        sys.exit(1)
    print("  [OK] Patch verified")

    if disc:
        write_exe_to_disc(disc_path, exe)
        print("  EXE written back to disc (LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))
        if os.path.exists(EDCRE):
            print("  Regenerating EDC/ECC...")
            r = subprocess.run([EDCRE, disc_path], capture_output=True, text=True, timeout=900)
            ok = r.returncode == 0
            print("  EDC/ECC: %s" % ("PASS" if ok else "FAIL"))
            if not ok:
                print("  stderr: %s" % r.stderr[-400:])
                sys.exit(1)
        else:
            print("  [WARN] edcre not found -- EDC/ECC not regenerated")
    else:
        with open(disc_path, "wb") as f:
            f.write(exe)
        print("  EXE written back")

    print("  [DONE] VSync timeout panic patched to graceful return")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(description="F6 VSync timeout patch (Cynthia freeze fix)")
    ap.add_argument("--disc", required=True, help="Path to master disc binary or raw EXE")
    ap.add_argument("--verify", action="store_true", help="Verify only, don't patch")
    args = ap.parse_args()

    print("F6 VSync Timeout Patch")
    print("  Disc: %s" % args.disc)
    apply_patch(args.disc, verify_only=args.verify)
