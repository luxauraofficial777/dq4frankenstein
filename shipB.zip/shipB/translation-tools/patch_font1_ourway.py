#!/usr/bin/env python3
"""
patch_font1_ourway.py -- Font 1 menu injection (block 0x048C), OUR pipeline.

No psx_tools. Uses our hbe DQ4Schema (the same encoder that patches dialogue
correctly) and our dq4_hbd_patcher helpers. The ONE fact kept from RadMage is
that the resident atlas already renders fullwidth Latin -- and our own
text_to_leaves() already emits those codes, so nothing of his encoder is used.

Verified against the retail EXE (not his lib):
  - SLPM_869.16 is a PS-X EXE; t_addr = 0x80017F00, text at file 0x800, so
    file = va - 0x80017700.
  - Block 0x048C at file 0x097AC8, 780 strings, treeEnd = 0 (tree runs to end).
  - It has NO in-block pointer table; it is referenced by 1,202 EXE words of
    the form (0x048C << 20) | (bit offset + hts*8), each landing exactly on a
    string start. Controls (neighbouring ids, 1-bit shift) give 0 hits, so the
    resolve test has a measured 0 false-positive rate.

Font 1 label policy (user): disemvowel + 3 letters per word. Font 2 dialogue is
untouched (that is the HBD patcher's job, full English).
"""

import argparse
import os
import re
import struct
import subprocess
import sys

sys.stdout.reconfigure(line_buffering=True)

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)
sys.path.insert(0, HERE)

from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.length_limited import build_tree_length_limited
import dq4_hbd_patcher as P

RAW, UOFF, USZ = 2352, 24, 2048
DISC = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")
BLOCK_ID = 0x048C

# --- Font 1 labels: OURS. disemvowel + 3 letters/word ----------------------
FONT1_MAX = 3
VOWELS = "AEIOUaeiou"
FONT1_WORDS = {"sword": "SWD"}

FONT1_COMMANDS = {
    # Boot / Name entry / System
    41: "SLOT", 74: "GNDR SET", 557: "GNDR", 582: "ENTR NAME",
    9: "ITM", 77: "TAC", 88: "BAG", 576: "TAC", 577: "TAC", 580: "FGT", 581: "WHO", 583: "---",

    # Overworld signpost prompts
    625: "{7F34} RED SGN.{7F0A}",
    627: "{7F34} RED SGN.{7F0A}{7F01}BCK SD.{7F01}CNT RED.{7F0B}",

    # Search "nothing found" lines (Lane E: blueprint §3)
    31: "NOT FND", 35: "NOT FND",
    585: "NOT FND{7F0B}", 598: "NOT FND{7F0B}",

    # Status-ailment message words (Lane E: blueprint §3)
    647: "BAD PSN", 648: "PSN", 649: "PAR",

    # Tactics (Groups 49 & 50)
    710: "BAL", 711: "GO!", 712: "MAN", 713: "HLP", 714: "NMG", 715: "OWN",
    716: "BAL", 717: "GO!", 718: "ETC", 719: "REC",

    # Combat actions
    720: "DMG", 721: "DFD", 722: "SKL", 723: "ATK", 724: "RUN", 725: "SWP",
    726: "FGT", 727: "END", 728: "MP",  729: "---",

    # Item/bag management & target selection
    730: "A-Z", 731: "TYP", 732: "ALL", 733: "WHO", 734: "WHO", 735: "EXT",
    736: "DRP", 737: "EQP", 738: "SHW", 739: "LUK",

    # Main field & system menus (Group 53 & secondary table 0x80020100)
    740: "GIV", 741: "USE", 742: "ACT", 743: "REC", 744: "BAG", 745: "ITM",
    746: "VAR", 747: "ORD", 748: "TAC", 749: "FUL", 750: "TAC", 751: "SRC",
    752: "SPL", 753: "STS", 754: "ITM", 755: "TLK", 756: "PRT", 757: "N",
    758: "Y",   759: "LOG", 760: "CFG", 761: "CPY", 762: "DLT", 763: "STR",
    764: "NEW", 765: "BAG", 766: "F",   767: "M",   768: "ALL",

    # Secondary field actions (Group 53 / status / equip)
    558: "ITM", 562: "STS", 565: "SPL", 568: "TAC", 569: "EQP", 570: "WPN",
    571: "ARM", 572: "SHL", 573: "HLM", 574: "ACS",

    # Shop & church commands (SIDs 650-662)
    650: "CUR", 651: "CUR", 652: "---", 653: "WTD", 654: "DEP",
    655: "DTX", 656: "RES", 657: "DIV", 658: "PRY", 659: "SEL",
    660: "BUY", 661: "EXT", 662: "GNDR",

    # Status attributes (SIDs 663-676)
    663: "LVL", 664: "DEF", 665: "ATK", 666: "DEF", 667: "ATK",
    668: "LUK", 669: "WIS", 670: "RES", 671: "AGI", 672: "STR",
    673: "MP",  674: "HP",  675: "MMP", 676: "MHP",

    # Party/equip (SIDs 677-679)
    677: "OWN", 678: "---", 679: "REM",
}

FONT1_HEROES = {
    145: "SHR",
    146: "CHU",
    147: "VIL",
    148: "SAR",
    149: "SHR",
    150: "SOL",
    151: "SOF",
    152: "HER",
    153: "RAG",
    154: "SLD",
    155: "ALN",
    156: "PRN",
    157: "KRY",
    158: "PRS",
    159: "BRY",
    160: "MAG",
    161: "TOR",
    162: "MRC",
    163: "MNA",
    164: "DVN",
    165: "MYA",
    166: "DNC",
    167: "OLD",
    168: "FLR",
    169: "HLM",
    170: "HLM",
    171: "CHD",
    172: "THM",
    173: "SCT",
    174: "BDG",
    175: "LRL",
    176: "POE",
    177: "PST",
    178: "OJM",
    179: "ALC",
    180: "HFF",
    181: "HST",
    182: "PNN",
    183: "JST",
    184: "LCA",
    185: "ZEN",
    186: "DRN",
    187: "DRG",
    188: "PSR",
    189: "EVL",
    190: "ROS",
}
_STRIP = chr(39) + chr(34) + ".,()"


def _skeleton(word):
    if not word:
        return word
    if len(word) <= FONT1_MAX:
        return word.upper()
    out = [word[0]]
    for ch in word[1:]:
        if ch in VOWELS:
            continue
        if out and ch.upper() == out[-1].upper():
            continue
        out.append(ch)
    return "".join(out)[:FONT1_MAX].upper()


_TOKEN_PASSTHROUGH = re.compile(r"^\{[0-9a-fA-F]{4}\}$")
_TOKEN_EMBEDDED = re.compile(r"\{[0-9a-fA-F]{4}\}")


def font1_label(name):
    words = name.split()
    res = []
    for w in words:
        # RC-2 SAFEGUARD (EXE-resident wild tokens): a {XXXX} control token is
        # STRUCTURE, never a word. Before this guard, _skeleton() vowel-stripped
        # it into garbage glyphs ({7F06} -> "{7F6}", glued "X{7F0A}Y" -> "X{7FY}Y"),
        # silently shifting the encoded bit offsets of every later SID in the
        # block (the Font-1 offset-misalignment / formatting-stall class).
        # Control tokens -- pagination markers {7F01}/{7F02}/{7F0A}/{7F0B} and
        # the EXE-resident set {7F06}/{7F10}/{7F19}/{7F1B}/{7F1C}/{7F1E}/{7F35}
        # -- pass through verbatim, position-locked.
        if _TOKEN_PASSTHROUGH.match(w) or _TOKEN_EMBEDDED.search(w):
            res.append(w)
            continue
        core = w.strip(_STRIP).lower()
        res.append(FONT1_WORDS[core] if core in FONT1_WORDS else _skeleton(w))
    return " ".join(res)


def load_names():
    import json
    import re
    jp = re.compile(u"[぀-ヿ一-鿿]")
    # Audit (Sep-06): exe_block_048c_translated.json carries 236 codes written
    # as <7F02>/<7F15> instead of {7F02}. text_to_leaves() only parses {XXXX};
    # an angle/square-bracket code would be injected as six literal glyphs.
    # Today no live SID sources from that file (all 399+2 come from the first
    # two), so this guard is a zero-change safety net for Lane E widening.
    badcode = re.compile(r"[<\[][0-9a-fA-F]{4}[>\]]")
    out = {}
    # Gemini's exe_block_048c_translated_full.json translates all 779 SIDs, but
    # injecting ALL of them deepens the Huffman tree past the point where the
    # UI-advancement bit-deltas (SIDs 773-778) can be preserved, so the block
    # fails to delta-lock. We therefore inject the visible name ranges that DO fit
    # (items/weapons/armor, spells, hero/class names, status/shop labels) and
    # leave the rest to their (harmless) originals. Gemini's file is first in the
    # load list below so its versions win for these SIDs.
    # SHIP: inject the fitted name ranges PLUS the battle/field/system band
    # (combat words like DMG/ATK/FLE and menu labels) which are the highest-
    # frequency player-visible strings. Stops before 769 so the 773-778 UI
    # delta-anchor strings stay original; main()'s has_ctrl guard keeps
    # control-bearing prompts on their originals. If this overflows the
    # delta-lock the build fails loudly and we narrow the band.
    target_sids = (
        set(FONT1_COMMANDS.keys())
        | set(FONT1_HEROES.keys())
        | set(range(150, 191))    # hero / class names
        | set(range(265, 379))    # spell names
        | set(range(379, 401))    # weapons / artifacts
        | set(range(444, 520))    # armor / shields / helmets
        | set(range(650, 769))    # status/shop/church + battle words (DMG/ATK/FLE) + field/system menus
    )
    for fn in ("exe_block_048c_translated_full.json", "exe_block_048c_truncated.json", "exe_block_048c_master.json", "exe_block_048c_translated.json"):
        p = os.path.join(ROOT, "translation", fn)
        if not os.path.exists(p):
            continue
        try:
            d = json.load(open(p, encoding="utf-8"))
        except Exception:
            continue
        if not isinstance(d, dict):
            continue
        for k, v in d.items():
            if not str(k).isdigit() or not isinstance(v, dict):
                continue
            en = (v.get("en") or "").strip()
            if not en or en.startswith("STR ") or jp.search(en) or badcode.search(en):
                continue
            sid = int(k)
            if sid in target_sids:
                out.setdefault(sid, en)
    return out


# --- disc file IO, our way (raw sectors) -----------------------------------
def find_exe(disc):
    with open(disc, "rb") as f:
        f.seek(22 * RAW + UOFF)
        d = f.read(USZ)
    off = 0
    while off < len(d):
        rl = d[off]
        if rl == 0:
            break
        nl = d[off + 32]
        name = d[off + 33:off + 33 + nl].decode("ascii", "replace")
        if name.startswith("SL") and "SYSTEM" not in name:
            return (struct.unpack_from("<I", d, off + 2)[0],
                    struct.unpack_from("<I", d, off + 10)[0])
        off += rl
    raise SystemExit("[FAIL] executable not in ISO directory")


def read_exe(disc, lba, size):
    b = bytearray()
    with open(disc, "rb") as f:
        for i in range((size + USZ - 1) // USZ):
            f.seek((lba + i) * RAW + UOFF)
            b.extend(f.read(USZ))
    return bytearray(b[:size])


def is_control(leaf):
    v = (leaf.content[0] << 8) | leaf.content[1]
    return v == 0 or (v & 0x7F00) == 0x7F00


def split_strings(leaves):
    out, cur = [], []
    for l in leaves:
        cur.append(l)
        if ((l.content[0] << 8) | l.content[1]) == 0:
            out.append(cur)
            cur = []
    if cur:
        out.append(cur)
    return out


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_dialogue_en.bin"))
    ap.add_argument("--out", default=None, help="Optional output disc (copies --disc first)")
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()

    target_disc = args.disc
    if args.out and not args.report:
        import shutil
        print(f"Creating output disc: {args.out} (from {args.disc})")
        shutil.copyfile(args.disc, args.out)
        target_disc = args.out

    sc = DQ4Schema()
    lba, size = find_exe(target_disc if not args.report else DISC)
    exe = read_exe(target_disc if not args.report else DISC, lba, size)
    pristine = bytes(exe)

    # geometry from the PS-X EXE header
    _pc, _gp, taddr, tsize = struct.unpack_from("<4I", exe, 0x10)
    load = taddr - 0x800

    # locate 0x048C our way
    o = None
    for x in range(0, len(exe) - 24, 4):
        end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe, x)
        if (bid & 0xFFFF) == BLOCK_ID and hts == 24 and 24 < txe < end <= 8192:
            o = x
            break
    if o is None:
        raise SystemExit("[FAIL] 0x048C not found")
    end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe, o)
    tree_end_off = o + (te if te else end)

    tree = sc.parse_tree(exe[o + txe + 10:tree_end_off])
    leaves = sc.decode(exe[o + hts:o + txe], tree)
    old_offs = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]
    old_strings = split_strings(leaves)
    n = len(old_strings)

    names = load_names()
    # build new leaf stream: translate menu/name strings; keep control strings
    new_leaves = []
    translated = 0
    for i in range(n):
        st = old_strings[i]
        has_ctrl = any(is_control(l) and ((l.content[0] << 8) | l.content[1]) != 0
                       for l in st)
        label = None
        if i in FONT1_HEROES:
            label = FONT1_HEROES[i]
        elif i in FONT1_COMMANDS:
            label = FONT1_COMMANDS[i]
        elif i in names and not has_ctrl and i not in range(769, 780):
            label = font1_label(names[i])
        if label is not None and (i in FONT1_COMMANDS or
                                  (not has_ctrl and i not in range(769, 780))):
            # Lane E: FONT1_COMMANDS labels are authored as complete strings
            # (control skeleton included, e.g. 625 {7F34}...{7F0A}), so they may
            # override control-bearing originals. Everything else still obeys
            # the has_ctrl veto.
            txt = label if label.endswith("{0000}") else label + "{0000}"
            new_leaves.extend(P.text_to_leaves(txt))
            translated += 1
        else:
            new_leaves.extend(st)     # keep original (incl. its {0000})

    # re-encode with OUR hbe, finding a fitting tree that strictly preserves
    # engine-hardcoded bit deltas for UI text advancement and cursor blink:
    # Delta 774-773 == 44, Delta 776-775 == 36, Delta 777-775 == 50, Delta 778-775 == 66.
    base_freq = {}
    for l in new_leaves:
        base_freq[l.content] = base_freq.get(l.content, 0) + 1

    budget = end - hts - 10
    best = None
    # Prioritize 55 (instant 13-bit calibration for current 394 SIDs), plus 5, 1, 95
    dummy_order = [55, 5, 1, 95] + [x for x in range(250) if x not in (55, 5, 1, 95)]
    for dummies in dummy_order:
        tf = dict(base_freq)
        for d in range(dummies):
            tf[bytes([(0x0600 + d) >> 8, (0x0600 + d) & 0xFF])] = 1
        for ml in (13, 12, 14):
            try:
                t = build_tree_length_limited(tf, schema=None, max_len=ml)
                tb = sc.write_tree(t)
                tx = sc.encode(new_leaves, t)
                tot = len(tx) + len(tb)
                if tot > budget:
                    continue
                offs = [bo for _i, bo in P.compute_sequence_bit_offsets(new_leaves, t)]
                if (offs[774] - offs[773] == 44 and
                    offs[776] - offs[775] == 36 and
                    offs[777] - offs[775] == 50 and
                    offs[778] - offs[775] == 66):
                    best = (tot, t, tx, tb, dummies, ml, offs)
                    break
            except Exception:
                continue
        if best is not None:
            break

    if best is None:
        raise SystemExit("[FAIL] could not find delta-locked tree for 0x048C")
    _tot, ntree, ntext, ntreeb, opt_dummies, opt_ml, new_offs = best

    # budget: header(24)+text+treehdr(10)+tree must be <= end (treeEnd=0 form)
    if len(ntext) + len(ntreeb) > budget:
        raise SystemExit("[FAIL] 0x048C overflow: %d > %d (need shorter Font 1 labels)"
                         % (len(ntext) + len(ntreeb), budget))

    if len(new_offs) != len(old_offs):
        raise SystemExit("[FAIL] 0x048C string count drift %d != %d"
                         % (len(new_offs), len(old_offs)))

    # Invariant assertions: engine hardcoded deltas for text advances and cursor blinking
    assert new_offs[774] - new_offs[773] == 44, f"Delta 774-773 drifted: {new_offs[774] - new_offs[773]}"
    assert new_offs[776] - new_offs[775] == 36, f"Delta 776-775 drifted: {new_offs[776] - new_offs[775]}"
    assert new_offs[777] - new_offs[775] == 50, f"Delta 777-775 drifted: {new_offs[777] - new_offs[775]}"
    assert new_offs[778] - new_offs[775] == 66, f"Delta 778-775 drifted: {new_offs[778] - new_offs[775]}"

    omap = {old_offs[i]: new_offs[i] for i in range(len(old_offs))}

    # assemble the block: NO zero padding inside text stream
    # new_txe = hts + len(ntext) exactly; tree header follows immediately
    # padding only AFTER ntreeb up to end
    new_txe = hts + len(ntext)
    new_tree_start = new_txe + 10
    new_tree_mid = new_tree_start + (len(ntreeb) // 2) - 1
    num_branches = len(ntree.branch_nodes())
    blk = bytearray()
    blk += struct.pack("<6I", end, bid, hts, 0, new_txe, unk)  # treeEnd stays 0
    blk += ntext
    blk += struct.pack("<IIH", new_tree_start, new_tree_mid, num_branches)
    blk += ntreeb
    if len(blk) < end:
        blk += b"\x00" * (end - len(blk))
    blk = blk[:end]
    assert len(blk) == end, "block size drift %d != %d" % (len(blk), end)

    if not args.report:
        exe[o:o + end] = blk

    # remap referrers: EVERY word that resolved to an old string start.
    starts = set(old_offs)
    rewritten = 0
    changed_refs = []
    for w_off in range(0x800, tsize, 4):
        w = struct.unpack_from("<I", exe, w_off)[0]
        if (w >> 20) != BLOCK_ID:
            continue
        rel = (w & 0xFFFFF) - hts * 8
        if rel not in starts:
            continue
        new_rel = omap[rel] + hts * 8
        new_w = (BLOCK_ID << 20) | (new_rel & 0xFFFFF)
        if not args.report:
            struct.pack_into("<I", exe, w_off, new_w)
        rewritten += 1
        changed_refs.append(w_off)

    # Split-immediate referrers: lui reg,0x48C0 paired with an ori/addiu that
    # READS that reg (the offset is the low half). The prior clobber heuristic
    # matched only ~63 of ~297 pairs, leaving 234 pointing at PRISTINE offsets
    # -> stat labels, save/erase, shop & battle menus decoded from the wrong
    # address and rendered as scrambled glyphs (confirmed in the RAM dumps:
    # 234 stale split-immediates, every one landing on an OLD string start).
    # Robust scan: for each lui reg,0x48C0, walk forward up to 15 instructions to
    # the first ori/addiu that reads reg; stop early if reg is overwritten. This
    # finds all 297 and remaps each via omap.
    split_done = 0
    split_words = []
    _CLOBBER = (0x08, 0x0C, 0x0D, 0x0E, 0x0F, 0x20, 0x21, 0x23, 0x24, 0x25)
    for so in range(0x800, len(exe) - 4, 4):
        w1 = struct.unpack_from("<I", exe, so)[0]
        if (w1 >> 26) != 0x0F or (w1 & 0xFFFF) != (BLOCK_ID << 4):  # lui reg, 0x48C0
            continue
        reg1 = (w1 >> 16) & 0x1F
        for d in range(1, 16):
            off2 = so + d * 4
            if off2 + 4 > len(exe):
                break
            w2 = struct.unpack_from("<I", exe, off2)[0]
            op2 = w2 >> 26
            rs2 = (w2 >> 21) & 0x1F
            rt2 = (w2 >> 16) & 0x1F
            if op2 in (0x09, 0x0D) and rs2 == reg1:   # addiu/ori _, reg1, imm
                imm2 = w2 & 0xFFFF
                if op2 == 0x09:
                    simm2 = imm2 - 0x10000 if imm2 >= 0x8000 else imm2
                    val = ((w1 & 0xFFFF) << 16) + simm2
                else:
                    val = ((w1 & 0xFFFF) << 16) | imm2
                if (val >> 20) == BLOCK_ID:
                    rel = (val & 0xFFFFF) - hts * 8
                    if rel in starts:
                        new_word = (BLOCK_ID << 20) | ((omap[rel] + hts * 8) & 0xFFFFF)
                        n_hi = (new_word >> 16) & 0xFFFF
                        n_lo = new_word & 0xFFFF
                        if op2 == 0x09 and n_lo >= 0x8000:
                            n_hi = (n_hi + 1) & 0xFFFF
                        if not args.report:
                            struct.pack_into("<I", exe, so, (w1 & 0xFFFF0000) | n_hi)
                            struct.pack_into("<I", exe, off2, (w2 & 0xFFFF0000) | n_lo)
                        split_done += 1
                        split_words.extend([so, off2])
                break
            if rt2 == reg1 and op2 in _CLOBBER:   # reg reloaded before use
                break

    # containment: nothing outside the block and the referrer words may differ
    allowed = set(range(o, o + end))
    for wf in changed_refs:
        allowed.update(range(wf, wf + 4))
    for wf in split_words:
        allowed.update(range(wf, wf + 4))
    stray = [i for i in range(min(len(exe), len(pristine)))
             if exe[i] != pristine[i] and i not in allowed]

    print("=" * 66)
    print("  FONT 1 (0x048C) INJECTION -- OUR PIPELINE (hbe, no psx_tools)")
    print("=" * 66)
    print("  block            file 0x%06X  VA 0x%08X" % (o, o + load))
    print("  strings          %d   translated %d   (control-preserved kept)" % (n, translated))
    print("  code+tree        %d / %d bytes" % (len(ntext) + len(ntreeb), budget))
    print("  referrers rewrit %d  (of 1202 resolving; our-scan, 0 false pos)" % rewritten)
    print("  split-imm rewrit %d  (lui/ori pairs, our-verified)" % split_done)
    print("  delta-lock       PASS (774-773=%d, 776-775=%d, 777-775=%d, 778-775=%d)"
          % (new_offs[774] - new_offs[773], new_offs[776] - new_offs[775],
             new_offs[777] - new_offs[775], new_offs[778] - new_offs[775]))
    print("  stray writes     %d %s" % (len(stray), [hex(x) for x in stray[:6]]))
    if args.report:
        print("  REPORT ONLY -- nothing written")
        return 0
    if stray:
        raise SystemExit("[FAIL] containment: %d bytes outside block+referrers" % len(stray))

    # write EXE back into the disc (in place)
    with open(target_disc, "r+b") as f:
        for i in range((size + USZ - 1) // USZ):
            chunk = bytes(exe[i * USZ:(i + 1) * USZ])
            if len(chunk) < USZ:
                chunk = chunk + b"\x00" * (USZ - len(chunk))
            f.seek((lba + i) * RAW + UOFF)
            f.write(chunk)

    # Remap referrers across all HBD overlay sectors
    print("  Remapping referrers in HBD overlays...")
    hbd_lba_start = lba + ((size + USZ - 1) // USZ)
    hbd_words_rewritten = 0
    hbd_split_rewritten = 0
    hbd_sectors_modified = 0

    # Known field menu referrer offsets (original Japanese) from session progress
    # These are the split-immediate low halves at the 5 menu locations
    FIELD_MENU_ORIGINAL_OFFSETS = {
        0xA749: 752,  # SPL (じゅもん)
        0xA780: 754,  # ITM (どうぐ)
        0xA72C: 751,  # SRC (しらべる)
        0xA768: 753,  # STS (つよさ)
        0xA70F: 750,  # TCT (さくせん)
        0xA798: 755,  # TLK (はなす)
    }
    # Sectors using the alternative referrer format (48-byte field menu table at marker 0x48C0F457)
    ALT_FORMAT_SECTORS = {3191, 65873, 105952, 106254}

    with open(target_disc, "r+b") as f:
        f.seek(0, 2)
        tot_sectors = f.tell() // RAW
        for sec in range(hbd_lba_start, tot_sectors):
            f.seek(sec * RAW + UOFF)
            chunk = bytearray(f.read(USZ))
            if len(chunk) < USZ:
                chunk.extend(b"\x00" * (USZ - len(chunk)))
            modified = False

            # 1. Direct 32-bit words
            for off in range(0, USZ - 4, 4):
                w = struct.unpack_from("<I", chunk, off)[0]
                if (w >> 20) == BLOCK_ID:
                    rel = (w & 0xFFFFF) - hts * 8
                    if rel in starts:
                        new_rel = omap[rel] + hts * 8
                        new_w = (BLOCK_ID << 20) | (new_rel & 0xFFFFF)
                        struct.pack_into("<I", chunk, off, new_w)
                        hbd_words_rewritten += 1
                        modified = True

            # 2. Split-immediates: lui reg,0x48C0 + ori/addiu that READS reg
            # (result may land in a different register; stop if reg is reloaded).
            # The old rt2==reg1 restriction only matched ori reg,reg,imm and so
            # missed 234 overlay pairs (stat labels, save/erase, shop & battle
            # menus) -> they kept pristine offsets and rendered scrambled.
            for so in range(0, USZ - 8, 4):
                w1 = struct.unpack_from("<I", chunk, so)[0]
                if (w1 >> 26) != 0x0F or (w1 & 0xFFFF) != (BLOCK_ID << 4):
                    continue
                reg1 = (w1 >> 16) & 0x1F
                for d in range(4, min(64, USZ - so), 4):
                    w2 = struct.unpack_from("<I", chunk, so + d)[0]
                    op2 = w2 >> 26
                    rs2 = (w2 >> 21) & 0x1F
                    rt2 = (w2 >> 16) & 0x1F
                    if op2 in (0x09, 0x0D) and rs2 == reg1:
                        imm2 = w2 & 0xFFFF
                        if op2 == 0x09:
                            simm2 = imm2 - 0x10000 if imm2 >= 0x8000 else imm2
                            val = ((w1 & 0xFFFF) << 16) + simm2
                        else:
                            val = ((w1 & 0xFFFF) << 16) | imm2
                        if (val >> 20) == BLOCK_ID:
                            rel = (val & 0xFFFFF) - hts * 8
                            if rel in starts:
                                new_word = (BLOCK_ID << 20) | ((omap[rel] + hts * 8) & 0xFFFFF)
                                n_hi = (new_word >> 16) & 0xFFFF
                                n_lo = new_word & 0xFFFF
                                if op2 == 0x09 and n_lo >= 0x8000:
                                    n_hi = (n_hi + 1) & 0xFFFF
                                struct.pack_into("<I", chunk, so, (w1 & 0xFFFF0000) | n_hi)
                                struct.pack_into("<I", chunk, so + d, (w2 & 0xFFFF0000) | n_lo)
                                hbd_split_rewritten += 1
                                modified = True
                        break
                    if rt2 == reg1 and op2 in (0x08, 0x0C, 0x0D, 0x0E, 0x0F, 0x20, 0x21, 0x23, 0x24, 0x25):
                        break

            # 3. Alternative format at known field menu sectors (3191, 65873, 105952, 106254)
            # These sectors contain the 48-byte field menu table starting at anchor 0x48C0F457.
            # It maps the 6 field commands: SPL(+0x06), ITM(+0x0E), SRC(+0x15), STS(+0x1C), TCT(+0x24), TLK(+0x2A).
            if sec in ALT_FORMAT_SECTORS:
                pos = chunk.find(b"\x57\xf4\xc0\x48")
                if pos != -1:
                    cmd_offsets = [
                        (0x06, 752, "SPL"),
                        (0x0E, 754, "ITM"),
                        (0x15, 751, "SRC"),
                        (0x1C, 753, "STS"),
                        (0x24, 750, "TCT"),
                        (0x2A, 755, "TLK"),
                    ]
                    for rel_pos, sid, name in cmd_offsets:
                        orig_off = struct.unpack_from("<H", chunk, pos + rel_pos)[0]
                        orig_rel = orig_off - hts * 8
                        if orig_rel in omap:
                            new_off = omap[orig_rel] + hts * 8
                            struct.pack_into("<H", chunk, pos + rel_pos, new_off)
                            hbd_words_rewritten += 1
                            modified = True
                            print(f"    Remapped field menu cmd {name} at sector {sec} off=0x{pos+rel_pos:X}: 0x{orig_off:04X} -> 0x{new_off:04X} (SID {sid})")

            if modified:
                f.seek(sec * RAW + UOFF)
                f.write(chunk)
                hbd_sectors_modified += 1

    print("  HBD sectors mod  %d  (32-bit: %d, split-imm: %d)" % (hbd_sectors_modified, hbd_words_rewritten, hbd_split_rewritten))

    if os.path.exists(EDCRE):
        r = subprocess.run([EDCRE, target_disc], capture_output=True, text=True, timeout=900)
        print("  EDC/ECC          %s" % ("PASS" if r.returncode == 0 else "FAIL"))
    print("  disc             %s" % target_disc)
    return 0


if __name__ == "__main__":
    sys.exit(main())
