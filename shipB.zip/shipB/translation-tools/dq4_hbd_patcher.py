#!/usr/bin/env python3
"""
Python HBD patcher for DQ4 PSX text blocks.

Patches translated English text directly into HBD blocks found by scanning
raw HBD bytes, bypassing the Java HeartBeatDataFolderEntryReader which cannot
parse types 23/24/25/27 due to different file content structure.

Block format (from HeartBeatDataTextContentWriter.java):
  Header (24 bytes):
    end(4LE)       - total content size (header + unknown2 + text + treeHeader + tree + unknown3)
    id(4LE)        - block ID (text_id in lower 16 bits)
    hts(4LE)       - huffman text start (always 24)
    treeEnd(4LE)   - huffman tree end (0 if tree goes to end)
    textEnd(4LE)   - huffman text end
    unk1(4LE)      - unknown1 (preserved as-is)
  unknown2:        - bytes from offset+24 to offset+hts (usually empty)
  textBytes:       - Huffman-encoded text (offset+hts to offset+textEnd)
  Tree header (10 bytes):
    treeStart(4LE) - huffman tree start (= textEnd + 10)
    treeMiddle(4LE)- tree middle offset
    numNodes(2LE)  - number of branch nodes
  treeBytes:       - serialized Huffman tree
  unknown3:        - dataDA (preserved as-is)
  End marker (4 bytes):
    end(4LE)       - same as header end
  Dialog pointers:
    count(4LE)     - number of dialog pointers
    [variable(4LE), value(4LE)] * count

Usage:
  python dq4_hbd_patcher.py [--input disc.bin] [--translations full_translation.json] [--output patched.bin]
"""
import struct, os, sys, json, time, re, copy

WORKSPACE = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, os.path.join(WORKSPACE, 'translation-tools'))
from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.node import HuffmanNode
from hbe.huffman.builder import build_tree
from hbe.huffman.length_limited import build_tree_length_limited, max_code_length

RAW_SECTOR = 2352
USER_OFFSET = 24
USER_SIZE = 2048
DQ4_DISC = os.path.join(WORKSPACE, 'Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin')
DQ4_HBD_LBA = 362
TRANSLATIONS = os.path.join(WORKSPACE, 'translation', 'full_translation.json')
OUTPUT_BIN = os.path.join(WORKSPACE, 'dq4_patched_python.bin')

# DW7ASCII mapping (from DW7ASCII.java)
ASCII_TO_DW7 = {}
for i in range(26):
    ASCII_TO_DW7[chr(ord('A') + i)] = 0x0260 + i
for i in range(26):
    ASCII_TO_DW7[chr(ord('a') + i)] = 0x0281 + i
for i in range(10):
    ASCII_TO_DW7[chr(ord('0') + i)] = 0x024F + i

ASCII_TO_DW7[' ']  = 0x0140
ASCII_TO_DW7['.']  = 0x0144
ASCII_TO_DW7[',']  = 0x0143
ASCII_TO_DW7[':']  = 0x0146
ASCII_TO_DW7['?']  = 0x0148
ASCII_TO_DW7['!']  = 0x0149
ASCII_TO_DW7["'"]  = 0x0166
ASCII_TO_DW7['-']  = 0x015D
ASCII_TO_DW7['/']  = 0x015E
ASCII_TO_DW7['&']  = 0x0195
ASCII_TO_DW7['*']  = 0x0196
ASCII_TO_DW7['(']  = 0x0169
ASCII_TO_DW7[')']  = 0x016A
ASCII_TO_DW7['=']  = 0x0181
ASCII_TO_DW7['~']  = 0x0160


# ---------------------------------------------------------------- paginator
# Window geometry, measured from the shipped Japanese script and confirmed on
# screen: the engine draws its own leading glyphs on the FIRST line of a box,
# so line 0 holds 18 characters and later lines hold 20, and the Japanese runs
# three lines to a box before advancing.
#
# Control codes, decoded from the retail archive (NOT the same as the older
# constant table, which had 7F02 and 7F0A the wrong way round):
#   7F04  start of a speaker box      7F02  LINE break inside the box
#   7F0A  BOX advance (wait + clear)  7F0B  end of message
#
# This is STRUCTURE PRESERVING. It only ever INSERTS a break at a word
# boundary. It never deletes, reorders or rewrites a control code, and it
# never crosses a {0000}, so sequence-count parity is untouched.
PAGE_LINE0 = 18
PAGE_LINEN = 20
PAGE_LINES = 3

_TOKEN_RE = re.compile(r'\{[0-9a-fA-F]{4}\}')

# EXE-RESIDENT CONTROL CODES: canonical registry lives in control_library.py
# (master control library, Sep-08). The 7 EXE-resident wild tokens
# (7F06/7F10/7F19/7F1B/7F1C/7F1E/7F35) are pass-through, POSITION-LOCKED
# structure: text_to_leaves encodes them as control leaves, the paginator
# treats them as zero-width, and no pass may delete, reorder or reformat
# them. PAGINATOR_CTRL = {7F01, 7F02, 7F0A, 7F0B} are the message-flow
# markers: the paginator may insert around them, never rewrite them, and
# trim_trailing_garbage_leaves must never drop a sequence that carries one
# (a trailing {7f0a}-advance / {7f0b}-terminator sequence is the engine's
# next-sid dispatch -- dropping it hard-freezes the message thread).
from control_library import (EXE_RESIDENT_CTRL, PAGINATOR_CTRL,   # noqa: F401
                             IMMUTABLE_CTRL)


def paginate_text(text, line0=PAGE_LINE0, linen=PAGE_LINEN, lines=PAGE_LINES):
    """Insert {7f02}/{7f0a} breaks so no rendered line overruns the window."""
    out = []
    line_len = 0
    line_idx = 0
    space_at = None          # index in `out` of the last space on this line

    def budget():
        return line0 if line_idx == 0 else linen

    pos = 0
    for m in _TOKEN_RE.finditer(text):
        for ch in text[pos:m.start()]:
            if ch == ' ':
                space_at = len(out)
            out.append(ch)
            line_len += 1
            if line_len <= budget():
                continue
            nonlocal_break = None
            if line_idx + 1 >= lines:
                nonlocal_break = '{7f0a}{7f02}'
                new_idx = 0
            else:
                nonlocal_break = '{7f02}'
                new_idx = line_idx + 1
            if space_at is not None:
                carried = len(out) - space_at - 1
                out[space_at:space_at + 1] = [nonlocal_break]
                line_len = carried
            else:
                tail = out.pop()
                out.append(nonlocal_break)
                out.append(tail)
                line_len = 1
            line_idx = new_idx
            space_at = None

        tok = m.group(0)
        low = tok.lower()
        out.append(tok)
        if low == '{7f02}':
            line_idx += 1
            line_len = 0
            space_at = None
        elif low == '{7f01}':
            # SAFEGUARD (RC-2): {7F01} is the EXE-UI newline. It MUST reset the
            # paginator's line counter; before the F5 fold this was worked
            # around by paginate=False on 048F, which left any other block
            # whose corpus carries {7F01} double-broken (048C disc census: 144
            # occurrences). Full reset (like a fresh box): never provokes a
            # {7f0a} insert inside a menu skeleton. Zero-width, never counted
            # as text.
            line_idx = 0
            line_len = 0
            space_at = None
        elif low in ('{7f04}', '{7f0a}', '{7f0b}', '{0000}'):
            line_idx = 0
            line_len = 0
            space_at = None
        pos = m.end()

    for ch in text[pos:]:
        out.append(ch)

    return ''.join(out)


# ---------------------------------------------------------------- block fit
# 193 of the 215 overflowing blocks are the engine's own placeholder, JP
# "ダミー" (3 symbols) against EN "Dummy" (4 distinct letters). The extra
# symbol costs 4 tree bytes, which is the whole overflow. "Dum" is 3 distinct
# letters and fits exactly, and the player never sees these blocks anyway.
DUMMY_FIT = "Dum"

_WS_RE = re.compile(r"[ ]{2,}")
_SP_PUNCT_RE = re.compile(r" +([,.!?])")


_TOKEN_SPLIT_RE = re.compile(r'(\{[0-9a-fA-F]{4}\})')

_CONTRACTIONS = [
    (r'\bdo not\b', "don't"), (r'\bdoes not\b', "doesn't"),
    (r'\bdid not\b', "didn't"), (r'\bcannot\b', "can't"),
    (r'\bcan not\b', "can't"), (r'\bwill not\b', "won't"),
    (r'\bwould not\b', "wouldn't"), (r'\bshould not\b', "shouldn't"),
    (r'\bcould not\b', "couldn't"), (r'\bis not\b', "isn't"),
    (r'\bare not\b', "aren't"), (r'\bwas not\b', "wasn't"),
    (r'\bwere not\b', "weren't"), (r'\bhave not\b', "haven't"),
    (r'\bhas not\b', "hasn't"), (r'\bhad not\b', "hadn't"),
    (r'\bI am\b', "I'm"), (r'\byou are\b', "you're"),
    (r'\bwe are\b', "we're"), (r'\bthey are\b', "they're"),
    (r'\bit is\b', "it's"), (r'\bthat is\b', "that's"),
    (r'\bhe is\b', "he's"), (r'\bshe is\b', "she's"),
    (r'\bI will\b', "I'll"), (r'\byou will\b', "you'll"),
    (r'\bI have\b', "I've"), (r'\byou have\b', "you've"),
    (r'\blet us\b', "let's"),
]
_ARTICLE_RE = re.compile(r'\b(the|a|an) +', re.IGNORECASE)
_VOWEL_MID_RE = re.compile(r'\b([A-Za-z])([A-Za-z]{3,})\b')


def _apply_to_text_spans(text, fn):
    """Run fn over the visible spans only, never over a {xxxx} token."""
    parts = _TOKEN_SPLIT_RE.split(text)
    for i in range(0, len(parts), 2):     # even indices are non-token spans
        parts[i] = fn(parts[i])
    return ''.join(parts)


def _drop_interior_vowels(span):
    def one(m):
        head, rest = m.group(1), m.group(2)
        return head + re.sub(r'[aeiou]', '', rest)
    return _VOWEL_MID_RE.sub(one, span)


def compact_english(text, level=1):
    """Tighten a block that is over budget, escalating by `level`.

    Every level preserves the {xxxx} control tokens and the {0000} count, so
    sequence parity is never touched. Higher levels trade prose polish for
    bytes -- a fully playable box beats a spare vowel.

      1  collapse whitespace, drop space before punctuation
      2  + contractions (do not -> don't)   [never invoked; apostrophe font bug]
      3  + drop articles (the / a / an)
      4  RETIRED (user directive Sep-06): interior vowels are NEVER dropped in
         Font 2 text. Level 4 is skipped by the ladder and the level>=4 branch
         below no longer disemvowels, so levels 5-8 keep whole words intact.
      5+ hard cap: truncate each visible span, one char shorter per level past 4.
         The overflow on the tightest blocks is TREE cost (2 bytes per distinct
         Latin letter), which prose edits cannot reach, so the last resort is a
         character cap. It clips a word but keeps the box on screen; control
         tokens and the {0000} count are never touched, so nothing desyncs.
    """
    out = _apply_to_text_spans(text, lambda s: _SP_PUNCT_RE.sub(r"\1", _WS_RE.sub(" ", s)))
    if level >= 2:
        def contract(s):
            for pat, rep in _CONTRACTIONS:
                s = re.sub(pat, rep, s, flags=re.IGNORECASE)
            return s
        out = _apply_to_text_spans(out, contract)
    if level >= 3:
        out = _apply_to_text_spans(out, lambda s: _ARTICLE_RE.sub('', s))
    # Level 4 (interior-vowel drop) RETIRED per user directive Sep-06:
    # Font 2 text keeps all its vowels at every escalation level.
    if level >= 5:
        keep = max(1, 40 - (level - 4) * 2)   # 38, 36, 34, ... chars per span

        def cap(s):
            s2 = s.rstrip()
            return (s2[:keep].rstrip() + s[len(s2):]) if len(s2) > keep else s
        out = _apply_to_text_spans(out, cap)
    return _apply_to_text_spans(out, lambda s: _WS_RE.sub(" ", s))


def sjis_fullwidth_char(c):
    """Convert a character to ShiftJIS fullwidth and strip 0x80 from high byte.
    This matches Java's HuffmanNode(char) constructor behavior for chars not in DW7ASCII."""
    try:
        sjis = c.encode('sjis')
        if len(sjis) == 2:
            hi = sjis[0] & 0x7F  # strip 0x80
            lo = sjis[1]
            return bytes([hi, lo])
        elif len(sjis) == 1:
            # Single-byte SJIS — convert to fullwidth
            # Map ASCII 0x21-0x7E to SJIS fullwidth 0x8140+
            code = sjis[0]
            if 0x21 <= code <= 0x7E:
                fw_map = {
                    0x21: 0x8149, 0x22: 0x8168, 0x23: 0x8194, 0x24: 0x8190,
                    0x25: 0x8193, 0x26: 0x8195, 0x27: 0x8166, 0x28: 0x8169,
                    0x29: 0x816A, 0x2A: 0x8196, 0x2B: 0x817B, 0x2C: 0x8143,
                    0x2D: 0x815D, 0x2E: 0x8144, 0x2F: 0x815E,
                    0x3A: 0x8146, 0x3B: 0x8149, 0x3C: 0x8183, 0x3D: 0x8181,
                    0x3E: 0x8184, 0x3F: 0x8148, 0x40: 0x8197,
                    0x5B: 0x816D, 0x5C: 0x815F, 0x5D: 0x816E, 0x5E: 0x814F,
                    0x5F: 0x8151, 0x60: 0x814D, 0x7B: 0x816F,
                    0x7C: 0x8162, 0x7D: 0x8170, 0x7E: 0x8160,
                }
                if code in fw_map:
                    val = fw_map[code]
                    return bytes([(val >> 8) & 0x7F, val & 0xFF])
            return bytes([0x01, code])  # fallback
    except Exception:
        return bytes([0x01, ord(c) & 0xFF])


def text_to_leaves(text, fullwidth=False):
    """Convert translation text string to list of HuffmanNode leaves.
    Matches DW7ASCII.toHuffmanText() behavior.

    fullwidth=True emits character codes with the 0x8000 bit SET (0x8260 =
    fullwidth Ａ) — the convention the ORIGINAL engine fonts use and which
    the Font-1 (menu) renderer consumes raw. The stripped 0x0260 form is only
    correct for renderers that OR 0x80 back into the high byte (HBD dialogue).
    OR is idempotent, so fullwidth codes are safe for both renderers — but
    stripped codes garble on the non-OR Font-1 renderer (observed: priest
    menu / start menu kana-Latin mix)."""
    leaves = []
    i = 0
    while i < len(text):
        c = text[i]
        if c == '{':
            # Parse control code {XXXX}
            j = text.index('}', i)
            hex_str = text[i+1:j]
            if len(hex_str) != 4:
                raise ValueError("Control code has not 4 letters: %s" % hex_str)
            val = int(hex_str, 16)
            content = bytes([(val >> 8) & 0xFF, val & 0xFF])
            if val == 0 or (val & 0x7F00) == 0x7F00:
                leaves.append(HuffmanNode.control(content))
            else:
                # DISC CONVENTION FIX (Lane 1, Sep-06): character content is
                # stored HIGH-BIT-STRIPPED (0xFE01 -> 0x7E01; the renderer ORs
                # 0x80 back). An unstripped high byte (0xFExx fragment codes in
                # 0x047F/0x0483) made write_tree/parse_tree read the value as a
                # branch index -> "Tree parse out of bounds" -> block skipped.
                content = bytes([(val >> 8) & 0x7F, val & 0xFF])
                leaves.append(HuffmanNode.character(content))
            i = j + 1
        elif c in ASCII_TO_DW7:
            val = ASCII_TO_DW7[c]
            if fullwidth:
                val |= 0x8000
            content = bytes([(val >> 8) & 0xFF, val & 0xFF])
            leaves.append(HuffmanNode.character(content))
            i += 1
        else:
            # Fall back to SJIS fullwidth
            content = sjis_fullwidth_char(c)
            val = (content[0] << 8) | content[1]
            if val == 0 or (val & 0x7F00) == 0x7F00:
                leaves.append(HuffmanNode.control(content))
            else:
                leaves.append(HuffmanNode.character(content))
            i += 1
    return leaves


def leaves_to_text(leaves):
    """Convert leaves back to text string (for verification)."""
    chars = []
    for leaf in leaves:
        if leaf is None:
            continue
        if leaf.is_control():
            content = leaf.content
            val = (content[0] << 8) | content[1]
            chars.append('{%04X}' % val)
        elif leaf.is_character():
            content = leaf.content
            hi = content[0] | 0x80
            lo = content[1]
            try:
                chars.append(bytes([hi, lo]).decode('sjis'))
            except:
                val = (hi << 8) | lo
                if 0x8260 <= val <= 0x829A:
                    chars.append(chr(val - 0x8200))
                elif 0x824F <= val <= 0x8258:
                    chars.append(chr(val - 0x824F + ord('0')))
                else:
                    chars.append('{%04X}' % val)
    return ''.join(chars)


def is_garbage_seq(text_part):
    """Check if a single sequence (without {0000}) is padding garbage."""
    clean = re.sub(r'\{[0-9A-Fa-f]{4}\}', '', text_part)
    if not clean:
        return True
    if len(set(clean)) == 1 and len(clean) >= 3:
        return True
    return False


def trim_trailing_garbage_leaves(leaves):
    """Trim trailing garbage sequences from a leaf list.
    A sequence is text between {0000} markers. Trailing sequences that are
    garbage (control-only, 1-2 chars, or single repeated char) are removed.
    Returns (trimmed_leaves, num_sequences)."""
    # Split leaves into sequences by {0000}
    sequences = []
    current = []
    for leaf in leaves:
        val = (leaf.content[0] << 8) | leaf.content[1]
        if val == 0x0000:
            current.append(leaf)
            sequences.append(current)
            current = []
        else:
            current.append(leaf)
    if current:
        sequences.append(current)  # trailing without {0000}

    # Trim trailing garbage
    while sequences:
        seq = sequences[-1]
        # SAFEGUARD (RC-2, control-leaf immutability): a trailing sequence that
        # carries an IMMUTABLE control (pagination marker or EXE-resident wild
        # token) is ENGINE STRUCTURE, not garbage -- it is the message
        # advance / terminator / freeze token the engine dispatches on.
        # Popping it desyncs the block from its next-sid referrer and
        # hard-freezes the message thread (006C/Cynthia class, RAM incident
        # 174/175). Such a sequence is kept unconditionally.
        has_immutable = any(
            ((l.content[0] << 8) | l.content[1]) in IMMUTABLE_CTRL
            for l in seq if l.is_control())
        if has_immutable:
            break
        # Check if garbage: convert to text for heuristic
        seq_text = leaves_to_text(seq)
        seq_text_no_0000 = seq_text.replace('{0000}', '')
        clean = re.sub(r'\{[0-9A-Fa-f]{4}\}', '', seq_text_no_0000)
        if not clean:
            sequences.pop()
        elif len(set(clean)) == 1 and len(clean) >= 3:
            # A single repeated character (e.g. 中中中中) is a decode artifact.
            sequences.pop()
        else:
            # NOTE: previously we also popped any trailing sequence with <= 2
            # visible chars. That silently DELETED legitimate short sequences --
            # e.g. 006C's 12th sequence 'シ' -- dropping the block from 12 to 11
            # sequences. The cutscene script still referenced 12, so its 12th
            # reference landed on stale bytes and the VM decoded garbage into the
            # text buffer -> the prologue swordmaster freeze. Trimming trailing
            # sequences desyncs the block from its referrers; a real short seq
            # kept is harmless, a real short seq dropped is a hang. So keep them.
            break

    # Flatten back
    trimmed = []
    for seq in sequences:
        trimmed.extend(seq)
    return trimmed, len(sequences)


def compute_sequence_bit_offsets(leaves, tree):
    """Compute bit offset of each sequence start (character after {0000}).
    Returns list of (seq_index, bit_offset)."""
    schema = DQ4Schema()
    codes = schema._collect_codes(tree)
    bit_pos = 0
    seq_starts = []
    seq_idx = 0
    is_after_0000 = True  # First character starts a sequence
    for leaf in leaves:
        content = leaf.content
        code = codes.get(content)
        if code is None:
            raise ValueError("Leaf content %s not in tree" % content.hex())
        if is_after_0000:
            seq_starts.append((seq_idx, bit_pos))
            is_after_0000 = False
        # Check if this leaf is {0000}
        val = (content[0] << 8) | content[1]
        if val == 0x0000:
            seq_idx += 1
            is_after_0000 = True
        bit_pos += len(code)
    return seq_starts


MAX_DIALOG_POINTERS = 4096


def parse_dialog_pointers(hbd, offset, end, text_bits=None):
    """Parse dialog pointers from the end of a block.
    Returns (num_pointers, [(variable, value), ...], total_bytes, valid).

    CRITICAL: `count` is a raw u32 read at offset+end. Not every block HAS a
    pointer table -- for those, this reads the NEXT block's header and gets a
    nonsense count. Trusting it made rebuild_block emit 4 + count*8 bytes,
    which the caller then spliced over the neighbouring archive data: measured
    at 194-438 KB per block and 19.4 MB of collateral across a build, which is
    why such a disc will not boot.

    So the table is now validated, and `valid` is False when it does not hold
    up. Callers MUST NOT write a pointer table when valid is False.
    """
    ptr_off = offset + end
    if ptr_off + 4 > len(hbd):
        return 0, [], 4, False
    count = struct.unpack_from('<I', hbd, ptr_off)[0]
    if count > MAX_DIALOG_POINTERS:
        return 0, [], 4, False
    if ptr_off + 4 + count * 8 > len(hbd):
        return 0, [], 4, False
    pointers = []
    for i in range(count):
        p_off = ptr_off + 4 + i * 8
        variable = struct.unpack_from('<I', hbd, p_off)[0]
        value = struct.unpack_from('<I', hbd, p_off + 4)[0]
        pointers.append((variable, value))
    # Every value is a BIT offset into this block's own code stream. Anything
    # past the end of that stream proves these bytes are not a pointer table.
    if text_bits is not None:
        for _v, val in pointers:
            if val > text_bits:
                return 0, [], 4, False
    total = 4 + count * 8
    return count, pointers, total, True


def original_header_text_budget(h):
    """Bytes available for (text + tree), i.e. what the original block used."""
    try:
        orig_text_len = h['text_end'] - h['hts']
        if h['tree_end'] != 0:
            orig_tree_len = h['tree_end'] - h['text_end'] - 10
        else:
            return None
        return orig_text_len + orig_tree_len
    except Exception:
        return None


def _end_fill_pad(tree_bytes, nbytes):
    """Pad bytes whose bitstream (LSB-first) decodes as repeated END codes.

    Falls back to zero fill only if the tree cannot be parsed or has no END
    leaf (should never happen for a rebuilt tree)."""
    if nbytes <= 0:
        return b''
    try:
        tree = DQ4Schema().parse_tree(tree_bytes)
        codes = DQ4Schema()._collect_codes(tree)
        end_code = codes.get(b'\x00\x00')
    except Exception:
        end_code = None
    if not end_code:
        return b'\x00' * nbytes
    need = nbytes * 8
    bits = (end_code * (need // len(end_code) + 2))[:need]
    out = bytearray(nbytes)
    for j, ch in enumerate(bits):
        if ch == '1':
            out[j // 8] |= 1 << (j % 8)
    return bytes(out)


def rebuild_block(original_header, unknown2, text_bytes, tree_bytes, unknown3,
                  dialog_pointers, original_end, dp_valid=True):
    """Rebuild a complete block with new text and tree.
    Returns bytes of the rebuilt block, or None if it would grow."""
    schema = DQ4Schema()

    # Calculate sizes
    header_size = 24
    tree_header_size = 10

    # Pad text bytes so text + tree matches original total (prevents unknown3 shift)
    orig_text_len = original_header['text_end'] - original_header['hts']
    orig_tree_len = 0
    if original_header['tree_end'] != 0:
        orig_tree_len = original_header['tree_end'] - original_header['text_end'] - tree_header_size
    else:
        orig_tree_len = original_header['end'] - original_header['text_end'] - tree_header_size - len(unknown3)
    orig_total = orig_text_len + orig_tree_len

    new_total = len(text_bytes) + len(tree_bytes)
    if new_total < orig_total:
        pad = orig_total - new_total
        # AUDIT FIX: this loop used to INCREASE pad to reach 4-byte alignment,
        # which could push the block past its original size and fail a block
        # that otherwise fit. Round DOWN instead; the slack is already ours.
        while pad > 0 and (len(text_bytes) + pad) % 4 != 0:
            pad -= 1
        # Q7 HARDENING: the pad lives INSIDE the code-stream region, so a stale
        # or overrunning decode lands in it. Zero fill decodes as repeated
        # glyphs (0x0489's 55x 'i' artifact = symptom amplifier: a drifting
        # decode prints 55 glyphs instead of stopping). Fill with repeated END
        # codes (LSB-first) instead so any stray read terminates immediately.
        text_bytes = text_bytes + _end_fill_pad(tree_bytes, pad)
    elif new_total > orig_total:
        # Tree grew — can't pad, check if total block still fits
        pass

    # Calculate new offsets
    new_end = header_size + len(unknown2) + len(text_bytes) + tree_header_size + len(tree_bytes) + len(unknown3)

    new_hts = header_size + len(unknown2)
    new_text_end = new_hts + len(text_bytes)
    new_tree_start = new_text_end + tree_header_size
    new_tree_end = new_tree_start + len(tree_bytes)
    new_tree_middle = new_tree_start + (len(tree_bytes) // 2) - 1

    # tree_end field: 0 if tree goes to end (no unknown3)
    new_tree_end_field = new_tree_end
    if len(unknown3) == 0 and new_tree_end == new_end:
        new_tree_end_field = 0

    # Number of branch nodes
    # We need to count branches in the tree that was built
    # This is set by the caller via tree param

    # Check total block size (including dialog pointers). When the table did
    # not validate we write no table at all, so it contributes nothing to
    # either side and the block stays exactly its original length.
    # RC-2 FIX (047D class): a VALIDATED-but-EMPTY pointer table must not be
    # appended either -- the block's record region already lives in unknown3
    # (preserved verbatim), and a fabricated 4-byte count header duplicated
    # it, growing every such block by 8 bytes -> block_grew -> the whole
    # block stayed Japanese (047D priest, new=8376/8284 era).
    dp_bytes = (4 + len(dialog_pointers) * 8) if (dp_valid and dialog_pointers) else 0
    new_total_block = new_end + 4 + dp_bytes
    orig_total_block = original_end + 4 + dp_bytes

    if new_total_block > orig_total_block:
        return None, new_total_block, orig_total_block

    # Build the block
    buf = bytearray()

    # Header
    buf += struct.pack('<I', new_end)
    buf += struct.pack('<I', original_header['id'])
    buf += struct.pack('<I', new_hts)
    buf += struct.pack('<I', new_tree_end_field)
    buf += struct.pack('<I', new_text_end)
    buf += struct.pack('<I', original_header['unk1'])

    # unknown2
    buf += unknown2

    # Text bytes
    buf += text_bytes

    # Tree header
    buf += struct.pack('<I', new_tree_start)
    buf += struct.pack('<I', new_tree_middle)
    # numNodes will be filled by caller
    buf += struct.pack('<H', 0)  # placeholder

    # Tree bytes
    buf += tree_bytes

    # unknown3
    buf += unknown3

    # End marker
    buf += struct.pack('<I', new_end)

    # Dialog pointers -- ONLY when the table validated AND has entries.
    # An empty validated table gets no append (see the dp_bytes fix above):
    # the pristine record region rides in unknown3, and appending a bare
    # count header grew the block past its slot (the 047D block_grew class).
    if not dp_valid or not dialog_pointers:
        return bytes(buf), new_total_block, orig_total_block
    buf += struct.pack('<I', len(dialog_pointers))
    for variable, value in dialog_pointers:
        buf += struct.pack('<I', variable)
        buf += struct.pack('<I', value)

    # Pad to original total block size
    pad_needed = orig_total_block - len(buf)
    if pad_needed > 0:
        buf += b'\x00' * pad_needed

    return bytes(buf), new_total_block, orig_total_block


def patch_block(hbd, block, translation_seqs, schema, fullwidth=False,
                paginate=True):
    """Patch a single block with translated text.
    Returns (patched_bytes, info_dict) or (None, info_dict) if skipped."""
    off = block['offset']
    end = block['end']
    hts = block['hts']
    text_end = block['text_end']
    tree_end = block['tree_end']
    block_id = block['block_id']

    # Extract original components
    original_header = {
        'end': end, 'id': block_id, 'hts': hts,
        'tree_end': tree_end, 'text_end': text_end,
        'unk1': struct.unpack_from('<I', hbd, off + 20)[0]
    }

    unknown2 = hbd[off + 24:off + hts]

    orig_text_bytes = hbd[off + hts:off + text_end]

    # Parse tree
    tree_start = struct.unpack_from('<I', hbd, off + text_end)[0]
    correct_tree_end = tree_end if tree_end != 0 else end
    tree_header_bytes = hbd[off + text_end:off + text_end + 10]
    orig_tree_start = struct.unpack_from('<I', hbd, off + text_end)[0]
    orig_tree_middle = struct.unpack_from('<I', hbd, off + text_end + 4)[0]
    orig_num_nodes = struct.unpack_from('<H', hbd, off + text_end + 8)[0]

    orig_tree_bytes = hbd[off + orig_tree_start:off + correct_tree_end]
    unknown3 = hbd[off + correct_tree_end:off + end]

    # Parse dialog pointers
    dp_count, dp_list, dp_total, dp_valid = parse_dialog_pointers(
        hbd, off, end, text_bits=(text_end - hts) * 8)

    # Parse original tree and decode original text
    try:
        orig_tree = schema.parse_tree(orig_tree_bytes)
        orig_leaves = schema.decode(orig_text_bytes, orig_tree)
    except Exception as e:
        return None, {'reason': 'parse_original_failed: %s' % str(e)}

    # Trim trailing garbage sequences from original (matching extractor behavior)
    orig_leaves, orig_seq_count = trim_trailing_garbage_leaves(orig_leaves)

    # Compute original sequence start bit offsets
    try:
        orig_seq_offsets = compute_sequence_bit_offsets(orig_leaves, orig_tree)
    except Exception as e:
        return None, {'reason': 'compute_orig_offsets_failed: %s' % str(e)}

    # Build translated text from translation sequences
    # translation_seqs is a dict: {"1": {"translation": "text{0000}"}, ...}
    # Normalize: remove all {0000} from each translation and add back exactly
    # one trailing {0000}. This prevents extra {0000} markers in translations
    # from creating phantom sequences that cause seq_count_mismatch.
    # Split the ORIGINAL leaves into sequences so an untranslated sequence can
    # fall back to its Japanese rather than being blanked.
    orig_seqs = []
    _cur = []
    for _leaf in orig_leaves:
        _cur.append(_leaf)
        if ((_leaf.content[0] << 8) | _leaf.content[1]) == 0x0000:
            orig_seqs.append(_cur)
            _cur = []
    if _cur:
        orig_seqs.append(_cur)

    translated_text = ''
    num_seqs = len(orig_seq_offsets)
    blanked = 0
    fellback = 0
    for i in range(num_seqs):
        seq_key = str(i + 1)
        entry = translation_seqs.get(seq_key) if isinstance(translation_seqs, dict) else None
        raw = ''
        if isinstance(entry, dict):
            # AUDIT FIX: corpora disagree on the key. full_translation*.json use
            # "translation"; full_translation_clean_master uses "en". Reading only
            # "translation" silently blanked EVERY sequence of the better corpus.
            raw = entry.get('translation') or entry.get('en') or ''
        elif isinstance(entry, str):
            raw = entry

        clean = raw.replace('{0000}', '').strip()
        # The placeholder entries read "Dummy{7f0b}", so compare the TEXT with
        # the control tokens removed, and substitute in place to keep them.
        visible = re.sub(r'\{[0-9a-fA-F]{4}\}', '', clean).strip()
        if visible == 'Dummy':
            clean = clean.replace('Dummy', DUMMY_FIT)
        # AUDIT FIX: an entry of control codes with NO visible text (e.g.
        # "{0000}{7f02}{7f0b}") is not a translation -- it renders as an empty
        # box and, worse, its {0000} count desyncs the sequence table. Treat it
        # as untranslated so the Japanese fallback below fires.
        if visible:
            translated_text += clean + '{0000}'
        else:
            # AUDIT FIX: was `translated_text += '{0000}'`, i.e. an EMPTY box.
            # Fall back to the pristine Japanese sequence instead, so partial
            # coverage reads as untranslated rather than as a blank window.
            if i < len(orig_seqs):
                jp = leaves_to_text(orig_seqs[i]).replace('{0000}', '')
                translated_text += jp + '{0000}'
                fellback += 1
            else:
                translated_text += '{0000}'
                blanked += 1

    # Reflow to the window BEFORE encoding, so long English lines break at
    # word boundaries instead of running off the right edge of the box.
    # F5 FOLD (Sep-08): blocks whose corpus already carries the pristine
    # break skeleton (e.g. EXE 0x048F — its {7F01} EXE-UI newlines do not
    # reset the paginator's line counter, so pagination double-breaks and
    # inflated 7F02 100->269) must be encoded with paginate=False.
    if paginate:
        translated_text = paginate_text(translated_text)

    # Convert translated text to leaves
    try:
        new_leaves = text_to_leaves(translated_text, fullwidth=fullwidth)
    except Exception as e:
        return None, {'reason': 'text_convert_failed: %s' % str(e)}

    # Count sequence starts in new leaves (should match original)
    new_seq_count = 0
    is_after_0000 = True
    for leaf in new_leaves:
        if is_after_0000:
            new_seq_count += 1
            is_after_0000 = False
        val = (leaf.content[0] << 8) | leaf.content[1]
        if val == 0x0000:
            is_after_0000 = True

    if new_seq_count != num_seqs:
        return None, {'reason': 'seq_count_mismatch: orig=%d new=%d' % (num_seqs, new_seq_count)}

    # Build frequency map
    freq = {}
    for leaf in new_leaves:
        content = leaf.content
        if content not in freq:
            freq[content] = 0
        freq[content] += 1

    # AUDIT FIX: max_len was pinned at 12 with no retry, so a tree that grew by
    # a few bytes failed the whole block -- 187 of 212 skips were the SAME
    # 4-byte miss (new=840 vs orig=836). Code length trades tree size against
    # encoded size, so search the range and keep the smallest TOTAL that still
    # round-trips. build_tree_length_limited was already imported for this.
    orig_text_len_budget = original_header_text_budget(original_header)
    best = None
    for _max_len in (12, 11, 13, 10, 14, 9, 15):
        try:
            _tree = build_tree_length_limited(freq, schema=None, max_len=_max_len)
            _txt = schema.encode(new_leaves, _tree)
            _tb = schema.write_tree(_tree)
        except Exception:
            continue
        _total = len(_txt) + len(_tb)
        if best is None or _total < best[0]:
            best = (_total, _tree, _txt, _tb, _max_len)
        if orig_text_len_budget is not None and _total <= orig_text_len_budget:
            break
    if best is None:
        return None, {'reason': 'tree_build_failed: no max_len produced a tree'}
    _total, new_tree, new_text_bytes, new_tree_bytes, _chosen_len = best

    # Count branch nodes
    num_branches = len(new_tree.branch_nodes())

    # Compute new sequence start bit offsets
    try:
        new_seq_offsets = compute_sequence_bit_offsets(new_leaves, new_tree)
    except Exception as e:
        return None, {'reason': 'compute_new_offsets_failed: %s' % str(e)}

    # Update dialog pointers
    # Map old bit offsets to new bit offsets
    offset_map = {}
    for (old_idx, old_off), (new_idx, new_off) in zip(orig_seq_offsets, new_seq_offsets):
        offset_map[old_off] = new_off

    updated_dp = []
    for variable, value in dp_list:
        if value in offset_map:
            updated_dp.append((variable, offset_map[value]))
        else:
            # Try to find closest match
            updated_dp.append((variable, value))

    # Rebuild block
    patched, new_total, orig_total = rebuild_block(
        original_header, unknown2, new_text_bytes, new_tree_bytes,
        unknown3, updated_dp, end, dp_valid=dp_valid
    )

    if patched is None:
        # RETRY LADDER: tighten the English and rebuild, escalating only as far
        # as needed. A fully readable box that FITS beats an ideal one that
        # overflows and stays Japanese. Every level preserves control tokens
        # and the {0000} count, so the pointer remap below stays valid.
        # Font 2 policy: FULL English wherever it fits in the original slot (the
        # ~1131 blocks that patch on the first pass never enter this ladder). For
        # the handful that overflow, escalate as an OVERFLOW BUFFER only, exactly
        # as far as needed -- level 1 lossless whitespace, then 3 drop articles.
        # Level 4 (disemvowel) is RETIRED per user directive Sep-06: Font 2 text
        # never loses its vowels. Level 2 (contractions) is SKIPPED: it
        # inserts apostrophes and this font maps ' -> 「, which renders as garbage.
        # Levels 5-8 (hard-cap / clip) are RETIRED (Sep-06, FORMAT §15c-i): the
        # engine has NO horizontal width check -- it draws past the box edge and
        # NEVER truncates a line, so any clip is 100% self-inflicted by the
        # encoder. The only real fit constraint is the byte budget (the Huffman
        # slot). A block that still overflows after L1 (lossless whitespace) + L3
        # (drop articles) is a CORPUS-FIT task -- shorten the translation -- and is
        # reported loudly as block_grew, NEVER silently clipped. (Vertical box
        # height <=3 lines is a paginator concern, handled at corpus authoring.)
        for _level in (1, 3):
            compacted = compact_english(translated_text, level=_level)
            if compacted == translated_text:
                continue
            try:
                retry_leaves = text_to_leaves(compacted, fullwidth=fullwidth)
            except Exception:
                continue
            rfreq = {}
            for l in retry_leaves:
                rfreq[l.content] = rfreq.get(l.content, 0) + 1
            rbest = None
            for _ml in (12, 11, 13, 10, 14):
                try:
                    _t = build_tree_length_limited(rfreq, schema=None, max_len=_ml)
                    _x = schema.encode(retry_leaves, _t)
                    _b = schema.write_tree(_t)
                except Exception:
                    continue
                if rbest is None or len(_x) + len(_b) < rbest[0]:
                    rbest = (len(_x) + len(_b), _t, _x, _b)
            if rbest is None:
                continue
            _tot, r_tree, r_text, r_treeb = rbest
            try:
                r_offs = compute_sequence_bit_offsets(retry_leaves, r_tree)
            except Exception:
                continue
            if len(r_offs) != len(orig_seq_offsets):
                continue
            r_map = {}
            for (_oi, oo), (_ni, no) in zip(orig_seq_offsets, r_offs):
                r_map[oo] = no
            r_dp = [(v, r_map.get(val, val)) for v, val in dp_list]
            patched, new_total, orig_total = rebuild_block(
                original_header, unknown2, r_text, r_treeb,
                unknown3, r_dp, end, dp_valid=dp_valid)
            if patched is not None:
                new_leaves = retry_leaves
                new_text_bytes = r_text
                new_tree_bytes = r_treeb
                new_tree = r_tree
                num_branches = len(r_tree.branch_nodes())
                break
        if patched is None:
            return None, {'reason': 'block_grew: new=%d orig=%d' % (new_total, orig_total)}

    # Fix numNodes in the patched block.
    # CRITICAL: rebuild_block PADS new_text_bytes internally (zero-fill to keep
    # unknown3/end at their original offsets when the English tree shrinks), so
    # len(new_text_bytes) here is the UNPADDED length. Computing the field
    # offset from it lands inside the padding -- the real numNodes field stayed
    # 0 and the game's Huffman decoder mis-parsed the tree (prologue 006C
    # runaway/freeze). Read the true text_end (header word 5, byte 16) from the
    # rebuilt buffer; numNodes sits in the tree header at text_end+8.
    buf = bytearray(patched)
    real_text_end = struct.unpack_from('<I', buf, 16)[0]
    num_nodes_off = real_text_end + 8
    struct.pack_into('<H', buf, num_nodes_off, num_branches)

    # Verify round-trip by comparing leaf content bytes (not SJIS text)
    # Note: padding bits in the encoded bitstream may decode as extra leaves,
    # so we only verify the first len(new_leaves) leaves match.
    try:
        verify_tree = schema.parse_tree(new_tree_bytes)
        verify_leaves = schema.decode(new_text_bytes, verify_tree)
        if len(verify_leaves) < len(new_leaves):
            return None, {'reason': 'roundtrip_too_few_leaves: %d vs %d' % (len(verify_leaves), len(new_leaves))}
        for i in range(len(new_leaves)):
            if verify_leaves[i].content != new_leaves[i].content:
                return None, {'reason': 'roundtrip_content_mismatch at leaf %d' % i}
    except Exception as e:
        return None, {'reason': 'roundtrip_failed: %s' % str(e)}

    # HEADER VERIFY: the game's two-array tree parser reads numNodes from the
    # tree header (text_end+8); a wrong value gives it a bogus root -> runaway
    # freeze. The leaf round-trip above uses parse_tree on the raw bytes and
    # canNOT catch a wrong header field, which is exactly how numNodes=0 shipped
    # in 723 blocks. Read it back from the assembled buffer and assert it.
    hdr_text_end = struct.unpack_from('<I', buf, 16)[0]
    hdr_num_nodes = struct.unpack_from('<H', buf, hdr_text_end + 8)[0]
    if hdr_num_nodes != num_branches:
        return None, {'reason': 'numNodes_header_mismatch: field=%d expected=%d' % (hdr_num_nodes, num_branches)}

    return bytes(buf), {
        'orig_text_len': len(orig_text_bytes),
        'new_text_len': len(new_text_bytes),
        'orig_tree_len': len(orig_tree_bytes),
        'new_tree_len': len(new_tree_bytes),
        'num_branches': num_branches,
        'dp_count': dp_count,
        'seq_count': num_seqs,
    }


def main():
    import argparse
    parser = argparse.ArgumentParser(description='DQ4 HBD Python Patcher')
    parser.add_argument('--input', default=DQ4_DISC, help='Input disc image')
    parser.add_argument('--translations', default=TRANSLATIONS, help='Translations JSON')
    parser.add_argument('--output', default=OUTPUT_BIN, help='Output disc image')
    args = parser.parse_args()

    print("=== DQ4 HBD Python Patcher ===")
    t_start = time.time()

    # Load translations
    print("Loading translations from %s..." % args.translations)
    with open(args.translations, 'r', encoding='utf-8') as f:
        translations = json.load(f)
    # BUG FIX: block ids are scanned as lowercase hex ('%04x'), but the corpus
    # has one uppercase key -- '006C', the opening sword-practice/Cynthia scene.
    # A case-sensitive intersection dropped exactly that block, leaving the
    # scene the game OPENS ON in Japanese (and crashing at Cynthia). Normalise
    # every corpus key to lowercase so selection is case-insensitive.
    translations = {k.lower(): v for k, v in translations.items()}
    print("  %d text IDs with translations" % len(translations))

    # Read HBD from disc
    print("Reading HBD from disc at LBA %d..." % DQ4_HBD_LBA)
    hbd = bytearray()
    with open(args.input, 'rb') as f:
        for i in range(200000):
            f.seek((DQ4_HBD_LBA + i) * RAW_SECTOR + USER_OFFSET)
            chunk = f.read(USER_SIZE)
            if not chunk or len(chunk) < USER_SIZE:
                break
            hbd.extend(chunk)
    hbd = bytes(hbd)
    print("  HBD: %d bytes (%d MB)" % (len(hbd), len(hbd) // 1048576))

    # Find all text blocks
    print("Scanning for text blocks...")
    blocks = []
    # PHASE C HOLD: ids whose type-44/type-26/EXE table referrers are not
    # remapped yet (the STEP 4d lane). Re-encoding these would corrupt place
    # names / person types (0x0020: 380 type-44 refs; 0x0026: 55). They are
    # admitted again once 4d exists. 0x048B is STEP 4's lane.
    HOLD_IDS = {0x0020, 0x0026, 0x048B}
    held = set()
    for off in range(0, len(hbd) - 24, 4):
        end, block_id, hts, tree_end, text_end, unk = struct.unpack_from('<6I', hbd, off)
        if hts < 24 or hts >= text_end:
            continue
        # PHASE C FIX: tree_end == 0 ("tree extends to end", FORMAT §3) was
        # treated as invalid, hiding 0x0484/0x0488 and the rest of the 191
        # d==0 blocks from STEP 1 entirely. They are valid; patch_block
        # already handles tree_end==0 via correct_tree_end = end.
        if text_end == 0:
            continue
        if end < 24 or end > 1048576:
            continue
        if block_id == 0:
            continue
        if tree_end > end or text_end > end:
            continue
        if off + text_end + 10 > len(hbd):
            continue
        tree_start = struct.unpack_from('<I', hbd, off + text_end)[0]
        if tree_start != text_end + 10:
            continue
        text_id = block_id & 0xFFFF
        if text_id in HOLD_IDS:
            held.add(text_id)
            continue
        blocks.append({
            'offset': off, 'end': end, 'block_id': block_id,
            'text_id': '%04x' % text_id, 'hts': hts,
            'tree_end': tree_end, 'text_end': text_end,
        })
    if held:
        print("  [HOLD] skipped d==0 blocks pending STEP 4d table-ref lane: %s"
              % ", ".join("0x%04X" % t for t in sorted(held)))
    print("  Found %d text blocks" % len(blocks))

    # Group blocks by text_id (multiple blocks can share a text_id)
    blocks_by_id = {}
    for block in blocks:
        tid = block['text_id']
        if tid not in blocks_by_id:
            blocks_by_id[tid] = []
        blocks_by_id[tid].append(block)

    # Patch blocks
    schema = DQ4Schema()
    patched_count = 0
    skipped_count = 0
    skip_reasons = {}
    corpus_error_blocks = []
    hbd_patched = bytearray(hbd)

    # Only patch text IDs that have translations
    translatable_ids = set(translations.keys()) & set(blocks_by_id.keys())
    print("  Translatable text IDs: %d (of %d in HBD, %d in translations)" %
          (len(translatable_ids), len(blocks_by_id), len(translations)))

    for tid in sorted(translatable_ids):
        translation = translations[tid]
        if not translation or len(translation) == 0:
            continue

        for block in blocks_by_id[tid]:
            result, info = patch_block(hbd, block, translation, schema)
            if result is not None:
                # Write patched block back into HBD
                off = block['offset']
                hbd_patched[off:off + len(result)] = result
                patched_count += 1
            else:
                skipped_count += 1
                reason = info.get('reason', 'unknown')
                skip_reasons[reason] = skip_reasons.get(reason, 0) + 1
                # block_grew is a TOLERATED overflow (block stays JP, renders
                # fine). Everything else -- a parse error, a sequence desync, a
                # bad header -- means the CORPUS is malformed and a block was
                # silently dropped; those must always be visible.
                is_corpus_error = not reason.startswith('block_grew')
                if is_corpus_error:
                    corpus_error_blocks.append((tid, block['offset'], reason))
                    print("  [CORPUS ERROR] SKIP %s at offset %d: %s" % (tid, block['offset'], reason))
                elif skipped_count <= 40:
                    print("  SKIP %s at offset %d: %s" % (tid, block['offset'], reason))

    elapsed = time.time() - t_start
    print("\nResults:")
    print("  Patched: %d blocks" % patched_count)
    print("  Skipped: %d blocks (block_grew overflow is expected; corpus errors are not)" % skipped_count)
    if skip_reasons:
        print("  Skip reasons:")
        for reason, count in sorted(skip_reasons.items(), key=lambda x: -x[1]):
            print("    %s: %d" % (reason, count))
    if corpus_error_blocks:
        print("\n  *** %d CORPUS-ERROR skips (malformed translation dropped a block) ***"
              % len(corpus_error_blocks))
        print("  *** Run: python translation-tools/validate_corpus.py <corpus> to locate them ***")
    print("  Time: %.1fs" % elapsed)

    # Write patched disc image
    print("\nWriting patched disc image to %s..." % args.output)
    # Copy original disc to output
    import shutil
    shutil.copy2(args.input, args.output)

    # Write patched HBD back into the disc image
    with open(args.output, 'r+b') as f:
        hbd_offset = DQ4_HBD_LBA * RAW_SECTOR + USER_OFFSET
        for i in range(0, len(hbd_patched), USER_SIZE):
            sector_idx = i // USER_SIZE
            disc_offset = (DQ4_HBD_LBA + sector_idx) * RAW_SECTOR + USER_OFFSET
            chunk = hbd_patched[i:i + USER_SIZE]
            if len(chunk) < USER_SIZE:
                chunk = chunk + b'\x00' * (USER_SIZE - len(chunk))
            f.seek(disc_offset)
            f.write(chunk)

    print("  Output: %s (%d bytes)" % (args.output, os.path.getsize(args.output)))

    # Regenerate EDC/ECC
    edcre = os.path.join(WORKSPACE, 'edcre', 'edcre-v1.1.0-windows-x86_64-static', 'edcre.exe')
    if os.path.exists(edcre):
        print("\nRegenerating EDC/ECC...")
        import subprocess
        result = subprocess.run([edcre, args.output], capture_output=True, text=True, timeout=300)
        print("  EDC/ECC: %s" % ("PASS" if result.returncode == 0 else "FAIL"))
        if result.returncode != 0:
            print("  stderr: %s" % result.stderr[:500])
    else:
        print("\nWARNING: edcre.exe not found, EDC/ECC not regenerated")

    print("\nDONE")
    print("Next steps:")
    print("  1. Test %s in DuckStation" % args.output)
    print("  2. Create .cue file referencing the patched .bin")


if __name__ == '__main__':
    main()
