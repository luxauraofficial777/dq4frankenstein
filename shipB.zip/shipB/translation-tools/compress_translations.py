#!/usr/bin/env python3
"""Compress all full_translation.json entries to fit within original Japanese length.
This is an emergency stability pass: lines longer than the original are shortened,
truncated if necessary, and marked with '...' to keep the game from overflowing.
"""
import csv
import glob
import json
import os
import re
import sys

CSV_DIR = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\csv"
FT_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation.json"
OUT_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation_safe.json"

CONTROL_CODE = re.compile(r"\{[0-9a-fA-F]+\}")
TERMINATOR = re.compile(r"\{0000\}$")

# Common shortening replacements (no apostrophes allowed)
REPLACEMENTS = [
    (re.compile(r"\bdo not\b"), "dont"),
    (re.compile(r"\bdo not\b"), "dont"),
    (re.compile(r"\bcannot\b"), "cant"),
    (re.compile(r"\bwill not\b"), "wont"),
    (re.compile(r"\bis not\b"), "isnt"),
    (re.compile(r"\bare not\b"), "arent"),
    (re.compile(r"\bhave not\b"), "havent"),
    (re.compile(r"\bhas not\b"), "hasnt"),
    (re.compile(r"\bhad not\b"), "hadnt"),
    (re.compile(r"\bdoes not\b"), "doesnt"),
    (re.compile(r"\bdid not\b"), "didnt"),
    (re.compile(r"\bwas not\b"), "wasnt"),
    (re.compile(r"\bwere not\b"), "werent"),
    (re.compile(r"\bit is\b"), "its"),
    (re.compile(r"\byou are\b"), "youre"),
    (re.compile(r"\bwe are\b"), "were"),
    (re.compile(r"\bthey are\b"), "theyre"),
    (re.compile(r"\bI am\b"), "Im"),
    (re.compile(r"\bI have\b"), "Ive"),
    (re.compile(r"\bI will\b"), "Ill"),
    (re.compile(r"\bthere is\b"), "theres"),
    (re.compile(r"\bthere has\b"), "theres"),
    (re.compile(r"\byou have\b"), "youve"),
    (re.compile(r"\bhe is\b"), "hes"),
    (re.compile(r"\bshe is\b"), "shes"),
    (re.compile(r"\bthat is\b"), "thats"),
    (re.compile(r"\bwhat is\b"), "whats"),
    (re.compile(r"\bwhere is\b"), "wheres"),
    (re.compile(r"\bwho is\b"), "whos"),
    (re.compile(r"\bhow is\b"), "hows"),
    (re.compile(r"\bbecause\b"), "since"),
    (re.compile(r"\bhowever\b"), "but"),
    (re.compile(r"\btherefore\b"), "so"),
    (re.compile(r"\bnevertheless\b"), "still"),
    (re.compile(r"\botherwise\b"), "else"),
    (re.compile(r"\bperhaps\b"), "maybe"),
    (re.compile(r"\bprobably\b"), "maybe"),
    (re.compile(r"\bdefinitely\b"), "sure"),
    (re.compile(r"\bcertainly\b"), "sure"),
    (re.compile(r"\bunderstand\b"), "get"),
    (re.compile(r"\bunderstood\b"), "got"),
    (re.compile(r"\bimportant\b"), "key"),
    (re.compile(r"\bremember\b"), "recall"),
    (re.compile(r"\bplease\b"), ""),
    (re.compile(r"\bactually\b"), ""),
    (re.compile(r"\breally\b"), ""),
    (re.compile(r"\bjust\b"), ""),
    (re.compile(r"\bvery\b"), ""),
    (re.compile(r"\bquite\b"), ""),
    (re.compile(r"\brather\b"), ""),
    (re.compile(r"\bsomewhat\b"), ""),
    (re.compile(r"\benough\b"), "ok"),
    (re.compile(r"\bapproximately\b"), "about"),
    (re.compile(r"\beverything\b"), "all"),
    (re.compile(r"\beveryone\b"), "all"),
    (re.compile(r"\bsomebody\b"), "someone"),
    (re.compile(r"\bsomething\b"), "thing"),
    (re.compile(r"\bsomewhere\b"), "place"),
    (re.compile(r"\bof course\b"), "sure"),
    (re.compile(r"\bby the way\b"), "oh"),
    (re.compile(r"\byou know\b"), ""),
    (re.compile(r"\bWell,\b"), ""),
    (re.compile(r"\bWell\b"), ""),
    (re.compile(r"\bNow,\b"), ""),
    (re.compile(r"\bSo,\b"), "So"),
    (re.compile(r"\bAnd,\b"), "And"),
    (re.compile(r"\bBut,\b"), "But"),
    (re.compile(r"\bHowever,\b"), "But"),
    (re.compile(r"\b{7f02}the\b"), "{7f02}"),
    (re.compile(r"\b{7f02}a\b"), "{7f02}"),
    (re.compile(r"\b{7f02}an\b"), "{7f02}"),
    (re.compile(r"\b{7f02}that\b"), "{7f02}"),
    (re.compile(r"\b{7f02}this\b"), "{7f02}"),
    (re.compile(r"\b{7f0a}the\b"), "{7f0a}"),
    (re.compile(r"\b{7f0a}a\b"), "{7f0a}"),
    (re.compile(r"\b{7f0a}an\b"), "{7f0a}"),
    (re.compile(r"\b{7f0a}that\b"), "{7f0a}"),
    (re.compile(r"\b{7f0a}this\b"), "{7f0a}"),
    (re.compile(r"\bthe\b"), ""),
    (re.compile(r"\ba\b"), ""),
    (re.compile(r"\ban\b"), ""),
    (re.compile(r"\bthat\b"), ""),
    (re.compile(r"\bthis\b"), ""),
    (re.compile(r"  +"), " "),
    (re.compile(r" ,"), ","),
    (re.compile(r" \."), "."),
    (re.compile(r" \?"), "?"),
    (re.compile(r" !"), "!"),
    (re.compile(r"\.{3,}"), "..."),
]


def split_with_controls(text):
    """Split text into visible segments and control-code tokens."""
    parts = []
    for m in CONTROL_CODE.finditer(text):
        parts.append(m.group(0))
    return parts


def visible_len(text):
    return len(CONTROL_CODE.sub("", text))


def shorten_text(text, max_len):
    """Try to compress text to fit max_len visible chars. Returns (new_text, was_truncated)."""
    # Don't touch control codes; work on visible text only
    tokens = []
    last = 0
    for m in CONTROL_CODE.finditer(text):
        if m.start() > last:
            tokens.append(("text", text[last:m.start()]))
        tokens.append(("ctrl", m.group(0)))
        last = m.end()
    if last < len(text):
        tokens.append(("text", text[last:]))

    # Apply replacements to each visible text segment
    changed = True
    while changed:
        changed = False
        new_tokens = []
        for typ, val in tokens:
            if typ == "text":
                new_val = val
                for rx, repl in REPLACEMENTS:
                    new_val, n = rx.subn(repl, new_val)
                    if n > 0:
                        changed = True
                # Clean up double spaces and leading/trailing spaces
                new_val = re.sub(r"  +", " ", new_val).strip()
                new_tokens.append(("text", new_val))
            else:
                new_tokens.append((typ, val))
        tokens = new_tokens

    # Reassemble and clean up spaces around control codes
    text = "".join(v for _, v in tokens)
    text = re.sub(r" \{7f02\}", "{7f02}", text)
    text = re.sub(r"\{7f02\} ", "{7f02}", text)
    text = re.sub(r" \{7f0a\}", "{7f0a}", text)
    text = re.sub(r"\{7f0a\} ", "{7f0a}", text)
    text = re.sub(r" \{7f0b\}", "{7f0b}", text)
    text = re.sub(r"\{7f0b\} ", "{7f0b}", text)
    text = re.sub(r"  +", " ", text).strip()

    vlen = visible_len(text)
    if vlen <= max_len:
        return text, False

    # Still too long: truncate to nearest sentence/word boundary before limit
    # Keep terminator if present
    has_term = TERMINATOR.search(text)
    suffix = "{0000}" if has_term else ""
    if suffix:
        text = text[:-6]  # strip {0000}

    # Recompute visible length without suffix
    vlen_no_suffix = visible_len(text)
    if vlen_no_suffix <= max_len - 3:
        text = text + "..."
    elif vlen_no_suffix > max_len:
        # Find last safe word boundary before max_len-3
        target = max_len - 3
        if target < 10:
            target = max_len
        visible = CONTROL_CODE.sub("", text)
        if len(visible) > target:
            # Find the last space before target in visible text
            truncated_visible = visible[:target]
            last_space = truncated_visible.rfind(" ")
            if last_space > 5:
                truncated_visible = truncated_visible[:last_space]
            # Rebuild text with control codes inserted
            # Simple approach: since we only have control codes in original positions, we can
            # rebuild by taking the first N visible characters and inserting all control codes
            # that fall within that visible range. This is approximate.
            result = []
            v_count = 0
            for m in re.finditer(r"[^{}]+|\{[0-9a-fA-F]+\}", text):
                token = m.group(0)
                if token.startswith("{"):
                    if v_count < len(truncated_visible):
                        result.append(token)
                else:
                    take = len(truncated_visible) - v_count
                    if take <= 0:
                        break
                    if take >= len(token):
                        result.append(token)
                        v_count += len(token)
                    else:
                        result.append(token[:take])
                        v_count += take
                        break
            text = "".join(result).strip()
        # Append ellipsis if we truncated
        if not text.endswith(".") and not text.endswith("!") and not text.endswith("?"):
            text = text + "..."
        else:
            text = text + "..."

    text = text + suffix
    # Final cleanup
    text = re.sub(r"  +", " ", text).strip()
    return text, True


def main():
    # Load original lengths from CSVs
    orig_len = {}
    for csv_path in glob.glob(os.path.join(CSV_DIR, "*.csv")):
        block_id = os.path.basename(csv_path).replace(".csv", "")
        with open(csv_path, encoding="utf-8") as f:
            reader = csv.DictReader(f)
            for row in reader:
                line = row["lineNumber"]
                orig = row.get("original", "")
                orig_clean = CONTROL_CODE.sub("", orig)
                orig_len[(block_id, line)] = len(orig_clean)

    with open(FT_PATH, encoding="utf-8") as f:
        ft = json.load(f)

    stats = {"total": 0, "shortened": 0, "truncated": 0, "ok": 0, "missing_csv": 0}
    for block_id, block in ft.items():
        for line_key, entry in block.items():
            stats["total"] += 1
            trans = entry.get("translation", "")
            if not trans:
                continue
            key = (block_id, line_key)
            if key not in orig_len:
                stats["missing_csv"] += 1
                continue
            olen = orig_len[key]
            tlen = visible_len(trans)
            if tlen <= olen:
                stats["ok"] += 1
                continue
            new_trans, was_truncated = shorten_text(trans, olen)
            entry["translation"] = new_trans
            if was_truncated:
                stats["truncated"] += 1
            else:
                stats["shortened"] += 1

    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(ft, f, ensure_ascii=False, indent=2)

    print("Compression pass complete.")
    print(f"  Total lines: {stats['total']}")
    print(f"  OK (fit): {stats['ok']}")
    print(f"  Shortened: {stats['shortened']}")
    print(f"  Truncated: {stats['truncated']}")
    print(f"  Missing CSV: {stats['missing_csv']}")
    print(f"  Safe JSON written to: {OUT_PATH}")

    # Show some examples of truncated lines
    print("\nSome truncated examples (first 10):")
    count = 0
    for block_id, block in ft.items():
        for line_key, entry in block.items():
            if count >= 10:
                break
            if "..." in entry["translation"] and entry["translation"].endswith("{0000}"):
                print(f"  {block_id} {line_key}: {entry['translation'][:100]}")
                count += 1


if __name__ == "__main__":
    main()
