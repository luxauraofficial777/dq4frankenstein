﻿#!/usr/bin/env python3
"""
patch_overlay_refs.py -- Generic stale-referrer remapper for externally
referenced HBD blocks (run as the LAST patch step, after all lanes).

WHY THIS EXISTS
---------------
Each lane (dq4_hbd_patcher, patch_save_menu, patch_font1_ourway,
patch_battle_overlay) re-encodes its blocks in place, which shifts sequence
bit offsets. Lanes remap their own referrers, but the scans were per-sector
and window-limited, so some refs stay pointing at PRISTINE bit offsets and
decode as scrambled glyphs:

  - Block 0x0474 (save menu): 26 split-immediates in overlay sectors
    106332-106334 were never remapped by ANY lane -> the save/erase confirm
    box rendered "tSSl unrtuel / uaee aon dloginture Log."
  - Facility blocks 0x0477/78/79/7B/7C/7D: overlay code refs never remapped
    -> shop/church/inn boxes scrambled.
  - Block 0x048B (battle): refs outside the 104000..106000 window or
    straddling a sector boundary -> battle command menu scrambled.
  - Block 0x048C (font 1): 4 straddling lui/ori pairs (SIDs 773/775/660).

METHOD (safe by construction)
-----------------------------
For each target block, parse the PRISTINE block (old sequence bit offsets)
and the BUILT block (new offsets) -> omap. Then scan the EXE and every HBD
overlay sector for referrer words:

  1. direct 32-bit words   (block_id << 20) | (bit + hts*8)
  2. split-immediates      lui reg, imm  +  ori/addiu reading reg
     (window=32 instructions, MIPS writes() clobber tracking, addiu sign-carry)
     (incl. pairs straddling a 2048-byte sector boundary, via a 128-byte
      rolling carry)

A word is rewritten ONLY IF its current value is byte-identical to the
pristine disc value at the same location AND it resolves to a pristine
string start (excluding trailing residue). Already-remapped words differ from
pristine and are skipped, so the pass can never double-remap or corrupt
another lane's work.

Usage:
  python patch_overlay_refs.py --disc build/dq4_sovereign_master.bin \
                               --base "Dragon Quest IV ... (Japan).bin"
  python patch_overlay_refs.py --disc ... --base ... --report   (read-only)
"""

import argparse
import os
import re
import struct
import sys

sys.stdout.reconfigure(line_buffering=True, encoding="utf-8")

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE) if "translation-tools" in HERE else HERE
sys.path.insert(0, HERE)

from hbe.huffman.dq4 import DQ4Schema
_psx = HERE
for _ in range(4):
    _psx = os.path.dirname(_psx)
    if os.path.isdir(os.path.join(_psx, "psx_tools", "dq4")):
        sys.path.insert(0, os.path.join(_psx, "psx_tools"))
        break
from dq4.textblock import TextBlock as _TextBlock
from dq4 import huffman as _huffman
import patch_table_refs as _R
import dq4_hbd_patcher as P

RAW, UOFF, USZ = 2352, 24, 2048
SC = DQ4Schema()

WINDOW = 32  # instructions
WINDOW_BYTES = WINDOW * 4  # 128 bytes
LUI = 0x0F
ORI = 0x0D
ADDIU = 0x09

# Blocks that external (EXE / overlay) code references by hardcoded bit offset.
TARGET_BLOCKS = [
    0x0474,  # save / memory-card menu
    0x0477, 0x0478, 0x0479, 0x047B, 0x047C, 0x047D,  # facilities
    0x048B,  # battle overlay
    0x048C,  # font 1
    # Phase C additions (corpus completion)
    0x0480,  # casino counter clerk (embedded-only)
    0x0483,  # memory-card integrity / church blessing flow
    0x0484,  # memory-card titles (5 linear + 55 embedded)
    0x0485,  # save-confirm flow (embedded)
    0x0486,  # shop-flow dialogue (embedded)
    0x0487,  # shop/vault keeper (embedded)
    0x0488,  # casino rules UI (2 linear, tre=0)
    0x047F,  # player titles table (222 seqs; feeds 0x047E 'Title' record)
]


def writes(w):
    """The register number an instruction writes, or None."""
    op = (w >> 26) & 0x3F
    if op == 0x00:  # SPECIAL
        fn = w & 0x3F
        if fn in (0x08, 0x0C, 0x0D):  # jr, syscall, break
            return None
        if fn in (0x11, 0x13):  # mthi, mtlo
            return None
        if fn in (0x18, 0x19, 0x1A, 0x1B):  # mult, multu, div, divu
            return None
        return (w >> 11) & 0x1F  # rd (includes jalr)
    if op == 0x01:  # REGIMM
        rt = (w >> 16) & 0x1F
        return 31 if rt in (0x10, 0x11) else None  # bltzal, bgezal write ra
    if op == 0x02:  # j
        return None
    if op == 0x03:  # jal
        return 31  # writes ra
    if op in (0x04, 0x05, 0x06, 0x07):  # beq, bne, blez, bgtz
        return None
    if 0x08 <= op <= 0x0F:  # addi..lui, all write rt
        return (w >> 16) & 0x1F
    if 0x20 <= op <= 0x26:  # lb..lwr, all write rt
        return (w >> 16) & 0x1F
    if op == 0x10 and ((w >> 21) & 0x1F) == 0:  # mfc0
        return (w >> 16) & 0x1F
    if op == 0x12 and ((w >> 21) & 0x1F) in (0x00, 0x02):  # mfc2, cfc2
        return (w >> 16) & 0x1F
    return None


def compose(hi, lo, op):
    """The 32-bit value a lui/low-half pair computes.
    ori zero-extends; addiu sign-extends and adds."""
    if op == ORI:
        return ((hi & 0xFFFF) << 16) | (lo & 0xFFFF)
    if op == ADDIU:
        lo = lo & 0xFFFF
        simm = (lo - 0x10000) if (lo & 0x8000) else lo
        return (((hi & 0xFFFF) << 16) + simm) & 0xFFFFFFFF
    raise ValueError(f"not a split-immediate low half: opcode 0x{op:02X}")


def halves(value, op):
    """(high halfword, low halfword) to STORE for a composed value."""
    value &= 0xFFFFFFFF
    if op == ORI:
        return (value >> 16) & 0xFFFF, value & 0xFFFF
    if op == ADDIU:
        return ((value + 0x8000) >> 16) & 0xFFFF, value & 0xFFFF
    raise ValueError(f"not a split-immediate low half: opcode 0x{op:02X}")


def read_disc_range(path, lba, size):
    b = bytearray()
    with open(path, "rb") as f:
        for i in range((size + USZ - 1) // USZ):
            f.seek((lba + i) * RAW + UOFF)
            b.extend(f.read(USZ))
    return bytearray(b[:size])


def find_exe(path):
    with open(path, "rb") as f:
        f.seek(22 * RAW + UOFF)
        d = f.read(USZ)
    off = 0
    while off < len(d):
        rl = d[off]
        if rl == 0:
            break
        nl = d[off + 32]
        name = d[off + 33:off + 33 + nl].decode("ascii", "replace")
        if name.startswith("SL") and "SYSTEM" not in name:
            return (struct.unpack_from("<I", d, off + 2)[0],
                    struct.unpack_from("<I", d, off + 10)[0])
        off += rl
    raise SystemExit("[FAIL] executable not in ISO directory")


def find_block_anywhere(disc, block_id, search_from=100000):
    """Sector-scan for a block header. Returns (sec, off, hdr6) or Nones."""
    tot = os.path.getsize(disc) // RAW
    CHUNK = 2048
    with open(disc, "rb") as f:
        for s_start in range(search_from, tot, CHUNK):
            n_sec = min(CHUNK, tot - s_start)
            f.seek(s_start * RAW)
            raw = f.read(n_sec * RAW)
            for i in range(n_sec):
                u = raw[i * RAW + UOFF: i * RAW + UOFF + USZ]
                for off in range(0, USZ - 24, 4):
                    end, bid, hts, tre, txe, unk = struct.unpack_from("<6I", u, off)
                    if (bid & 0xFFFF) == block_id and 24 <= hts < txe < end <= 16384:
                        return s_start + i, off, (end, bid, hts, tre, txe, unk)
    return None, None, None


def read_block_bytes(disc, sec, off, length):
    out = bytearray()
    pos, rem, cur_off = sec, length, off
    with open(disc, "rb") as f:
        while rem > 0:
            f.seek(pos * RAW + UOFF)
            u = f.read(USZ)
            take = min(rem, USZ - cur_off)
            out.extend(u[cur_off:cur_off + take])
            rem -= take
            pos += 1
            cur_off = 0
    return bytes(out)


def is_delim(leaf):
    return (leaf.content[0] << 8) | leaf.content[1] == 0


def parse_block_pristine(blk, bid):
    """Parse pristine block: 0x0474/0x048C raw, others apply trim_trailing_garbage_leaves."""
    end, bid_, hts, tre, txe, unk = struct.unpack_from("<6I", blk, 0)
    ts, tm, nn = struct.unpack_from("<IIH", blk, txe)
    tree = SC.parse_tree(bytes(blk[ts:ts + 4 * nn + 6]))
    leaves = SC.decode(blk[hts:txe], tree)
    if bid in (0x0474, 0x048C):
        pass
    else:
        leaves, _ = P.trim_trailing_garbage_leaves(leaves)
    offs = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]
    return hts, len(offs), offs


def parse_block_master(blk, bid):
    """Parse master block: 0x0474/0x048C raw, others drop only trailing unterminated run."""
    end, bid_, hts, tre, txe, unk = struct.unpack_from("<6I", blk, 0)
    ts, tm, nn = struct.unpack_from("<IIH", blk, txe)
    tree = SC.parse_tree(bytes(blk[ts:ts + 4 * nn + 6]))
    leaves = SC.decode(blk[hts:txe], tree)
    if bid in (0x0474, 0x048C):
        pass
    else:
        last_delim = -1
        for idx, l in enumerate(leaves):
            if is_delim(l):
                last_delim = idx
        if last_delim != -1 and last_delim + 1 < len(leaves):
            leaves = leaves[:last_delim + 1]
    offs = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]
    return hts, len(offs), offs


def locate_in_exe(exe, block_id):
    for x in range(0, len(exe) - 24, 4):
        end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe, x)
        if (bid & 0xFFFF) == block_id and hts == 24 and 24 < txe < end <= 8192:
            return x, end
    return None, None


def locate_battle_block(disc, block_id=0x048B, first=105000, span=1500):
    """Same locator patch_battle_overlay uses (byte pattern, sector-wise read)."""
    target = struct.pack("<II", block_id, 24)
    with open(disc, "rb") as f:
        f.seek(first * RAW)
        u = bytearray()
        for _ in range(span):
            u.extend(f.read(RAW)[UOFF:UOFF + USZ])
    idx = u.find(target)
    if idx < 4:
        return None, None, None
    hdr_off = idx - 4
    sec = first + (hdr_off // USZ)
    off = hdr_off % USZ
    hdr = struct.unpack_from("<6I", u, hdr_off)
    return sec, off, hdr


def scan_split_pairs(buf, resolve_func, target_luis, window=WINDOW):
    """Fast pending-lui dataflow scanner with writes() clobber model.
    resolve_func(val, lo_op) -> new_val or None.
    target_luis is a set of valid lui immediate values (with addiu carry)."""
    out = []
    pending = {}  # reg -> (offset, lui_imm)
    words = struct.unpack(f"<{len(buf) // 4}I", buf[:(len(buf) // 4) * 4])

    for i, w in enumerate(words):
        op = (w >> 26) & 0x3F

        if not pending:
            if op == LUI:
                imm = w & 0xFFFF
                if imm in target_luis and ((w >> 21) & 0x1F) == 0:
                    rt = (w >> 16) & 0x1F
                    pending[rt] = (i * 4, imm)
            continue

        rs = (w >> 21) & 0x1F
        rt = (w >> 16) & 0x1F
        imm = w & 0xFFFF
        o = i * 4

        if op == LUI:
            if rs == 0 and imm in target_luis:
                pending[rt] = (o, imm)
            else:
                pending.pop(rt, None)
            continue

        if op in (ORI, ADDIU) and rs == rt:
            live = pending.get(rt)
            if live is not None and (o - live[0]) <= 4 * window:
                val = compose(live[1], imm, op)
                new_val = resolve_func(val, op)
                if new_val is not None:
                    out.append((live[0], o, op, val, new_val))
                del pending[rt]
                continue

        d = writes(w)
        if d is not None:
            pending.pop(d, None)
    return out


def has_target_lui(buf, target_luis):
    """Quick check if a buffer contains any target LUI."""
    words = struct.unpack(f"<{len(buf) // 4}I", buf[:(len(buf) // 4) * 4])
    for w in words:
        if (w >> 26) == LUI and (w & 0xFFFF) in target_luis and ((w >> 21) & 0x1F) == 0:
            return True
    return False


def _default_base():
    cands = [
        os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"),
        os.path.join(os.path.dirname(ROOT), "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"),
    ]
    for c in cands:
        if os.path.exists(c):
            return c
    return cands[0]


def build_omaps(pristine_disc, master_disc):
    """Builds per-block omaps, pos tables, and hts."""
    omaps = {}          # block_id -> {old_bit: new_bit}
    hts_by = {}         # block_id -> hts
    pos_by = {}         # block_id -> {old_bit: seq_idx}
    seq_count_by = {}   # block_id -> total_seq_count

    plba0, psize0 = find_exe(pristine_disc)
    mlba0, msize0 = find_exe(master_disc)
    pexe0 = read_disc_range(pristine_disc, plba0, psize0)
    mexe0 = read_disc_range(master_disc, mlba0, msize0)

    for bid in TARGET_BLOCKS:
        if bid == 0x048C:
            po, pend = locate_in_exe(pexe0, bid)
            mo, mend = locate_in_exe(mexe0, bid)
            if po is None or mo is None:
                print("  block 0x%04X: NOT FOUND in EXE -- skipped" % bid)
                continue
            pb = parse_block_pristine(bytes(pexe0[po:po + pend]), bid)
            mb = parse_block_master(bytes(mexe0[mo:mo + mend]), bid)
            sec_p, sec_m = -1, -1
        elif bid == 0x048B:
            sp, so, hp = locate_battle_block(pristine_disc, bid)
            sm, om, hm = locate_battle_block(master_disc, bid)
            if sp is None or sm is None:
                print("  block 0x%04X: NOT FOUND (battle locator) -- skipped" % bid)
                continue
            pb = parse_block_pristine(read_block_bytes(pristine_disc, sp, so, hp[0]), bid)
            mb = parse_block_master(read_block_bytes(master_disc, sm, om, hm[0]), bid)
            sec_p, sec_m = sp, sm
        else:
            sp, so, hp = find_block_anywhere(pristine_disc, bid)
            sm, om, hm = find_block_anywhere(master_disc, bid)
            if sp is None or sm is None:
                print("  block 0x%04X: NOT FOUND (pristine=%s master=%s) -- skipped" % (bid, sp, sm))
                continue
            pb = parse_block_pristine(read_block_bytes(pristine_disc, sp, so, hp[0]), bid)
            mb = parse_block_master(read_block_bytes(master_disc, sm, om, hm[0]), bid)
            sec_p, sec_m = sp, sm

        p_hts, p_n, p_offs = pb
        m_hts, m_n, m_offs = mb
        if m_n < p_n:
            # F2 FOLD (Sep-08): STEP 1's re-encode can drop tail sequences
            # (observed: the last seq, an unreferenced '!' artifact â€” 0479
            # 23->22, 047B 251->250, 047D 291->290). Ordinal identity holds
            # for the prefix, so bind pristine seqs 0..m_n-1 to master seqs
            # 0..m_n-1 and leave the unbound tail OUT of the omap: its
            # referrers (none known) keep their pristine-consistent offsets.
            # GUARD: only bind when the unbound pristine tail seqs are
            # artifact-like ('!' / empty). Otherwise fall back to the old
            # skip. The G2 multi-tree gate arbitrates the result.
            bindable = True
            try:
                if bid == 0x048C:
                    praw = bytes(pexe0[po:po + pend])
                else:
                    praw = read_block_bytes(pristine_disc, sp, so, hp[0])
                _tb = _TextBlock(praw)
                _tree = _huffman.HuffmanTree(_tb)
                for _bit in p_offs[m_n:]:
                    _s = "".join(_R.decode_at(_tb, _bit, _tree, 300))
                    _s = _s.split("<END>")[0].strip().strip("\u3000").strip()
                    # RC-2: a control-only tail ({7f0b} terminator / pad
                    # markers) is artifact-like too -- visible chars after
                    # stripping {XXXX} tokens is the test, so a pure control
                    # tail binds while real text still blocks the fold.
                    _vis = re.sub(r"\{[0-9a-fA-F]{4}\}", "", _s).strip()
                    if _vis not in ("",):
                        if _s not in ("!", "ａ"):
                            bindable = False
                            break
            except Exception as _e:
                print("  block 0x%04X: tail probe failed (%s) -- skipped" % (bid, _e))
                continue
            if not bindable:
                print("  block 0x%04X: seq count drift %d != %d (tail not artifact) -- skipped"
                      % (bid, p_n, m_n))
                continue
            print("  block 0x%04X: seq count drift %d != %d -- PREFIX-BIND first %d "
                  "(tail %d artifact seqs unbound; G2 arbitrates)"
                  % (bid, p_n, m_n, m_n, p_n - m_n))
            p_offs = p_offs[:m_n]
            p_n = m_n
        if m_n > p_n:
            # STEP 1 re-encode appends artifact padding sequences at the TAIL
            # (proven on 0x0489: real seqs keep ordinals 1..N, then zero-pad /
            # 'i'-pad artifacts). Real sequence bit-offsets are unchanged, so
            # the ordinal mapping stays valid for the first p_n entries.
            print("  block 0x%04X: %d artifact pad seqs (tail) -- using first %d"
                  % (bid, m_n - p_n, p_n))
            m_offs = m_offs[:p_n]

        omaps[bid] = {p_offs[i]: m_offs[i] for i in range(p_n)
                      if p_offs[i] != m_offs[i]}
        hts_by[bid] = p_hts
        pos_by[bid] = {p_offs[i]: i for i in range(p_n)}
        seq_count_by[bid] = p_n
        moved = len(omaps[bid])
        print("  block 0x%04X: sec %d->%d  hts=%d  seqs=%d  shifted=%d"
              % (bid, sec_p, sec_m, p_hts, p_n, moved))

    return omaps, hts_by, pos_by, seq_count_by


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_sovereign_master.bin"))
    ap.add_argument("--base", default=_default_base())
    ap.add_argument("--report", action="store_true", help="scan only, write nothing")
    args = ap.parse_args()

    master, pristine = args.disc, args.base
    print("=" * 70)
    print("  OVERLAY STALE-REF REMAP (post-pass, pristine-compare filter)")
    print("=" * 70)

    omaps, hts_by, pos_by, seq_count_by = build_omaps(pristine, master)
    if not omaps:
        raise SystemExit("[FAIL] no target blocks could be parsed")

    # Precalculate valid target lui immediates (exact + addiu carry)
    target_luis = set()
    for bid in omaps:
        target_luis.add(bid << 4)
        target_luis.add((bid << 4) + 1)

    def resolve_val(val, lo_op=None):
        """Resolves val to new word with noise control and last-offset exclusion."""
        bid = val >> 20
        if bid not in omaps:
            return None
        rel = (val & 0xFFFFF) - hts_by[bid] * 8
        if rel not in omaps[bid]:
            return None
        seq_idx = pos_by[bid].get(rel)
        # Last offset exclusion: trailing residue is not a valid sequence
        if seq_idx is None or seq_idx + 1 >= seq_count_by[bid]:
            return None
        new_rel = omaps[bid][rel] + hts_by[bid] * 8
        return (bid << 20) | (new_rel & 0xFFFFF)

    # ---- EXE scan --------------------------------------------------------
    plba, psize = find_exe(pristine)
    mlba, msize = find_exe(master)
    pexe = read_disc_range(pristine, plba, psize)
    mexe = read_disc_range(master, mlba, msize)
    tsize = struct.unpack_from("<I", pexe, 0x1C)[0]

    exe_stats = {bid: [0, 0] for bid in omaps}   # direct, split
    exe_writes = []                              # (off, newword) for direct; ("split", so, off2, hi_w, lo_w)

    for w_off in range(0x800, min(tsize, len(mexe) - 4), 4):
        wm = struct.unpack_from("<I", mexe, w_off)[0]
        if (wm >> 20) not in omaps:
            continue
        new_w = resolve_val(wm)
        if new_w is None:
            continue
        wp = struct.unpack_from("<I", pexe, w_off)[0]
        if wp != wm:
            continue  # already remapped
        bid = wm >> 20
        exe_writes.append((w_off, new_w))
        exe_stats[bid][0] += 1

    for hi_off, lo_off, op, old_val, new_val in scan_split_pairs(mexe, resolve_val, target_luis, window=WINDOW):
        if mexe[hi_off:hi_off + 4] != pexe[hi_off:hi_off + 4] or mexe[lo_off:lo_off + 4] != pexe[lo_off:lo_off + 4]:
            continue  # already remapped
        bid = old_val >> 20
        w1 = struct.unpack_from("<I", mexe, hi_off)[0]
        w2 = struct.unpack_from("<I", mexe, lo_off)[0]
        n_hi, n_lo = halves(new_val, op)
        exe_writes.append(("split", hi_off, lo_off, (w1 & 0xFFFF0000) | n_hi, (w2 & 0xFFFF0000) | n_lo))
        exe_stats[bid][1] += 1

    # ---- overlay scan (full disc, chunked 1024 sectors) ----------------
    hbd_start = mlba + ((msize + USZ - 1) // USZ)
    tot = os.path.getsize(master) // RAW
    ov_stats = {bid: [0, 0, 0] for bid in omaps}   # direct, split, straddle
    ov_writes = []                                  # (sec, kind, data...)
    prev_m = b""
    prev_p = b""

    CHUNK_SECS = 1024
    cur_sec = hbd_start
    with open(master, "rb") as fm, open(pristine, "rb") as fq:
        while cur_sec < tot:
            n_sec = min(CHUNK_SECS, tot - cur_sec)
            fm.seek(cur_sec * RAW)
            fq.seek(cur_sec * RAW)
            raw_m = fm.read(n_sec * RAW)
            raw_p = fq.read(n_sec * RAW)

            for i in range(n_sec):
                sec = cur_sec + i
                cm = raw_m[i * RAW + UOFF: i * RAW + UOFF + USZ]
                cp = raw_p[i * RAW + UOFF: i * RAW + UOFF + USZ]

                # 1. direct words (unpack entire sector in one call)
                words_m = struct.unpack("<512I", cm)
                words_p = struct.unpack("<512I", cp)
                for idx, wm in enumerate(words_m):
                    bid = wm >> 20
                    if bid not in omaps:
                        continue
                    if words_p[idx] != wm:
                        continue  # already remapped
                    new_w = resolve_val(wm)
                    if new_w is None:
                        continue
                    off = idx * 4
                    ov_writes.append((sec, "direct", off, new_w))
                    ov_stats[bid][0] += 1

                # 2. in-sector split pairs
                for hi_off, lo_off, op, old_val, new_val in scan_split_pairs(cm, resolve_val, target_luis, window=WINDOW):
                    if cm[hi_off:hi_off + 4] != cp[hi_off:hi_off + 4] or cm[lo_off:lo_off + 4] != cp[lo_off:lo_off + 4]:
                        continue
                    bid = old_val >> 20
                    w1 = struct.unpack_from("<I", cm, hi_off)[0]
                    w2 = struct.unpack_from("<I", cm, lo_off)[0]
                    n_hi, n_lo = halves(new_val, op)
                    ov_writes.append((sec, "split", hi_off, lo_off,
                                      (w1 & 0xFFFF0000) | n_hi, (w2 & 0xFFFF0000) | n_lo))
                    ov_stats[bid][1] += 1

                # 3. cross-sector straddles (only if prev sector tail has a target lui)
                if prev_m and has_target_lui(prev_m, target_luis):
                    win_m = prev_m + cm[:WINDOW_BYTES]
                    win_p = prev_p + cp[:WINDOW_BYTES]
                    base = len(prev_m)
                    for hi_off, lo_off, op, old_val, new_val in scan_split_pairs(win_m, resolve_val, target_luis, window=WINDOW):
                        if not (hi_off < base <= lo_off):
                            continue
                        if win_m[hi_off:hi_off + 4] != win_p[hi_off:hi_off + 4] or win_m[lo_off:lo_off + 4] != win_p[lo_off:lo_off + 4]:
                            continue
                        bid = old_val >> 20
                        w1 = struct.unpack_from("<I", win_m, hi_off)[0]
                        w2 = struct.unpack_from("<I", win_m, lo_off)[0]
                        n_hi, n_lo = halves(new_val, op)
                        ov_writes.append((sec - 1, "straddle", USZ - (base - hi_off), lo_off - base,
                                          (w1 & 0xFFFF0000) | n_hi, (w2 & 0xFFFF0000) | n_lo))
                        ov_stats[bid][2] += 1

                prev_m, prev_p = cm[-WINDOW_BYTES:], cp[-WINDOW_BYTES:]

            cur_sec += n_sec

    # ---- report ----------------------------------------------------------
    print()
    print("  %-8s %8s %8s %10s %10s" % ("block", "exe d/s", "ov d/s", "straddle", "status"))
    total = 0
    for bid in TARGET_BLOCKS:
        if bid not in omaps:
            continue
        d, s = exe_stats[bid]
        odw, osp, ost = ov_stats[bid]
        tot_b = d + s + odw + osp + ost
        total += tot_b
        print("  0x%04X   %4d/%-4d %4d/%-4d %6d      %s"
              % (bid, d, s, odw, osp, ost, "REMAP" if tot_b else "clean"))
    print("  TOTAL stale referrers found: %d" % total)

    if args.report:
        print("  REPORT ONLY -- nothing written")
        return 0
    if total == 0:
        print("  nothing to do")
        return 0

    # ---- apply EXE writes ------------------------------------------------
    for item in exe_writes:
        if item[0] == "split":
            _, so, off2, hi_w, lo_w = item
            struct.pack_into("<I", mexe, so, hi_w)
            struct.pack_into("<I", mexe, off2, lo_w)
        else:
            w_off, new_w = item
            struct.pack_into("<I", mexe, w_off, new_w)
    with open(master, "r+b") as f:
        for i in range((msize + USZ - 1) // USZ):
            chunk = bytes(mexe[i * USZ:(i + 1) * USZ])
            if len(chunk) < USZ:
                chunk = chunk + b"\x00" * (USZ - len(chunk))
            f.seek((mlba + i) * RAW + UOFF)
            f.write(chunk)

    # ---- apply overlay writes -------------------------------------------
    # group by sector
    by_sec = {}
    for item in ov_writes:
        if item[1] == "straddle":
            sec_hi, _, hi_off, lo_off, hi_w, lo_w = item
            by_sec.setdefault(sec_hi, []).append(("direct_patch", hi_off, hi_w))
            by_sec.setdefault(sec_hi + 1, []).append(("direct_patch", lo_off, lo_w))
        else:
            by_sec.setdefault(item[0], []).append(item)

    with open(master, "r+b") as f:
        for sec, items in sorted(by_sec.items()):
            f.seek(sec * RAW + UOFF)
            chunk = bytearray(f.read(USZ))
            for item in items:
                if item[0] == "direct_patch":
                    _, off, new_w = item
                    struct.pack_into("<I", chunk, off, new_w)
                elif item[1] == "direct":
                    _, _, off, new_w = item
                    struct.pack_into("<I", chunk, off, new_w)
                elif item[1] == "split":
                    _, _, so, off2, hi_w, lo_w = item
                    struct.pack_into("<I", chunk, so, hi_w)
                    struct.pack_into("<I", chunk, off2, lo_w)
            f.seek(sec * RAW + UOFF)
            f.write(chunk)

    print("  wrote EXE refs: %d   overlay refs: %d across %d sectors"
          % (len(exe_writes), len(ov_writes), len(by_sec)))
    print("  NOTE: run edcre (STEP 5) after this pass -- overlay EDC/ECC changed")
    return 0


if __name__ == "__main__":
    sys.exit(main())


