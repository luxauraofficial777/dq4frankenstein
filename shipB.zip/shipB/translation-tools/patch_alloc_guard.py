#!/usr/bin/env python3
"""
patch_alloc_guard.py

Dynamic KSEG0 allocator guard — intercepts all calls through the allocator
wrapper at 0x8009B138 and range-checks the target address (a0) against the
resident message module's protected range [0x80011F00, 0x80012F00).

If a0 falls within the protected range, the guard remaps it by adding
0x2100 (shifting from 0x80011F00 → 0x80014000, the free scratch space
between the module end and the EXE load address).

This is a GENERAL fix that catches ALL allocator call sites, including
dynamic addresses computed at runtime (e.g., the call at 0x8005A57C where
a0 = s3 = s2 + 0xC, with s2 being a dynamically computed base address).

ARCHITECTURE:
  Caller → jal 0x8009B138 (wrapper)
    Wrapper: sp -= 0x18; sw ra,0x10(sp); jal 0x800B8924 (guard); ...
  Guard at 0x800B8924:
    Save ra to 0x14(sp)  [free slot in wrapper's frame]
    if a0 < 0x80011F00: skip check (below protected range)
    if a0 >= 0x80012F00: skip check (above protected range)
    else: a0 += 0x2100 (remap to safe region 0x80014000+)
    jal 0x8009C658 (real CD-ROM DMA allocator)
    restore ra; return to wrapper

PROTECTED RANGE:
  0x80011F00 – 0x80012EFF : resident message module (code + data)
  0x80014000 – 0x80017EFF : safe scratch space (0x3F00 bytes)
  0x800C06B8              : BSS start (message-queue pointer)

PATCH SITES:
  1. EXE offset 0x83A40 (RAM 0x8009B140):
     jal 0x8009C658 (0x0C002719) → jal 0x800B8924 (0x0C002E49)
     Redirects wrapper's inner call to guard routine

  2. EXE offset 0xA1224 (RAM 0x800B8924):
     17 instructions of guard code written to free space (was all zeros)
"""
import struct
import sys
import os
import subprocess

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

# Disc sector geometry (matches patch_f6_overlay_collision.py)
RAW, UOFF, USZ = 2352, 24, 2048
EXE_LBA, EXE_SECTORS = 24, 338
EXE_SIZE = EXE_SECTORS * USZ

# PSX EXE load address
RAM_BASE = 0x80017700

# ── Patch site 1: redirect wrapper's jal ──────────────────────────────
WRAPPER_JAL_RAM = 0x8009B140
WRAPPER_JAL_OFF = WRAPPER_JAL_RAM - RAM_BASE  # 0x83A40
EXPECTED_ORIG_JAL = 0x0C027196  # jal 0x8009C658
PATCH_NEW_JAL = 0x0C02E249      # jal 0x800B8924

# ── Patch site 2: guard code in free space ────────────────────────────
GUARD_RAM = 0x800B8924
GUARD_OFF = GUARD_RAM - RAM_BASE  # 0xA1224
GUARD_SIZE = 17 * 4  # 68 bytes

# ── Guard code (17 MIPS instructions) ────────────────────────────────
# Protected range: [0x80011F00, 0x80012F00)
# Remap offset: +0x2100 (0x80011F00 → 0x80014000)
GUARD_CODE = [
    0xAFBF0014,  # [0]  sw $ra, 0x14($sp) — save return addr (free slot)
    0x3C028001,  # [1]  lui $v0, 0x8001
    0x34421F00,  # [2]  ori $v0, $v0, 0x1F00 — v0 = 0x80011F00 (protected start)
    0x0082582B,  # [3]  sltu $v1, $a0, $v0 — v1 = (a0 < protected_start)
    0x14600007,  # [4]  bnez $v1, +7 — if below range, skip to jal
    0x00000000,  # [5]  nop (delay slot)
    0x3C028001,  # [6]  lui $v0, 0x8001
    0x34422F00,  # [7]  ori $v0, $v0, 0x2F00 — v0 = 0x80012F00 (protected end)
    0x0082582B,  # [8]  sltu $v1, $a0, $v0 — v1 = (a0 < protected_end)
    0x10600002,  # [9]  beqz $v1, +2 — if above range, skip to jal
    0x00000000,  # [10] nop (delay slot)
    0x24842100,  # [11] addiu $a0, $a0, 0x2100 — REMAP to safe region
    0x0C027196,  # [12] jal 0x8009C658 — call real inner allocator
    0x00000000,  # [13] nop (delay slot)
    0x8FBF0014,  # [14] lw $ra, 0x14($sp) — restore return addr
    0x03E00008,  # [15] jr $ra — return to wrapper (0x8009B148)
    0x00000000,  # [16] nop (delay slot)
]

EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")


def is_disc_image(path):
    with open(path, "rb") as f:
        head = f.read(16)
    return head[:8] != b"PS-X EXE"


def read_exe_from_disc(disc_path):
    exe = bytearray()
    with open(disc_path, "rb") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            exe.extend(f.read(USZ))
    return exe[:EXE_SIZE]


def write_exe_to_disc(disc_path, exe_data):
    with open(disc_path, "r+b") as f:
        for i in range(EXE_SECTORS):
            f.seek((EXE_LBA + i) * RAW + UOFF)
            f.write(bytes(exe_data[i * USZ:(i + 1) * USZ]))


def apply_patch(disc_path, verify_only=False):
    disc = is_disc_image(disc_path)
    if disc:
        print("  Mode: disc image (MODE2/2352, LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))
        exe = read_exe_from_disc(disc_path)
    else:
        print("  Mode: raw PS-X EXE")
        with open(disc_path, "rb") as f:
            exe = bytearray(f.read())

    print("  EXE size: %d bytes (0x%X)" % (len(exe), len(exe)))

    # ── Verify patch site 1: wrapper jal ─────────────────────────────
    if WRAPPER_JAL_OFF + 4 > len(exe):
        print("[FAIL] Wrapper jal offset 0x%X beyond EXE size" % WRAPPER_JAL_OFF)
        sys.exit(1)

    orig_jal = struct.unpack_from("<I", exe, WRAPPER_JAL_OFF)[0]
    print("  Patch site 1: RAM 0x%08X, EXE offset 0x%X" % (WRAPPER_JAL_RAM, WRAPPER_JAL_OFF))
    print("    Current: 0x%08X (expected 0x%08X original, 0x%08X patched)" % (
        orig_jal, EXPECTED_ORIG_JAL, PATCH_NEW_JAL))

    if orig_jal == EXPECTED_ORIG_JAL:
        print("    [OK] Original jal 0x8009C658 — ready to patch")
    elif orig_jal == PATCH_NEW_JAL:
        print("    [SKIP] Already patched (jal 0x800B8924)")
    else:
        print("[FAIL] Unexpected byte at wrapper jal site")
        sys.exit(1)

    # ── Verify patch site 2: guard code free space ───────────────────
    if GUARD_OFF + GUARD_SIZE > len(exe):
        print("[FAIL] Guard code offset 0x%X beyond EXE size" % GUARD_OFF)
        sys.exit(1)

    print("  Patch site 2: RAM 0x%08X, EXE offset 0x%X (%d bytes)" % (
        GUARD_RAM, GUARD_OFF, GUARD_SIZE))

    # Check that the free space is all zeros (or already contains our guard)
    is_free = True
    is_guarded = True
    for i in range(GUARD_SIZE):
        b = exe[GUARD_OFF + i]
        if b != 0:
            is_free = False
        # Check if it matches our guard code
    for i in range(len(GUARD_CODE)):
        w = struct.unpack_from("<I", exe, GUARD_OFF + i * 4)[0]
        if w != GUARD_CODE[i]:
            is_guarded = False
            break

    if is_guarded:
        print("    [SKIP] Guard code already present")
    elif is_free:
        print("    [OK] Free space verified (all zeros) — ready for guard code")
    else:
        print("[FAIL] Free space at 0x%X is not empty — aborting" % GUARD_OFF)
        sys.exit(1)

    if verify_only:
        print("  [VERIFY] Patch not applied (verify-only mode)")
        return

    # ── Apply patch 1: redirect wrapper jal ──────────────────────────
    if orig_jal == EXPECTED_ORIG_JAL:
        print("  Patching wrapper: jal 0x8009C658 → jal 0x800B8924")
        struct.pack_into("<I", exe, WRAPPER_JAL_OFF, PATCH_NEW_JAL)
        v = struct.unpack_from("<I", exe, WRAPPER_JAL_OFF)[0]
        if v != PATCH_NEW_JAL:
            print("[FAIL] Wrapper jal patch verification failed")
            sys.exit(1)
        print("    [OK] Wrapper now calls guard at 0x800B8924")

    # ── Apply patch 2: write guard code ──────────────────────────────
    if not is_guarded:
        print("  Writing guard code (%d instructions) to 0x%08X..." % (
            len(GUARD_CODE), GUARD_RAM))
        for i, instr in enumerate(GUARD_CODE):
            struct.pack_into("<I", exe, GUARD_OFF + i * 4, instr)
        # Verify
        for i, expected in enumerate(GUARD_CODE):
            v = struct.unpack_from("<I", exe, GUARD_OFF + i * 4)[0]
            if v != expected:
                print("[FAIL] Guard code verification failed at instruction %d" % i)
                print("  Expected 0x%08X, got 0x%08X" % (expected, v))
                sys.exit(1)
        print("    [OK] Guard code written and verified")

    # ── Write back ───────────────────────────────────────────────────
    if disc:
        write_exe_to_disc(disc_path, exe)
        print("  EXE written back to disc (LBA %d..%d)" % (EXE_LBA, EXE_LBA + EXE_SECTORS - 1))
        if os.path.exists(EDCRE):
            print("  Regenerating EDC/ECC...")
            r = subprocess.run([EDCRE, disc_path], capture_output=True, text=True, timeout=900)
            ok = r.returncode == 0
            print("  EDC/ECC: %s" % ("PASS" if ok else "FAIL"))
            if not ok:
                print("  stderr: %s" % r.stderr[-400:])
                sys.exit(1)
        else:
            print("  [WARN] edcre not found -- EDC/ECC not regenerated")
    else:
        with open(disc_path, "wb") as f:
            f.write(exe)
        print("  EXE written back")

    print("  [DONE] KSEG0 allocator guard active at 0x800B8924")
    print("  [DONE] Protected range: 0x80011F00-0x80012EFF (resident message module)")
    print("  [DONE] Remap target: 0x80014000-0x80014F00 (safe scratch space)")
    print("  [DONE] All 4 allocator call sites are now guarded")


if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser(
        description="KSEG0 allocator guard — dynamic range-check for resident memory protection")
    ap.add_argument("--disc", required=True, help="Path to master disc binary or raw EXE")
    ap.add_argument("--verify", action="store_true", help="Verify only, don't patch")
    args = ap.parse_args()

    print("KSEG0 Allocator Guard (Dynamic Range-Check)")
    print("  Disc: %s" % args.disc)
    apply_patch(args.disc, verify_only=args.verify)
