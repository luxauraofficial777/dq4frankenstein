"""
JSON schema serialization for the Heart Beat Engine.

Converts HuffmanNode trees and block metadata into JSON-friendly structures.
"""

from typing import Any, Dict, List

from hbe.huffman import HuffmanNode
from hbe.parser import TextContent


def tree_to_dict(root: HuffmanNode) -> Dict[str, Any]:
    """Serialize a Huffman tree to a nested dict."""
    node: Dict[str, Any] = {"type": root.node_type.name}
    if root.is_branch():
        node["id"] = root.node_id
        node["children"] = [tree_to_dict(c) for c in root.children]
    elif root.content is not None:
        node["content"] = root.content.hex().upper()
    return node


def tree_from_dict(data: Dict[str, Any]) -> HuffmanNode:
    """Deserialize a Huffman tree from a nested dict."""
    node_type = data["type"]
    if node_type == "Branch":
        node = HuffmanNode.branch(data.get("id", 0))
        node.children = [tree_from_dict(c) for c in data.get("children", [])]
        return node
    content = bytes.fromhex(data["content"])
    if node_type == "ControlCharacter":
        return HuffmanNode.control(content)
    if node_type == "Character":
        return HuffmanNode.character(content)
    raise ValueError(f"Unknown node type: {node_type}")


def text_content_to_dict(content: TextContent) -> Dict[str, Any]:
    """Serialize a TextContent object to a dict."""
    return {
        "type_id": content.type_id,
        "block_id": content.block_id_hex,
        "end": content.end,
        "huffman_text_start": content.huffman_text_start,
        "huffman_text_end": content.huffman_text_end,
        "huffman_tree_end": content.huffman_tree_end,
        "tree_number_of_nodes": content.tree_number_of_nodes,
        "dialog_pointer_count": content.dialog_pointer_count,
    }
