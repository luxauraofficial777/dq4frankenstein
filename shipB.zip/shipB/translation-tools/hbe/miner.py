"""
Mining tools for the Heart Beat Engine.

Pattern search across disc images, HBD archives, and EXEs.
"""

import re
import struct
from dataclasses import dataclass
from typing import List, Union

from hbe.archive import HBDArchive
from hbe.exe import EXE


@dataclass
class Match:
    """One pattern match."""

    source: str
    offset: int
    context: bytes
    meta: dict = None


class PatternMiner:
    """Search for bytes, SJIS strings, and control codes in HBD/EXE/Disc sources."""

    def find_bytes(self, pattern: bytes, source: Union[bytes, HBDArchive, EXE]) -> List[Match]:
        """Find all occurrences of a byte pattern."""
        data = self._to_bytes(source)
        matches = []
        for i in range(len(data) - len(pattern) + 1):
            if data[i:i + len(pattern)] == pattern:
                context = data[max(0, i - 16):i + len(pattern) + 16]
                matches.append(Match(source=self._source_name(source), offset=i, context=context))
        return matches

    def find_sjis(self, text: str, source: Union[bytes, HBDArchive, EXE]) -> List[Match]:
        """Find a Shift-JIS string in a source."""
        try:
            pattern = text.encode("shift_jis")
        except UnicodeEncodeError:
            return []
        return self.find_bytes(pattern, source)

    def find_control_code(self, code: bytes, archive: HBDArchive) -> List[Match]:
        """Find a control code in parsed text files (raw bytes)."""
        return self.find_bytes(code, archive)

    @staticmethod
    def _to_bytes(source: Union[bytes, HBDArchive, EXE]) -> bytes:
        if isinstance(source, bytes):
            return source
        if isinstance(source, HBDArchive):
            return source.data
        if isinstance(source, EXE):
            return bytes(source.data)
        raise TypeError(f"Unsupported source type: {type(source)}")

    @staticmethod
    def _source_name(source: Union[bytes, HBDArchive, EXE]) -> str:
        if isinstance(source, bytes):
            return "bytes"
        return type(source).__name__


class CrossGameMiner:
    """Compare blocks between two HBD archives (e.g. DQ4 vs DW7)."""

    def compare_headers(self, block_a: bytes, block_b: bytes) -> dict:
        """Compare 24-byte block headers."""
        if len(block_a) < 24 or len(block_b) < 24:
            return {"error": "block too short"}
        a = struct.unpack("<6I", block_a[:24])
        b = struct.unpack("<6I", block_b[:24])
        return {
            "end_diff": a[0] - b[0],
            "id_diff": a[1] - b[1],
            "hts_diff": a[2] - b[2],
            "tree_end_diff": a[3] - b[3],
            "text_end_diff": a[4] - b[4],
            "unknown_diff": a[5] - b[5],
        }
