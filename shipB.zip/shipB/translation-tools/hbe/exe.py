"""
PSX EXE pointer table utilities for the Heart Beat Engine.

The EXE stores 4-byte encoded references to HBD folders. This module provides
symmetric encode/decode functions matching the Java reference:

    start_hex = 8-char BE hex of start sector
    count_hex = 8-char BE hex of sector count
    combined    = count_hex[5:8] + start_hex[3:8]  # 3 + 5 chars
    encoded     = reverse byte order of combined
"""

import struct
from dataclasses import dataclass
from typing import List, Optional


@dataclass
class FolderPointer:
    """A decoded folder pointer found in the EXE."""

    start_sector: int
    sector_count: int
    exe_offset: Optional[int] = None

    def encode(self) -> bytes:
        """Encode this pointer into the 4-byte EXE format."""
        start_hex = f"{self.start_sector:08X}"
        count_hex = f"{self.sector_count:08X}"
        combined = count_hex[5:8] + start_hex[3:8]
        return bytes.fromhex(combined)[::-1]


def decode_pointer(data: bytes) -> FolderPointer:
    """Decode 4 bytes from the EXE into a folder pointer."""
    if len(data) != 4:
        raise ValueError("Pointer must be 4 bytes")
    reversed_bytes = data[::-1]
    hex_str = reversed_bytes.hex().upper()
    count_part = hex_str[:3]
    start_part = hex_str[3:]
    sector_count = int(count_part, 16)
    start_sector = int(start_part, 16)
    return FolderPointer(start_sector=start_sector, sector_count=sector_count)


class EXE:
    """In-memory model of a PSX EXE."""

    def __init__(self, data: bytes):
        self.data = bytearray(data)

    @classmethod
    def from_file(cls, path: str) -> "EXE":
        with open(path, "rb") as f:
            return cls(f.read())

    def read_pointer(self, offset: int) -> FolderPointer:
        """Read and decode a folder pointer at the given EXE offset."""
        ptr = decode_pointer(self.data[offset:offset + 4])
        ptr.exe_offset = offset
        return ptr

    def write_pointer(self, offset: int, pointer: FolderPointer) -> None:
        """Encode and write a folder pointer at the given EXE offset."""
        self.data[offset:offset + 4] = pointer.encode()

    def find_pointer_pattern(self, start_sector: int, sector_count: int) -> List[int]:
        """Find all EXE offsets that encode the given folder pointer."""
        needle = FolderPointer(start_sector, sector_count).encode()
        matches = []
        for i in range(len(self.data) - 3):
            if self.data[i:i + 4] == needle:
                matches.append(i)
        return matches
