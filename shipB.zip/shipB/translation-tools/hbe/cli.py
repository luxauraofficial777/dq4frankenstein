"""
Command-line interface for the Heart Beat Engine toolchain.

Supports one deterministic tick at a time:

    python -m hbe tick --game dq4 --folder 26046 --file 6 --action decode
    python -m hbe tick --game dw7 --search-tree --input HBD1PS1D.W7 --output dw7_tree_report.json

This module is intentionally lightweight; the real orchestration is built from
hbe.archive, hbe.parser, hbe.huffman, and hbe.miner.
"""

import argparse
import json
import sys
from pathlib import Path

from hbe.archive import HBDArchive
from hbe.huffman import DW7TreeMiner
from hbe.parser import default_registry


def cmd_tick(args):
    """Execute a single tick: read, parse, inspect, and report."""
    if not args.input:
        print("error: --input is required for tick", file=sys.stderr)
        return 1

    archive = HBDArchive.from_file(args.input)
    registry = default_registry()

    if args.folder is not None and args.file is not None:
        path = f"{args.folder}/{args.file}"
        file_obj = archive.get_file(path)
        if file_obj is None:
            print(f"error: file {path} not found", file=sys.stderr)
            return 1
        content = registry.parse_file(file_obj)
        print(f"File {path} (type {file_obj.type_id}):")
        print(f"  is_text: {content.is_text}")
        print(f"  raw size: {len(content.raw)}")
        if hasattr(content, "block_id_hex"):
            print(f"  block id: {content.block_id_hex}")
        if hasattr(content, "text"):
            print(f"  sequences: {len(content.text)}")
        return 0

    print("error: tick requires --folder and --file", file=sys.stderr)
    return 1


def cmd_search_tree(args):
    """Run the DW7 tree candidate search against a list of blocks."""
    if not args.input:
        print("error: --input is required for search-tree", file=sys.stderr)
        return 1

    # Load raw HBD and extract (tree_bytes, text_bytes) pairs.
    # For now, scan the first 2000 sectors for type-19 blocks.
    archive = HBDArchive.from_file(args.input)
    registry = default_registry()
    blocks = []
    for f in archive.files_of_type(19):
        try:
            data = registry.decompress_if_needed(f)
            if len(data) < 24:
                continue
            header = data[:24]
            import struct
            end, block_id, hts, tree_end, text_end, unknown = struct.unpack("<6I", header)
            # DW7 blocks have tree_end=text_end=0; use heuristic for gap.
            if text_end != 0:
                tree_bytes = data[text_end + 10:end]
                text_bytes = data[hts:text_end]
            else:
                # Heuristic: gap ends at hts; assume tree starts at hts + 10
                tree_start = hts + 10
                tree_bytes = data[tree_start:tree_start + 1024]
                text_bytes = data[hts:tree_start]
            blocks.append((tree_bytes, text_bytes))
        except Exception:
            continue

    miner = DW7TreeMiner()
    report = miner.mine(blocks)

    output_path = args.output or "dw7_tree_report.json"
    with open(output_path, "w", encoding="utf-8") as f:
        json.dump(report, f, indent=2)
    print(f"Wrote DW7 tree candidate report: {output_path}")
    if report:
        print(f"Best candidate: {report[0]['candidate']} "
              f"(score={report[0]['total_valid']})")
    return 0


def main(argv=None):
    parser = argparse.ArgumentParser(
        prog="hbe",
        description="Heart Beat Engine toolchain — one tick at a time.",
    )
    subparsers = parser.add_subparsers(dest="command")

    tick = subparsers.add_parser("tick", help="Run one deterministic tick")
    tick.add_argument("--game", choices=["dq4", "dw7", "dq7"], default="dq4")
    tick.add_argument("--input", type=str)
    tick.add_argument("--folder", type=int)
    tick.add_argument("--file", type=int)
    tick.add_argument("--action", choices=["decode", "encode", "inspect"], default="decode")
    tick.add_argument("--output", type=str)

    search = subparsers.add_parser("search-tree", help="Search for DW7 Huffman tree candidates")
    search.add_argument("--game", choices=["dw7", "dq7"], default="dw7")
    search.add_argument("--input", type=str)
    search.add_argument("--output", type=str)

    args = parser.parse_args(argv)
    if args.command is None:
        parser.print_help()
        return 1

    if args.command == "tick":
        return cmd_tick(args)
    if args.command == "search-tree":
        return cmd_search_tree(args)

    return 1


if __name__ == "__main__":
    sys.exit(main())
