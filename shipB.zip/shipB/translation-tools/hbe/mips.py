"""
MIPS R3000A disassembler for PSX EXE analysis.

Decodes MIPS I instructions, searches for Huffman decompression patterns,
and traces tree-loading code. Used to locate the compression schema in
any HeartBeat Engine EXE (DQ4, DW7, DQ7).
"""

import struct
from dataclasses import dataclass
from typing import List, Optional

REG_NAMES = [
    "zero", "at", "v0", "v1", "a0", "a1", "a2", "a3",
    "t0", "t1", "t2", "t3", "t4", "t5", "t6", "t7",
    "s0", "s1", "s2", "s3", "s4", "s5", "s6", "s7",
    "t8", "t9", "k0", "k1", "gp", "sp", "fp", "ra",
]

OP_SPECIAL = 0x00
OP_REGIMM  = 0x01
OP_J       = 0x02
OP_JAL     = 0x03
OP_BEQ     = 0x04
OP_BNE     = 0x05
OP_ADDIU   = 0x09
OP_ANDI    = 0x0C
OP_ORI     = 0x0D
OP_LUI     = 0x0F
OP_LH      = 0x21
OP_LW      = 0x23
OP_LHU     = 0x25
OP_SH      = 0x29
OP_SW      = 0x2B

FN_SLL  = 0x00
FN_SRL  = 0x02
FN_SRA  = 0x03
FN_SLLV = 0x04
FN_SRLV = 0x06
FN_JR   = 0x08
FN_ADDU = 0x21
FN_AND  = 0x24
FN_OR   = 0x25
FN_SLT  = 0x2A
FN_SLTU = 0x2B


@dataclass
class MIPSInstruction:
    offset: int
    raw: int
    opcode: int
    rs: int
    rt: int
    rd: int
    shamt: int
    funct: int
    immediate: int
    mnemonic: str
    operands: str
    is_branch: bool = False
    branch_target: Optional[int] = None
    is_load: bool = False
    is_store: bool = False

    @property
    def hex(self) -> str:
        return f"{self.raw:08X}"

    def __repr__(self) -> str:
        return f"0x{self.offset:05X}: {self.hex}  {self.mnemonic:<8} {self.operands}"


def _reg(n: int) -> str:
    return f"${REG_NAMES[n]}"


def decode_word(word: int, offset: int) -> MIPSInstruction:
    opcode = (word >> 26) & 0x3F
    rs = (word >> 21) & 0x1F
    rt = (word >> 16) & 0x1F
    rd = (word >> 11) & 0x1F
    shamt = (word >> 6) & 0x1F
    funct = word & 0x3F
    imm_raw = word & 0xFFFF
    immediate = imm_raw - 0x10000 if imm_raw & 0x8000 else imm_raw

    mn = ""
    ops = ""
    is_br = False
    bt = None
    is_ld = False
    is_st = False

    if opcode == OP_SPECIAL:
        fmap = {
            FN_SLL: "sll", FN_SRL: "srl", FN_SRA: "sra",
            FN_SLLV: "sllv", FN_SRLV: "srlv",
            FN_JR: "jr", FN_ADDU: "addu", FN_AND: "and",
            FN_OR: "or", FN_SLT: "slt", FN_SLTU: "sltu",
        }
        mn = fmap.get(funct, f"sp_{funct:02X}")
        if funct in (FN_SLL, FN_SRL, FN_SRA):
            ops = f"{_reg(rd)}, {_reg(rt)}, {shamt}"
        elif funct in (FN_SLLV, FN_SRLV):
            ops = f"{_reg(rd)}, {_reg(rt)}, {_reg(rs)}"
        elif funct == FN_JR:
            ops = _reg(rs)
        else:
            ops = f"{_reg(rd)}, {_reg(rs)}, {_reg(rt)}"

    elif opcode == OP_REGIMM:
        rt_names = {0: "bltz", 1: "bgez", 0x10: "bltzal", 0x11: "bgezal"}
        mn = rt_names.get(rt, f"ri_{rt:02X}")
        is_br = True
        bt = offset + 4 + (immediate << 2)
        ops = f"{_reg(rs)}, 0x{bt:X}"

    elif opcode in (OP_J, OP_JAL):
        mn = "j" if opcode == OP_J else "jal"
        is_br = True
        tgt = (word & 0x3FFFFFF) << 2
        bt = tgt  # Store as offset (lower 28 bits); caller must OR upper 4 bits
        ops = f"0x{tgt:08X}"

    elif opcode in (OP_BEQ, OP_BNE):
        mn = "beq" if opcode == OP_BEQ else "bne"
        is_br = True
        bt = offset + 4 + (immediate << 2)
        ops = f"{_reg(rs)}, {_reg(rt)}, 0x{bt:X}"

    elif opcode in (0x06, 0x07):
        mn = "blez" if opcode == 0x06 else "bgtz"
        is_br = True
        bt = offset + 4 + (immediate << 2)
        ops = f"{_reg(rs)}, 0x{bt:X}"

    elif opcode == OP_ADDIU:
        mn = "addiu"
        ops = f"{_reg(rt)}, {_reg(rs)}, {immediate}"

    elif opcode == OP_ANDI:
        mn = "andi"
        ops = f"{_reg(rt)}, {_reg(rs)}, 0x{imm_raw:04X}"

    elif opcode == OP_ORI:
        mn = "ori"
        ops = f"{_reg(rt)}, {_reg(rs)}, 0x{imm_raw:04X}"

    elif opcode == OP_LUI:
        mn = "lui"
        ops = f"{_reg(rt)}, 0x{imm_raw:04X}"

    elif opcode == OP_LH:
        mn = "lh"; is_ld = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    elif opcode == OP_LW:
        mn = "lw"; is_ld = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    elif opcode == OP_LHU:
        mn = "lhu"; is_ld = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    elif opcode == 0x24:
        mn = "lbu"; is_ld = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    elif opcode == OP_SH:
        mn = "sh"; is_st = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    elif opcode == OP_SW:
        mn = "sw"; is_st = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    elif opcode == 0x08:
        mn = "addi"
        ops = f"{_reg(rt)}, {_reg(rs)}, {immediate}"

    elif opcode == 0x0A:
        mn = "slti"
        ops = f"{_reg(rt)}, {_reg(rs)}, {immediate}"

    elif opcode == 0x28:
        mn = "sb"; is_st = True
        ops = f"{_reg(rt)}, {immediate}({_reg(rs)})"

    else:
        mn = f"op{opcode:02X}"
        ops = f"raw=0x{word:08X}"

    return MIPSInstruction(
        offset=offset, raw=word, opcode=opcode, rs=rs, rt=rt, rd=rd,
        shamt=shamt, funct=funct, immediate=immediate,
        mnemonic=mn, operands=ops, is_branch=is_br, branch_target=bt,
        is_load=is_ld, is_store=is_st,
    )


class MIPSDisassembler:
    """Disassemble a PSX EXE binary."""

    def __init__(self, data: bytes):
        self.data = data
        self.instructions: List[MIPSInstruction] = []
        self._disasm()

    def _disasm(self):
        for i in range(0, len(self.data) - 3, 4):
            word = struct.unpack_from("<I", self.data, i)[0]
            self.instructions.append(decode_word(word, i))

    def at(self, offset: int) -> Optional[MIPSInstruction]:
        idx = offset // 4
        return self.instructions[idx] if 0 <= idx < len(self.instructions) else None

    def range(self, start: int, end: int) -> List[MIPSInstruction]:
        return [i for i in self.instructions if start <= i.offset < end]

    def find_andi_0x8000(self) -> List[MIPSInstruction]:
        """Find andi rt, rs, 0x8000 — the classic Huffman branch-bit test."""
        return [i for i in self.instructions
                if i.opcode == OP_ANDI and (i.raw & 0xFFFF) == 0x8000]

    def find_andi_mask(self, mask: int) -> List[MIPSInstruction]:
        """Find andi with any specific mask value."""
        return [i for i in self.instructions
                if i.opcode == OP_ANDI and (i.raw & 0xFFFF) == mask]

    def find_lhu_sequences(self, window: int = 8) -> List[List[MIPSInstruction]]:
        """Find clusters of lhu instructions — Huffman tree node loads."""
        results = []
        i = 0
        while i < len(self.instructions):
            if self.instructions[i].opcode == OP_LHU:
                cluster = [self.instructions[i]]
                j = i + 1
                while j < len(self.instructions) and j - i < window:
                    if self.instructions[j].opcode == OP_LHU:
                        cluster.append(self.instructions[j])
                    elif self.instructions[j].opcode not in (OP_ANDI, OP_ORI, OP_ADDIU, OP_SPECIAL, OP_BEQ, OP_BNE, 0x06, 0x07):
                        break
                    j += 1
                if len(cluster) >= 2:
                    results.append(self.instructions[i:min(i + window, j)])
                i = j
            else:
                i += 1
        return results

    def find_huffman_patterns(self) -> List[dict]:
        """
        Find candidate Huffman decompression routines.

        Scans for instruction patterns that indicate bit-by-bit
        tree traversal: andi mask + branch + lhu + srl/sll.
        """
        signatures = []

        # Pattern 1: andi 0x8000 followed by branch + lhu within 6 instructions
        andi_hits = self.find_andi_0x8000()
        for hit in andi_hits:
            idx = self.instructions.index(hit)
            window = self.instructions[idx:idx + 10]
            has_branch = any(i.is_branch for i in window[1:5])
            has_lhu = any(i.opcode == OP_LHU for i in window[1:8])
            has_srl = any(i.funct == FN_SRL for i in window[1:6])
            score = sum([has_branch, has_lhu, has_srl])
            if score >= 2:
                signatures.append({
                    "name": "andi_0x8000_branch_lhu",
                    "offset": hit.offset,
                    "score": score,
                    "window": window,
                    "notes": f"andi 0x8000 at 0x{hit.offset:X}, "
                             f"branch={has_branch}, lhu={has_lhu}, srl={has_srl}",
                })

        # Pattern 2: andi with other common branch bits
        for mask in (0x4000, 0x0100, 0x0080, 0x0001, 0x7FFF):
            hits = self.find_andi_mask(mask)
            for hit in hits:
                idx = self.instructions.index(hit)
                window = self.instructions[idx:idx + 10]
                has_branch = any(i.is_branch for i in window[1:5])
                has_lhu = any(i.opcode == OP_LHU for i in window[1:8])
                if has_branch and has_lhu:
                    signatures.append({
                        "name": f"andi_0x{mask:04X}_branch_lhu",
                        "offset": hit.offset,
                        "score": 2,
                        "window": window,
                        "notes": f"andi 0x{mask:04X} at 0x{hit.offset:X}",
                    })

        # Pattern 3: srl rd, rt, 15 (testing bit 15 via shift) + branch + lhu
        for i_idx, ins in enumerate(self.instructions):
            if ins.funct == FN_SRL and ins.shamt == 15:
                window = self.instructions[i_idx:i_idx + 10]
                has_branch = any(i.is_branch for i in window[1:5])
                has_lhu = any(i.opcode == OP_LHU for i in window[1:8])
                if has_branch and has_lhu:
                    signatures.append({
                        "name": "srl_15_branch_lhu",
                        "offset": ins.offset,
                        "score": 2,
                        "window": window,
                        "notes": f"srl {ins.shamt} at 0x{ins.offset:X}",
                    })

        # Pattern 4: srl rd, rt, 7 (testing bit 7 — byte-level branch bit)
        for i_idx, ins in enumerate(self.instructions):
            if ins.funct == FN_SRL and ins.shamt == 7:
                window = self.instructions[i_idx:i_idx + 8]
                has_branch = any(i.is_branch for i in window[1:4])
                has_load = any(i.is_load for i in window[1:6])
                if has_branch and has_load:
                    signatures.append({
                        "name": "srl_7_branch_load",
                        "offset": ins.offset,
                        "score": 2,
                        "window": window,
                        "notes": f"srl 7 at 0x{ins.offset:X} (byte-level bit test)",
                    })

        signatures.sort(key=lambda s: s["score"], reverse=True)
        return signatures

    def find_lui_ori_pairs(self) -> List[dict]:
        """
        Find lui + ori pairs that build 32-bit addresses — these may
        point to the Huffman tree location in memory.
        """
        results = []
        for i in range(len(self.instructions) - 1):
            ins = self.instructions[i]
            nxt = self.instructions[i + 1]
            if ins.opcode == OP_LUI and nxt.opcode == OP_ORI:
                upper = (ins.raw & 0xFFFF) << 16
                lower = nxt.raw & 0xFFFF
                addr = upper | lower
                if 0x80000000 <= addr <= 0x80200000:
                    results.append({
                        "offset": ins.offset,
                        "addr": addr,
                        "lui": ins,
                        "ori": nxt,
                    })
        return results

    def find_data_references(self, target_low: int, target_high: int) -> List[dict]:
        """Find lui+ori pairs that build an address in a given range."""
        pairs = self.find_lui_ori_pairs()
        return [p for p in pairs if target_low <= p["addr"] <= target_high]

    def trace_branches_from(self, start_offset: int, depth: int = 30) -> List[MIPSInstruction]:
        """Trace a basic block from start_offset until unconditional jump or depth."""
        result = []
        ins = self.at(start_offset)
        if ins is None:
            return result
        for _ in range(depth):
            result.append(ins)
            if ins.mnemonic in ("jr", "j", "jal") and not ins.mnemonic.startswith("op"):
                break
            if ins.is_branch and ins.branch_target is not None:
                result.append(self.at(ins.branch_target) or ins)
            next_off = ins.offset + 4
            ins = self.at(next_off)
            if ins is None:
                break
        return result
