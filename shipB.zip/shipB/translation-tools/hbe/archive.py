"""
HBD archive model for the Heart Beat Engine.

Reads the HBD1PS1D file (already extracted from the disc) and classifies
entries into binary, 60010108, folder, and zero/padding sectors.
"""

import struct
from dataclasses import dataclass, field
from typing import List, Optional, Union


SECTOR_SIZE = 2048


@dataclass
class HBDFile:
    """A single file inside a folder."""
    index: int
    parent: "HBDFolder"
    size: int
    size_uncompressed: int
    unknown: bytes
    flags: int
    type_id: int
    content: bytes = field(default=b"")
    # Parsed content object, if a parser was applied.
    parsed: Optional[object] = None

    @property
    def is_compressed(self) -> bool:
        return self.size_uncompressed != self.size and self.flags != 0

    @property
    def path(self) -> str:
        return f"{self.parent.index}/{self.index}"

    def __repr__(self) -> str:
        return f"HBDFile({self.path}, type={self.type_id}, size={self.size})"


@dataclass
class HBDFolder:
    """A folder entry spanning one or more sectors."""
    index: int
    sector: int
    sector_count: int
    number_of_files: int
    size: int
    unknown: bytes
    files: List[HBDFile] = field(default_factory=list)

    @property
    def path(self) -> str:
        return f"folder/{self.index}"

    def __repr__(self) -> str:
        return f"HBDFolder({self.index}, sector={self.sector}, files={len(self.files)})"


@dataclass
class HBD600Entry:
    """A 60010108 entry."""
    index: int
    sector: int
    data: bytes


@dataclass
class HBDZeroEntry:
    """A zero/padding sector."""
    index: int
    sector: int


@dataclass
class HBDLogicalEntry:
    """Unrecognized or logical entry (e.g. the very first binary sector)."""
    index: int
    sector: int
    data: bytes


HBDEntry = Union[HBDLogicalEntry, HBD600Entry, HBDFolder, HBDZeroEntry]


class HBDArchive:
    """In-memory model of an HBD1PS1D archive."""

    def __init__(self, data: bytes):
        if len(data) % SECTOR_SIZE != 0:
            raise ValueError("HBD data must be a multiple of 2048 bytes")
        self.data = data
        self.entries: List[HBDEntry] = []
        self.folders: List[HBDFolder] = []
        self._parse()

    @classmethod
    def from_file(cls, path: str) -> "HBDArchive":
        with open(path, "rb") as f:
            return cls(f.read())

    @classmethod
    def from_disc_image(cls, path: str, start_sector: int, size: int) -> "HBDArchive":
        """
        Read the HBD from a raw PSX disc image (2352-byte sectors).
        Skips the 24-byte CD-ROM sub-header and reads only the 2048-byte user payload.
        """
        DISC_SECTOR_SIZE = 2352
        USER_DATA_OFFSET = 24
        num_sectors = size // SECTOR_SIZE

        with open(path, "rb") as f:
            data = bytearray()
            for i in range(num_sectors):
                f.seek((start_sector + i) * DISC_SECTOR_SIZE + USER_DATA_OFFSET)
                data.extend(f.read(SECTOR_SIZE))
        return cls(bytes(data))

    def _parse(self):
        entry_index = 0
        sector_index = 0
        total_sectors = len(self.data) // SECTOR_SIZE

        # First sector is the binary header.
        if total_sectors > 0:
            self.entries.append(HBDLogicalEntry(
                index=entry_index,
                sector=sector_index,
                data=self._sector(0)
            ))
            entry_index += 1
            sector_index += 1

        while sector_index < total_sectors:
            sector = self._sector(sector_index)
            if self._is_600(sector):
                self.entries.append(HBD600Entry(
                    index=entry_index,
                    sector=sector_index,
                    data=sector
                ))
                sector_index += 1
            elif self._is_folder(sector):
                try:
                    folder = self._parse_folder(sector_index, entry_index)
                    self.entries.append(folder)
                    self.folders.append(folder)
                    sector_index += folder.sector_count
                except (ValueError, struct.error):
                    # Corrupt or false-positive folder: treat as logical sector
                    self.entries.append(HBDLogicalEntry(
                        index=entry_index,
                        sector=sector_index,
                        data=sector
                    ))
                    sector_index += 1
            elif self._is_zero(sector):
                self.entries.append(HBDZeroEntry(
                    index=entry_index,
                    sector=sector_index
                ))
                sector_index += 1
            else:
                # Unknown signature: treat as a logical/binary sector.
                self.entries.append(HBDLogicalEntry(
                    index=entry_index,
                    sector=sector_index,
                    data=sector
                ))
                sector_index += 1
            entry_index += 1

    def _sector(self, n: int) -> bytes:
        return self.data[n * SECTOR_SIZE:(n + 1) * SECTOR_SIZE]

    @staticmethod
    def _is_600(sector: bytes) -> bool:
        return sector[0] == 0x60 and sector[1] == 0x01 and sector[2] == 0x01 and sector[3] == 0x80

    @staticmethod
    def _is_folder(sector: bytes) -> bool:
        # Heartbeat folder header: 4-byte file count, 4-byte sector count,
        # 4-byte size, 4-byte unknown.  Accept any non-zero file/sector count
        # that looks plausible; _parse_folder will reject false positives.
        if len(sector) < 16:
            return False
        num_files = struct.unpack("<I", sector[0:4])[0]
        sector_count = struct.unpack("<I", sector[4:8])[0]
        if num_files == 0 or sector_count == 0:
            return False
        if num_files > 1000 or sector_count > 1000:
            return False
        return True

    @staticmethod
    def _is_zero(sector: bytes) -> bool:
        return all(b == 0 for b in sector[:4])

    def _parse_folder(self, sector_index: int, entry_index: int) -> HBDFolder:
        first_sector = self._sector(sector_index)
        number_of_files = struct.unpack("<I", first_sector[0:4])[0]
        sector_count = struct.unpack("<I", first_sector[4:8])[0]
        size = struct.unpack("<I", first_sector[8:12])[0]
        unknown = first_sector[12:16]

        # Concatenate all sectors belonging to this folder.
        folder_data = b"".join(
            self._sector(sector_index + i) for i in range(sector_count)
        )

        folder = HBDFolder(
            index=entry_index,
            sector=sector_index,
            sector_count=sector_count,
            number_of_files=number_of_files,
            size=size,
            unknown=unknown,
        )

        # First, read all file headers (16 bytes each) in order.
        offset = 16
        headers = []
        for i in range(number_of_files):
            if offset + 16 > len(folder_data):
                raise ValueError(
                    f"Folder {entry_index} (sector {sector_index}, "
                    f"{sector_count} sectors, {len(folder_data)} bytes, "
                    f"{number_of_files} files): file header {i} at offset {offset} "
                    f"exceeds folder data size"
                )
            file_header = folder_data[offset:offset + 16]
            f_size = struct.unpack("<I", file_header[0:4])[0]
            f_size_unc = struct.unpack("<I", file_header[4:8])[0]
            f_unknown = file_header[8:12]
            f_flags = struct.unpack("<H", file_header[12:14])[0]
            f_type = struct.unpack("<H", file_header[14:16])[0]
            headers.append((f_size, f_size_unc, f_unknown, f_flags, f_type))
            offset += 16

        # File contents start after all headers.
        content_offset = 16 + number_of_files * 16
        for i, (f_size, f_size_unc, f_unknown, f_flags, f_type) in enumerate(headers):
            if content_offset + f_size > len(folder_data):
                raise ValueError(
                    f"Folder {entry_index} (sector {sector_index}, "
                    f"{sector_count} sectors, {len(folder_data)} bytes): "
                    f"file {i} content size {f_size} at offset {content_offset} "
                    f"exceeds folder data size"
                )
            file_content = folder_data[content_offset:content_offset + f_size]
            content_offset += f_size

            file_obj = HBDFile(
                index=i,
                parent=folder,
                size=f_size,
                size_uncompressed=f_size_unc,
                unknown=f_unknown,
                flags=f_flags,
                type_id=f_type,
                content=file_content,
            )
            folder.files.append(file_obj)

        return folder

    def files(self) -> List[HBDFile]:
        """All files in all folders."""
        return [f for folder in self.folders for f in folder.files]

    def files_of_type(self, type_id: int) -> List[HBDFile]:
        return [f for f in self.files() if f.type_id == type_id]

    def get_file(self, path: str) -> Optional[HBDFile]:
        """Look up a file by path like 'folder_index/file_index'."""
        parts = path.split("/")
        if len(parts) != 2:
            return None
        try:
            folder_idx = int(parts[0])
            file_idx = int(parts[1])
        except ValueError:
            return None
        for folder in self.folders:
            if folder.index == folder_idx:
                for f in folder.files:
                    if f.index == file_idx:
                        return f
        return None
