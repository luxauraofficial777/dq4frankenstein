"""Dragon Quest LZSS compression (DQLZS).

Matches the Okumura LZSS decompression format used by DQ4 PSX:
- 4096-byte circular ring buffer
- Threshold 3 (matches of length 3 to 18)
- Max match length 18
- Initial ring buffer position: 4096 - 18 = 4078
- Ring buffer initialized to all 0x00
- Flags byte: 8 bits, bit 0 (LSB) to bit 7 (MSB)
  - 1 = literal byte
  - 0 = reference pair (c0, c1):
        pos = c0 | ((c1 & 0xF0) << 4)
        len = (c1 & 0x0F) + 3

Includes 1-byte lookahead lazy matching to achieve optimal compression ratios,
guaranteeing recompressed cutscene scripts fit strictly within their original archive slots.
"""

RING_SIZE = 4096
RING_WRAP = RING_SIZE - 1
MAX_STORE_LENGTH = 18
THRESHOLD = 3
INITIAL_R = RING_SIZE - MAX_STORE_LENGTH  # 4078

# The "best" encoder walks the FULL hash chain (every candidate match position in
# the 4096-byte ring) to find the globally longest match -> the true shortest
# stream. This is byte-for-byte the unbounded walk that built the F14F83B7 master
# and fits the tight slots (e.g. the 18320-byte overlay module). GLM's variant
# sweep uses SMALLER caps below to intentionally DEGRADE quality (worse encoder =
# longer stream) when a too-short stream must be inflated to fill a slot; but the
# shortest-fit precheck and the tightest slots need this full-chain optimum. A
# 4096-ring cannot hold more than ~4096 candidate positions, so RING_SIZE is
# effectively unbounded; the max-length (18) early-exit keeps the common case fast.
_MAX_CHAIN_BEST = RING_SIZE


def _find_best_match(ring_buffer: bytearray, r: int, data: bytes, in_idx: int, data_len: int,
                     max_chain: int = 32, min_match: int = THRESHOLD):
    max_match_len = min(MAX_STORE_LENGTH, data_len - in_idx)
    if max_match_len < min_match:
        return 0, 0

    target_3 = data[in_idx:in_idx + 3]
    p = 0
    best_len = 0
    best_pos = 0
    chains = 0

    while True:
        idx = ring_buffer.find(target_3, p, RING_SIZE + 2)
        if idx == -1 or idx >= RING_SIZE:
            break
        p = idx + 1
        pos = idx
        chains += 1
        if chains > max_chain:
            break

        # HARDWARE SAFETY (confirmed by SLPM_869.16 disassembly at 0x80027FAC):
        # the PSX decompressor takes a fast-path WORD block-copy when both
        # pos+len<4096 and r+len<4096. That word copy cannot handle a source
        # range that overlaps the destination -- an RLE match where the copy
        # reads bytes written earlier in the SAME match. That happens exactly when
        # match_len > distance, where distance = (r - pos) mod 4096. dqlzs used to
        # allow it (reading data[in_idx+dist]); on hardware the overlapping word
        # copy runs away, flooding high RAM (b6e9b2ea...) -> the 006C freeze.
        # Cap every match at match_len <= distance so it is strictly
        # non-overlapping and safe on both the fast and slow decode paths.
        distance = (r - pos) & RING_WRAP
        match_l = 0
        while match_l < max_match_len and match_l < distance:
            read_idx = (pos + match_l) & RING_WRAP
            char = ring_buffer[read_idx]
            if char == data[in_idx + match_l]:
                match_l += 1
            else:
                break

        if match_l > best_len:
            best_len = match_l
            best_pos = pos
            if best_len == max_match_len:
                break

    return best_len, best_pos


def dqlzs_compress(data: bytes) -> bytes:
    """Compress data using Dragon Quest LZSS with lazy matching.

    Args:
        data: Uncompressed bytes to compress.

    Returns:
        Compressed bytes compatible with lzss_uncompress.
    """
    if not data:
        return b""

    # Use 8192-byte ring buffer (mirrored upper half) for fast wrapped searches
    ring_buffer = bytearray(RING_SIZE * 2)
    r = INITIAL_R

    out = bytearray()
    in_idx = 0
    data_len = len(data)
    tokens = []

    def flush_tokens(toks):
        if not toks:
            return
        flag_byte = 0
        payload = bytearray()
        for i, tok in enumerate(toks):
            if tok[0]:  # literal
                flag_byte |= (1 << i)
                payload.append(tok[1])
            else:  # reference
                pos, length = tok[1], tok[2]
                c0 = pos & 0xFF
                c1 = ((pos >> 4) & 0xF0) | ((length - THRESHOLD) & 0x0F)
                payload.append(c0)
                payload.append(c1)
        out.append(flag_byte)
        out.extend(payload)

    while in_idx < data_len:
        match_len, match_pos = _find_best_match(ring_buffer, r, data, in_idx, data_len,
                                                max_chain=_MAX_CHAIN_BEST)

        # Lazy matching: check if emitting a literal and matching at in_idx + 1 gives a strictly longer match
        if match_len >= THRESHOLD and in_idx + 1 < data_len:
            old_byte = ring_buffer[r]
            char0 = data[in_idx]
            r_next = (r + 1) & RING_WRAP
            ring_buffer[r] = char0
            ring_buffer[r + RING_SIZE] = char0

            next_len, next_pos = _find_best_match(ring_buffer, r_next, data, in_idx + 1, data_len,
                                                  max_chain=_MAX_CHAIN_BEST)

            if next_len > match_len:
                # Keep the literal and let the next iteration take the longer match
                tokens.append((True, char0))
                r = r_next
                in_idx += 1
                if len(tokens) == 8:
                    flush_tokens(tokens)
                    tokens = []
                continue
            else:
                # Revert speculative ring buffer update
                ring_buffer[r] = old_byte
                ring_buffer[r + RING_SIZE] = old_byte

        if match_len >= THRESHOLD:
            tokens.append((False, match_pos, match_len))
            for i in range(match_len):
                b = data[in_idx + i]
                ring_buffer[r] = b
                ring_buffer[r + RING_SIZE] = b
                r = (r + 1) & RING_WRAP
            in_idx += match_len
        else:
            char = data[in_idx]
            tokens.append((True, char))
            ring_buffer[r] = char
            ring_buffer[r + RING_SIZE] = char
            r = (r + 1) & RING_WRAP
            in_idx += 1

        if len(tokens) == 8:
            flush_tokens(tokens)
            tokens = []

    if tokens:
        flush_tokens(tokens)

    return bytes(out)


# ---------------------------------------------------------------------------
# Length-targeted compression (LZS-overrun fix).
#
# The DQ4 LZS decoder reads flag bytes until the INPUT is exhausted (declared
# ulen sizes the buffer but does not bound the writes). Zero-padding a short
# recompressed stream to fill its archive slot makes the decoder read those
# 0x00 bytes as extra flag bytes -> extra tokens -> real bytes written past
# ulen (measured +3..+4764). Fix: fill the slot with a VALID stream that
# decodes to exactly `img` (no 0x00 pad). We produce that by taking the normal
# (shortest) encoding and inflating it to the exact slot length -- converting
# trailing MATCH tokens into the LITERAL bytes they would have produced (same
# decoded output, longer stream), with a partial split for byte precision.
# ---------------------------------------------------------------------------

def _compress_to_tokens(data: bytes, force_prefix: int = 0, lazy: bool = True,
                        max_chain: int = 32, min_match: int = THRESHOLD):
    """Same algorithm as dqlzs_compress but returns a token list.

    Tokens: ('L', byte) for a literal, ('M', pos, length, out_off) for a match
    (out_off = index into `data` the match reproduces, so it can be expanded to
    literals losslessly).

    `force_prefix` emits the first N bytes as literals before normal matching
    begins. It shifts the total token count (hence the flag-byte alignment /
    length parity) without changing the decoded output -- used to make an exact
    slot length reachable with zero overrun.

    `lazy`, `max_chain`, `min_match` degrade encoder quality on demand: a
    WORSE encoder produces a LONGER stream. When the optimal stream is shorter
    than the archive slot by more than a tail-pad can cover, sweep these to
    land the natural length inside the slot (RadMage's max_chain doctrine).
    """
    if not data:
        return []
    ring_buffer = bytearray(RING_SIZE * 2)
    r = INITIAL_R
    in_idx = 0
    data_len = len(data)
    toks = []
    while in_idx < min(force_prefix, data_len):
        char = data[in_idx]
        toks.append(('L', char))
        ring_buffer[r] = char
        ring_buffer[r + RING_SIZE] = char
        r = (r + 1) & RING_WRAP
        in_idx += 1
    while in_idx < data_len:
        match_len, match_pos = _find_best_match(ring_buffer, r, data, in_idx, data_len,
                                                max_chain=max_chain, min_match=min_match)
        if match_len < min_match:
            match_len = 0  # below the demanded quality: force a literal
        if lazy and match_len >= THRESHOLD and in_idx + 1 < data_len:
            old_byte = ring_buffer[r]
            char0 = data[in_idx]
            r_next = (r + 1) & RING_WRAP
            ring_buffer[r] = char0
            ring_buffer[r + RING_SIZE] = char0
            next_len, _np = _find_best_match(ring_buffer, r_next, data, in_idx + 1, data_len,
                                             max_chain=max_chain, min_match=min_match)
            if next_len > match_len:
                toks.append(('L', char0))
                r = r_next
                in_idx += 1
                continue
            else:
                ring_buffer[r] = old_byte
                ring_buffer[r + RING_SIZE] = old_byte
        if match_len >= THRESHOLD:
            toks.append(('M', match_pos, match_len, in_idx))
            for i in range(match_len):
                b = data[in_idx + i]
                ring_buffer[r] = b
                ring_buffer[r + RING_SIZE] = b
                r = (r + 1) & RING_WRAP
            in_idx += match_len
        else:
            char = data[in_idx]
            toks.append(('L', char))
            ring_buffer[r] = char
            ring_buffer[r + RING_SIZE] = char
            r = (r + 1) & RING_WRAP
            in_idx += 1
    return toks


def _emit_tokens(toks) -> bytes:
    out = bytearray()
    for g in range(0, len(toks), 8):
        group = toks[g:g + 8]
        flag_byte = 0
        payload = bytearray()
        for i, tok in enumerate(group):
            if tok[0] == 'L':
                flag_byte |= (1 << i)
                payload.append(tok[1])
            else:
                pos, length = tok[1], tok[2]
                payload.append(pos & 0xFF)
                payload.append(((pos >> 4) & 0xF0) | ((length - THRESHOLD) & 0x0F))
        out.append(flag_byte)
        out.extend(payload)
    return bytes(out)


def _count_tokens(toks):
    """(n, num_match, num_lit) for a token list."""
    n = len(toks)
    num_match = sum(1 for t in toks if t[0] == 'M')
    return n, num_match, n - num_match


def _toks_len(n, num_match, num_lit):
    # bytes = ceil(n/8) flag bytes + literal payload(1 each) + match payload(2 each)
    return (n + 7) // 8 + num_lit + 2 * num_match


def _build_emit(toks, plan, data):
    """Materialize the plan (index -> ('full',) | ('partial', j)) into a token
    list and emit. O(n)."""
    final = []
    for idx, t in enumerate(toks):
        p = plan.get(idx)
        if p is None:
            final.append(t)
            continue
        pos, m, off = t[1], t[2], t[3]
        if p[0] == 'full':
            final.extend(('L', data[off + k]) for k in range(m))
        else:
            j = p[1]
            final.append(('M', pos, m - j, off))
            final.extend(('L', data[off + (m - j) + k]) for k in range(j))
    return _emit_tokens(final)


def _fill_exact(toks, data, target_len):
    """Grow the token stream's encoding to EXACTLY `target_len` bytes by
    converting matches into the literals they reproduce (same decoded output).

    Walk: right-to-left greedy -- full conversions while they fit, partial
    splits otherwise. Fine phase: when the walk stalls (every remaining match
    is length-3 -- a 3-match cannot split and a full conversion adds >= +3 --
    or n%%8 == 7 makes every +1 token cost +2 stream bytes), grow existing
    partial splits incrementally until the target is met. Raises ValueError
    when the target is unreachable for this tokenization.
    """
    n, num_match, num_lit = _count_tokens(toks)
    cur = _toks_len(n, num_match, num_lit)
    if cur > target_len:
        raise ValueError("shortest stream %d > target %d" % (cur, target_len))
    if cur == target_len:
        return _emit_tokens(toks)

    plan = {}
    i = n - 1
    while i >= 0 and cur < target_len:
        t = toks[i]
        if t[0] != 'M':
            i -= 1
            continue
        m = t[2]
        full = _toks_len(n + (m - 1), num_match - 1, num_lit + m)
        if full <= target_len:
            plan[i] = ('full',)
            n += (m - 1); num_match -= 1; num_lit += m; cur = full
            i -= 1
            continue
        best_j = 0
        best_len = cur
        for j in range(1, m - THRESHOLD + 1):
            plen = _toks_len(n + j, num_match, num_lit + j)
            if plen == target_len:
                plan[i] = ('partial', j)
                return _build_emit(toks, plan, data)
            if plen < target_len:
                best_j = j
                best_len = plen
            else:
                break
        if best_j > 0:
            plan[i] = ('partial', best_j)
            n += best_j; num_lit += best_j; cur = best_len
        i -= 1

    if cur == target_len:
        return _build_emit(toks, plan, data)

    # FINE PHASE. Grow already-planned (or fresh) partial splits by exact
    # count deltas. `applied` seeds from the walk's partials so deltas are
    # never double-counted; 'full'-planned matches are excluded (they can only
    # shrink). A candidate is committed only when its exact new length is
    # <= target, so overshoot is impossible.
    applied = {i2: p[1] for i2, p in plan.items() if p[0] == 'partial'}
    candidates = [i2 for i2, t2 in enumerate(toks)
                  if t2[0] == 'M' and t2[2] > THRESHOLD
                  and plan.get(i2) != ('full',)]
    guard = 0
    while cur < target_len and candidates and guard < 2048:
        guard += 1
        best = None        # (plen, i2, j_new)
        for i2 in candidates:
            m2 = toks[i2][2]
            j_old = applied.get(i2, 0)
            for j in range(j_old + 1, m2 - THRESHOLD + 1):
                plen = _toks_len(n + (j - j_old), num_match, num_lit + (j - j_old))
                if plen == target_len:
                    plan[i2] = ('partial', j)
                    return _build_emit(toks, plan, data)
                if plen < target_len and (best is None or plen > best[0]):
                    best = (plen, i2, j)
        if best is None:
            break
        plen, i2, j = best
        j_old = applied.get(i2, 0)
        plan[i2] = ('partial', j)
        n += (j - j_old)
        num_lit += (j - j_old)
        cur = plen
        applied[i2] = j
    if cur == target_len:
        return _build_emit(toks, plan, data)
    raise ValueError("could not hit exact target %d (reached %d)" % (target_len, cur))


def compress_targeted(data: bytes, target_len: int, force_prefix: int = 0) -> bytes:
    """Return a valid LZS stream of EXACTLY `target_len` bytes that decodes to
    `data`. Raises ValueError if the shortest encoding already exceeds
    target_len, or if the exact length is unreachable (caller uses slack)."""
    toks = _compress_to_tokens(data, force_prefix=force_prefix)
    return _fill_exact(toks, data, target_len)


# Group-boundary-safe tail pads. Appended AFTER a stream that ends on a flag
# group boundary, each pattern is read by the decoder and terminates at EOF
# with at most +3 decoded bytes (pristine parity 0..+3):
#   k=1  [0x00]                  lone flag -> first match needs payload -> EOF  (+0)
#   k=2  [0x01, 0x00]            one literal, then lone flag                    (+1)
#   k=3  [0x01, 0x00, 0x00]      one literal, then lone flag                    (+1)
#   k=4  [0x00, 0x01, 0x00, 0x00] one match from zeroed ring, then lone flag    (+3)
_TAIL_PADS = {
    1: b"\x00",
    2: b"\x01\x00",
    3: b"\x01\x00\x00",
    4: b"\x00\x01\x00\x00",
}

# Encoder-quality variants, highest quality first. A worse encoder produces a
# LONGER stream: when the optimal encoding is shorter than the slot by more
# than a tail pad can cover, sweep down this list to land the natural length
# near the slot (RadMage's max_chain doctrine -- unsatisfiable floors RAISE).
_VARIANTS = [
    dict(lazy=True, max_chain=_MAX_CHAIN_BEST, min_match=3),   # full-chain optimum (F14F83B7 parity)
    dict(lazy=False, max_chain=_MAX_CHAIN_BEST, min_match=3),
    dict(lazy=True, max_chain=32, min_match=3),
    dict(lazy=False, max_chain=32, min_match=3),
    dict(lazy=True, max_chain=16, min_match=3),
    dict(lazy=False, max_chain=16, min_match=3),
    dict(lazy=True, max_chain=8, min_match=3),
    dict(lazy=False, max_chain=8, min_match=3),
    dict(lazy=True, max_chain=4, min_match=3),
    dict(lazy=False, max_chain=4, min_match=3),
    dict(lazy=True, max_chain=2, min_match=3),
    dict(lazy=False, max_chain=2, min_match=3),
    dict(lazy=True, max_chain=32, min_match=4),
    dict(lazy=False, max_chain=32, min_match=4),
    dict(lazy=True, max_chain=8, min_match=4),
    dict(lazy=False, max_chain=8, min_match=4),
    dict(lazy=True, max_chain=32, min_match=5),
    dict(lazy=False, max_chain=32, min_match=5),
]


def compress_to_slot(data: bytes, slot_len: int, max_slack: int = 3) -> bytes:
    """Fill an archive slot of exactly `slot_len` bytes with a valid LZS stream
    whose decode is `data` plus at most +3 trailing bytes (pristine parity).

    Strategy: sweep encoder-quality variants (optimal first) toward the
    closest-below-slot natural length; exact-fill the remainder with
    match->literal conversions; when the remainder is 1..4 bytes, close it
    with a group-boundary-safe tail pad. Raises ValueError on a genuine slot
    overflow (shortest encoding > slot) or when nothing lands within slack.
    """
    overflow_err = None
    candidates = []
    for v in _VARIANTS:
        toks = _compress_to_tokens(data, 0, **v)
        nat = _toks_len(*_count_tokens(toks))
        if nat > slot_len:
            if overflow_err is None or nat < overflow_err[0]:
                overflow_err = (nat, "shortest stream %d > slot %d" % (nat, slot_len))
            continue
        if nat == slot_len:
            return _emit_tokens(toks)
        candidates.append((nat, v, toks))
    if not candidates:
        raise ValueError("genuine slot overflow: %s" % (overflow_err,))
    candidates.sort(key=lambda c: -c[0])  # closest-below first
    for nat, v, toks in candidates:
        # force_prefix sweep: prepend 0..N literals to shift the stream upward
        # (each prefix byte re-tokenizes as a literal, +~1 stream byte each).
        # Varying fp also cycles the total token count through its residue mod 8,
        # which is exactly what lets a boundary-safe tail pad apply (path b).
        max_fp = min(slot_len - nat + 8, len(data))
        for fp in range(0, max_fp):
            toks2 = toks if fp == 0 else _compress_to_tokens(data, fp, **v)
            # (a) exact fill -> +0 overrun, the preferred outcome.
            try:
                return _fill_exact(toks2, data, slot_len)
            except ValueError:
                pass
            # (b) group-boundary-safe tail pad closes a 1..4-byte shortfall. It is
            # ONLY valid when the emitted stream ends ON a flag-group boundary
            # (len(toks) % 8 == 0); appended mid-group, the final flag byte's
            # unused (zero => match) bits swallow the pad as match payload and the
            # decode runs past the +3 pristine parity (measured +7 on a 5/8 group).
            # The boundary guard is the necessary-and-sufficient safety condition;
            # the caller's unbounded round-trip gate is the backstop.
            n2 = len(toks2)
            nat2 = _toks_len(*_count_tokens(toks2))
            shortfall = slot_len - nat2
            if shortfall in _TAIL_PADS and n2 % 8 == 0:
                return _emit_tokens(toks2) + _TAIL_PADS[shortfall]
    raise ValueError("compress_to_slot could not land slot %d within +%d decode slack "
                     "(variants + force_prefix exhausted; %s). If the slot exceeds the "
                     "all-literal maximum for this data, the slot itself is larger than "
                     "any valid stream of this image -- investigate upstream."
                     % (slot_len, max_slack, overflow_err))


