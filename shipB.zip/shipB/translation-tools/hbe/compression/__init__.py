from .lzss import lzss_uncompress
from .dqlzs import dqlzs_compress

__all__ = ["lzss_uncompress", "dqlzs_compress"]
