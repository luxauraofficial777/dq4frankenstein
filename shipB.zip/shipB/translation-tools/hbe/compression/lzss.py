"""LZSS decompressor matching the Java/org.crosswire implementation used by DQ4/DW7.

Ring buffer size: 4096 bytes
Max stored length: 18
Threshold: 3
"""

RING_SIZE = 4096
RING_WRAP = RING_SIZE - 1
MAX_STORE_LENGTH = 18
THRESHOLD = 3


def lzss_uncompress(compressed_data: bytes, expected_size: int = -1) -> bytes:
    """Decompress LZSS data.

    Args:
        compressed_data: The compressed byte stream.
        expected_size: If >= 0, decompression stops when this many bytes have
            been produced. If -1, decompression runs until the input is
            exhausted.

    Returns:
        The decompressed bytes.
    """
    out = bytearray()
    ring_buffer = bytearray(RING_SIZE)
    r = RING_SIZE - MAX_STORE_LENGTH

    flags = 0
    flag_count = 0
    data_idx = 0

    while data_idx < len(compressed_data):
        if expected_size >= 0 and len(out) >= expected_size:
            break

        if flag_count > 0:
            flags = (flags >> 1) & 0xFF
            flag_count -= 1
        else:
            if data_idx >= len(compressed_data):
                break
            flags = compressed_data[data_idx]
            data_idx += 1
            flag_count = 7

        if (flags & 1) != 0:
            if data_idx >= len(compressed_data):
                break
            char = compressed_data[data_idx]
            data_idx += 1
            out.append(char)
            ring_buffer[r] = char
            r = (r + 1) & RING_WRAP
        else:
            if data_idx + 1 >= len(compressed_data):
                break
            c0 = compressed_data[data_idx]
            c1 = compressed_data[data_idx + 1]
            data_idx += 2

            pos = c0 | ((c1 & 0xF0) << 4)
            length = (c1 & 0x0F) + THRESHOLD

            for _ in range(length):
                char = ring_buffer[(pos + _) & RING_WRAP]
                out.append(char)
                ring_buffer[r] = char
                r = (r + 1) & RING_WRAP

    return bytes(out)
