"""Entry point for `python -m hbe`."""

from hbe.cli import main

if __name__ == "__main__":
    main()
