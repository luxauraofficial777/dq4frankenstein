"""
HBD folder/sector allocation planner for the Heart Beat Engine.

The allocation invariant is:

    folder_size = 16 (folder header)
                + number_of_files * 16 (file headers)
                + sum(file content sizes)
    sector_count = ceil(folder_size / 2048)

If a folder's sector count or start sector changes, the EXE pointer table must
be updated. This planner computes layouts and detects moves.
"""

from dataclasses import dataclass
from typing import List

from hbe.archive import HBDFolder


SECTOR_SIZE = 2048
FOLDER_HEADER_SIZE = 16
FILE_HEADER_SIZE = 16


@dataclass
class FolderLayout:
    """Computed layout of a folder."""

    folder: HBDFolder
    content_size: int
    header_size: int
    expected_size: int
    sector_count: int
    remaining_bytes: int


class AllocationPlanner:
    """Plan folder layouts and detect allocation changes."""

    def plan_folder(self, folder: HBDFolder) -> FolderLayout:
        """Compute the required layout for a folder."""
        content_size = sum(f.size for f in folder.files)
        header_size = FOLDER_HEADER_SIZE + folder.number_of_files * FILE_HEADER_SIZE
        expected_size = header_size + content_size
        sector_count = (expected_size + SECTOR_SIZE - 1) // SECTOR_SIZE
        remaining_bytes = sector_count * SECTOR_SIZE - expected_size

        return FolderLayout(
            folder=folder,
            content_size=content_size,
            header_size=header_size,
            expected_size=expected_size,
            sector_count=sector_count,
            remaining_bytes=remaining_bytes,
        )

    def plan_archive(self, folders: List[HBDFolder]) -> List[FolderLayout]:
        """Compute layouts for all folders in order."""
        return [self.plan_folder(f) for f in folders]

    def detect_move(self, original: FolderLayout, updated: FolderLayout) -> bool:
        """Return True if the folder layout changed in a way that requires EXE patching."""
        return (
            original.sector_count != updated.sector_count
            or original.folder.sector != updated.folder.sector
        )

    def fit(self, text_content, max_bytes: int) -> bool:
        """Check whether a text content object fits within a byte budget."""
        # Placeholder for future smart-fitting logic.
        return len(text_content.raw) <= max_bytes
