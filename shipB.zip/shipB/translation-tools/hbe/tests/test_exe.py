"""
Unit tests for EXE pointer encoding/decoding.
"""

import unittest

from hbe.exe import FolderPointer, decode_pointer


class TestEXEPointer(unittest.TestCase):

    def test_encode_decode_folder_pointer(self):
        # Folder at sector 362 spanning 44 sectors.
        ptr = FolderPointer(start_sector=362, sector_count=44)
        encoded = ptr.encode()
        decoded = decode_pointer(encoded)
        self.assertEqual(decoded.start_sector, 362)
        self.assertEqual(decoded.sector_count, 44)

    def test_decode_known_example(self):
        # Any round-trip should be symmetric.
        ptr = FolderPointer(start_sector=0x16A, sector_count=0x2C)
        encoded = ptr.encode()
        decoded = decode_pointer(encoded)
        self.assertEqual(decoded.start_sector, 0x16A)
        self.assertEqual(decoded.sector_count, 0x2C)


if __name__ == "__main__":
    unittest.main()
