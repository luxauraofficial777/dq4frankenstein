"""
Unit tests for the Huffman tree builder.
"""

import unittest

from hbe.huffman import DQ4Schema, build_tree


class TestHuffmanBuilder(unittest.TestCase):

    def test_build_simple_tree(self):
        schema = DQ4Schema()
        frequencies = {
            b"\x00\x00": 10,  # {0000}
            b"\x7f\x0a": 5,   # {7f0a}
            b"\x02\x01": 3,   # character (0x0201, must be < 0x8000)
        }
        root = build_tree(frequencies, schema)
        self.assertTrue(root.is_branch())
        leaves = root.leaf_nodes()
        self.assertEqual(len(leaves), 3)

    def test_frequencies_determine_tree(self):
        schema = DQ4Schema()
        # Three leaves with different frequencies; tree format needs >= 3
        # leaves (2 branches) so root's right child is a branch at end-4.
        frequencies = {
            b"\x00\x00": 100,
            b"\x7f\x0a": 10,
            b"\x02\x93": 1,
        }
        root = build_tree(frequencies, schema)
        leaves = root.leaf_nodes()
        self.assertEqual(len(leaves), 3)


if __name__ == "__main__":
    unittest.main()
