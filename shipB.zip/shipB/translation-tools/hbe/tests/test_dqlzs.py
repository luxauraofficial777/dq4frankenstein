"""
Unit tests for the DQLZS codec's overrun-safe slot filling (the church-freeze fix).

The DQ4 LZS decoder reads flag bytes until the INPUT is exhausted (the declared
ulen sizes the output buffer but does not bound the writes). A recompressed
stream that is 0x00-padded to fill its archive slot therefore decodes the pad as
extra flag bytes -> extra tokens -> real bytes written PAST ulen (measured
+3..+4764 in the archive -> the RAM clobber behind the church-exit hang).
``compress_to_slot`` fills the slot with a VALID stream instead. These tests lock
that contract:

  * round-trip  : decode[:ulen] == original for natural and slot-filled streams
  * overrun     : natural and slot-filled streams overrun by <= +3 (pristine parity)
  * exact-fit   : compress_to_slot lands EXACTLY slot_len bytes
  * overflow    : a slot below the shortest achievable stream RAISES (never pads)
  * unfillable  : a slot above any valid stream of the image RAISES
  * RLE safety  : long single-byte runs round-trip (the non-overlapping distance cap)
  * planted +ve : the retired zero-pad path DOES overrun > +3 (the gate is a real control)
"""

import random
import unittest

from hbe.compression.dqlzs import dqlzs_compress, compress_to_slot
from hbe.compression.lzss import lzss_uncompress


def _decode_unbounded(stream, orig_len, slack=8192):
    """Decode PAST ulen so any overrun is observable. A bounded decode
    (expected_size == ulen) stops at ulen and is structurally blind to the exact
    overrun these tests gate."""
    return lzss_uncompress(stream, orig_len + slack)


def _fixtures():
    """A spread of the entropy profiles the archive actually contains: text,
    highly repetitive (RLE), periodic, incompressible random, mixed records, and
    a length that lands the final token mid flag-group."""
    rnd = random.Random(0xDA7A)
    return {
        "tiny": b"A",
        "text": b"The quick brown fox jumps over the lazy dog. " * 40,
        "rle_zero": b"\x00" * 500,
        "rle_byte": b"\xAB" * 500,
        "periodic": b"ABCD" * 300,
        "incompressible": bytes(rnd.randrange(256) for _ in range(1024)),
        "mixed": (b"HEADER\x00\x01\x02" + bytes(rnd.randrange(256) for _ in range(300))
                  + b"FOOTERFOOTER" * 20),
        "near_boundary": bytes(rnd.randrange(256) for _ in range(255)),
    }


class TestDqlzsRoundTrip(unittest.TestCase):
    def test_natural_roundtrip_and_overrun(self):
        for name, data in _fixtures().items():
            with self.subTest(fixture=name):
                comp = dqlzs_compress(data)
                dec = _decode_unbounded(comp, len(data))
                self.assertEqual(dec[:len(data)], data, f"{name}: content mismatch")
                overrun = len(dec) - len(data)
                self.assertTrue(0 <= overrun <= 3,
                                f"{name}: natural overrun {overrun} outside pristine 0..+3")

    def test_rle_no_overlap_runaway(self):
        # RLE data is where an overlapping (match_len > distance) token would make
        # the hardware fast-path word copy run away (the 006C high-RAM flood). The
        # distance cap must keep the round-trip exact for long single-byte runs.
        for data in (b"\x00" * 4000, b"\x5A" * 4000, b"\x00\x01" * 2000):
            with self.subTest(n=len(data), head=data[:2]):
                comp = dqlzs_compress(data)
                dec = _decode_unbounded(comp, len(data))
                self.assertEqual(dec[:len(data)], data)
                self.assertTrue(0 <= len(dec) - len(data) <= 3)


class TestCompressToSlot(unittest.TestCase):
    def test_slot_contract_never_violated(self):
        # THE contract: for any (data, slot) compress_to_slot must EITHER raise
        # ValueError OR return exactly slot_len bytes decoding to data with
        # overrun <= 3. Returning a >+3 stream (the mid-group tail-pad bug:
        # overrun 7 on a 5/8 group) is the violation this locks out. Awkward
        # slots that legitimately cannot be filled are free to raise.
        for name, data in _fixtures().items():
            nat = len(dqlzs_compress(data))
            for extra in (0, 1, 2, 3, 4, 7, 15, 40):
                slot = nat + extra
                with self.subTest(fixture=name, slot=slot):
                    try:
                        stream = compress_to_slot(data, slot, max_slack=3)
                    except ValueError:
                        continue  # acceptable: this slot is unfillable for this image
                    self.assertEqual(len(stream), slot,
                                     f"{name}: stream {len(stream)} != slot {slot}")
                    dec = _decode_unbounded(stream, len(data))
                    self.assertEqual(dec[:len(data)], data, f"{name}: slot decode mismatch")
                    overrun = len(dec) - len(data)
                    self.assertTrue(0 <= overrun <= 3, f"{name}: slot overrun {overrun} > +3")

    def test_reasonable_slots_fill(self):
        # Regression guard the other way: the boundary fix must NOT turn into
        # "raise everything". Substantial data with a small inflation (+0..+4)
        # must actually produce a valid stream, mirroring the real archive slots
        # (all 67 overlay modules land within this band).
        for name in ("text", "rle_byte", "periodic", "mixed"):
            data = _fixtures()[name]
            nat = len(dqlzs_compress(data))
            for extra in (0, 1, 2, 3, 4):
                slot = nat + extra
                with self.subTest(fixture=name, slot=slot):
                    stream = compress_to_slot(data, slot, max_slack=3)
                    self.assertEqual(len(stream), slot)
                    dec = _decode_unbounded(stream, len(data))
                    self.assertEqual(dec[:len(data)], data)
                    self.assertTrue(0 <= len(dec) - len(data) <= 3)

    def test_genuine_overflow_raises(self):
        # A slot below the shortest achievable stream cannot be filled by any
        # valid encoding -> must RAISE, never silently truncate or pad.
        data = _fixtures()["incompressible"]
        nat = len(dqlzs_compress(data))
        with self.assertRaises(ValueError):
            compress_to_slot(data, nat // 2, max_slack=3)

    def test_unsatisfiable_slot_raises(self):
        # A slot larger than any valid stream of this image (well beyond the all-
        # literal maximum + tail pad) is genuinely unfillable -> must RAISE.
        data = b"MODULE" * 20
        absurd = len(data) * 2 + 500
        with self.assertRaises(ValueError):
            compress_to_slot(data, absurd, max_slack=3)


class TestZeroPadDefectIsReal(unittest.TestCase):
    """Planted positive: prove the retired zero-pad path DOES overrun > +3 for at
    least one real fixture, so the overrun<=+3 gate is a genuine control and not a
    tautology. If nothing here ever overran, the gate would be a no-op."""

    def test_zero_pad_overruns_somewhere(self):
        offenders = []
        for name, data in _fixtures().items():
            comp = dqlzs_compress(data)
            for pad in range(1, 33):
                bad = comp + b"\x00" * pad          # exactly what the old code did
                dec = _decode_unbounded(bad, len(data))
                overrun = len(dec) - len(data)
                if dec[:len(data)] != data or not (0 <= overrun <= 3):
                    offenders.append((name, pad, overrun))
                    break
        self.assertTrue(offenders,
                        "zero-padding never overran any fixture -> the overrun gate "
                        "would be a no-op; fixtures are not exercising the defect")


if __name__ == "__main__":
    unittest.main()
