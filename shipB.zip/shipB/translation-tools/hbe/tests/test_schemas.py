"""
Unit tests for JSON schema serialization.
"""

import unittest

from hbe import HuffmanNode, tree_from_dict, tree_to_dict


class TestSchemaSerialization(unittest.TestCase):

    def test_tree_roundtrip(self):
        root = HuffmanNode.branch(2)
        branch0 = HuffmanNode.branch(0)
        branch1 = HuffmanNode.branch(1)
        branch0.children = [HuffmanNode.control(b"\x00\x00"), HuffmanNode.character(b"\x02\x93")]
        branch1.children = [HuffmanNode.control(b"\x7f\x0a"), HuffmanNode.control(b"\x7f\x0b")]
        root.children = [branch0, branch1]

        data = tree_to_dict(root)
        restored = tree_from_dict(data)
        self.assertEqual(restored, root)


if __name__ == "__main__":
    unittest.main()
