"""
Unit tests for the 12-bit length-limited Huffman tree builder.
"""

import unittest

from hbe.huffman import (
    DQ4Schema,
    DW7Schema,
    build_tree,
    build_tree_length_limited,
    build_and_validate,
    validate_tree_constraints,
    max_code_length,
    code_lengths,
    MAX_CODE_LENGTH,
)


class TestLengthLimitedBuilder(unittest.TestCase):

    def test_simple_tree_within_limit(self):
        """A small tree should naturally fit within 12 bits."""
        schema = DQ4Schema()
        frequencies = {
            b"\x00\x00": 100,
            b"\x7f\x0a": 50,
            b"\x02\x93": 1,
        }
        root = build_tree_length_limited(frequencies, schema)
        self.assertTrue(max_code_length(root) <= MAX_CODE_LENGTH)

    def test_skewed_distribution_stays_within_limit(self):
        """Fibonacci-like frequencies can produce deep trees; must be constrained."""
        schema = DQ4Schema()
        # Build frequencies that would normally create a very deep tree
        # (Fibonacci-like distribution produces depth = N-1 for N symbols)
        frequencies = {}
        for i in range(20):
            content = bytes([(i >> 8) & 0xFF, i & 0xFF])
            frequencies[content] = 1 << i  # 1, 2, 4, 8, 16, ...

        root = build_tree_length_limited(frequencies, schema, max_len=12)
        depth = max_code_length(root)
        self.assertLessEqual(depth, 12,
                             f"Tree depth {depth} exceeds 12-bit limit")

    def test_large_symbol_set(self):
        """A large symbol set (256 entries) must still fit within 12 bits."""
        schema = DQ4Schema()
        frequencies = {}
        for i in range(256):
            content = bytes([(i >> 8) & 0xFF, i & 0xFF])
            # Skewed distribution
            frequencies[content] = (i + 1) * (i + 1)

        root = build_tree_length_limited(frequencies, schema, max_len=12)
        depth = max_code_length(root)
        self.assertLessEqual(depth, 12,
                             f"Tree depth {depth} exceeds 12-bit limit for 256 symbols")

    def test_all_symbols_preserved(self):
        """No symbols should be lost during length limiting."""
        schema = DQ4Schema()
        frequencies = {
            bytes([(i >> 8) & 0xFF, i & 0xFF]): (1 << i)
            for i in range(15)
        }
        original_symbols = set(frequencies.keys())

        root = build_tree_length_limited(frequencies, schema, max_len=12)
        leaf_contents = {leaf.content for leaf in root.leaf_nodes()}

        self.assertEqual(original_symbols, leaf_contents,
                         "Symbol set changed during length limiting")

    def test_round_trip_serialization(self):
        """The length-limited tree must round-trip through the schema."""
        schema = DQ4Schema()
        frequencies = {
            bytes([(i >> 8) & 0xFF, i & 0xFF]): (1 << i)
            for i in range(15)
        }

        root = build_tree_length_limited(frequencies, schema)
        tree_bytes = schema.write_tree(root)
        reparsed = schema.parse_tree(tree_bytes)

        self.assertEqual(root, reparsed,
                         "Tree does not round-trip through DQ4Schema")

    def test_dw7_schema_round_trip(self):
        """Length-limited tree must also work with DW7Schema."""
        schema = DW7Schema()
        frequencies = {
            bytes([(i >> 8) & 0xFF, i & 0xFF]): (1 << i)
            for i in range(15)
        }

        root = build_tree_length_limited(frequencies, max_len=12)
        depth = max_code_length(root)
        self.assertLessEqual(depth, 12)

        # Verify all original symbols are present in the tree
        original_symbols = set(frequencies.keys())
        leaf_contents = {leaf.content for leaf in root.leaf_nodes()}
        self.assertEqual(original_symbols, leaf_contents)

    def test_validate_constraints(self):
        """validate_tree_constraints should correctly identify violations."""
        schema = DQ4Schema()
        frequencies = {
            b"\x00\x00": 100,
            b"\x7f\x0a": 50,
            b"\x02\x93": 1,
        }
        root = build_tree(frequencies, schema=None)
        is_valid, violations = validate_tree_constraints(root, max_len=12)
        self.assertTrue(is_valid)
        self.assertEqual(violations, [])

    def test_build_and_validate_pipeline(self):
        """Full pipeline should produce valid tree + binary header + report."""
        schema = DQ4Schema()
        frequencies = {
            bytes([(i >> 8) & 0xFF, i & 0xFF]): (1 << i)
            for i in range(15)
        }

        root, tree_bytes, report = build_and_validate(frequencies, schema, max_len=12)

        self.assertTrue(report["is_valid"])
        self.assertLessEqual(report["max_depth"], 12)
        self.assertEqual(report["violations"], [])
        self.assertGreater(report["tree_size"], 0)
        self.assertEqual(len(tree_bytes) % 4, 0,
                         "Tree bytes must be 4-byte aligned")

    def test_too_many_symbols_raises(self):
        """Should raise ValueError when symbols > 2^max_len."""
        schema = DQ4Schema()
        # 2^12 = 4096 symbols max for 12-bit codes
        # With 5000 symbols, it's impossible
        frequencies = {
            bytes([(i >> 8) & 0xFF, i & 0xFF]): 1
            for i in range(5000)
        }
        with self.assertRaises(ValueError):
            build_tree_length_limited(frequencies, schema, max_len=12)

    def test_empty_frequencies_raises(self):
        """Should raise ValueError for empty frequencies."""
        with self.assertRaises(ValueError):
            build_tree_length_limited({}, DQ4Schema(), max_len=12)

    def test_uniform_distribution(self):
        """Uniform distribution should produce a balanced tree within limit."""
        schema = DQ4Schema()
        frequencies = {
            bytes([(i >> 8) & 0xFF, i & 0xFF]): 100
            for i in range(100)
        }
        root = build_tree_length_limited(frequencies, schema, max_len=12)
        depth = max_code_length(root)
        # 100 symbols, uniform: depth should be ~7 (log2(100) ≈ 6.6)
        self.assertLessEqual(depth, 12)
        self.assertGreaterEqual(depth, 6)

    def test_code_lengths_mapping(self):
        """code_lengths should return correct mapping for all leaves."""
        schema = DQ4Schema()
        frequencies = {
            b"\x00\x00": 100,
            b"\x7f\x0a": 50,
            b"\x02\x93": 1,
        }
        root = build_tree(frequencies, schema=None)
        lengths = code_lengths(root)
        self.assertEqual(len(lengths), 3)
        self.assertEqual(sum(2 ** (-v) for v in lengths.values()), 1.0,
                         "Kraft inequality must be satisfied (sum = 1)")


if __name__ == "__main__":
    unittest.main()
