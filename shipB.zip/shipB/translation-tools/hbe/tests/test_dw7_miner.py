"""
Unit tests for the DW7 Huffman tree candidate miner.
"""

import unittest

from hbe.huffman import DW7SchemaCandidate, DW7CandidateParams


class TestDW7SchemaCandidate(unittest.TestCase):

    def test_dq4_like_candidate_accepts_dq4_tree(self):
        """A DQ4-encoded tree should be accepted by the DQ4-like candidate."""
        from hbe.huffman import DQ4Schema, HuffmanNode
        root = HuffmanNode.branch(2)
        branch0 = HuffmanNode.branch(0)
        branch1 = HuffmanNode.branch(1)
        branch0.children = [HuffmanNode.control(b"\x7f\x0a"), HuffmanNode.control(b"\x00\x00")]
        branch1.children = [HuffmanNode.control(b"\x7f\x0b"), HuffmanNode.character(b"\x02\x02")]
        root.children = [branch0, branch1]
        schema = DQ4Schema()
        tree_bytes = schema.write_tree(root)

        params = DW7CandidateParams(
            name="dq4_like_le",
            node_size=2,
            branch_bit=0x8000,
            root_offset=-4,
            array_split="half",
            byte_order="le",
            use_mask=False,
            root_plus_one=True,
        )
        candidate = DW7SchemaCandidate(params)
        tree = candidate.try_parse_tree(tree_bytes)

        self.assertIsNotNone(tree)
        self.assertEqual(len(tree.leaf_nodes()), 4)

    def test_invalid_tree_returns_none(self):
        """Garbage bytes should not parse as a valid tree."""
        params = DW7CandidateParams(
            name="dq4_like_le",
            node_size=2,
            branch_bit=0x8000,
            root_offset=-4,
            array_split="half",
            byte_order="le",
            use_mask=False,
        )
        candidate = DW7SchemaCandidate(params)
        tree = candidate.try_parse_tree(b"\x00\x00\x00\x00")
        self.assertIsNone(tree)


if __name__ == "__main__":
    unittest.main()
