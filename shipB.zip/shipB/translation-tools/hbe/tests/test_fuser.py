"""
Unit tests for the Fuser patching engine.
"""

import unittest

from hbe import Fuser, HBDArchive


class TestFuser(unittest.TestCase):

    def test_apply_file_transform(self):
        """A transform patch should be queued and materialized."""
        # Minimal archive: logical sector, zero sector.
        data = b"\x01\x02\x03\x04" + b"\x00" * (2048 - 4)
        data += b"\x00" * 2048
        archive = HBDArchive(data)

        fuser = Fuser()
        # The archive has no folders/files, so this transform target does not exist.
        with self.assertRaises(ValueError):
            fuser.apply_file_transform(archive, "0/0", lambda f: b"\xFF" * len(f.content))


if __name__ == "__main__":
    unittest.main()
