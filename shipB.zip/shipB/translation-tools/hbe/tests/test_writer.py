"""
Unit tests for the HBD archive writer.
"""

import unittest

from hbe import HBDArchive, HBDWriter


class TestHBDWriter(unittest.TestCase):

    def test_roundtrip_empty_archive(self):
        """A minimal archive with one logical sector should round-trip."""
        data = b"\x01\x02\x03\x04" + b"\x00" * (2048 - 4)
        archive = HBDArchive(data)
        writer = HBDWriter()
        rebuilt = writer.write(archive)
        self.assertEqual(rebuilt, data)

    def test_roundtrip_zero_sector(self):
        """A zero sector archive should round-trip."""
        data = b"\x00" * 2048
        archive = HBDArchive(data)
        writer = HBDWriter()
        rebuilt = writer.write(archive)
        self.assertEqual(rebuilt, data)


if __name__ == "__main__":
    unittest.main()
