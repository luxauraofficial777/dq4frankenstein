"""
Unit tests for the allocation planner.
"""

import unittest

from hbe.allocation import AllocationPlanner
from hbe.archive import HBDFolder, HBDFile


class TestAllocationPlanner(unittest.TestCase):

    def test_plan_empty_folder(self):
        folder = HBDFolder(
            index=0,
            sector=10,
            sector_count=1,
            number_of_files=0,
            size=0,
            unknown=b"\x00\x00\x00\x00",
        )
        planner = AllocationPlanner()
        layout = planner.plan_folder(folder)
        self.assertEqual(layout.header_size, 16)
        self.assertEqual(layout.expected_size, 16)
        self.assertEqual(layout.sector_count, 1)
        self.assertEqual(layout.remaining_bytes, 2032)

    def test_plan_folder_with_files(self):
        folder = HBDFolder(
            index=1,
            sector=20,
            sector_count=2,
            number_of_files=1,
            size=100,
            unknown=b"\x00\x00\x00\x00",
        )
        folder.files.append(HBDFile(
            index=0,
            parent=folder,
            size=100,
            size_uncompressed=100,
            unknown=b"\x00\x00\x00\x00",
            flags=0,
            type_id=40,
            content=b"\x00" * 100,
        ))
        planner = AllocationPlanner()
        layout = planner.plan_folder(folder)
        self.assertEqual(layout.expected_size, 16 + 16 + 100)
        self.assertEqual(layout.sector_count, 1)
        self.assertEqual(layout.remaining_bytes, 2048 - 132)


if __name__ == "__main__":
    unittest.main()
