"""
Round-trip tests for the DQ4 Huffman schema.

Tests the schema against a real type-19 text block extracted from the game
(original_006C_folder26046_text.bin) and a synthetic tree/bitstream.
"""

import os
import struct
import unittest

from hbe.huffman.bitutils import bitstream_to_bytes
from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.node import HuffmanNode, NodeType


BASE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"


def read_block(path: str) -> bytes:
    with open(path, "rb") as f:
        return f.read()


def parse_text_block_header(data: bytes) -> dict:
    """Parse the 24-byte DQ4 type-19 text block header."""
    if len(data) < 24:
        raise ValueError("Block too short for header")
    end, block_id, hts, tree_end, text_end, unknown1 = struct.unpack("<6I", data[:24])
    return {
        "end": end,
        "id": block_id,
        "huffman_text_start": hts,
        "huffman_tree_end": tree_end,
        "huffman_text_end": text_end,
        "unknown1": unknown1,
    }


class TestDQ4Synthetic(unittest.TestCase):
    """Smoke test with a hand-built DQ4-style tree."""

    def test_simple_tree_roundtrip(self):
        # Build a 4-leaf tree with IDs chosen so the last stored node is a
        # branch, which is what parse_tree expects. With 6 descendants,
        # array size = 14, offsetB = 6, root id = 2.
        #
        #            root(2)
        #           /        \
        #     branch(0)     branch(1)
        #      /     \        /     \
        #   ctrl0   char_a  char_b  char_c
        root = HuffmanNode.branch(2)
        branch0 = HuffmanNode.branch(0)
        branch1 = HuffmanNode.branch(1)
        ctrl0 = HuffmanNode.control(b"\x00\x00")
        char_a = HuffmanNode.character(b"\x02\x93")
        char_b = HuffmanNode.character(b"\x02\xCD")
        char_c = HuffmanNode.character(b"\x02\xDD")
        branch0.children = [ctrl0, char_a]
        branch1.children = [char_b, char_c]
        root.children = [branch0, branch1]

        schema = DQ4Schema()
        tree_bytes = schema.write_tree(root)
        parsed = schema.parse_tree(tree_bytes)

        # Topology should match
        self.assertEqual(parsed, root)

        # Decode a bitstream: 0->0 ctrl0, 0->1 char_a, 1->0 char_b, 1->1 char_c
        # Logical bits = 00 01 10 11 = 00011011.
        # bytes_to_bitstream reverses each byte, so we store the byte whose
        # reversal is 00011011: 11011000 = 0xD8.
        text_bytes = bytes([0xD8])
        leaves = schema.decode(text_bytes, parsed)
        self.assertEqual(len(leaves), 4)
        self.assertEqual(leaves[0].content, b"\x00\x00")
        self.assertEqual(leaves[1].content, b"\x02\x93")
        self.assertEqual(leaves[2].content, b"\x02\xCD")
        self.assertEqual(leaves[3].content, b"\x02\xDD")

        # Encode must produce 32-bit-aligned bytes and the first 4 decoded
        # leaves must match the original 4 leaves.
        reencoded = schema.encode(leaves, parsed)
        self.assertEqual(len(reencoded) % 4, 0)
        redecoded_prefix = schema.decode(reencoded, parsed)[:4]
        self.assertEqual(leaves, redecoded_prefix)


class TestDQ4RealBlock(unittest.TestCase):
    """Round-trip against a real extracted text block."""

    def test_006c_roundtrip(self):
        path = os.path.join(BASE, "original_006C_folder26046_text.bin")
        if not os.path.exists(path):
            self.skipTest(f"Missing test fixture: {path}")

        data = read_block(path)
        header = parse_text_block_header(data)
        hts = header["huffman_text_start"]
        hte = header["huffman_text_end"]
        tree_end = header["huffman_tree_end"]
        end = header["end"]

        if tree_end == 0:
            tree_end = end

        text_bytes = data[hts:hte]

        # Tree header is at hte: 2 ints + 1 short = 10 bytes
        tree_start = struct.unpack("<I", data[hte:hte + 4])[0]
        tree_bytes = data[tree_start:tree_end]

        schema = DQ4Schema()
        tree = schema.parse_tree(tree_bytes)
        leaves = schema.decode(text_bytes, tree)

        # Re-encode and compare
        reencoded = schema.encode(leaves, tree)
        self.assertEqual(text_bytes, reencoded,
            f"Round-trip mismatch for text block 006C: "
            f"original {len(text_bytes)} bytes vs reencoded {len(reencoded)} bytes")

        # Sanity checks
        self.assertGreater(len(leaves), 0)
        self.assertIsNotNone(tree.node_id)


if __name__ == "__main__":
    unittest.main()
