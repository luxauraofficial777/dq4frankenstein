"""
Integration test: read the DQ4 HBD archive, parse every type-19 text block,
and verify Huffman round-trip for each.
"""

import os
import unittest

from hbe.archive import HBDArchive
from hbe.compression import lzss_uncompress
from hbe.huffman.dq4 import DQ4Schema
from hbe.parser.text import TextContentParser


BASE = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION"
DISC_PATH = os.path.join(BASE, "dq4_jp_original.bin")
HBD_SECTOR = 362
HBD_SIZE = 319436800


class TestHBDRoundTrip(unittest.TestCase):
    """Round-trip all type-19 text blocks in the HBD archive."""

    def test_all_text_roundtrip(self):
        if not os.path.exists(DISC_PATH):
            self.skipTest(f"Missing disc image: {DISC_PATH}")

        archive = HBDArchive.from_disc_image(DISC_PATH, HBD_SECTOR, HBD_SIZE)

        schema = DQ4Schema()
        parser = TextContentParser(schema)

        text_types = (19, 40, 42)
        all_failures = []
        for type_id in text_types:
            text_files = archive.files_of_type(type_id)
            total = len(text_files)
            failures = []
            for f in text_files:
                try:
                    is_compressed = f.size != f.size_uncompressed and f.flags != 0
                    if is_compressed:
                        content = lzss_uncompress(f.content, f.size_uncompressed)
                    else:
                        content = f.content

                    parsed = parser.parse(content)
                    reencoded = schema.encode(parsed.text, parsed.tree)
                    if reencoded != parsed.text_bytes:
                        failures.append((f.path, "reencode mismatch", len(parsed.text_bytes), len(reencoded)))
                except Exception as e:
                    failures.append((f.path, type(e).__name__, str(e), content[:48].hex() if isinstance(content, bytes) else repr(content)[:80]))

            if failures:
                for fail in failures[:10]:
                    print(f"FAIL type {type_id}: {fail}")
                all_failures.append((type_id, failures))
            print(f"Type {type_id}: {total - len(failures)}/{total} round-tripped")

        if all_failures:
            total_fail = sum(len(f) for _, f in all_failures)
            self.fail(f"{total_fail} text blocks failed round-trip across types {text_types}")

        print(f"All text blocks round-tripped successfully.")


if __name__ == "__main__":
    unittest.main()
