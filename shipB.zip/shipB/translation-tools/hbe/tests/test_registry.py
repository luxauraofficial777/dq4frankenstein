"""
Unit tests for the content-type registry.
"""

import unittest

from hbe.huffman import DQ4Schema, HuffmanNode
from hbe.parser import (
    BinaryContent,
    ContentTypeRegistry,
    TextContent,
    TextContentParser,
    default_registry,
)


def _build_valid_text_block() -> bytes:
    """Build a minimal valid DQ4 text block with a synthetic tree."""
    # Tree: root(2) -> branch(0) + branch(1), each with two control leaves.
    root = HuffmanNode.branch(2)
    branch0 = HuffmanNode.branch(0)
    branch1 = HuffmanNode.branch(1)
    branch0.children = [HuffmanNode.control(b"\x00\x00"), HuffmanNode.control(b"\x7f\x0a")]
    branch1.children = [HuffmanNode.control(b"\x7f\x0b"), HuffmanNode.character(b"\x02\x02")]
    root.children = [branch0, branch1]

    schema = DQ4Schema()
    tree_bytes = schema.write_tree(root)

    hts = 24
    text_end = hts
    tree_start = hts + 10
    tree_end = tree_start + len(tree_bytes)
    end = tree_end  # at_end starts here
    header = (
        end.to_bytes(4, "little") +
        b"\x6c\x00\x00\x00" +
        hts.to_bytes(4, "little") +
        tree_end.to_bytes(4, "little") +
        text_end.to_bytes(4, "little") +
        b"\x00\x00\x00\x00"
    )
    tree_header = (
        tree_start.to_bytes(4, "little") +
        tree_start.to_bytes(4, "little") +
        len(root.branch_nodes()).to_bytes(2, "little")
    )
    at_end = end.to_bytes(4, "little")
    dialog_count = (0).to_bytes(4, "little")
    return header + tree_header + tree_bytes + at_end + dialog_count


class TestContentTypeRegistry(unittest.TestCase):

    def test_default_registry_parses_text_types(self):
        registry = default_registry()
        data = _build_valid_text_block()
        content = registry.parse(40, data)
        self.assertIsInstance(content, TextContent)
        self.assertTrue(content.is_text)

    def test_unknown_type_falls_back_to_binary(self):
        registry = default_registry()
        content = registry.parse(99, b"\x00\x01\x02\x03")
        self.assertIsInstance(content, BinaryContent)

    def test_custom_registration(self):
        registry = ContentTypeRegistry()
        parser = TextContentParser()
        registry.register(40, parser)
        data = _build_valid_text_block()
        content = registry.parse(40, data)
        self.assertIsInstance(content, TextContent)


if __name__ == "__main__":
    unittest.main()
