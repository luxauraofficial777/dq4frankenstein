"""
hbe - Heart Beat Engine toolkit for DQ4 PSX translation.

Provides deterministic control over HBD archive parsing, Huffman compression,
and PSX EXE coupling for Dragon Quest IV (and eventually DW7).
"""

from .allocation import AllocationPlanner
from .archive import HBDArchive, HBDFolder, HBDFile
from .compression import lzss_uncompress
from .exe import EXE, FolderPointer
from .fuser import Fuser, Patch
from .huffman import HuffmanNode
from .iso9660 import ISODirent, ISO9660
from .miner import CrossGameMiner, PatternMiner
from .schemas import text_content_to_dict, tree_from_dict, tree_to_dict
from .sector import DiscImage, Sector
from .translation_store import TranslationEntry, TranslationStore
from .writer import HBDWriter
from .validator import Validator, ValidationReport
from .mips import MIPSDisassembler, MIPSInstruction, decode_word
from .tree_cracker import TreeCracker, TreeEncoding, CandidateBlock, generate_encodings
from .rom_compare import HBDComparator, EXEComparator, ThreeWayComparator

__version__ = "0.2.0"

__all__ = [
    "AllocationPlanner",
    "HBDArchive",
    "HBDFolder",
    "HBDFile",
    "lzss_uncompress",
    "EXE",
    "FolderPointer",
    "Fuser",
    "Patch",
    "HuffmanNode",
    "CrossGameMiner",
    "PatternMiner",
    "tree_to_dict",
    "tree_from_dict",
    "text_content_to_dict",
    "DiscImage",
    "Sector",
    "TranslationStore",
    "TranslationEntry",
    "Validator",
    "ValidationReport",
    "HBDWriter",
    "MIPSDisassembler",
    "MIPSInstruction",
    "decode_word",
    "TreeCracker",
    "TreeEncoding",
    "CandidateBlock",
    "generate_encodings",
    "HBDComparator",
    "EXEComparator",
    "ThreeWayComparator",
]
