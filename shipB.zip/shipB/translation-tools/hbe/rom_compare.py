"""
Cross-ROM comparison harness for HeartBeat Engine games.

Compares HBD archives across DQ4, DW7 US, and DQ7 JP to:
  1. Find divergent regions (where localized text lives)
  2. Compare EXE decompression routines via MIPS disassembly
  3. Identify shared vs game-specific engine code

All comparisons process in batches of 50 blocks with progress reporting.
"""

import struct
import sys
import time
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple

from .mips import MIPSDisassembler, MIPSInstruction


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class DivergentRegion:
    """A region where two HBDs differ."""
    offset: int
    length: int
    us_data: bytes
    jp_data: bytes
    us_offset: int
    jp_offset: int
    block_id: Optional[int] = None
    notes: str = ""


@dataclass
class EXEComparison:
    """Comparison of two EXE files."""
    name_a: str
    name_b: str
    exe_a: bytes
    exe_b: bytes
    shared_regions: List[Tuple[int, int]] = field(default_factory=list)
    divergent_regions: List[Tuple[int, int]] = field(default_factory=list)
    huffman_patterns_a: List[dict] = field(default_factory=list)
    huffman_patterns_b: List[dict] = field(default_factory=list)
    addr_refs_a: List[dict] = field(default_factory=list)
    addr_refs_b: List[dict] = field(default_factory=list)


# ---------------------------------------------------------------------------
# Progress reporter (shared pattern)
# ---------------------------------------------------------------------------

class _Progress:
    def __init__(self, total: int, label: str):
        self.total = total
        self.label = label
        self.current = 0
        self.start = time.time()

    def update(self, current: int):
        self.current = current
        pct = current / self.total if self.total > 0 else 0
        bar_w = 40
        filled = int(bar_w * pct)
        bar = "=" * filled + "-" * (bar_w - filled)
        elapsed = time.time() - self.start
        rate = current / elapsed if elapsed > 0 else 0
        eta = (self.total - current) / rate if rate > 0 else 0
        sys.stdout.write(
            f"\r{self.label}: [{bar}] {current}/{self.total} "
            f"({pct:.0%}) {rate:.1f}/s ETA {eta:.0f}s"
        )
        sys.stdout.flush()

    def done(self):
        self.update(self.total)
        elapsed = time.time() - self.start
        sys.stdout.write(f" done ({elapsed:.1f}s)\n")
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# HBD comparison
# ---------------------------------------------------------------------------

class HBDComparator:
    """
    Compare two HBD files sector-by-sector to find divergent regions.
    Processes in batches of 50 sectors.
    """

    BATCH_SIZE = 50
    SECTOR = 2048

    def __init__(self, us_data: bytes, jp_data: bytes,
                 us_label: str = "DW7_US", jp_label: str = "DQ7_JP"):
        self.us_data = us_data
        self.jp_data = jp_data
        self.us_label = us_label
        self.jp_label = jp_label
        self.divergent: List[DivergentRegion] = []

    def compare(self) -> List[DivergentRegion]:
        """Find all divergent sectors between US and JP HBDs."""
        us_sectors = len(self.us_data) // self.SECTOR
        jp_sectors = len(self.jp_data) // self.SECTOR
        min_sectors = min(us_sectors, jp_sectors)

        progress = _Progress(min_sectors, f"Comparing {self.us_label} vs {self.jp_label}")

        # Track contiguous divergent runs
        div_start = None
        div_us_start = None
        div_jp_start = None

        batch_end = 0
        for i in range(min_sectors):
            us_off = i * self.SECTOR
            jp_off = i * self.SECTOR
            us_sec = self.us_data[us_off:us_off + self.SECTOR]
            jp_sec = self.jp_data[jp_off:jp_off + self.SECTOR]

            if us_sec != jp_sec:
                if div_start is None:
                    div_start = us_off
                    div_us_start = us_off
                    div_jp_start = jp_off
            else:
                if div_start is not None:
                    self.divergent.append(DivergentRegion(
                        offset=div_start,
                        length=us_off - div_start,
                        us_data=self.us_data[div_us_start:us_off],
                        jp_data=self.jp_data[div_jp_start:jp_off],
                        us_offset=div_us_start,
                        jp_offset=div_jp_start,
                    ))
                    div_start = None
                    div_us_start = None
                    div_jp_start = None

            # Update progress in batches
            if i >= batch_end:
                progress.update(i)
                batch_end = i + self.BATCH_SIZE

        # Close trailing divergent region
        if div_start is not None:
            end_off = min_sectors * self.SECTOR
            self.divergent.append(DivergentRegion(
                offset=div_start,
                length=end_off - div_start,
                us_data=self.us_data[div_us_start:end_off],
                jp_data=self.jp_data[div_jp_start:end_off],
                us_offset=div_us_start,
                jp_offset=div_jp_start,
            ))

        progress.done()

        # Also check if one HBD is longer than the other
        if us_sectors != jp_sectors:
            extra_start = min_sectors * self.SECTOR
            longer = self.us_data if us_sectors > jp_sectors else self.jp_data
            self.divergent.append(DivergentRegion(
                offset=extra_start,
                length=len(longer) - extra_start,
                us_data=self.us_data[extra_start:] if us_sectors > jp_sectors else b"",
                jp_data=self.jp_data[extra_start:] if jp_sectors > us_sectors else b"",
                us_offset=extra_start,
                jp_offset=extra_start,
                notes="Size difference — one HBD is longer",
            ))

        return self.divergent

    def report(self) -> str:
        lines = []
        lines.append("=" * 70)
        lines.append(f"HBD COMPARISON: {self.us_label} vs {self.jp_label}")
        lines.append("=" * 70)
        lines.append(f"US size: {len(self.us_data):,} bytes ({len(self.us_data) // self.SECTOR} sectors)")
        lines.append(f"JP size: {len(self.jp_data):,} bytes ({len(self.jp_data) // self.SECTOR} sectors)")
        lines.append(f"Divergent regions: {len(self.divergent)}")
        lines.append("")

        total_div = sum(r.length for r in self.divergent)
        lines.append(f"Total divergent bytes: {total_div:,} ({total_div / len(self.us_data):.1%} of US)")
        lines.append("")

        for i, r in enumerate(self.divergent[:30]):
            lines.append(
                f"  Region {i+1}: offset=0x{r.offset:06X} "
                f"len={r.length:,} "
                f"us_off=0x{r.us_offset:06X} "
                f"jp_off=0x{r.jp_offset:06X}"
            )
            if r.notes:
                lines.append(f"    Notes: {r.notes}")
            # Show first 32 bytes of each
            us_preview = r.us_data[:32].hex()
            jp_preview = r.jp_data[:32].hex()
            lines.append(f"    US: {us_preview}")
            lines.append(f"    JP: {jp_preview}")

        if len(self.divergent) > 30:
            lines.append(f"  ... and {len(self.divergent) - 30} more regions")

        lines.append("")
        lines.append("=" * 70)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# EXE comparison
# ---------------------------------------------------------------------------

class EXEComparator:
    """
    Compare two PSX EXE files using MIPS disassembly.
    Finds shared code, divergent routines, and Huffman patterns.
    """

    def __init__(self, exe_a: bytes, exe_b: bytes,
                 name_a: str = "DQ4", name_b: str = "DW7"):
        self.exe_a = exe_a
        self.exe_b = exe_b
        self.name_a = name_a
        self.name_b = name_b

    def compare(self) -> EXEComparison:
        result = EXEComparison(
            name_a=self.name_a,
            name_b=self.name_b,
            exe_a=self.exe_a,
            exe_b=self.exe_b,
        )

        # Disassemble both
        print(f"Disassembling {self.name_a} EXE ({len(self.exe_a):,} bytes)...")
        disasm_a = MIPSDisassembler(self.exe_a)
        print(f"Disassembling {self.name_b} EXE ({len(self.exe_b):,} bytes)...")
        disasm_b = MIPSDisassembler(self.exe_b)

        # Find Huffman patterns in both
        print(f"Searching for Huffman patterns in {self.name_a}...")
        result.huffman_patterns_a = disasm_a.find_huffman_patterns()
        print(f"  Found {len(result.huffman_patterns_a)} candidate patterns")

        print(f"Searching for Huffman patterns in {self.name_b}...")
        result.huffman_patterns_b = disasm_b.find_huffman_patterns()
        print(f"  Found {len(result.huffman_patterns_b)} candidate patterns")

        # Find address references (lui+ori pairs)
        print(f"Finding address references in {self.name_a}...")
        result.addr_refs_a = disasm_a.find_lui_ori_pairs()
        print(f"  Found {len(result.addr_refs_a)} lui+ori pairs")

        print(f"Finding address references in {self.name_b}...")
        result.addr_refs_b = disasm_b.find_lui_ori_pairs()
        print(f"  Found {len(result.addr_refs_b)} lui+ori pairs")

        # Find shared and divergent code regions (4-instruction windows)
        print("Comparing instruction sequences...")
        self._compare_instructions(disasm_a, disasm_b, result)

        return result

    def _compare_instructions(self, disasm_a, disasm_b, result):
        """Find shared and divergent instruction sequences."""
        ins_a = disasm_a.instructions
        ins_b = disasm_b.instructions
        min_len = min(len(ins_a), len(ins_b))

        # Compare raw instruction words in batches
        BATCH = 50
        progress = _Progress(min_len, "Comparing instructions")

        shared_start = None
        div_start = None

        for i in range(0, min_len, 1):
            same = ins_a[i].raw == ins_b[i].raw

            if same:
                if shared_start is None:
                    shared_start = i
                if div_start is not None:
                    result.divergent_regions.append(
                        (div_start * 4, (i - div_start) * 4)
                    )
                    div_start = None
            else:
                if div_start is None:
                    div_start = i
                if shared_start is not None:
                    result.shared_regions.append(
                        (shared_start * 4, (i - shared_start) * 4)
                    )
                    shared_start = None

            if i % BATCH == 0:
                progress.update(i)

        # Close trailing regions
        if shared_start is not None:
            result.shared_regions.append(
                (shared_start * 4, (min_len - shared_start) * 4)
            )
        if div_start is not None:
            result.divergent_regions.append(
                (div_start * 4, (min_len - div_start) * 4)
            )

        progress.done()

    def report(self, result: EXEComparison) -> str:
        lines = []
        lines.append("=" * 70)
        lines.append(f"EXE COMPARISON: {result.name_a} vs {result.name_b}")
        lines.append("=" * 70)
        lines.append(f"{result.name_a} size: {len(result.exe_a):,} bytes")
        lines.append(f"{result.name_b} size: {len(result.exe_b):,} bytes")
        lines.append("")

        # Shared regions
        shared_bytes = sum(l for _, l in result.shared_regions)
        div_bytes = sum(l for _, l in result.divergent_regions)
        lines.append(f"Shared code: {len(result.shared_regions)} regions, {shared_bytes:,} bytes")
        lines.append(f"Divergent code: {len(result.divergent_regions)} regions, {div_bytes:,} bytes")
        lines.append("")

        # Huffman patterns
        lines.append(f"Huffman patterns in {result.name_a}: {len(result.huffman_patterns_a)}")
        for p in result.huffman_patterns_a[:5]:
            lines.append(f"  score={p['score']} name={p['name']} offset=0x{p['offset']:X}")
            lines.append(f"    {p['notes']}")

        lines.append("")
        lines.append(f"Huffman patterns in {result.name_b}: {len(result.huffman_patterns_b)}")
        for p in result.huffman_patterns_b[:5]:
            lines.append(f"  score={p['score']} name={p['name']} offset=0x{p['offset']:X}")
            lines.append(f"    {p['notes']}")

        lines.append("")

        # Address references
        lines.append(f"Address refs in {result.name_a}: {len(result.addr_refs_a)}")
        for r in result.addr_refs_a[:10]:
            lines.append(f"  0x{r['offset']:X} -> 0x{r['addr']:08X}")

        lines.append("")
        lines.append(f"Address refs in {result.name_b}: {len(result.addr_refs_b)}")
        for r in result.addr_refs_b[:10]:
            lines.append(f"  0x{r['offset']:X} -> 0x{r['addr']:08X}")

        lines.append("")
        lines.append("=" * 70)
        return "\n".join(lines)


# ---------------------------------------------------------------------------
# Three-way comparison
# ---------------------------------------------------------------------------

class ThreeWayComparator:
    """
    Compare all three HBE ROMs: DQ4, DW7 US, DQ7 JP.
    """

    def __init__(
        self,
        dq4_exe: bytes,
        dw7_us_exe: bytes,
        dq7_jp_exe: bytes,
        dq4_hbd: Optional[bytes] = None,
        dw7_us_hbd: Optional[bytes] = None,
        dq7_jp_hbd: Optional[bytes] = None,
    ):
        self.dq4_exe = dq4_exe
        self.dw7_us_exe = dw7_us_exe
        self.dq7_jp_exe = dq7_jp_exe
        self.dq4_hbd = dq4_hbd
        self.dw7_us_hbd = dw7_us_hbd
        self.dq7_jp_hbd = dq7_jp_hbd

    def run(self) -> str:
        """Run all comparisons and return a combined report."""
        report_parts = []

        # EXE comparisons
        print("\n--- DQ4 vs DW7 US EXE ---")
        cmp1 = EXEComparator(self.dq4_exe, self.dw7_us_exe, "DQ4", "DW7_US")
        result1 = cmp1.compare()
        report_parts.append(cmp1.report(result1))

        print("\n--- DQ4 vs DQ7 JP EXE ---")
        cmp2 = EXEComparator(self.dq4_exe, self.dq7_jp_exe, "DQ4", "DQ7_JP")
        result2 = cmp2.compare()
        report_parts.append(cmp2.report(result2))

        print("\n--- DW7 US vs DQ7 JP EXE ---")
        cmp3 = EXEComparator(self.dw7_us_exe, self.dq7_jp_exe, "DW7_US", "DQ7_JP")
        result3 = cmp3.compare()
        report_parts.append(cmp3.report(result3))

        # HBD comparisons (if data available)
        if self.dw7_us_hbd and self.dq7_jp_hbd:
            print("\n--- DW7 US vs DQ7 JP HBD ---")
            hbd_cmp = HBDComparator(
                self.dw7_us_hbd, self.dq7_jp_hbd, "DW7_US", "DQ7_JP"
            )
            hbd_cmp.compare()
            report_parts.append(hbd_cmp.report())

        if self.dq4_hbd and self.dw7_us_hbd:
            print("\n--- DQ4 vs DW7 US HBD ---")
            hbd_cmp2 = HBDComparator(
                self.dq4_hbd, self.dw7_us_hbd, "DQ4", "DW7_US"
            )
            hbd_cmp2.compare()
            report_parts.append(hbd_cmp2.report())

        return "\n\n".join(report_parts)
