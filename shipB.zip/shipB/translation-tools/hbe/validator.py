"""
Validation layer for the Heart Beat Engine toolchain.

Checks archive, EXE, and disc invariants before any write operation.
"""

from dataclasses import dataclass, field
from typing import List

from hbe.allocation import AllocationPlanner
from hbe.archive import HBDArchive
from hbe.exe import EXE


@dataclass
class ValidationIssue:
    """One validation failure or warning."""

    level: str  # "error" or "warning"
    message: str


@dataclass
class ValidationReport:
    """Report containing all validation issues."""

    errors: List[ValidationIssue] = field(default_factory=list)
    warnings: List[ValidationIssue] = field(default_factory=list)

    @property
    def is_valid(self) -> bool:
        return len(self.errors) == 0

    def add_error(self, message: str):
        self.errors.append(ValidationIssue("error", message))

    def add_warning(self, message: str):
        self.warnings.append(ValidationIssue("warning", message))


class Validator:
    """Validate HBD archive and EXE invariants."""

    def __init__(self, planner: AllocationPlanner = None):
        self.planner = planner or AllocationPlanner()

    def check_archive(self, archive: HBDArchive, original: HBDArchive = None) -> ValidationReport:
        """Validate an HBD archive against the original."""
        report = ValidationReport()

        if len(archive.data) % 2048 != 0:
            report.add_error(f"HBD size {len(archive.data)} is not a multiple of 2048")

        if original is not None and len(archive.data) > len(original.data):
            report.add_error(
                f"HBD size {len(archive.data)} exceeds original {len(original.data)}"
            )

        for folder in archive.folders:
            layout = self.planner.plan_folder(folder)
            if layout.sector_count != folder.sector_count:
                report.add_error(
                    f"Folder {folder.index}: computed sector count {layout.sector_count} "
                    f"!= stored {folder.sector_count}"
                )
            if layout.remaining_bytes < 0:
                report.add_error(
                    f"Folder {folder.index}: content exceeds sector allocation"
                )

        return report

    def check_exe(self, exe: EXE, archive: HBDArchive) -> ValidationReport:
        """Validate that EXE folder pointers point to valid folders."""
        report = ValidationReport()
        for folder in archive.folders:
            matches = exe.find_pointer_pattern(folder.sector, folder.sector_count)
            if not matches:
                report.add_warning(
                    f"Folder {folder.index}: no EXE pointer found for "
                    f"sector={folder.sector} count={folder.sector_count}"
                )
        return report

    def check_text_roundtrip(self, archive: HBDArchive, registry) -> ValidationReport:
        """Validate that every text file in the archive round-trips."""
        report = ValidationReport()
        for f in archive.files():
            content = registry.parse_file(f)
            if content.is_text:
                try:
                    # Round-trip is already performed during parse; this checks stability.
                    if not hasattr(content, "text") or not hasattr(content, "tree"):
                        report.add_error(f"Text file {f.path}: missing parsed text/tree")
                except Exception as e:
                    report.add_error(f"Text file {f.path}: round-trip failed: {e}")
        return report
