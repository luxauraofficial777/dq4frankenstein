"""
Content-type registry for the Heart Beat Engine.

Maps HBD file type IDs to BlockParser instances. Unknown types fall back to
BinaryParser, which preserves raw bytes and produces a heuristic preview.
"""

from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional

from hbe.compression import lzss_uncompress
from hbe.huffman import DQ4Schema

from .base import BlockContent, BlockParser
from .binary import BinaryParser
from .image import ImageParser
from .qqes import QQESParser
from .script import ScriptParser
from .text import TextContentParser


@dataclass
class ContentTypeRegistry:
    """Registry of parsers for each HBD file type ID."""

    parsers: Dict[int, BlockParser] = field(default_factory=dict)
    default: BlockParser = field(default_factory=lambda: BinaryParser())

    def register(self, type_id: int, parser: BlockParser) -> None:
        """Register a parser for a given HBD file type."""
        self.parsers[type_id] = parser

    def parse(self, type_id: int, data: bytes, **context: Any) -> BlockContent:
        """Parse data according to the registered parser for type_id."""
        parser = self.parsers.get(type_id, self.default)
        return parser.parse(data, type_id=type_id, **context)

    def decompress_if_needed(self, file_obj) -> bytes:
        """Return decompressed file content if the file is LZSS-compressed."""
        if file_obj.is_compressed:
            return lzss_uncompress(file_obj.content, file_obj.size_uncompressed)
        return file_obj.content

    def parse_file(self, file_obj) -> BlockContent:
        """Parse an HBDFile object, decompressing first if needed."""
        data = self.decompress_if_needed(file_obj)
        content = self.parse(
            file_obj.type_id,
            data,
            folder_index=file_obj.parent.index,
            file_index=file_obj.index,
            path=file_obj.path,
        )
        file_obj.parsed = content
        return content


def default_registry() -> ContentTypeRegistry:
    """Create a registry with the known DQ4/DW7 content-type parsers."""
    registry = ContentTypeRegistry()

    dq4_schema = DQ4Schema()
    text_parser = TextContentParser(dq4_schema)

    registry.register(19, text_parser)
    registry.register(40, text_parser)
    registry.register(42, text_parser)

    # Type 39 is script bytecode; usually LZSS-compressed.
    registry.register(39, ScriptParser())

    # Type 1, 8, 10 are TIM / image blocks.
    image_parser = ImageParser()
    for t in (1, 8, 10):
        registry.register(t, image_parser)

    # Types 20-24 are qQES model/animation blocks.
    qqes_parser = QQESParser()
    for t in range(20, 25):
        registry.register(t, qqes_parser)

    return registry
