"""
Parser for DQ4 type-19 (and 40/42) Huffman-encoded text blocks.
"""

import struct
from dataclasses import dataclass, field
from typing import List

from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.node import HuffmanNode

from .base import BlockContent


@dataclass(kw_only=True)
class TextContent(BlockContent):
    """Parsed content of a type-19 text file."""
    end: int
    block_id: int
    huffman_text_start: int
    huffman_tree_end: int
    huffman_text_end: int
    unknown1: int
    unknown2: bytes
    text_bytes: bytes
    tree_start: int
    tree_middle: int
    tree_number_of_nodes: int
    tree_bytes: bytes
    unknown3: bytes
    at_end: int
    dialog_pointer_count: int
    dialog_pointers: List[bytes] = field(default_factory=list)
    tree: HuffmanNode = None
    text: List[HuffmanNode] = field(default_factory=list)
    type_id: int = 0
    raw: bytes = b""

    @property
    def is_text(self) -> bool:
        return True

    @property
    def block_id_hex(self) -> str:
        return f"{self.block_id:04X}"


class TextContentParser:
    """Parse a type-19 DQ4 text block using the DQ4 Huffman schema."""

    def __init__(self, schema: DQ4Schema = None):
        self.schema = schema or DQ4Schema()

    def parse(self, data: bytes, **context) -> TextContent:
        if len(data) < 24:
            raise ValueError("Text block too short for header")

        header = struct.unpack("<6I", data[:24])
        end, block_id, hts, tree_end, hte, unknown1 = header

        if tree_end == 0:
            tree_end = end

        unknown2 = data[24:hts]
        text_bytes = data[hts:hte]

        tree_header = data[hte:hte + 10]
        tree_start, tree_middle, tree_nodes = struct.unpack("<IIH", tree_header)

        tree_bytes = data[tree_start:tree_end]
        unknown3 = data[tree_end:end]

        at_end = struct.unpack("<I", data[end:end + 4])[0]
        dp_count = struct.unpack("<I", data[end + 4:end + 8])[0]
        dp_data = data[end + 8:end + 8 + dp_count * 8]
        dialog_pointers = [dp_data[i:i + 8] for i in range(0, len(dp_data), 8)]

        tree = self.schema.parse_tree(tree_bytes)
        text = self.schema.decode(text_bytes, tree)

        return TextContent(
            type_id=context.get("type_id", 0),
            raw=data,
            end=end,
            block_id=block_id,
            huffman_text_start=hts,
            huffman_tree_end=tree_end,
            huffman_text_end=hte,
            unknown1=unknown1,
            unknown2=unknown2,
            text_bytes=text_bytes,
            tree_start=tree_start,
            tree_middle=tree_middle,
            tree_number_of_nodes=tree_nodes,
            tree_bytes=tree_bytes,
            unknown3=unknown3,
            at_end=at_end,
            dialog_pointer_count=dp_count,
            dialog_pointers=dialog_pointers,
            tree=tree,
            text=text,
        )
