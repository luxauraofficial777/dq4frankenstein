"""
Fallback parser for unknown or raw binary HBD files.
"""

from dataclasses import dataclass
from typing import Any

from .base import BlockContent, BlockParser


@dataclass
class BinaryContent(BlockContent):
    """Raw binary content with a heuristic preview."""

    preview: str = ""


class BinaryParser(BlockParser):
    """Default parser that preserves raw bytes and shows a hex preview."""

    def parse(self, data: bytes, **context: Any) -> BlockContent:
        preview = self._hex_preview(data)
        return BinaryContent(
            type_id=context.get("type_id", -1),
            raw=data,
            preview=preview,
        )
