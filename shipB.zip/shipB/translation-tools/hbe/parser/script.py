"""
Script content parser for HBD type-39 files.

Type-39 files contain cut-scene / script bytecode. They are often LZSS
compressed in the archive (size != size_uncompressed && flags != 0). The
registry decompresses them before calling this parser.
"""

from dataclasses import dataclass
from typing import Any

from .base import BlockContent, BlockParser


@dataclass
class ScriptContent(BlockContent):
    """Parsed script bytecode content."""

    preview: str = ""


class ScriptParser(BlockParser):
    """Stub parser for type-39 script files."""

    def parse(self, data: bytes, **context: Any) -> BlockContent:
        preview = self._hex_preview(data)
        return ScriptContent(
            type_id=context.get("type_id", 39),
            raw=data,
            preview=preview,
        )
