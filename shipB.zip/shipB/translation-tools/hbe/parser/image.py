"""
Image parser for TIM and sprite blocks in the HBD archive.

Likely block types: 1 (font), 8 (TIM), 10 (multi TIM), 13-18 (sprites).
"""

from dataclasses import dataclass
from typing import Any

from .base import BlockContent, BlockParser


TIM_MAGIC = b"\x10\x00\x00\x00"


@dataclass
class ImageContent(BlockContent):
    """Parsed image content with TIM metadata."""

    is_tim: bool = False
    preview: str = ""


class ImageParser(BlockParser):
    """Detect and parse TIM image blocks."""

    def parse(self, data: bytes, **context: Any) -> BlockContent:
        is_tim = data[:4] == TIM_MAGIC
        preview = self._hex_preview(data)
        return ImageContent(
            type_id=context.get("type_id", 0),
            raw=data,
            is_tim=is_tim,
            preview=preview,
        )
