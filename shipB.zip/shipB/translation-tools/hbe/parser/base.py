"""
Base classes for HBD content parsers.
"""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from typing import Any, Dict, List


@dataclass(kw_only=True)
class BlockContent:
    """Base parsed content for any HBD file type."""

    type_id: int
    raw: bytes
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def is_text(self) -> bool:
        return False


@dataclass(kw_only=True)
class BinaryContent(BlockContent):
    """Fallback content for unknown or binary file types."""

    preview: str = ""


class BlockParser(ABC):
    """Abstract parser for a specific HBD file type."""

    @abstractmethod
    def parse(self, data: bytes, **context: Any) -> BlockContent:
        """Parse raw bytes into a BlockContent object."""
        ...

    def _hex_preview(self, data: bytes, max_bytes: int = 64) -> str:
        """Return a compact hex preview of binary data."""
        sample = data[:max_bytes]
        return sample.hex()
