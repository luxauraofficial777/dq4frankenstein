"""
qQES model/animation block parser for HBD types 20-24.

The qQES marker is `71 51 45 53`. These blocks are not yet fully understood;
this parser detects the marker and preserves the raw bytes.
"""

from dataclasses import dataclass
from typing import Any

from .base import BlockContent, BlockParser


QQES_MARKER = b"qQES"


@dataclass
class QQESContent(BlockContent):
    """Parsed qQES block content."""

    has_marker: bool = False
    preview: str = ""


class QQESParser(BlockParser):
    """Detect qQES model/animation blocks."""

    def parse(self, data: bytes, **context: Any) -> BlockContent:
        has_marker = QQES_MARKER in data[:64]
        preview = self._hex_preview(data)
        return QQESContent(
            type_id=context.get("type_id", 0),
            raw=data,
            has_marker=has_marker,
            preview=preview,
        )
