"""
CD-ROM sector abstraction for the Heart Beat Engine.

A PlayStation Mode 2 / Form 1 / XA sector is 2352 bytes:
- 12 bytes sync
- 4 bytes MSF header
- 4 bytes sub-header
- 4 bytes sub-header copy
- 2048 bytes user data
- 4 bytes EDC
- 280 bytes ECC

The engine only cares about the 2048-byte user payload.
"""

from dataclasses import dataclass


RAW_SECTOR_SIZE = 2352
USER_DATA_SIZE = 2048
USER_DATA_OFFSET = 24


@dataclass(frozen=True)
class Sector:
    """One CD-ROM sector with user data payload."""

    raw: bytes

    @property
    def user_data(self) -> bytes:
        return self.raw[USER_DATA_OFFSET:USER_DATA_OFFSET + USER_DATA_SIZE]

    @property
    def is_valid(self) -> bool:
        return len(self.raw) == RAW_SECTOR_SIZE

    @classmethod
    def from_user_data(cls, data: bytes) -> "Sector":
        """Create a sector from 2048 bytes of user data (no EDC/ECC)."""
        if len(data) != USER_DATA_SIZE:
            raise ValueError(f"User data must be {USER_DATA_SIZE} bytes")
        raw = bytearray(RAW_SECTOR_SIZE)
        raw[USER_DATA_OFFSET:USER_DATA_OFFSET + USER_DATA_SIZE] = data
        return cls(bytes(raw))


class DiscImage:
    """Simple model of a raw PSX disc image."""

    def __init__(self, data: bytes):
        if len(data) % RAW_SECTOR_SIZE != 0:
            raise ValueError("Disc image size must be a multiple of 2352 bytes")
        self.data = data

    def __len__(self) -> int:
        return len(self.data) // RAW_SECTOR_SIZE

    def sector(self, index: int) -> Sector:
        start = index * RAW_SECTOR_SIZE
        return Sector(self.data[start:start + RAW_SECTOR_SIZE])

    def read_user_data(self, start_sector: int, size: int) -> bytes:
        """Read a contiguous region of user data from the disc."""
        out = bytearray()
        sectors_needed = (size + USER_DATA_SIZE - 1) // USER_DATA_SIZE
        for i in range(sectors_needed):
            out.extend(self.sector(start_sector + i).user_data)
        return bytes(out[:size])
