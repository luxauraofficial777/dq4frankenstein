"""
Fusing / patching engine for the Heart Beat Engine.

Applies transformations to an HBDArchive and produces a new archive. This is
the core of the deterministic build process.
"""

from dataclasses import dataclass
from typing import Any, Callable, Dict, List

from hbe.archive import HBDArchive, HBDFile


@dataclass
class Patch:
    """A single deterministic patch to a target."""

    target: str          # e.g. "hbd:26046/6", "exe:0xD1DD", "disc:sector+offset"
    old_bytes: bytes
    new_bytes: bytes
    reason: str


class Fuser:
    """Apply patches and transformations to an archive."""

    def __init__(self):
        self.patches: List[Patch] = []

    def add_patch(self, patch: Patch) -> None:
        self.patches.append(patch)

    def apply_file_transform(
        self,
        archive: HBDArchive,
        path: str,
        transform: Callable[[HBDFile], bytes],
        reason: str = ""
    ) -> None:
        """Apply a transformation to a single file's content."""
        file_obj = archive.get_file(path)
        if file_obj is None:
            raise ValueError(f"File not found: {path}")
        old = file_obj.content
        new = transform(file_obj)
        self.add_patch(Patch(
            target=f"hbd:{path}",
            old_bytes=old,
            new_bytes=new,
            reason=reason or f"transform {path}",
        ))

    def materialize(self, archive: HBDArchive) -> HBDArchive:
        """Return a new archive with all queued file content patches applied."""
        from .writer import HBDWriter
        # Apply queued patches to file contents.
        for patch in self.patches:
            if not patch.target.startswith("hbd:"):
                continue
            path = patch.target[4:]
            file_obj = archive.get_file(path)
            if file_obj is None:
                raise ValueError(f"Patch target file not found: {path}")
            file_obj.content = patch.new_bytes
            file_obj.size = len(patch.new_bytes)
        return HBDArchive(HBDWriter().write(archive))

    def report(self) -> List[Patch]:
        """Return the list of queued patches."""
        return list(self.patches)
