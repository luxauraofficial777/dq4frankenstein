"""
Bitstream decoder for the Heart Beat Engine.

Decodes a Huffman-compressed bitstream into a sequence of leaf nodes using a
provided schema and tree.
"""

from typing import List

from .node import HuffmanNode
from .schema import HuffmanSchema


class BitstreamDecoder:
    """Decode a bitstream into leaf nodes using a schema."""

    def __init__(self, schema: HuffmanSchema):
        self.schema = schema

    def decode(self, text_bytes: bytes, tree: HuffmanNode) -> List[HuffmanNode]:
        """Decode text_bytes using the given tree."""
        return self.schema.decode(text_bytes, tree)
