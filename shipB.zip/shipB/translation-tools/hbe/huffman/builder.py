"""
Generic Huffman tree builder for the Heart Beat Engine.

Builds an optimal Huffman tree from character frequencies and assigns node IDs
in a schema-compatible way.
"""

import heapq
from collections import Counter
from typing import Dict, List, Tuple

from .node import HuffmanNode
from .schema import HuffmanSchema


def build_tree(
    frequencies: Dict[bytes, int],
    schema: HuffmanSchema = None
) -> HuffmanNode:
    """
    Build a canonical Huffman tree from a frequency map.

    Args:
        frequencies: Mapping from 2-byte leaf content to frequency.
        schema: Optional schema to validate serialization against.

    Returns:
        Root HuffmanNode with node IDs assigned.
    """
    if not frequencies:
        raise ValueError("Cannot build tree from empty frequencies")

    # Each heap item is (frequency, counter, node)
    counter = 0
    heap: List[Tuple[int, int, HuffmanNode]] = []
    for content, freq in frequencies.items():
        if len(content) != 2:
            raise ValueError(f"Leaf content must be 2 bytes: {content}")
        heapq.heappush(heap, (freq, counter, HuffmanNode.leaf_from_value(
            (content[0] << 8) | content[1]
        )))
        counter += 1

    while len(heap) > 1:
        f1, c1, left = heapq.heappop(heap)
        f2, c2, right = heapq.heappop(heap)
        parent = HuffmanNode.branch(0)
        parent.children = [left, right]
        heapq.heappush(heap, (f1 + f2, counter, parent))
        counter += 1

    root = heap[0][2]
    _assign_ids(root)

    # Tree format requires root's right child to be a branch (stored at end-4).
    # Swap if needed — doesn't affect Huffman optimality.
    if not root.children[1].is_branch() and root.children[0].is_branch():
        root.children = [root.children[1], root.children[0]]
        _assign_ids(root)  # reassign IDs after swap

    if schema is not None:
        # Validate that the tree can be serialized and re-parsed.
        tree_bytes = schema.write_tree(root)
        reparsed = schema.parse_tree(tree_bytes)
        if reparsed != root:
            raise ValueError("Built tree does not round-trip through schema")

    return root


def _assign_ids(root: HuffmanNode) -> None:
    """Assign branch node IDs in post-order, so root gets the highest ID.
    Required by DQ4/DW7 tree format: root is derived from last stored branch at end-4."""
    next_id = 0

    def walk(node: HuffmanNode):
        nonlocal next_id
        if node.is_branch():
            for child in node.children:
                walk(child)
            node.node_id = next_id
            next_id += 1

    walk(root)


def frequencies_from_text(text: List[HuffmanNode]) -> Dict[bytes, int]:
    """Count frequencies of leaf contents in a decoded text sequence."""
    counts = Counter()
    for leaf in text:
        if leaf.content is None or len(leaf.content) != 2:
            raise ValueError(f"Leaf must have 2-byte content: {leaf}")
        counts[leaf.content] += 1
    return dict(counts)
