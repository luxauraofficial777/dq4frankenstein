"""
DQ4 Huffman schema for the Heart Beat Engine.

Tree layout:
- All nodes are 2 bytes.
- The tree is stored as two parallel arrays:
    Array A starts at offset 0.
    Array B starts at offset (len + 2) // 2 - 2.
- For a branch with ID N, its left child is at ArrayA[N*2] and its right
  child at ArrayB[N*2].
- Branch nodes are marked with high bit set: value = 0x8000 | id.
- Control-character leaves start with 0x7F or are 0x0000.
- Character leaves store a Shift-JIS code point with the high byte stripped;
  the parser adds 0x80 back at render time.
- The root is implicit: root ID = (last stored node value - 0x8000) + 1.

Bitstream layout:
- Bits within each byte are reversed before interpretation.
- 0 = left child, 1 = right child.
- Encoded bytes are padded to a multiple of 4 bytes (32 bits).
"""

from typing import List

from .bitutils import bytes_to_bitstream, bitstream_to_bytes
from .node import HuffmanNode, NodeType
from .schema import HuffmanSchema


class DQ4Schema(HuffmanSchema):
    """DQ4 per-block adaptive Huffman schema."""

    BRANCH_BIT = 0x8000

    @property
    def name(self) -> str:
        return "DQ4"

    def parse_tree(self, tree_bytes: bytes) -> HuffmanNode:
        if len(tree_bytes) < 4 or len(tree_bytes) % 2 != 0:
            raise ValueError(f"Invalid DQ4 tree length: {len(tree_bytes)}")

        # Derive the root from the last stored node (at length-4).
        last_node_idx = len(tree_bytes) - 4
        last_node_value = self._read_short_be(self._swap(tree_bytes[last_node_idx:last_node_idx + 2]))
        if last_node_value < self.BRANCH_BIT:
            raise ValueError(
                f"Root node at end-4 is not a branch: 0x{last_node_value:04X}"
            )
        last_node_number = last_node_value - self.BRANCH_BIT
        root_number = last_node_number + 1

        # Second array starts at this offset.
        offset_b = (len(tree_bytes) + 2) // 2 - 2

        root = HuffmanNode.branch(root_number)
        self._parse_children(root, root_number, tree_bytes, offset_b)
        return root

    def _parse_children(self, parent: HuffmanNode, cur_number: int,
                        tree_bytes: bytes, offset_b: int):
        """Recursively parse left (bit=0) and right (bit=1) children."""
        for bit in (0, 1):
            offset = 0 if bit == 0 else offset_b
            index = offset + cur_number * 2
            if index < 0 or index + 2 > len(tree_bytes):
                raise ValueError(
                    f"Tree parse out of bounds: bit={bit}, id={cur_number}, "
                    f"index={index}, len={len(tree_bytes)}"
                )
            node_bytes = tree_bytes[index:index + 2]
            value = self._read_short_be(self._swap(node_bytes))

            if (value & self.BRANCH_BIT) != 0:
                child_id = value & 0x7FFF
                child = HuffmanNode.branch(child_id)
                parent.children.append(child)
                self._parse_children(child, child_id, tree_bytes, offset_b)
            elif value == 0 or (value & 0xFF00) == 0x7F00:
                child = HuffmanNode.control(bytes([(value >> 8) & 0xFF, value & 0xFF]))
                parent.children.append(child)
            else:
                child = HuffmanNode.character(bytes([(value >> 8) & 0xFF, value & 0xFF]))
                parent.children.append(child)

    def write_tree(self, root: HuffmanNode) -> bytes:
        descendants = root.descendants()
        # Every descendant is stored as 2 bytes, plus 2 trailing zero bytes.
        array_size = len(descendants) * 2 + 2
        data = bytearray(array_size)
        offset_b = (len(data) + 2) // 2 - 2
        self._write_children(root, data, offset_b)
        return bytes(data)

    def _write_children(self, parent: HuffmanNode, data: bytearray, offset_b: int):
        parent_id = parent.node_id
        if parent_id is None:
            raise ValueError("Branch node must have an ID before serialization")

        for i, child in enumerate(parent.children):
            is_left = (i == 0)
            index = (0 if is_left else offset_b) + parent_id * 2
            if index < 0 or index + 2 > len(data):
                raise ValueError(
                    f"Tree write out of bounds: id={parent_id}, index={index}, "
                    f"len={len(data)}"
                )
            node_bytes = self._node_to_bytes(child)
            data[index:index + 2] = node_bytes

            if child.is_branch():
                self._write_children(child, data, offset_b)

    def _node_to_bytes(self, node: HuffmanNode) -> bytes:
        if node.is_branch():
            if node.node_id is None:
                raise ValueError("Branch node has no ID")
            value = self.BRANCH_BIT | node.node_id
            return bytes([value & 0xFF, (value >> 8) & 0xFF])
        if node.content is None or len(node.content) != 2:
            raise ValueError(f"Leaf node must have 2-byte content: {node}")
        # Both characters and controls are stored byte-swapped.
        return bytes([node.content[1], node.content[0]])

    def decode(self, text_bytes: bytes, tree: HuffmanNode) -> List[HuffmanNode]:
        bits = bytes_to_bitstream(text_bytes)
        leaves = []
        node = tree
        for bit in bits:
            if bit == "0":
                node = node.left
            else:
                node = node.right
            if node is None:
                raise ValueError("Invalid bitstream: reached null child")
            if node.is_leaf():
                leaves.append(node)
                node = tree
        return leaves

    def encode(self, leaves: List[HuffmanNode], tree: HuffmanNode) -> bytes:
        codes = self._collect_codes(tree)
        bits = []
        for leaf in leaves:
            content = self._leaf_to_content(leaf)
            code = codes.get(content)
            if code is None:
                raise ValueError(f"Leaf content {content.hex()} not found in tree")
            bits.append(code)
        return bitstream_to_bytes("".join(bits))

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------
    @staticmethod
    def _read_short_be(data: bytes) -> int:
        if len(data) != 2:
            raise ValueError("short read requires 2 bytes")
        return (data[0] << 8) | data[1]

    @staticmethod
    def _swap(data: bytes) -> bytes:
        """Swap the two bytes of a short, matching the engine's on-disk convention."""
        if len(data) != 2:
            raise ValueError("swap requires 2 bytes")
        return bytes([data[1], data[0]])

    def __repr__(self) -> str:
        return f"DQ4Schema()"
