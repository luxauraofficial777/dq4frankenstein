"""
Bitstream encoder for the Heart Beat Engine.

Encodes a sequence of leaf nodes into a Huffman-compressed bitstream using a
provided schema and tree.
"""

from typing import List

from .node import HuffmanNode
from .schema import HuffmanSchema


class BitstreamEncoder:
    """Encode leaf nodes into a bitstream using a schema."""

    def __init__(self, schema: HuffmanSchema):
        self.schema = schema

    def encode(self, leaves: List[HuffmanNode], tree: HuffmanNode) -> bytes:
        """Encode leaves using the given tree."""
        return self.schema.encode(leaves, tree)
