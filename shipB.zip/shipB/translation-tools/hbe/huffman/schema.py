"""
Base Huffman schema interface.

A schema defines how a Huffman tree is serialized and how the text bitstream
is encoded/decoded for a specific game or engine variant (e.g. DQ4, DW7).
"""

from abc import ABC, abstractmethod
from typing import List, Tuple

from .node import HuffmanNode


class HuffmanSchema(ABC):
    """Abstract Huffman schema for the Heart Beat Engine."""

    @property
    @abstractmethod
    def name(self) -> str:
        """Human-readable schema name."""
        ...

    @abstractmethod
    def parse_tree(self, tree_bytes: bytes) -> HuffmanNode:
        """Parse raw tree bytes into a HuffmanNode tree."""
        ...

    @abstractmethod
    def write_tree(self, root: HuffmanNode) -> bytes:
        """Serialize a HuffmanNode tree back to raw bytes."""
        ...

    @abstractmethod
    def decode(self, text_bytes: bytes, tree: HuffmanNode) -> List[HuffmanNode]:
        """
        Decode a bitstream into a list of leaf nodes (characters/control codes).
        """
        ...

    @abstractmethod
    def encode(self, leaves: List[HuffmanNode], tree: HuffmanNode) -> bytes:
        """
        Encode a list of leaf nodes into a bitstream byte array.
        """
        ...

    def roundtrip(self, text_bytes: bytes, tree_bytes: bytes) -> Tuple[bytes, bytes]:
        """
        Convenience: decode text and re-encode it, returning (decoded_leaves, reencoded_bytes).
        """
        tree = self.parse_tree(tree_bytes)
        leaves = self.decode(text_bytes, tree)
        reencoded = self.encode(leaves, tree)
        return leaves, reencoded

    def _leaf_to_content(self, leaf: HuffmanNode) -> bytes:
        if leaf.content is None or len(leaf.content) != 2:
            raise ValueError(f"Leaf node must have 2-byte content: {leaf}")
        return leaf.content

    def _collect_codes(self, tree: HuffmanNode) -> "dict[bytes, str]":
        """
        Walk the tree and build a mapping from leaf content to bit code.
        0 = left child, 1 = right child.
        """
        codes: "dict[bytes, str]" = {}

        def walk(node: HuffmanNode, prefix: str):
            if node.is_leaf():
                content = self._leaf_to_content(node)
                codes[content] = prefix
                return
            if node.left:
                walk(node.left, prefix + "0")
            if node.right:
                walk(node.right, prefix + "1")

        walk(tree, "")
        return codes
