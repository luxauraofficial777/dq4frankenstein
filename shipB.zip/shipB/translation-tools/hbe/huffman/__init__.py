"""
Huffman tree schemas and bitstream codecs for the Heart Beat Engine.
"""

from .node import HuffmanNode, NodeType
from .schema import HuffmanSchema
from .dq4 import DQ4Schema
from .dw7 import DW7Schema, DW7SchemaCandidate, DW7TreeMiner, DW7CandidateParams
from .builder import build_tree, frequencies_from_text
from .decoder import BitstreamDecoder
from .encoder import BitstreamEncoder
from .length_limited import (
    build_tree_length_limited,
    validate_tree_constraints,
    tree_to_binary_header,
    build_and_validate,
    max_code_length,
    code_lengths,
    MAX_CODE_LENGTH,
)

__all__ = [
    "HuffmanNode",
    "NodeType",
    "HuffmanSchema",
    "DQ4Schema",
    "DW7Schema",
    "DW7SchemaCandidate",
    "DW7TreeMiner",
    "DW7CandidateParams",
    "build_tree",
    "build_tree_length_limited",
    "frequencies_from_text",
    "BitstreamDecoder",
    "BitstreamEncoder",
    "validate_tree_constraints",
    "tree_to_binary_header",
    "build_and_validate",
    "max_code_length",
    "code_lengths",
    "MAX_CODE_LENGTH",
]
