"""
Bit manipulation utilities for Heart Beat Engine bitstreams.

The engine stores Huffman bits in bit-reversed byte order. Within a byte,
the LSB is decoded first after reversal. This module centralizes those
conventions so every schema uses the same primitive operations.
"""


def byte_to_bits(b: int) -> str:
    """Return the 8 bits of a byte as a string, MSB first."""
    return format(b & 0xFF, "08b")


def reverse_bits(s: str) -> str:
    """Reverse a bit string."""
    return s[::-1]


def bitstream_to_bytes(bits: str) -> bytes:
    """
    Convert a bit string to bytes using the engine's convention:
    split into 8-bit chunks, reverse each chunk, then store as a byte.
    The total length is padded to a multiple of 32 bits (4 bytes).
    """
    # Pad the bitstream to a multiple of 8
    if len(bits) % 8:
        bits += "0" * (8 - (len(bits) % 8))

    # Pad to a multiple of 32 bits (4 bytes) for alignment
    while len(bits) % 32:
        bits += "0" * 8

    result = bytearray()
    for i in range(0, len(bits), 8):
        chunk = bits[i:i + 8]
        # reverse the chunk before converting to byte
        reversed_chunk = chunk[::-1]
        result.append(int(reversed_chunk, 2))
    return bytes(result)


def bytes_to_bitstream(data: bytes) -> str:
    """
    Convert bytes to a bit string using the engine's convention:
    reverse each byte's bits and concatenate.
    """
    bits = []
    for b in data:
        bits.append(byte_to_bits(b)[::-1])
    return "".join(bits)


def bits_to_int(bits: str) -> int:
    """Parse a bit string as an unsigned integer (MSB first)."""
    if not bits:
        return 0
    return int(bits, 2)


def int_to_bits(value: int, width: int) -> str:
    """Format an integer as a fixed-width bit string, MSB first."""
    return format(value & ((1 << width) - 1), f"0{width}b")
