"""
Huffman tree node for Heart Beat Engine text blocks.

A node is either a branch (with two children), a control character leaf,
or a character leaf. Leaves carry a 2-byte content payload. The exact
interpretation of that payload depends on the Huffman schema.
"""

from enum import Enum, auto
from typing import List, Optional


class NodeType(Enum):
    Branch = auto()
    ControlCharacter = auto()
    Character = auto()


class HuffmanNode:
    """A node in a Heart Beat Engine Huffman tree."""

    def __init__(self, node_type: NodeType, content: Optional[bytes] = None):
        if content is not None and len(content) != 2:
            raise ValueError("Huffman node content must be exactly 2 bytes")
        self.node_type = node_type
        self.content = content  # 2 bytes for leaves; None for branches
        self.children: List["HuffmanNode"] = []
        # For branches, this is populated by the schema when building the tree.
        self._id: Optional[int] = None

    # ------------------------------------------------------------------
    # Constructors
    # ------------------------------------------------------------------
    @classmethod
    def branch(cls, node_id: int) -> "HuffmanNode":
        n = cls(NodeType.Branch)
        n._id = node_id
        return n

    @classmethod
    def control(cls, content: bytes) -> "HuffmanNode":
        return cls(NodeType.ControlCharacter, content)

    @classmethod
    def character(cls, content: bytes) -> "HuffmanNode":
        return cls(NodeType.Character, content)

    @classmethod
    def leaf_from_value(cls, value: int) -> "HuffmanNode":
        """Create a control or character leaf from a 2-byte value."""
        content = bytes([(value >> 8) & 0xFF, value & 0xFF])
        if value == 0 or (value & 0x7F00) == 0x7F00:
            return cls(NodeType.ControlCharacter, content)
        return cls(NodeType.Character, content)

    # ------------------------------------------------------------------
    # Properties
    # ------------------------------------------------------------------
    def is_branch(self) -> bool:
        return self.node_type == NodeType.Branch

    def is_control(self) -> bool:
        return self.node_type == NodeType.ControlCharacter

    def is_character(self) -> bool:
        return self.node_type == NodeType.Character

    def is_leaf(self) -> bool:
        return not self.is_branch()

    def is_zero(self) -> bool:
        return self.is_control() and self.content == b"\x00\x00"

    @property
    def node_id(self) -> Optional[int]:
        return self._id

    @node_id.setter
    def node_id(self, value: int):
        if not self.is_branch():
            raise ValueError("Only branch nodes can have an ID")
        self._id = value

    @property
    def left(self) -> Optional["HuffmanNode"]:
        return self.children[0] if self.children else None

    @property
    def right(self) -> Optional["HuffmanNode"]:
        return self.children[1] if len(self.children) > 1 else None

    def leftmost_leaf(self) -> "HuffmanNode":
        n = self
        while n.is_branch() and n.children:
            n = n.children[0]
        return n

    def rightmost_leaf(self) -> "HuffmanNode":
        n = self
        while n.is_branch() and n.children:
            n = n.children[-1]
        return n

    # ------------------------------------------------------------------
    # Tree traversal
    # ------------------------------------------------------------------
    def descendants(self) -> List["HuffmanNode"]:
        """All nodes below this one, in pre-order."""
        result = []
        for child in self.children:
            result.append(child)
            result.extend(child.descendants())
        return result

    def branch_nodes(self) -> List["HuffmanNode"]:
        return [n for n in self.descendants() if n.is_branch()]

    def leaf_nodes(self) -> List["HuffmanNode"]:
        return [n for n in self.descendants() if n.is_leaf()]

    def __eq__(self, other: object) -> bool:
        if not isinstance(other, HuffmanNode):
            return NotImplemented
        return (self.node_type == other.node_type and
                self.content == other.content and
                self.children == other.children)

    def __repr__(self) -> str:
        if self.is_branch():
            return f"Branch({self._id})"
        if self.content is None:
            return f"{self.node_type.name}(??)"
        return f"{self.node_type.name}({self.content.hex().upper()})"
