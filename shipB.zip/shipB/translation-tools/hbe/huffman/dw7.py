"""
DW7 Huffman schema for the Heart Beat Engine.

KIMI MIPS analysis (Session B) confirmed DW7 uses the IDENTICAL tree format
as DQ4: 2-byte LE nodes, 0x8000 branch bit, 0x7FFF index mask, root at end-4,
dual-array split at (len+2)//2-2. The only difference is that DW7 uses a
GLOBAL tree (loaded once to RAM 0x800EF1C8) instead of per-block trees.

DW7Schema is therefore a thin subclass of DQ4Schema.
"""

import struct
from dataclasses import dataclass
from typing import List, Optional, Tuple

from .bitutils import bytes_to_bitstream, bitstream_to_bytes
from .node import HuffmanNode, NodeType
from .schema import HuffmanSchema
from .dq4 import DQ4Schema


@dataclass(frozen=True)
class DW7CandidateParams:
    """Parameters for one DW7 tree encoding candidate."""
    name: str
    node_size: int          # 2 or 4 bytes per node
    branch_bit: int         # e.g. 0x8000, 0x4000, 0x7FFF mask
    root_offset: int        # bytes from end of tree region to root node (-2, -4, -6, ...)
    array_split: str        # "half", "interleaved", "single"
    byte_order: str         # "le" or "be"
    use_mask: bool = False  # if True, branch_id = value & branch_bit (otherwise value - branch_bit)
    root_plus_one: bool = False  # if True, root_id = branch_id + 1 (DQ4 convention); else root_id = branch_id (DW7 convention)


class DW7SchemaCandidate:
    """One candidate DW7 tree decoder."""

    def __init__(self, params: DW7CandidateParams):
        self.params = params

    def name(self) -> str:
        return self.params.name

    def _read_value(self, data: bytes, offset: int) -> int:
        """Read a node_size value at the given offset using the candidate byte order."""
        if self.params.byte_order == "le":
            if self.params.node_size == 2:
                return struct.unpack_from("<H", data, offset)[0]
            return struct.unpack_from("<I", data, offset)[0]
        else:
            if self.params.node_size == 2:
                return struct.unpack_from(">H", data, offset)[0]
            return struct.unpack_from(">I", data, offset)[0]

    def _is_branch(self, value: int) -> bool:
        if self.params.use_mask:
            return (value & self.params.branch_bit) != 0
        return value >= self.params.branch_bit

    def _branch_id(self, value: int) -> int:
        if self.params.use_mask:
            return value & self.params.branch_bit
        return value - self.params.branch_bit

    def _array_offsets(self, tree_len: int) -> Tuple[int, int]:
        """Return (offset_a, offset_b) for the two child arrays."""
        split = self.params.array_split
        if split == "single":
            return 0, 0
        if split == "half":
            mid = (tree_len + 2) // 2 - 2
            return 0, mid
        if split == "interleaved":
            return 0, self.params.node_size
        raise ValueError(f"Unknown array_split: {split}")

    def try_parse_tree(self, tree_bytes: bytes) -> Optional[HuffmanNode]:
        """Try to parse tree_bytes with this candidate encoding. Return None on failure."""
        if len(tree_bytes) < abs(self.params.root_offset) + self.params.node_size:
            return None
        if len(tree_bytes) % self.params.node_size != 0:
            return None

        root_pos = len(tree_bytes) + self.params.root_offset
        try:
            root_value = self._read_value(tree_bytes, root_pos)
        except struct.error:
            return None

        if not self._is_branch(root_value):
            return None

        root_id = self._branch_id(root_value)
        if self.params.root_plus_one:
            root_id += 1
        root = HuffmanNode.branch(root_id)

        offset_a, offset_b = self._array_offsets(len(tree_bytes))
        seen = set()

        def parse(node: HuffmanNode, node_id: int) -> bool:
            if node_id in seen:
                return False
            seen.add(node_id)
            for bit, off in enumerate((offset_a, offset_b)):
                if self.params.array_split == "single":
                    index = node_id * self.params.node_size
                else:
                    index = off + node_id * self.params.node_size
                if index < 0 or index + self.params.node_size > len(tree_bytes):
                    return False
                value = self._read_value(tree_bytes, index)
                if self._is_branch(value):
                    child_id = self._branch_id(value)
                    child = HuffmanNode.branch(child_id)
                    node.children.append(child)
                    if not parse(child, child_id):
                        return False
                else:
                    node.children.append(HuffmanNode.leaf_from_value(value))
            return True

        try:
            if not parse(root, root_id):
                return None
        except Exception:
            return None

        # Validate all branches resolved and tree has leaves.
        leaves = root.leaf_nodes()
        if not leaves:
            return None
        return root

    def decode_text(self, text_bytes: bytes, tree: HuffmanNode) -> List[HuffmanNode]:
        """Decode a bitstream using the parsed tree."""
        bits = bytes_to_bitstream(text_bytes)
        leaves = []
        node = tree
        for bit in bits:
            if bit == "0":
                node = node.left
            else:
                node = node.right
            if node is None:
                raise ValueError("Invalid bitstream: reached null child")
            if node.is_leaf():
                leaves.append(node)
                node = tree
        return leaves

    def score(self, tree_bytes: bytes, text_bytes: bytes) -> dict:
        """
        Score this candidate against a tree and its text bitstream.
        Returns a dict with metrics; higher 'valid' is better.
        """
        tree = self.try_parse_tree(tree_bytes)
        if tree is None:
            return {"valid": 0, "error": "tree_parse_failed"}

        leaves = tree.leaf_nodes()
        controls = [l for l in leaves if l.is_control()]
        chars = [l for l in leaves if l.is_character()]

        result = {
            "valid": 1,
            "branches": len(tree.branch_nodes()),
            "leaves": len(leaves),
            "controls": len(controls),
            "chars": len(chars),
            "has_0000": any(l.content == b"\x00\x00" for l in controls),
            "has_7f0a": any(l.content == b"\x7f\x0a" for l in controls),
            "has_7f0b": any(l.content == b"\x7f\x0b" for l in controls),
            "decodable": False,
        }

        try:
            self.decode_text(text_bytes, tree)
            result["decodable"] = True
            result["valid"] += 1
        except Exception:
            pass

        # Bonus for control codes that match known DQ4/DW7 control codes.
        if result["has_0000"]:
            result["valid"] += 1
        if result["has_7f0a"] or result["has_7f0b"]:
            result["valid"] += 1

        return result


class DW7TreeMiner:
    """Run a battery of DW7 tree candidates against a set of blocks."""

    DEFAULT_CANDIDATES = [
        # DQ4-like variants (root_plus_one=True for DQ4 convention)
        DW7CandidateParams("dq4_like_le", 2, 0x8000, -4, "half", "le", False, True),
        DW7CandidateParams("dq4_like_be", 2, 0x8000, -4, "half", "be", False, True),
        DW7CandidateParams("dq4_like_root2", 2, 0x8000, -2, "half", "le", False, True),
        DW7CandidateParams("dq4_like_root6", 2, 0x8000, -6, "half", "le", False, True),
        # DW7 variants (root_plus_one=False for DW7 convention)
        DW7CandidateParams("dw7_le", 2, 0x8000, -4, "half", "le", False, False),
        DW7CandidateParams("dw7_be", 2, 0x8000, -4, "half", "be", False, False),
        # Branch-bit variations
        DW7CandidateParams("branch_4000", 2, 0x4000, -4, "half", "le", False, False),
        DW7CandidateParams("branch_7fff_mask", 2, 0x7FFF, -4, "half", "le", True, False),
        # Array layout variations
        DW7CandidateParams("single_flat", 2, 0x8000, -4, "single", "le", False, False),
        DW7CandidateParams("interleaved", 2, 0x8000, -4, "interleaved", "le", False, False),
        # 4-byte node candidates
        DW7CandidateParams("node4_le", 4, 0x8000, -4, "half", "le", False, False),
        DW7CandidateParams("node4_be", 4, 0x8000, -4, "half", "be", False, False),
        DW7CandidateParams("node4_root8", 4, 0x8000, -8, "half", "le", False, False),
    ]

    def __init__(self, candidates: Optional[List[DW7CandidateParams]] = None):
        self.candidates = [
            DW7SchemaCandidate(p)
            for p in (candidates or self.DEFAULT_CANDIDATES)
        ]

    def mine(self, blocks: List[Tuple[bytes, bytes]]) -> List[dict]:
        """
        Score every candidate against a list of (tree_bytes, text_bytes) pairs.
        Returns a sorted list of candidate reports, best first.
        """
        reports = []
        for candidate in self.candidates:
            scores = []
            for tree_bytes, text_bytes in blocks:
                try:
                    scores.append(candidate.score(tree_bytes, text_bytes))
                except Exception:
                    scores.append({"valid": 0, "error": "exception"})
            total_valid = sum(s["valid"] for s in scores)
            reports.append({
                "candidate": candidate.name(),
                "total_valid": total_valid,
                "scores": scores,
            })

        reports.sort(key=lambda r: r["total_valid"], reverse=True)
        return reports


class DW7Schema(DQ4Schema):
    """
    DW7 global Huffman schema.

    Tree format confirmed by MIPS disassembly (KIMI Session B):
    - 2-byte LE nodes, 0x8000 branch bit, 0x7FFF index mask
    - Root at end-4, dual-array split at (len+2)//2-2
    - Bitstream: bits reversed per byte, 0=left, 1=right, padded to 4 bytes

    Key difference from DQ4: DW7 uses root_id = (value & 0x7FFF) WITHOUT the +1
    offset that DQ4 uses. DW7 also uses a SINGLE global tree (loaded to RAM
    0x800EF1C8) for all text blocks, rather than per-block trees.
    """

    TREE_RAM_ADDRESS = 0x800EF1C8

    @property
    def name(self) -> str:
        return "DW7"

    def parse_tree(self, tree_bytes: bytes) -> HuffmanNode:
        """Parse DW7 tree. Same as DQ4 but root_id = value & 0x7FFF (no +1)."""
        if len(tree_bytes) < 4 or len(tree_bytes) % 2 != 0:
            raise ValueError(f"Invalid DW7 tree length: {len(tree_bytes)}")

        last_node_idx = len(tree_bytes) - 4
        last_node_value = self._read_short_be(
            self._swap(tree_bytes[last_node_idx:last_node_idx + 2])
        )
        if last_node_value < self.BRANCH_BIT:
            raise ValueError(
                f"Root node at end-4 is not a branch: 0x{last_node_value:04X}"
            )
        root_number = last_node_value & 0x7FFF

        offset_b = ((len(tree_bytes) + 2) // 2 - 2) & ~1

        root = HuffmanNode.branch(root_number)
        self._parse_children(root, root_number, tree_bytes, offset_b)
        return root

    def write_tree(self, root: HuffmanNode) -> bytes:
        """Write DW7 tree. Same as DQ4 but offset_b uses even alignment (& ~1)."""
        descendants = root.descendants()
        array_size = len(descendants) * 2 + 2
        data = bytearray(array_size)
        offset_b = ((len(data) + 2) // 2 - 2) & ~1
        self._write_children(root, data, offset_b)
        return bytes(data)

    def __repr__(self) -> str:
        return f"DW7Schema(tree_ram=0x{self.TREE_RAM_ADDRESS:08X})"
