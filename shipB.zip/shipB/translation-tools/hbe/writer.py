"""
HBD archive writer for the Heart Beat Engine.

Rebuilds the raw HBD byte stream from an in-memory archive model. This is a
core component for the Fuser and the build pipeline.
"""

import struct
from typing import List

from hbe.archive import HBDArchive, HBDFolder, HBDEntry, HBD600Entry, HBDLogicalEntry, HBDZeroEntry


SECTOR_SIZE = 2048


class HBDWriter:
    """Serialize an HBDArchive back to bytes."""

    def write(self, archive: HBDArchive) -> bytes:
        """Serialize the archive into a byte stream of 2048-byte sectors."""
        out = bytearray()
        for entry in archive.entries:
            out.extend(self._write_entry(entry))

        # Ensure total size is a multiple of the sector size.
        remainder = len(out) % SECTOR_SIZE
        if remainder:
            out.extend(b"\x00" * (SECTOR_SIZE - remainder))
        return bytes(out)

    def _write_entry(self, entry: HBDEntry) -> bytes:
        if isinstance(entry, HBDFolder):
            return self._write_folder(entry)
        if isinstance(entry, HBD600Entry):
            return self._pad(entry.data)
        if isinstance(entry, HBDLogicalEntry):
            return self._pad(entry.data)
        if isinstance(entry, HBDZeroEntry):
            return b"\x00" * SECTOR_SIZE
        raise TypeError(f"Unknown entry type: {type(entry)}")

    def _write_folder(self, folder: HBDFolder) -> bytes:
        """Serialize a folder: header, file headers, file contents, padding."""
        data = bytearray()
        unknown_val = folder.unknown
        if isinstance(unknown_val, bytes):
            unknown_val = struct.unpack("<I", unknown_val)[0]
        data.extend(struct.pack("<4I", folder.number_of_files, folder.sector_count, folder.size, unknown_val))
        for f in folder.files:
            data.extend(struct.pack("<2I", f.size, f.size_uncompressed))
            data.extend(f.unknown)
            data.extend(struct.pack("<2H", f.flags, f.type_id))
        for f in folder.files:
            data.extend(f.content)
        return self._pad(bytes(data))

    @staticmethod
    def _pad(data: bytes) -> bytes:
        """Pad data to a multiple of SECTOR_SIZE."""
        if len(data) % SECTOR_SIZE == 0:
            return data
        return data + b"\x00" * (SECTOR_SIZE - (len(data) % SECTOR_SIZE))
