"""
DW7/DQ7 Huffman tree cracker — brute-force tree encoding discovery.

Processes blocks in batches of 50 with progress reporting. Tries every
plausible tree encoding variant against candidate text blocks from all
three HBE ROMs (DQ4, DW7 US, DQ7 JP).

Strategy:
  1. Extract candidate text blocks from each ROM's HBD
  2. For each block, try every tree encoding variant
  3. Score by valid tree topology, control codes, decodable text
  4. Report the winning encoding

All processing is batched to avoid memory exhaustion on large HBDs.
"""

import struct
import sys
import time
from dataclasses import dataclass, field
from typing import Callable, Dict, List, Optional, Tuple

from .huffman.bitutils import bytes_to_bitstream, bitstream_to_bytes
from .huffman.node import HuffmanNode, NodeType
from .huffman.schema import HuffmanSchema


# ---------------------------------------------------------------------------
# Progress reporter
# ---------------------------------------------------------------------------

class ProgressReporter:
    """Simple progress bar for batch processing."""

    def __init__(self, total: int, label: str = "Processing", bar_width: int = 40):
        self.total = total
        self.label = label
        self.bar_width = bar_width
        self.current = 0
        self.start_time = time.time()

    def update(self, current: int):
        self.current = current
        pct = current / self.total if self.total > 0 else 0
        filled = int(self.bar_width * pct)
        bar = "=" * filled + "-" * (self.bar_width - filled)
        elapsed = time.time() - self.start_time
        rate = current / elapsed if elapsed > 0 else 0
        eta = (self.total - current) / rate if rate > 0 else 0
        sys.stdout.write(
            f"\r{self.label}: [{bar}] {current}/{self.total} "
            f"({pct:.0%}) {rate:.1f}/s ETA {eta:.0f}s"
        )
        sys.stdout.flush()

    def done(self):
        self.update(self.total)
        elapsed = time.time() - self.start_time
        sys.stdout.write(f" done ({elapsed:.1f}s)\n")
        sys.stdout.flush()

    def batch_done(self, batch_num: int, total_batches: int, hits: int):
        elapsed = time.time() - self.start_time
        sys.stdout.write(
            f"  batch {batch_num}/{total_batches} — "
            f"{hits} hits so far ({elapsed:.1f}s elapsed)\n"
        )
        sys.stdout.flush()


# ---------------------------------------------------------------------------
# Tree encoding candidates
# ---------------------------------------------------------------------------

@dataclass(frozen=True)
class TreeEncoding:
    """One candidate tree encoding to test."""
    name: str
    node_size: int           # 1, 2, or 4 bytes per node
    branch_bit: int          # 0x8000, 0x4000, 0x80, 0x01, etc.
    root_loc: str            # "end-4", "end-2", "end-6", "start", "header"
    array_layout: str        # "dual", "single", "interleaved"
    byte_order: str          # "le" or "be"
    use_mask: bool           # True: (val & bit) != 0; False: val >= bit
    header_size: int         # 24 or 32 bytes
    tree_location: str       # "after_text", "before_text", "in_gap", "in_exe", "global"

    def __repr__(self) -> str:
        return (
            f"TreeEncoding({self.name}: "
            f"node={self.node_size}B bit=0x{self.branch_bit:04X} "
            f"root={self.root_loc} layout={self.array_layout} "
            f"order={self.byte_order} hdr={self.header_size} "
            f"loc={self.tree_location})"
        )


def generate_encodings() -> List[TreeEncoding]:
    """Generate all plausible tree encoding variants to test."""
    encodings = []

    node_sizes = [1, 2, 4]
    branch_bits = [0x8000, 0x4000, 0x0100, 0x0080, 0x0001, 0x7FFF]
    root_locs = ["end-4", "end-2", "end-6", "end-8", "start", "header"]
    layouts = ["dual", "single", "interleaved"]
    byte_orders = ["le", "be"]
    header_sizes = [24, 32]
    tree_locs = ["after_text", "before_text", "in_gap", "in_exe"]

    for ns in node_sizes:
        for bb in branch_bits:
            # Skip nonsensical combos: 1-byte node with 0x8000 bit
            if ns == 1 and bb > 0xFF:
                continue
            for rl in root_locs:
                for lay in layouts:
                    for bo in byte_orders:
                        for hs in header_sizes:
                            for tl in tree_locs:
                                name = (
                                    f"n{ns}b{bb:04X}{rl}"
                                    f"_{lay}_{bo}_h{hs}_{tl}"
                                )
                                encodings.append(TreeEncoding(
                                    name=name,
                                    node_size=ns,
                                    branch_bit=bb,
                                    root_loc=rl,
                                    array_layout=lay,
                                    byte_order=bo,
                                    use_mask=(bb == 0x7FFF),
                                    header_size=hs,
                                    tree_location=tl,
                                ))
    return encodings


# ---------------------------------------------------------------------------
# Block extraction
# ---------------------------------------------------------------------------

@dataclass
class CandidateBlock:
    """A candidate text block extracted from an HBD."""
    source: str              # "DQ4", "DW7_US", "DQ7_JP"
    folder_index: int
    file_index: int
    type_id: int
    offset: int              # byte offset in HBD
    size: int
    raw: bytes
    header: Tuple[int, ...]  # parsed header fields
    hts: int                 # huffman text start
    gap: bytes               # gap region between header and text
    text_region: bytes       # text bitstream region
    post_text: bytes         # everything after text (may contain tree)


def extract_blocks_from_hbd(
    hbd_data: bytes,
    source: str,
    type_filter: Optional[int] = None,
    max_blocks: int = 500,
) -> List[CandidateBlock]:
    """
    Extract candidate text blocks from raw HBD data.
    Scans for 24-byte and 32-byte headers with plausible field values.
    """
    SECTOR = 2048
    blocks = []
    offset = 0

    while offset + 24 <= len(hbd_data) and len(blocks) < max_blocks:
        # Try 24-byte header
        hdr24 = struct.unpack_from("<6I", hbd_data, offset)
        end, block_id, hts, tree_end, text_end, unk = hdr24

        # Try 32-byte header
        hdr32 = None
        if offset + 32 <= len(hbd_data):
            hdr32 = struct.unpack_from("<8I", hbd_data, offset)

        # Check if this looks like a valid text block header
        valid = False
        header_size = 24
        header = hdr24

        # 24-byte header sanity: end > hts > header_size, reasonable sizes
        if (24 < hts < 65536 and end > hts and end < 1048576
                and block_id != 0):
            valid = True
            header_size = 24

        # 32-byte header check
        if hdr32 and not valid:
            end32 = hdr32[0]
            hts32 = hdr32[2]
            if (32 < hts32 < 65536 and end32 > hts32 and end32 < 1048576
                    and hdr32[1] != 0):
                valid = True
                header_size = 32
                header = hdr32
                end = end32
                hts = hts32

        if not valid:
            offset += SECTOR
            continue

        # Extract regions
        gap = hbd_data[header_size:min(hts, len(hbd_data))]
        text_region = hbd_data[hts:min(end, len(hbd_data))] if end > hts else b""
        post_text = hbd_data[end:min(end + 4096, len(hbd_data))] if end < len(hbd_data) else b""

        # Determine type if not filtering
        type_id = 0  # unknown without folder context

        blocks.append(CandidateBlock(
            source=source,
            folder_index=-1,
            file_index=-1,
            type_id=type_id,
            offset=offset,
            size=end,
            raw=hbd_data[offset:min(offset + end, len(hbd_data))],
            header=header,
            hts=hts,
            gap=gap,
            text_region=text_region,
            post_text=post_text,
        ))

        offset += max(end, SECTOR)

    return blocks


def extract_blocks_from_archive(
    archive,
    source: str,
    type_filter: Optional[int] = None,
    max_blocks: int = 500,
) -> List[CandidateBlock]:
    """Extract candidate blocks from a parsed HBDArchive."""
    blocks = []
    for folder in archive.folders:
        for f in folder.files:
            if type_filter and f.type_id != type_filter:
                continue
            if len(f.content) < 24:
                continue
            try:
                hdr = struct.unpack_from("<6I", f.content, 0)
                end, block_id, hts, tree_end, text_end, unk = hdr
            except struct.error:
                continue

            if not (24 < hts < 65536 and end > hts and end < 1048576):
                continue

            gap = f.content[24:min(hts, len(f.content))]
            text_region = f.content[hts:min(end, len(f.content))] if end > hts else b""
            post_text = f.content[end:min(end + 4096, len(f.content))] if end < len(f.content) else b""

            blocks.append(CandidateBlock(
                source=source,
                folder_index=folder.index,
                file_index=f.index,
                type_id=f.type_id,
                offset=-1,
                size=end,
                raw=f.content,
                header=hdr,
                hts=hts,
                gap=gap,
                text_region=text_region,
                post_text=post_text,
            ))

            if len(blocks) >= max_blocks:
                return blocks
    return blocks


# ---------------------------------------------------------------------------
# Tree parser — tries one encoding against one block
# ---------------------------------------------------------------------------

def _read_val(data: bytes, offset: int, size: int, byte_order: str) -> Optional[int]:
    """Read a value of given size and byte order. Returns None on error."""
    try:
        if size == 1:
            return data[offset]
        elif size == 2:
            fmt = "<H" if byte_order == "le" else ">H"
            return struct.unpack_from(fmt, data, offset)[0]
        elif size == 4:
            fmt = "<I" if byte_order == "le" else ">I"
            return struct.unpack_from(fmt, data, offset)[0]
    except (struct.error, IndexError):
        return None
    return None


def _is_branch(value: int, encoding: TreeEncoding) -> bool:
    if encoding.use_mask:
        return (value & encoding.branch_bit) != 0
    return value >= encoding.branch_bit


def _branch_id(value: int, encoding: TreeEncoding) -> int:
    if encoding.use_mask:
        return value & encoding.branch_bit
    return value - encoding.branch_bit


def _root_offset(tree_len: int, encoding: TreeEncoding) -> int:
    """Calculate root node offset within tree bytes."""
    rl = encoding.root_loc
    ns = encoding.node_size
    if rl == "end-4":
        return tree_len - 4 if tree_len >= 4 else -1
    elif rl == "end-2":
        return tree_len - 2 if tree_len >= 2 else -1
    elif rl == "end-6":
        return tree_len - 6 if tree_len >= 6 else -1
    elif rl == "end-8":
        return tree_len - 8 if tree_len >= 8 else -1
    elif rl == "start":
        return 0
    elif rl == "header":
        return 0  # tree starts with root
    return -1


def _array_offsets(tree_len: int, encoding: TreeEncoding) -> Tuple[int, int]:
    """Return (offset_a, offset_b) for the two child arrays."""
    lay = encoding.array_layout
    if lay == "single":
        return 0, 0
    elif lay == "dual":
        mid = tree_len // 2
        # Round to node_size boundary
        mid = (mid // encoding.node_size) * encoding.node_size
        return 0, mid
    elif lay == "interleaved":
        return 0, encoding.node_size
    return 0, 0


def try_parse_tree(
    tree_bytes: bytes,
    text_bytes: bytes,
    encoding: TreeEncoding,
) -> Optional[dict]:
    """
    Try to parse tree_bytes with the given encoding.
    Returns a result dict with tree, leaves, and score, or None on failure.
    """
    ns = encoding.node_size
    if len(tree_bytes) < ns:
        return None
    if len(tree_bytes) % ns != 0:
        return None

    root_off = _root_offset(len(tree_bytes), encoding)
    if root_off < 0 or root_off + ns > len(tree_bytes):
        return None

    root_val = _read_val(tree_bytes, root_off, ns, encoding.byte_order)
    if root_val is None or not _is_branch(root_val, encoding):
        return None

    root_id = _branch_id(root_val, encoding)
    off_a, off_b = _array_offsets(len(tree_bytes), encoding)

    # Walk the tree
    seen = set()
    leaf_values = []

    def parse(node_id: int, depth: int) -> bool:
        if node_id in seen:
            return False
        if depth > 32:
            return False
        seen.add(node_id)

        for bit in (0, 1):
            base = off_a if bit == 0 else off_b
            idx = base + node_id * ns
            if idx < 0 or idx + ns > len(tree_bytes):
                return False

            val = _read_val(tree_bytes, idx, ns, encoding.byte_order)
            if val is None:
                return False

            if _is_branch(val, encoding):
                child_id = _branch_id(val, encoding)
                if not parse(child_id, depth + 1):
                    return False
            else:
                leaf_values.append(val)
        return True

    try:
        if not parse(root_id, 0):
            return None
    except (RecursionError, Exception):
        return None

    if not leaf_values:
        return None

    # Score the result
    controls = [v for v in leaf_values if v == 0 or (v & 0x7F00) == 0x7F00]
    chars = [v for v in leaf_values if v not in controls]

    has_0000 = any(v == 0 for v in controls)
    has_7f0a = any(v == 0x7F0A for v in controls)
    has_7f0b = any(v == 0x7F0B for v in controls)
    has_7f02 = any(v == 0x7F02 for v in controls)

    score = 0
    score += 1  # valid tree topology
    if controls:
        score += 1
    if has_0000:
        score += 2  # {0000} is the most common control code
    if has_7f0a or has_7f0b:
        score += 2
    if has_7f02:
        score += 1
    if 50 <= len(leaf_values) <= 300:
        score += 1  # plausible character set size
    if len(controls) >= 2:
        score += 1

    # Try to decode text
    decodable = False
    decoded_sample = []
    if text_bytes and score >= 3:
        try:
            bits = bytes_to_bitstream(text_bytes)
            node_idx = root_id
            consumed = 0
            for b in bits[:2000]:  # limit to prevent hangs
                base = off_a if b == "0" else off_b
                idx = base + node_idx * ns
                if idx < 0 or idx + ns > len(tree_bytes):
                    break
                val = _read_val(tree_bytes, idx, ns, encoding.byte_order)
                if val is None:
                    break
                if _is_branch(val, encoding):
                    node_idx = _branch_id(val, encoding)
                else:
                    decoded_sample.append(val)
                    node_idx = root_id
                    consumed += 1
                    if consumed >= 50:
                        break
            if consumed >= 5:
                decodable = True
                score += 3
        except Exception:
            pass

    return {
        "encoding": encoding,
        "score": score,
        "leaves": len(leaf_values),
        "controls": len(controls),
        "chars": len(chars),
        "has_0000": has_0000,
        "has_7f0a": has_7f0a,
        "has_7f0b": has_7f0b,
        "has_7f02": has_7f02,
        "decodable": decodable,
        "decoded_sample": decoded_sample[:20],
        "tree_bytes_len": len(tree_bytes),
        "text_bytes_len": len(text_bytes) if text_bytes else 0,
    }


# ---------------------------------------------------------------------------
# Cracker — batch processing with progress
# ---------------------------------------------------------------------------

class TreeCracker:
    """
    Crack the DW7/DQ7 Huffman tree encoding by brute-forcing
    all plausible encodings against candidate text blocks.

    Processes in batches of 50 blocks to avoid memory issues.
    """

    BATCH_SIZE = 50

    def __init__(
        self,
        blocks: List[CandidateBlock],
        encodings: Optional[List[TreeEncoding]] = None,
    ):
        self.blocks = blocks
        self.encodings = encodings or generate_encodings()
        self.results: List[dict] = []
        self.best_result: Optional[dict] = None

    def crack(self, progress_label: str = "Cracking") -> List[dict]:
        """
        Run the full crack. Returns all results with score >= 3,
        sorted by score descending.
        """
        total = len(self.blocks)
        progress = ProgressReporter(total, progress_label)
        total_batches = (total + self.BATCH_SIZE - 1) // self.BATCH_SIZE

        for batch_num in range(total_batches):
            start = batch_num * self.BATCH_SIZE
            end = min(start + self.BATCH_SIZE, total)
            batch = self.blocks[start:end]

            batch_hits = 0
            for block in batch:
                # Determine which regions to test as "tree"
                tree_candidates = self._extract_tree_candidates(block)

                for tree_label, tree_bytes, text_bytes in tree_candidates:
                    if not tree_bytes or len(tree_bytes) < 4:
                        continue

                    for enc in self.encodings:
                        result = try_parse_tree(tree_bytes, text_bytes, enc)
                        if result and result["score"] >= 3:
                            result["block_source"] = block.source
                            result["block_offset"] = block.offset
                            result["block_header"] = block.header
                            result["tree_label"] = tree_label
                            self.results.append(result)
                            batch_hits += 1

                            if self.best_result is None or result["score"] > self.best_result["score"]:
                                # Store tree_bytes only for the new best
                                result["tree_bytes"] = tree_bytes
                                result["text_bytes"] = text_bytes
                                # Clean previous best's bytes
                                if self.best_result and "tree_bytes" in self.best_result:
                                    del self.best_result["tree_bytes"]
                                    self.best_result.pop("text_bytes", None)
                                self.best_result = result

                progress.update(start + (batch - batch[0:1]).index(block) + 1 if False else end)

            progress.batch_done(batch_num + 1, total_batches, len(self.results))

        progress.done()

        self.results.sort(key=lambda r: r["score"], reverse=True)
        return self.results

    def _extract_tree_candidates(self, block: CandidateBlock) -> List[Tuple[str, bytes, bytes]]:
        """
        Extract candidate tree regions from a block.
        Returns list of (label, tree_bytes, text_bytes).
        """
        candidates = []
        raw = block.raw
        hts = block.hts
        end = block.header[0] if block.header else len(raw)

        # 1. Tree after text (DQ4 style)
        if end > hts and end < len(raw):
            text = raw[hts:end]
            # Tree is between text_end and end
            # Try various tree locations after text
            tree_after = raw[end:min(end + 2048, len(raw))]
            if len(tree_after) >= 4:
                candidates.append(("after_text", tree_after, text))

        # 2. Tree in the gap (between header and text)
        gap = block.gap
        if len(gap) >= 4:
            candidates.append(("in_gap", gap, block.text_region))

        # 3. Tree before text (from header to hts)
        if hts > 24 and hts < len(raw):
            pre = raw[24:hts]
            if len(pre) >= 4:
                candidates.append(("before_text", pre, block.text_region))

        # 4. Post-text region (everything after end)
        post = block.post_text
        if len(post) >= 4:
            candidates.append(("post_text", post, block.text_region))

        # 5. Entire block as tree (global tree hypothesis)
        if len(raw) >= 4 and len(raw) <= 8192:
            candidates.append(("full_block", raw, b""))

        # 6. Gap split into sub-regions (first half, second half)
        if len(gap) >= 8:
            mid = len(gap) // 2
            candidates.append(("gap_first_half", gap[:mid], block.text_region))
            candidates.append(("gap_second_half", gap[mid:], block.text_region))

        return candidates

    def report(self) -> str:
        """Generate a text report of the crack results."""
        lines = []
        lines.append("=" * 70)
        lines.append("DW7/DQ7 HUFFMAN TREE CRACK REPORT")
        lines.append("=" * 70)
        lines.append(f"Blocks tested: {len(self.blocks)}")
        lines.append(f"Encodings tested: {len(self.encodings)}")
        lines.append(f"Total candidates with score >= 3: {len(self.results)}")
        lines.append("")

        if self.best_result:
            r = self.best_result
            enc = r["encoding"]
            lines.append("BEST CANDIDATE:")
            lines.append(f"  Encoding: {enc.name}")
            lines.append(f"  Node size: {enc.node_size} bytes")
            lines.append(f"  Branch bit: 0x{enc.branch_bit:04X}")
            lines.append(f"  Root location: {enc.root_loc}")
            lines.append(f"  Array layout: {enc.array_layout}")
            lines.append(f"  Byte order: {enc.byte_order}")
            lines.append(f"  Header size: {enc.header_size}")
            lines.append(f"  Tree location: {enc.tree_location}")
            lines.append(f"  Score: {r['score']}")
            lines.append(f"  Leaves: {r['leaves']} (controls: {r['controls']}, chars: {r['chars']})")
            lines.append(f"  Has {{0000}}: {r['has_0000']}")
            lines.append(f"  Has {{7f0a}}: {r['has_7f0a']}")
            lines.append(f"  Has {{7f0b}}: {r['has_7f0b']}")
            lines.append(f"  Decodable: {r['decodable']}")
            lines.append(f"  Block source: {r['block_source']}")
            lines.append(f"  Tree label: {r['tree_label']}")
            if r["decoded_sample"]:
                sample_hex = " ".join(f"{v:04X}" for v in r["decoded_sample"][:10])
                lines.append(f"  Decoded sample: {sample_hex}")
            lines.append("")

        lines.append("TOP 10 CANDIDATES:")
        for i, r in enumerate(self.results[:10]):
            lines.append(
                f"  {i+1}. score={r['score']} "
                f"{r['encoding'].name} "
                f"src={r['block_source']} "
                f"tree={r['tree_label']} "
                f"leaves={r['leaves']} "
                f"ctrl={r['controls']} "
                f"dec={r['decodable']}"
            )

        lines.append("")
        lines.append("=" * 70)
        return "\n".join(lines)
