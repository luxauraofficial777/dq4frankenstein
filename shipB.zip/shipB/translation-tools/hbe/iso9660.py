"""
Minimal ISO 9660 parser for locating files in a PSX disc image.

Supports Primary Volume Descriptor and root directory traversal to find
HBD, EXE, and SYSTEM.CNF files.
"""

import struct
from dataclasses import dataclass
from typing import Dict, List, Optional


SECTOR_SIZE = 2048


@dataclass
class ISODirent:
    """One ISO 9660 directory record."""

    name: str
    start_sector: int
    size: int
    is_directory: bool


class ISO9660:
    """Minimal ISO 9660 filesystem reader."""

    def __init__(self, data: bytes):
        self.data = data
        self.files: Dict[str, ISODirent] = {}
        self._parse()

    @classmethod
    def from_file(cls, path: str) -> "ISO9660":
        with open(path, "rb") as f:
            return cls(f.read())

    def _read_sector(self, index: int) -> bytes:
        return self.data[index * SECTOR_SIZE:(index + 1) * SECTOR_SIZE]

    def _parse(self):
        # Search for Primary Volume Descriptor starting at sector 16.
        for i in range(16, 32):
            sector = self._read_sector(i)
            if sector[0] == 0x01 and sector[1:6] == b"CD001":
                self._parse_pvd(sector)
                return
        raise ValueError("Primary Volume Descriptor not found")

    def _parse_pvd(self, sector: bytes):
        root_offset = 156
        root_record = sector[root_offset:root_offset + 34]
        root_start = struct.unpack("<I", root_record[2:6])[0]
        root_size = struct.unpack("<I", root_record[10:14])[0]
        self._parse_directory(root_start, root_size, "")

    def _parse_directory(self, start_sector: int, size: int, prefix: str):
        sectors = (size + SECTOR_SIZE - 1) // SECTOR_SIZE
        data = b"".join(self._read_sector(start_sector + i) for i in range(sectors))[:size]
        offset = 0
        while offset < len(data):
            length = data[offset]
            if length == 0:
                offset += 1
                continue
            record = data[offset:offset + length]
            dirent = self._parse_dirent(record, prefix)
            if dirent is None:
                offset += length
                continue
            path = f"{prefix}/{dirent.name}" if prefix else dirent.name
            if dirent.is_directory:
                if dirent.name not in ("", ".", ".."):
                    self._parse_directory(dirent.start_sector, dirent.size, path)
            else:
                self.files[path] = ISODirent(
                    name=dirent.name,
                    start_sector=dirent.start_sector,
                    size=dirent.size,
                    is_directory=False,
                )
            offset += length

    @staticmethod
    def _parse_dirent(record: bytes, prefix: str) -> Optional[ISODirent]:
        if len(record) < 34:
            return None
        name_len = record[32]
        name = record[33:33 + name_len].decode("ascii", errors="replace").split(";")[0]
        if name == "\x00":
            name = ""
        if name == "\x01":
            name = ".."
        start_sector = struct.unpack("<I", record[2:6])[0]
        size = struct.unpack("<I", record[10:14])[0]
        flags = record[25]
        is_directory = bool(flags & 0x02)
        return ISODirent(name=name, start_sector=start_sector, size=size, is_directory=is_directory)

    def find(self, name: str) -> Optional[ISODirent]:
        return self.files.get(name)
