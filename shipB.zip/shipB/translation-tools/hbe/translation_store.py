"""
Translation store for the Heart Beat Engine.

Single canonical store for translated text entries, replacing the dual
full_translation.json / full_translation_original.json files.
"""

from dataclasses import dataclass, field
from typing import Dict, Optional


@dataclass
class TranslationEntry:
    """One translated segment."""

    text: str
    status: str = "translated"  # translated, compressed, truncated, placeholder, control-only
    original: str = ""


class TranslationStore:
    """Canonical store for all translated text."""

    def __init__(self):
        # (text_id, offset_hex) -> TranslationEntry
        self._entries: Dict[tuple, TranslationEntry] = {}

    def get(self, text_id: str, offset_hex: str) -> Optional[TranslationEntry]:
        return self._entries.get((text_id, offset_hex))

    def set(self, text_id: str, offset_hex: str, text: str, status: str = "translated"):
        self._entries[(text_id, offset_hex)] = TranslationEntry(text=text, status=status)

    def export(self, path: str):
        """Export the store to JSON."""
        import json
        data = {
            f"{tid}:{off}": {
                "text": e.text,
                "status": e.status,
                "original": e.original,
            }
            for (tid, off), e in self._entries.items()
        }
        with open(path, "w", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2)

    def import_json(self, path: str):
        """Import the store from JSON."""
        import json
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
        for key, value in data.items():
            tid, off = key.split(":", 1)
            self._entries[(tid, off)] = TranslationEntry(
                text=value.get("text", ""),
                status=value.get("status", "translated"),
                original=value.get("original", ""),
            )
