#!/usr/bin/env python3
"""QA checks on full_translation.json"""
import json

FT_PATH = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation.json"

with open(FT_PATH, encoding="utf-8") as f:
    ft = json.load(f)

total = 0
no_terminator = 0
has_apostrophe = 0
has_jp = 0
has_placeholder = 0
has_ellipsis = 0

for block_id, block in ft.items():
    for line_num, entry in block.items():
        trans = entry.get("translation", "")
        total += 1
        
        # Check terminator
        if not trans.endswith("{0000}"):
            no_terminator += 1
        
        # Check apostrophes
        if "'" in trans or "\u2019" in trans or "\u2018" in trans:
            has_apostrophe += 1
        
        # Check for Japanese characters
        if any(ord(c) >= 0x3000 for c in trans):
            has_jp += 1
        
        # Check for PLACEHOLDER
        if "PLACEHOLDER" in trans:
            has_placeholder += 1
        
        # Check for ellipsis placeholder
        if trans.strip() == "...{0000}":
            has_ellipsis += 1

print(f"Total entries: {total}")
print(f"Missing terminator: {no_terminator}")
print(f"Has apostrophe: {has_apostrophe}")
print(f"Has Japanese: {has_jp}")
print(f"Has PLACEHOLDER: {has_placeholder}")
print(f"Has ellipsis (...{{0000}}): {has_ellipsis}")
print(f"Blocks: {len(ft)}")
