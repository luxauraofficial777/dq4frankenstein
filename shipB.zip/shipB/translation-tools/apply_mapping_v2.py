#!/usr/bin/env python3
"""
Apply a Japanese-to-English translation mapping to build the full translation JSON.

Fixes over the original apply_mapping.py:
  - Matches full cleaned lines (with control codes removed) against the mapping
    instead of requiring every segment between control codes to be present.
  - Preserves all original control codes by placing the English translation at
    the first text segment and appending the remaining codes.
  - Every CSV line is included in the output; untranslated lines get a clear
    placeholder that QA can detect.

Output: translation/full_translation.json
"""
import glob
import csv
import re
import json
import os

CSV_DIR = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\csv"
EXISTING_JSON = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\session-translations.json"
MAPPING_JSON = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\translation_mapping.json"
OUTPUT_JSON = r"c:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation.json"

CTRL = re.compile(r'\{[0-9a-fA-F]{4}\}')


def has_jp(text):
    return any(ord(c) >= 0x3000 for c in text)


def translate_line(orig, mapping, norm_mapping=None):
    """
    Translate one CSV line using the full-line mapping.
    Returns the translated string with control codes preserved, or None if the
    line has no mapping entry.
    """
    codes = CTRL.findall(orig)
    tokens = CTRL.split(orig)

    clean = ''.join(tokens).strip()
    if not clean:
        return orig  # line is only control codes

    clean_norm = clean.replace("\u3000", " ").strip()

    if clean in mapping:
        english = mapping[clean]
    elif clean_norm in mapping:
        english = mapping[clean_norm]
    elif norm_mapping and clean_norm in norm_mapping:
        english = norm_mapping[clean_norm]
    else:
        return None

    # Reconstruct: keep every original control code, put the English text at the
    # first non-empty segment. This guarantees the page breaks, terminators, and
    # speaker prefixes from the original line stay intact.
    parts = []
    placed = False
    for i, token in enumerate(tokens):
        if i > 0:
            parts.append(codes[i - 1])
        if token.strip() and not placed:
            parts.append(english)
            placed = True

    return ''.join(parts)


def main():
    existing = {}
    if os.path.exists(EXISTING_JSON):
        with open(EXISTING_JSON, encoding="utf-8") as f:
            existing = json.load(f)

    mapping = {}
    if os.path.exists(MAPPING_JSON):
        with open(MAPPING_JSON, encoding="utf-8") as f:
            mapping = json.load(f)

    # Build normalized lookup: replace all U+3000 fullwidth spaces with ASCII spaces
    # in keys so mixed-space keys from batch scripts still match.
    norm_mapping = {}
    for k, v in mapping.items():
        norm_key = k.replace("\u3000", " ").strip()
        if norm_key not in norm_mapping:
            norm_mapping[norm_key] = v

    print(f"Translation mapping entries: {len(mapping)}")

    full_translation = {}
    stats = {
        "existing": 0,
        "mapped": 0,
        "ascii": 0,
        "placeholder": 0,
    }

    files = sorted(glob.glob(os.path.join(CSV_DIR, "*.csv")))

    for f in files:
        file_id = os.path.basename(f).replace(".csv", "").lower()
        existing_block = existing.get(file_id, {})

        with open(f, encoding="utf-8") as fh:
            reader = csv.reader(fh)
            next(reader, None)

            block = {}
            for row in reader:
                if not row or len(row) < 2:
                    continue
                line_num = row[0].strip()
                orig = row[1].strip()

                # CSVs may contain duplicate line numbers for the same sequence.
                # The translation JSON only needs one entry per unique line number.
                if line_num in block:
                    continue

                if line_num in existing_block:
                    block[line_num] = existing_block[line_num]
                    stats["existing"] += 1
                    continue

                if not has_jp(orig):
                    block[line_num] = {"translation": orig}
                    stats["ascii"] += 1
                    continue

                trans = translate_line(orig, mapping, norm_mapping)
                if trans is not None:
                    # Remove apostrophes (the game font does not support them).
                    trans = trans.replace("'", "").replace("'", "").replace("'", "")
                    # Replace full-width spaces with ASCII spaces (ShiftJIS encoder issues).
                    trans = trans.replace("\u3000", " ")
                    # Make sure every translated line ends with a terminator.
                    if not trans.endswith('{0000}'):
                        trans += '{0000}'
                    block[line_num] = {"translation": trans}
                    stats["mapped"] += 1
                else:
                    placeholder = f"[PLACEHOLDER: {file_id} {line_num}]{{0000}}"
                    block[line_num] = {"translation": placeholder}
                    stats["placeholder"] += 1

            if block:
                full_translation[file_id] = block

    with open(OUTPUT_JSON, "w", encoding="utf-8") as out:
        json.dump(full_translation, out, ensure_ascii=False, indent=2)

    total = sum(stats.values())
    written = sum(len(v) for v in full_translation.values())
    print(f"Total lines processed: {total}")
    print(f"  Existing (session): {stats['existing']}")
    print(f"  Mapped via translation_mapping.json: {stats['mapped']}")
    print(f"  Already ASCII: {stats['ascii']}")
    print(f"  Placeholders (untranslated): {stats['placeholder']}")
    print(f"  Blocks with content: {len(full_translation)}")
    print(f"Entries written to JSON: {written}")
    print(f"Written to: {OUTPUT_JSON}")


if __name__ == "__main__":
    main()
