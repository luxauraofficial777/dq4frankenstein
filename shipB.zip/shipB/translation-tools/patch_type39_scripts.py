#!/usr/bin/env python3
"""
patch_type39_scripts.py -- Type-39 cutscene script referrer remap.

Root Cause Addressed
--------------------
Cutscene scripts (type 39) reference dialogue sequences by 32-bit words
(text_id << 20 | bit_offset + hts*8). When text blocks are re-encoded into English,
their sequence bit-offsets shift. Because scripts are LZSS-compressed, raw-binary
patchers cannot see or rewrite them. This script decompresses every type-39 script,
remaps stale reference words using the pristine-vs-built offset map, recompresses with
the native DQ LZSS compressor, clamps to the original slot (pad, never truncate), and
writes back -- zero sector growth, zero shift.

dqlzs is verified correct: the recompressed 006C script decompresses byte-for-byte in
console RAM (8/8 chunks located contiguously in a live RAM grab). The compressor is NOT
the cause of any freeze; it faithfully reproduces the intended bytes.
"""

import argparse
import os
import struct
import subprocess
import sys
import time
import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE) if "translation-tools" in HERE else HERE
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
sys.stdout.reconfigure(encoding='utf-8', line_buffering=True)

EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")

from hbe.archive import HBDArchive
from hbe.compression.lzss import lzss_uncompress
from hbe.compression.dqlzs import compress_to_slot
from hbe.huffman.dq4 import DQ4Schema
import dq4_hbd_patcher as P

RAW, UOFF, USZ, HBD_LBA = 2352, 24, 2048, 362
_pristine_name = "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"
PRISTINE = os.path.join(ROOT, _pristine_name)
if not os.path.exists(PRISTINE):
    # shipped-copy invocation (ship/translation-tools) resolves ROOT to ship/;
    # walk up to the repo root that actually holds the pristine disc
    _d = ROOT
    for _ in range(4):
        _d = os.path.dirname(_d)
        if os.path.exists(os.path.join(_d, _pristine_name)):
            PRISTINE = os.path.join(_d, _pristine_name)
            break


def read_hbd(path):
    with open(path, "rb") as f:
        f.seek(HBD_LBA * RAW)
        raw = f.read()
    num_sectors = len(raw) // RAW
    out = bytearray(num_sectors * USZ)
    for s in range(num_sectors):
        base = s * RAW + UOFF
        out[s * USZ:(s + 1) * USZ] = raw[base:base + USZ]
    return bytes(out)


def text_seq_offsets(content, sc):
    end, bid, hts, te, txe, unk = struct.unpack_from("<6I", content, 0)
    tree = sc.parse_tree(content[txe + 10:(te if te else end)])
    lv = sc.decode(content[hts:txe], tree)
    offs = [bo for _i, bo in P.compute_sequence_bit_offsets(lv, tree)]
    return (bid & 0xFFFF), hts, offs


def build_word_map(pa, ba):
    sc = DQ4Schema()
    word_map = {}
    changed_blocks = 0
    for p_fo, b_fo in zip(pa.folders, ba.folders):
        if p_fo.index != b_fo.index:
            continue
        for p_fi, b_fi in zip(p_fo.files, b_fo.files):
            if p_fi.type_id != 40 or p_fi.content == b_fi.content:
                continue
            try:
                jtid, jhts, joffs = text_seq_offsets(p_fi.content, sc)
                etid, ehts, eoffs = text_seq_offsets(b_fi.content, sc)
            except Exception:
                continue
            if jtid != etid or joffs == eoffs:
                continue
            changed_blocks += 1
            for i in range(min(len(joffs), len(eoffs))):
                ow = (jtid << 20) | ((joffs[i] + jhts * 8) & 0xFFFFF)
                nw = (etid << 20) | ((eoffs[i] + ehts * 8) & 0xFFFFF)
                if ow != nw:
                    word_map[ow] = nw
    return word_map, changed_blocks


def main():
    ap = argparse.ArgumentParser(description="Remap external references inside compressed type-39 scripts")
    ap.add_argument("disc", nargs="?", default=os.path.join(ROOT, "build", "dq4_dialogue_en.bin"))
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.disc):
        raise SystemExit(f"[FAIL] Target disc not found: {args.disc}")
    if not os.path.exists(PRISTINE):
        raise SystemExit(f"[FAIL] Pristine disc not found: {PRISTINE}")

    print("[*] Reading pristine and built HBD archives...")
    t0 = time.time()
    jp_hbd = read_hbd(PRISTINE)
    en_hbd = read_hbd(args.disc)
    print(f"    Read both in {time.time()-t0:.2f}s")

    pa = HBDArchive(jp_hbd)
    ba = HBDArchive(en_hbd)

    print("[*] Building referrer word map (pristine -> built)...")
    word_map, changed_blocks = build_word_map(pa, ba)
    print(f"    {len(word_map)} shifted offsets across {changed_blocks} changed blocks")
    if not word_map:
        print("    Nothing to remap.")
        return 0
    keys = np.fromiter(word_map.keys(), dtype="<u4")

    print("[*] Scanning and remapping type-39 cutscene scripts...")
    total_scripts = patched_scripts = total_words = 0
    scripts_to_patch = []

    for fo in ba.folders:
        content_offset = 16 + fo.number_of_files * 16
        for fi in fo.files:
            if fi.type_id == 39:
                total_scripts += 1
                try:
                    if fi.is_compressed:
                        dec = bytearray(lzss_uncompress(fi.content, fi.size_uncompressed))
                    else:
                        dec = bytearray(fi.content)
                except Exception as ex:
                    print(f"    [WARN] decompress {fo.index}/{fi.index}: {ex}")
                    content_offset += fi.size
                    continue
                hits = []
                for shift in range(4):
                    usable = ((len(dec) - shift) // 4) * 4
                    if usable <= 0:
                        continue
                    arr = np.frombuffer(bytes(dec[shift:shift + usable]), dtype="<u4")
                    for m in np.where(np.isin(arr, keys))[0]:
                        off = shift + int(m) * 4
                        ow = int(arr[m])
                        # Opcode context check: genuine cutscene dialogue referrers
                        # are preceded by the dialogue call opcode (A021C000 / A021C0B0).
                        # Rewriting random non-dialogue words corrupts cutscene VM scripts (e.g. Chapter 1 court freeze).
                        if off >= 4 and dec[off - 2 : off] == b"\x21\xa0" and dec[off - 3] == 0xc0:
                            hits.append((off, ow, word_map[ow]))
                if hits:
                    hits.sort(key=lambda x: x[0])
                    scripts_to_patch.append((fo, fi, content_offset, dec, hits))
            content_offset += fi.size

    print(f"    {len(scripts_to_patch)} scripts contain shifted references")

    for fo, fi, content_offset, dec, hits in scripts_to_patch:
        for off, ow, nw in hits:
            struct.pack_into("<I", dec, off, nw)
        total_words += len(hits)
        patched_scripts += 1
        if args.report:
            continue

        if fi.is_compressed:
            # Fill the slot with a VALID stream, NEVER zero-pad. The DQ4 LZS
            # decoder reads flag bytes until the INPUT (slot) is exhausted, so a
            # trailing 0x00 pad decodes as extra tokens -> real bytes written
            # past ulen (the church-clobber class; measured +3..+177 on these
            # scripts). compress_to_slot lands exactly fi.size with <=+3 decode
            # slack, and RAISES on a genuine overflow (shortest > slot) so the
            # build aborts instead of shipping an oversized script.
            try:
                padded = compress_to_slot(bytes(dec), fi.size, max_slack=3)
            except ValueError as e:
                raise SystemExit(
                    f"[FAIL] SCRIPT slot-fill {fo.index}/{fi.index} (slot {fi.size}B): {e}")
            # UNBOUNDED round-trip: decode PAST ulen (len(dec)+8) so any overrun
            # is observable. The old bounded decode (expected_size=len(dec))
            # stopped at ulen and was structurally blind to the exact defect.
            verify = lzss_uncompress(padded, len(dec) + 8)
            overrun = len(verify) - len(dec)
            if verify[:len(dec)] != bytes(dec) or not (0 <= overrun <= 3):
                raise SystemExit(
                    f"[FAIL] roundtrip/overrun {fo.index}/{fi.index}: "
                    f"overrun={overrun} content_ok={verify[:len(dec)] == bytes(dec)}")
        else:
            padded = bytes(dec) + b"\x00" * (fi.size - len(dec))

        hbd_offset = fo.sector * USZ + content_offset
        disc_lba = HBD_LBA + hbd_offset // USZ
        sec_off = hbd_offset % USZ
        with open(args.disc, "r+b") as df:
            written, cur_sec, cur_off = 0, disc_lba, sec_off
            while written < len(padded):
                clen = min(len(padded) - written, USZ - cur_off)
                df.seek(cur_sec * RAW + UOFF + cur_off)
                df.write(padded[written:written + clen])
                written += clen
                cur_sec += 1
                cur_off = 0

    print("\n" + "=" * 72)
    print("TYPE-39 SCRIPT REMAP SUMMARY:")
    print(f"  scripts scanned      : {total_scripts}")
    print(f"  scripts remapped     : {patched_scripts}")
    print(f"  reference words fixed: {total_words}")
    print(f"  status               : {'REPORT ONLY' if args.report else 'SUCCESS (in-place, zero shift)'}")
    print("=" * 72)

    if not args.report and patched_scripts > 0 and os.path.exists(EDCRE):
        print("[*] Regenerating EDC/ECC...")
        subprocess.run([EDCRE, args.disc], capture_output=True, text=True, timeout=900)
        print("    done.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
