#!/usr/bin/env python3
"""
patch_battle_overlay.py -- Injects English Battle Overlay & Monster Data (Block 0x048B).

Block 0x048B: 817 sequences (battle messages 0..579, monsters 580..816).
Re-encoded text + tree fits within 10,878 bytes (budget 11,078 bytes, tre=0).
Writes block in-place (handling sector boundary bridging) and remaps
ALL direct 32-bit words and split-immediates across sectors 104000..106000.
"""

import argparse
import json
import os
import struct
import subprocess
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE) if "translation-tools" in HERE else HERE
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
sys.stdout.reconfigure(encoding='utf-8')

from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.length_limited import build_tree_length_limited
import dq4_hbd_patcher as P

RAW, UOFF, USZ = 2352, 24, 2048
EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")
TRANS_PATH = os.path.join(ROOT, "translation", "block_048b_battle_overlay_translated.json")
JSON_PATH = TRANS_PATH if os.path.exists(TRANS_PATH) else os.path.join(ROOT, "translation", "block_048b_battle_overlay.json")
BLOCK_ID_048B = 0x048B
BLOCK_ID_048C = 0x048C


def find_block_048b(disc_path):
    target = b"\x8b\x04\x00\x00\x18\x00\x00\x00"
    with open(disc_path, "rb") as f:
        f.seek(105000 * RAW)
        raw = f.read(1500 * RAW)
        u_data = bytearray()
        for i in range(1500):
            u_data.extend(raw[i * RAW + UOFF : i * RAW + UOFF + USZ])
        idx = u_data.find(target)
        if idx != -1:
            hdr_off = idx - 4
            sec = 105000 + (hdr_off // USZ)
            u_off = hdr_off % USZ
            hdr = struct.unpack_from("<6I", u_data, hdr_off)
            return sec, u_off, hdr
    return None, None, None


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", default=os.path.join(ROOT, "build", "dq4_sovereign_master.bin"))
    ap.add_argument("--report", action="store_true")
    args = ap.parse_args()

    if not os.path.exists(args.disc):
        raise SystemExit(f"[FAIL] Disc not found: {args.disc}")

    sec, off, hdr = find_block_048b(args.disc)
    if sec is None:
        raise SystemExit("[FAIL] Block 0x048B not found on disc")

    end, bid, hts, tre, txe, unk = hdr
    print(f"  Found Block 0x048B at Sector {sec}, user_off={off} (end={end}, txe={txe})")

    # Read original block from disc
    sectors_needed = ((off + end + USZ - 1) // USZ) + 1
    raw_data = bytearray()
    with open(args.disc, "rb") as f:
        for s in range(sec, sec + sectors_needed):
            f.seek(s * RAW + UOFF)
            raw_data.extend(f.read(USZ))
    orig_blk = bytes(raw_data[off : off + end])

    sc = DQ4Schema()
    tree_bytes = orig_blk[txe + 10 : (tre if tre else end)]
    orig_tree = sc.parse_tree(tree_bytes)
    orig_leaves = sc.decode(orig_blk[hts:txe], orig_tree)
    old_seq_starts = P.compute_sequence_bit_offsets(orig_leaves, orig_tree)
    old_offs = [bo for _i, bo in old_seq_starts]
    if len(old_offs) > 817:
        orig_leaves, _ = P.trim_trailing_garbage_leaves(orig_leaves)
        old_seq_starts = P.compute_sequence_bit_offsets(orig_leaves, orig_tree)
        old_offs = [bo for _i, bo in old_seq_starts]
    starts = set(old_offs)
    if len(old_offs) != 817:
        raise SystemExit(f"[FAIL] Original block has {len(old_offs)} sequences, expected 817")

    # Load translated sequences
    with open(JSON_PATH, "r", encoding="utf-8") as f:
        trans = json.load(f)

    if len(trans) != len(old_offs):
        raise SystemExit(f"[FAIL] Translation count drift: {len(trans)} != {len(old_offs)}")

    new_leaves = []
    for item in trans:
        txt = item.get("en") or item["jp"]
        new_leaves.extend(P.text_to_leaves(txt))

    freq = {}
    for l in new_leaves:
        freq[l.content] = freq.get(l.content, 0) + 1

    budget = (tre if tre else end) - hts - 10
    best = None
    for ml in (14, 13, 12, 11):
        try:
            t = build_tree_length_limited(freq, schema=None, max_len=ml)
            tb = sc.write_tree(t)
            tx = sc.encode(new_leaves, t)
        except Exception:
            continue
        tot = len(tx) + len(tb)
        if tot <= budget and (best is None or tot < best[0]):
            best = (tot, t, tx, tb, ml)

    if best is None:
        raise SystemExit(f"[FAIL] Could not fit Block 0x048B in {budget} bytes")

    tot, ntree, ntext, ntreeb, opt_ml = best
    new_seq_starts = P.compute_sequence_bit_offsets(new_leaves, ntree)
    new_offs = [bo for _i, bo in new_seq_starts]

    if len(new_offs) != len(old_offs):
        raise SystemExit(f"[FAIL] Sequence count drift: {len(new_offs)} != {len(old_offs)}")

    omap = {old_offs[i]: new_offs[i] for i in range(len(old_offs))}

    # CORRECTED block assembly: NO zero padding inside text stream
    # new_txe = hts + len(ntext) exactly (no zeros)
    # Tree header follows immediately, then tree, then pad to 'end'
    new_txe = hts + len(ntext)
    new_tree_start = new_txe + 10
    new_tree_mid = new_tree_start + (len(ntreeb) // 2) - 1
    num_branches = len(ntree.branch_nodes())
    new_tre = new_tree_start + len(ntreeb)

    blk = bytearray()
    # B2 FIX: word 3 (d = tree end / font-record start) MUST keep the pristine
    # value. 0x048B has d == 0 in the pristine disc (no per-block font record;
    # one of RadMage's 191 d==0 blocks). Writing new_tre here advertised a
    # phantom font-record region [10908, end) of zero bytes whose modulus the
    # engine unconditionally divides by (FORMAT.md 12b, `break 0x1C00` trap).
    blk += struct.pack("<6I", end, bid, hts, tre, new_txe, unk)
    # B2 gate: the emitted header must not move d (word 3) or f6 (word 5)
    emitted = struct.unpack_from("<6I", blk, 0)
    if emitted[3] != hdr[3]:
        raise SystemExit(f"[FAIL] B2 gate: word 3 (d) moved: pristine={hdr[3]} emitted={emitted[3]}")
    if emitted[5] != hdr[5]:
        raise SystemExit(f"[FAIL] B2 gate: word 5 (unk/f6) moved: pristine={hdr[5]} emitted={emitted[5]}")
    blk += ntext
    blk += struct.pack("<IIH", new_tree_start, new_tree_mid, num_branches)
    blk += ntreeb
    if len(blk) < end:
        blk += b"\x00" * (end - len(blk))
    blk = blk[:end]

    # Verify the encoded bytes round-trip to the 817 REAL sequences. Decoding the
    # encoded text can yield ONE spurious trailing sequence: the padding bits that
    # round the final Huffman code up to a byte boundary decode as an extra leaf.
    # It sits AFTER the 817th {0000}, past no referrer, so the game never touches
    # it. (Previously this relied on trim_trailing_garbage_leaves stripping it, but
    # that trim was correctly made less aggressive so it stops deleting legitimate
    # short sequences like 006C's 'シ' -- the prologue-freeze fix. So instead of
    # trimming, require the 817 real sequences to match and allow one trailing
    # artifact.) new_offs is the authoritative source-leaf count, already == 817.
    verify_leaves = sc.decode(ntext, ntree)
    verify_offs = [bo for _i, bo in P.compute_sequence_bit_offsets(verify_leaves, ntree)]
    if len(verify_offs) < 817 or verify_offs[:817] != new_offs:
        raise SystemExit(f"[FAIL] Re-encoded 0x048B does not round-trip to 817 sequences (got {len(verify_offs)})")
    if len(verify_offs) > 818:
        raise SystemExit(f"[FAIL] Re-encoded 0x048B has {len(verify_offs)} sequences (>818 trailing artifacts)")

    print(f"  Re-encoded 0x048B: text={len(ntext)}B, tree={len(ntreeb)}B, total={tot}/{budget}B (left: {budget - tot}B)")
    print(f"  Verified 817 real sequences round-trip ({len(verify_offs)} decoded incl trailing artifact)")

    if args.report:
        print("  REPORT ONLY -- nothing written")
        return 0

    # Write block to disc across sectors at the shifted location (sec)
    with open(args.disc, "r+b") as f:
        written = 0
        cur_sec = sec
        cur_off = off
        while written < len(blk):
            chunk_len = min(len(blk) - written, USZ - cur_off)
            f.seek(cur_sec * RAW + UOFF + cur_off)
            f.write(blk[written : written + chunk_len])
            written += chunk_len
            cur_sec += 1
            cur_off = 0

    print(f"  Injected Block 0x048B strictly at Sector {sec} (user_off={off})")

    # Remap referrers in battle database sectors 104000..106000
    print("  Remapping 0x048B referrers across sectors 104000..106000...")
    remap_words = 0
    remap_split = 0
    sectors_modified = 0

    # Battle overlay range
    REMAP_START = 104000
    REMAP_END = 106000

    with open(args.disc, "r+b") as f:
        for s in range(REMAP_START, REMAP_END):
            f.seek(s * RAW + UOFF)
            chunk = bytearray(f.read(USZ))
            modified = False

            # 1. Direct 32-bit words: (w >> 20) == BLOCK_ID_048B
            for off_w in range(0, USZ - 4, 4):
                w = struct.unpack_from("<I", chunk, off_w)[0]
                if (w >> 20) == BLOCK_ID_048B:
                    rel = (w & 0xFFFFF) - hts * 8
                    if rel in starts:
                        new_rel = omap[rel] + hts * 8
                        new_w = (BLOCK_ID_048B << 20) | (new_rel & 0xFFFFF)
                        struct.pack_into("<I", chunk, off_w, new_w)
                        remap_words += 1
                        modified = True

            # 2. Split-immediates for Block 0x048B: lui $reg, 0x48B0 + ori/addiu
            for so in range(0, USZ - 8, 4):
                w1 = struct.unpack_from("<I", chunk, so)[0]
                if (w1 >> 26) != 0x0F:  # lui
                    continue
                imm1 = w1 & 0xFFFF
                if (imm1 >> 4) != BLOCK_ID_048B:
                    continue
                reg1 = (w1 >> 16) & 0x1F
                for d in range(4, min(64, USZ - so), 4):
                    w2 = struct.unpack_from("<I", chunk, so + d)[0]
                    op2 = w2 >> 26
                    rs2 = (w2 >> 21) & 0x1F
                    rt2 = (w2 >> 16) & 0x1F
                    imm2 = w2 & 0xFFFF
                    if rt2 == reg1 and op2 in (0x09, 0x0D) and rs2 == reg1:
                        if op2 == 0x09:  # addiu
                            simm2 = imm2 if imm2 < 0x8000 else imm2 - 0x10000
                            val = (imm1 << 16) + simm2
                        else:  # ori
                            val = (imm1 << 16) | imm2
                        if (val >> 20) == BLOCK_ID_048B:
                            rel = (val & 0xFFFFF) - hts * 8
                            if rel in starts:
                                new_rel = omap[rel] + hts * 8
                                new_word = (BLOCK_ID_048B << 20) | (new_rel & 0xFFFFF)
                                n_hi = (new_word >> 16) & 0xFFFF
                                n_lo = new_word & 0xFFFF
                                if op2 == 0x09 and n_lo >= 0x8000:
                                    n_hi = (n_hi + 1) & 0xFFFF
                                struct.pack_into("<I", chunk, so, (w1 & 0xFFFF0000) | n_hi)
                                struct.pack_into("<I", chunk, so + d, (w2 & 0xFFFF0000) | n_lo)
                                remap_split += 1
                                modified = True
                        break



            if modified:
                f.seek(s * RAW + UOFF)
                f.write(chunk)
                sectors_modified += 1

    print(f"  Remapped {remap_words} direct 0x048B words across {sectors_modified} sectors.")
    print(f"  Remapped {remap_split} split-immediate pairs (0x048B).")

    # Run EDC/ECC verification
    if os.path.exists(EDCRE):
        print("  Verifying EDC/ECC...")
        r = subprocess.run([EDCRE, args.disc], capture_output=True, text=True, timeout=900)
        print(f"  EDC/ECC: {'PASS' if r.returncode == 0 else 'FAIL'}")
        if r.returncode != 0:
            print(f"  stderr: {r.stderr[:500]}")

    return 0


if __name__ == "__main__":
    sys.exit(main())