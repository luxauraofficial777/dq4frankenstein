#!/usr/bin/env python3
"""
validate_iso.py - ISO 9660 directory validation for Frankenstein builds.

Parses the ISO 9660 Primary Volume Descriptor and directory records
to verify all file LBAs point to valid sectors and file sizes are sane.

Usage:
    python validate_iso.py <bin_file> [--expected-hbd-lba N] [--expected-hbd-size N]
"""
import struct
import os
import sys
import argparse

SECTOR_SIZE = 2352
USER_OFFSET = 24
USER_SIZE = 2048

PVD_LBA = 16
ROOT_DIR_LBA = 23  # Typically sector 22 or 23 for PSX discs


def read_sector_user(f, lba):
    f.seek(lba * SECTOR_SIZE + USER_OFFSET)
    return f.read(USER_SIZE)


def parse_pvd(f):
    """Parse Primary Volume Descriptor at sector 16."""
    data = read_sector_user(f, PVD_LBA)
    if data[0] != 0x01:
        return None, "PVD type mismatch (expected 0x01)"
    if data[1:6] != b'CD001':
        return None, "PVD identifier mismatch (expected CD001)"
    
    vol_id = data[40:72].decode('ascii', errors='replace').rstrip(' ')
    
    # Root directory record is at offset 156, 34 bytes
    root_rec = data[156:156+34]
    root_lba_le = struct.unpack_from('<I', root_rec, 2)[0]
    root_lba_be = struct.unpack_from('>I', root_rec, 6)[0]
    root_size_le = struct.unpack_from('<I', root_rec, 10)[0]
    root_size_be = struct.unpack_from('>I', root_rec, 14)[0]
    
    # Volume space size
    vol_space_le = struct.unpack_from('<I', data, 80)[0]
    vol_space_be = struct.unpack_from('>I', data, 84)[0]
    
    # Logical block size
    block_size_le = struct.unpack_from('<H', data, 128)[0]
    block_size_be = struct.unpack_from('>H', data, 130)[0]
    
    info = {
        'vol_id': vol_id,
        'root_lba_le': root_lba_le,
        'root_lba_be': root_lba_be,
        'root_size_le': root_size_le,
        'root_size_be': root_size_be,
        'vol_space_le': vol_space_le,
        'vol_space_be': vol_space_be,
        'block_size_le': block_size_le,
        'block_size_be': block_size_be,
    }
    
    errors = []
    if root_lba_le != root_lba_be:
        errors.append(f"Root LBA endian mismatch: LE={root_lba_le} BE={root_lba_be}")
    if root_size_le != root_size_be:
        errors.append(f"Root size endian mismatch: LE={root_size_le} BE={root_size_be}")
    if vol_space_le != vol_space_be:
        errors.append(f"Volume space endian mismatch: LE={vol_space_le} BE={vol_space_be}")
    if block_size_le != block_size_be:
        errors.append(f"Block size endian mismatch: LE={block_size_le} BE={block_size_be}")
    if block_size_le != USER_SIZE:
        errors.append(f"Block size unexpected: {block_size_le} (expected {USER_SIZE})")
    
    return info, errors


def parse_directory(f, lba, size, depth=0, max_depth=5):
    """Parse ISO 9660 directory records at the given LBA."""
    entries = []
    errors = []
    
    if depth > max_depth:
        return entries, errors
    
    # Read all sectors for this directory
    num_sectors = (size + USER_SIZE - 1) // USER_SIZE
    data = bytearray()
    for i in range(num_sectors):
        data.extend(read_sector_user(f, lba + i))
    
    offset = 0
    while offset < len(data):
        rec_len = data[offset] & 0xFF
        if rec_len == 0:
            # Padding to end of sector
            sector_pos = offset % USER_SIZE
            if sector_pos > 0:
                offset += (USER_SIZE - sector_pos)
                if offset >= len(data):
                    break
                continue
            else:
                break
        
        if offset + rec_len > len(data):
            errors.append(f"Dir entry at offset {offset}: record length {rec_len} exceeds data")
            break
        
        # Parse directory record
        ext_attr_len = data[offset + 1] & 0xFF
        lba_le = struct.unpack_from('<I', data, offset + 2)[0]
        lba_be = struct.unpack_from('>I', data, offset + 6)[0]
        data_size_le = struct.unpack_from('<I', data, offset + 10)[0]
        data_size_be = struct.unpack_from('>I', data, offset + 14)[0]
        flags = data[offset + 25] & 0xFF
        name_len = data[offset + 32] & 0xFF
        name = data[offset + 33:offset + 33 + name_len].decode('ascii', errors='replace').rstrip('\x00')
        
        is_dir = bool(flags & 0x02)
        
        # Skip . and .. entries
        if name == '\x00' or name == '\x01':
            offset += rec_len
            continue
        
        # Validate endianness
        if lba_le != lba_be:
            errors.append(f"File '{name}': LBA endian mismatch LE={lba_le} BE={lba_be}")
        if data_size_le != data_size_be:
            errors.append(f"File '{name}': size endian mismatch LE={data_size_le} BE={data_size_be}")
        
        entries.append({
            'name': name,
            'lba': lba_le,
            'size': data_size_le,
            'is_dir': is_dir,
            'flags': flags,
        })
        
        # Recurse into subdirectories
        if is_dir and depth < max_depth:
            sub_entries, sub_errors = parse_directory(f, lba_le, data_size_le, depth + 1, max_depth)
            entries.extend(sub_entries)
            errors.extend(sub_errors)
        
        offset += rec_len
    
    return entries, errors


def validate_iso(bin_path, expected_hbd_lba=None, expected_hbd_size=None):
    """Validate ISO 9660 structure of a PSX disc image."""
    print(f"Validating ISO: {bin_path}")
    print(f"  File size: {os.path.getsize(bin_path):,} bytes")
    
    file_sectors = os.path.getsize(bin_path) // SECTOR_SIZE
    print(f"  Total sectors: {file_sectors}")
    
    all_errors = []
    all_warnings = []
    
    with open(bin_path, 'rb') as f:
        # Parse PVD
        pvd_info, pvd_errors = parse_pvd(f)
        if pvd_info is None:
            print(f"  FATAL: {pvd_errors}")
            return False, [pvd_errors], []
        
        print(f"\n  PVD:")
        print(f"    Volume ID: '{pvd_info['vol_id']}'")
        print(f"    Root dir LBA: {pvd_info['root_lba_le']}")
        print(f"    Root dir size: {pvd_info['root_size_le']:,} bytes")
        print(f"    Volume space: {pvd_info['vol_space_le']:,} sectors")
        print(f"    Block size: {pvd_info['block_size_le']}")
        
        all_errors.extend(pvd_errors)
        
        if pvd_info['vol_space_le'] > file_sectors:
            all_errors.append(f"Volume space ({pvd_info['vol_space_le']}) exceeds file sectors ({file_sectors})")
        
        # Parse root directory
        print(f"\n  Directory entries:")
        entries, dir_errors = parse_directory(f, pvd_info['root_lba_le'], pvd_info['root_size_le'])
        all_errors.extend(dir_errors)
        
        hbd_found = False
        exe_found = False
        
        for entry in entries:
            if entry['is_dir']:
                continue
            
            name = entry['name']
            lba = entry['lba']
            size = entry['size']
            
            print(f"    {name}: LBA={lba}, size={size:,}, flags=0x{entry['flags']:02X}")
            
            # Validate LBA is within disc bounds
            if lba >= file_sectors:
                all_errors.append(f"File '{name}': LBA {lba} exceeds disc sectors {file_sectors}")
            
            # Validate size doesn't exceed disc bounds
            end_sector = lba + (size + USER_SIZE - 1) // USER_SIZE
            if end_sector > file_sectors:
                all_errors.append(f"File '{name}': end sector {end_sector} exceeds disc sectors {file_sectors}")
            
            # Check for HBD file
            if 'HBD' in name.upper():
                hbd_found = True
                if expected_hbd_lba is not None and lba != expected_hbd_lba:
                    all_errors.append(f"HBD LBA mismatch: got {lba}, expected {expected_hbd_lba}")
                if expected_hbd_size is not None and size != expected_hbd_size:
                    all_warnings.append(f"HBD size: got {size:,}, expected {expected_hbd_size:,}")
                print(f"    ** HBD file found **")
            
            # Check for EXE file
            if name.startswith('SL') or name.startswith('SC'):
                exe_found = True
                print(f"    ** EXE file found **")
        
        if not hbd_found:
            all_warnings.append("No HBD file found in directory")
        if not exe_found:
            all_warnings.append("No EXE file found in directory")
        
        # Check SYSTEM.CNF
        cnf_found = any('SYSTEM' in e['name'].upper() or 'CNF' in e['name'].upper() for e in entries if not e['is_dir'])
        if not cnf_found:
            all_warnings.append("No SYSTEM.CNF found in directory")
    
    # Report
    print(f"\n  {'='*40}")
    if all_errors:
        print(f"  ERRORS ({len(all_errors)}):")
        for e in all_errors:
            print(f"    [ERROR] {e}")
    else:
        print(f"  No errors found")
    
    if all_warnings:
        print(f"  WARNINGS ({len(all_warnings)}):")
        for w in all_warnings:
            print(f"    [WARN] {w}")
    
    passed = len(all_errors) == 0
    print(f"\n  RESULT: {'PASS' if passed else 'FAIL'}")
    return passed, all_errors, all_warnings


def main():
    parser = argparse.ArgumentParser(description='Validate ISO 9660 directory structure')
    parser.add_argument('bin_file', help='Path to .bin disc image')
    parser.add_argument('--expected-hbd-lba', type=int, default=None, help='Expected HBD file LBA')
    parser.add_argument('--expected-hbd-size', type=int, default=None, help='Expected HBD file size')
    args = parser.parse_args()
    
    if not os.path.exists(args.bin_file):
        print(f"ERROR: File not found: {args.bin_file}")
        sys.exit(1)
    
    passed, errors, warnings = validate_iso(args.bin_file, args.expected_hbd_lba, args.expected_hbd_size)
    sys.exit(0 if passed else 1)


if __name__ == '__main__':
    main()
