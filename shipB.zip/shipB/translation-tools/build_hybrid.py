#!/usr/bin/env python3
"""
Build a playable hybrid translation for DQ4 PSX.
Batch-processed version to avoid IDE timeout.

Strategy:
  Tier 1 - System/Menu/Heart blocks: aggressively truncated English (Srch, Tlk, Atk)
  Tier 2 - Story/Script/NPC blocks: real English, progressively compressed to fit kanji buffer

Progressive compression for story lines:
  Pass 1: Contractions without apostrophes (do not -> dont, cannot -> cant)
  Pass 2: Drop filler words (just, really, very, quite, perhaps, actually)
  Pass 3: Drop articles (the, a, an) except at sentence start
  Pass 4: Shorten common phrases (something -> thing, someone -> one, etc.)
  Pass 5: Drop pronouns where implied (I think -> think, you know -> know)
  Pass 6: If still over budget, truncate at sentence/clause boundary
  Pass 7: If still over, hard truncate with ellipsis

The result is concise "telegram English" that preserves meaning and fits buffers.
Not elegant prose, but readable and makes sense in context.

Output: full_translation_hybrid_playable.json
"""
import csv
import glob
import json
import os
import re
import sys

CSV_DIR = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\csv"
FT_ORIG_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation_original.json"
OUT_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\full_translation_hybrid_playable.json"
REPORT_PATH = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\hybrid_playable_report.txt"
BATCH_SIZE = 100  # blocks per batch
SAFETY_MARGIN = 0.90  # compress to 90% of original byte length to prevent compressed-size overflow

CONTROL_CODE = re.compile(r"\{[0-9a-fA-F]+\}")
TERMINATOR = re.compile(r"\{0000\}$")

# --- Menu/System short forms (Tier 1) ---
MENU_SHORT = {
    "攻撃": "Atk", "防御": "Def", "魔法": "Magic", "道具": "Item",
    "装備": "Equip", "調べる": "Srch", "話す": "Tlk", "買う": "Buy",
    "売る": "Sell", "はい": "Yes", "いいえ": "No", "セーブ": "Save",
    "宿屋": "Inn", "教会": "Chrch", "城": "Castle", "村": "Vill",
    "山": "Mt", "洞窟": "Cave", "町": "Town", "港": "Port",
    "海": "Sea", "砂漠": "Dsr", "塔": "Twr", "神殿": "Shrn",
    "城下町": "CTown", "武器": "Wpn", "防具": "Arm", "盾": "Shld",
    "兜": "Helm", "鎧": "Mail", "刀": "Bld", "剣": "Swd",
    "槍": "Spear", "斧": "Axe", "棍": "Club", "爪": "Claw",
    "弓": "Bow", "杖": "Staff", "鞭": "Whip", "ハンマー": "Hmr",
    "フラン": "Pan", "鍋": "Pot", "薬": "Med", "草": "Herb",
    "種": "Seed", "花": "Flwr", "木": "Wood", "葉": "Leaf",
    "きのこ": "Shrm", "肉": "Meat", "魚": "Fish", "卵": "Egg",
    "ミルク": "Milk", "水": "Water", "油": "Oil", "酒": "Booze",
    "毒": "Psn", "封印": "Seal", "眠り": "Slp", "混乱": "Conf",
    "呪い": "Crse", "即死": "Dth", "MP": "MP", "HP": "HP",
    "レベル": "Lv", "経験値": "Exp", "ゴールド": "G", "お金": "G",
    "宝": "Trs", "鍵": "Key", "扉": "Door", "宝箱": "Chest",
    "階段": "Stairs", "橋": "Brdg", "井戸": "Well", "船": "Ship",
    "馬": "Horse", "車": "Cart", "飛行船": "Airshp", "翼": "Wing",
    "女神": "Godess", "神": "God", "魔王": "Demon", "勇者": "Hero",
    "王": "King", "姫": "Prncs", "王子": "Prnce", "兵士": "Guard",
    "商人": "Shop", "冒険者": "Advn", "旅人": "Trvlr", "村民": "Villgr",
    "女": "Woman", "男": "Man", "子供": "Kid", "犬": "Dog",
    "猫": "Cat", "鳥": "Bird", "狼": "Wolf", "スライム": "Slime",
    "ドラキー": "Draky", "ゴブリン": "Goblin", "コボルト": "Kobold",
    "オーク": "Orc", "幽霊": "Ghost", "骸骨": "Skel", "ゾンビ": "Zombie",
    "魔物": "Mon", "敵": "Foe", "仲間": "Ally", "パーティ": "Party",
    "主人公": "Hero", "名前": "Name", "性別": "Sex", "職業": "Job",
    "年齢": "Age", "身長": "Ht", "体重": "Wt", "強さ": "Str",
    "素早さ": "Agi", "賢さ": "Int", "運": "Luck", "魅力": "Chrm",
    "最大HP": "MaxHP", "最大MP": "MaxMP", "攻撃力": "Atk", "防御力": "Def",
    "装備中": "On", "未装備": "Off", "手持ち": "Held", "倉庫": "Store",
    "預かり": "Hold", "預ける": "Stash", "引き出す": "Take",
    "調合": "Mix", "錬金": "Alch", "鍛冶": "Forge", "特殊": "Spec",
    "必殺": "Deathblow", "連携": "Combo", "ぼうぎょ": "Def",
    "にげる": "Run", "ちから": "Str", "まもり": "Def",
    "すばやさ": "Agi", "かしこさ": "Int", "うん": "Luck",
    "みりょく": "Chrm", "けいけん": "Exp", "おかね": "G",
    "しょじ": "Have", "そうび": "Equip", "つかう": "Use",
    "なげる": "Throw", "わたす": "Give", "すてる": "Drop",
    "じゅもん": "Spell", "とくぎ": "Skill", "おぼえる": "Learn",
    "わすれる": "Forget", "召喚": "Call", "変身": "Morph",
    "身代わり": "Cover", "分身": "Split", "しょうかん": "Call",
    "へんしん": "Morph", "みがわり": "Cover", "ぶんしん": "Split",
    "なかま": "Ally", "てき": "Foe", "たたかう": "Fight",
    "ぼうぎょする": "Defend", "まほう": "Magic", "どうぐ": "Item",
    "そうびする": "Equip", "しらべる": "Srch", "はなす": "Tlk",
    "かう": "Buy", "うる": "Sell", "はな": "Yes", "いい": "No",
}

# --- Progressive compression rules for story text (Tier 2) ---

# Pass 1: Contractions (NO apostrophes - game font doesn't support them)
CONTRACTIONS = [
    (re.compile(r"\bdo not\b", re.I), "dont"),
    (re.compile(r"\bcannot\b", re.I), "cant"),
    (re.compile(r"\bwill not\b", re.I), "wont"),
    (re.compile(r"\bis not\b", re.I), "isnt"),
    (re.compile(r"\bare not\b", re.I), "arent"),
    (re.compile(r"\bhave not\b", re.I), "havent"),
    (re.compile(r"\bhas not\b", re.I), "hasnt"),
    (re.compile(r"\bhad not\b", re.I), "hadnt"),
    (re.compile(r"\bdoes not\b", re.I), "doesnt"),
    (re.compile(r"\bdid not\b", re.I), "didnt"),
    (re.compile(r"\bwas not\b", re.I), "wasnt"),
    (re.compile(r"\bwere not\b", re.I), "werent"),
    (re.compile(r"\bit is\b", re.I), "its"),
    (re.compile(r"\byou are\b", re.I), "youre"),
    (re.compile(r"\bwe are\b", re.I), "were"),
    (re.compile(r"\bthey are\b", re.I), "theyre"),
    (re.compile(r"\bI am\b"), "Im"),
    (re.compile(r"\bI have\b"), "Ive"),
    (re.compile(r"\bI will\b"), "Ill"),
    (re.compile(r"\bthere is\b", re.I), "theres"),
    (re.compile(r"\bthere has\b", re.I), "theres"),
    (re.compile(r"\byou have\b", re.I), "youve"),
    (re.compile(r"\bhe is\b", re.I), "hes"),
    (re.compile(r"\bshe is\b", re.I), "shes"),
    (re.compile(r"\bthat is\b", re.I), "thats"),
    (re.compile(r"\bwhat is\b", re.I), "whats"),
    (re.compile(r"\bwhere is\b", re.I), "wheres"),
    (re.compile(r"\bwho is\b", re.I), "whos"),
    (re.compile(r"\bhow is\b", re.I), "hows"),
    (re.compile(r"\bI would\b"), "Id"),
    (re.compile(r"\byou would\b", re.I), "youd"),
    (re.compile(r"\bhe would\b", re.I), "hed"),
    (re.compile(r"\bshe would\b", re.I), "shed"),
    (re.compile(r"\bwe would\b", re.I), "wed"),
    (re.compile(r"\bthey would\b", re.I), "theyd"),
    (re.compile(r"\bI could\b"), "I could"),
    (re.compile(r"\byou could\b", re.I), "you could"),
]

# Pass 2: Drop filler words
FILLER_DROPS = [
    (re.compile(r"\bjust\b", re.I), ""),
    (re.compile(r"\breally\b", re.I), ""),
    (re.compile(r"\bvery\b", re.I), ""),
    (re.compile(r"\bquite\b", re.I), ""),
    (re.compile(r"\brather\b", re.I), ""),
    (re.compile(r"\bsomewhat\b", re.I), ""),
    (re.compile(r"\bactually\b", re.I), ""),
    (re.compile(r"\bperhaps\b", re.I), "maybe"),
    (re.compile(r"\bprobably\b", re.I), "maybe"),
    (re.compile(r"\bdefinitely\b", re.I), "sure"),
    (re.compile(r"\bcertainly\b", re.I), "sure"),
    (re.compile(r"\bof course\b", re.I), "sure"),
    (re.compile(r"\bby the way\b", re.I), ""),
    (re.compile(r"\byou know\b", re.I), ""),
    (re.compile(r"\bWell,\b"), ""),
    (re.compile(r"\bNow,\b"), ""),
    (re.compile(r"\bSo,\b"), "So"),
    (re.compile(r"\bAnd,\b"), "And"),
    (re.compile(r"\bBut,\b"), "But"),
    (re.compile(r"\bHowever,\b", re.I), "But"),
    (re.compile(r"\bnevertheless\b", re.I), "still"),
    (re.compile(r"\botherwise\b", re.I), "else"),
    (re.compile(r"\bapproximately\b", re.I), "about"),
    (re.compile(r"\beverything\b", re.I), "all"),
    (re.compile(r"\beveryone\b", re.I), "all"),
    (re.compile(r"\bsomebody\b", re.I), "one"),
    (re.compile(r"\bsomething\b", re.I), "thing"),
    (re.compile(r"\bsomewhere\b", re.I), "place"),
    (re.compile(r"\bunderstand\b", re.I), "get"),
    (re.compile(r"\bunderstood\b", re.I), "got"),
    (re.compile(r"\bimportant\b", re.I), "key"),
    (re.compile(r"\bremember\b", re.I), "recall"),
    (re.compile(r"\bbecause\b", re.I), "since"),
    (re.compile(r"\btherefore\b", re.I), "so"),
    (re.compile(r"\bplease\b", re.I), ""),
]

# Pass 3: Drop articles (not at sentence start)
ARTICLE_DROPS = [
    (re.compile(r"(?<!^)\bthe\b", re.I), ""),
    (re.compile(r"(?<!^)\ba\b", re.I), ""),
    (re.compile(r"(?<!^)\ban\b", re.I), ""),
]

# Pass 4: Shorten common phrases
PHRASE_SHORTS = [
    (re.compile(r"\bsomething\b", re.I), "thing"),
    (re.compile(r"\bsomeone\b", re.I), "one"),
    (re.compile(r"\bsomebody\b", re.I), "one"),
    (re.compile(r"\beverything\b", re.I), "all"),
    (re.compile(r"\beveryone\b", re.I), "all"),
    (re.compile(r"\bnothing\b", re.I), "nil"),
    (re.compile(r"\bnobody\b", re.I), "none"),
    (re.compile(r"\bwithout\b", re.I), "w/o"),
    (re.compile(r"\bbefore\b", re.I), "prior"),
    (re.compile(r"\bafter\b", re.I), "post"),
    (re.compile(r"\bbetween\b", re.I), "btwn"),
    (re.compile(r"\bthrough\b", re.I), "thru"),
    (re.compile(r"\balthough\b", re.I), "tho"),
    (re.compile(r"\bthough\b", re.I), "tho"),
    (re.compile(r"\benough\b", re.I), "ok"),
    (re.compile(r"\byourself\b", re.I), "uself"),
    (re.compile(r"\bmyself\b", re.I), "mself"),
    (re.compile(r"\bherself\b", re.I), "hself"),
    (re.compile(r"\bhimself\b", re.I), "hself"),
    (re.compile(r"\bitself\b", re.I), "iself"),
    (re.compile(r"\btheir\b", re.I), "thier"),
    (re.compile(r"\bthem\b", re.I), "em"),
    (re.compile(r"\bgoing to\b", re.I), "gonna"),
    (re.compile(r"\bwant to\b", re.I), "wanna"),
    (re.compile(r"\bhave to\b", re.I), "gotta"),
    (re.compile(r"\bout of\b", re.I), "from"),
    (re.compile(r"\bkinds of\b", re.I), ""),
    (re.compile(r"\bsort of\b", re.I), ""),
    (re.compile(r"\btype of\b", re.I), ""),
    (re.compile(r"\ba lot of\b", re.I), "many"),
    (re.compile(r"\blots of\b", re.I), "many"),
    (re.compile(r"\bplenty of\b", re.I), "much"),
    (re.compile(r"\bin front of\b", re.I), "before"),
    (re.compile(r"\bon top of\b", re.I), "atop"),
    (re.compile(r"\bat the same time\b", re.I), "too"),
    (re.compile(r"\bin order to\b", re.I), "to"),
    (re.compile(r"\bas soon as\b", re.I), "when"),
    (re.compile(r"\bas well\b", re.I), "too"),
    (re.compile(r"\bas well as\b", re.I), "and"),
    (re.compile(r"\bin addition\b", re.I), "also"),
    (re.compile(r"\bfor example\b", re.I), "eg"),
    (re.compile(r"\bfor instance\b", re.I), "eg"),
    (re.compile(r"\bsuch as\b", re.I), "like"),
    (re.compile(r"\bwhether or not\b", re.I), "if"),
    (re.compile(r"\beven though\b", re.I), "tho"),
    (re.compile(r"\beven if\b", re.I), "if"),
    (re.compile(r"\bas if\b", re.I), "like"),
    (re.compile(r"\blook like\b", re.I), "seem"),
    (re.compile(r"\bseem like\b", re.I), "seem"),
    (re.compile(r"\bfeel like\b", re.I), "feel"),
    (re.compile(r"\bcome from\b", re.I), "hail"),
    (re.compile(r"\btalk about\b", re.I), "discuss"),
    (re.compile(r"\bthink about\b", re.I), "ponder"),
    (re.compile(r"\bworry about\b", re.I), "fear"),
    (re.compile(r"\bask about\b", re.I), "ask"),
    (re.compile(r"\bhear about\b", re.I), "hear"),
    (re.compile(r"\bknow about\b", re.I), "know"),
    (re.compile(r"\bforget about\b", re.I), "forget"),
    (re.compile(r"\bfind out\b", re.I), "learn"),
    (re.compile(r"\bfigure out\b", re.I), "solve"),
    (re.compile(r"\bpoint out\b", re.I), "note"),
    (re.compile(r"\bturn out\b", re.I), "happen"),
    (re.compile(r"\bwork out\b", re.I), "succeed"),
    (re.compile(r"\bcarry out\b", re.I), "do"),
    (re.compile(r"\bhold on\b", re.I), "wait"),
    (re.compile(r"\bhold up\b", re.I), "wait"),
    (re.compile(r"\bgo on\b", re.I), "continue"),
    (re.compile(r"\bgo ahead\b", re.I), "proceed"),
    (re.compile(r"\bgo back\b", re.I), "return"),
    (re.compile(r"\bcome back\b", re.I), "return"),
    (re.compile(r"\bcome in\b", re.I), "enter"),
    (re.compile(r"\bcome over\b", re.I), "approach"),
    (re.compile(r"\bstand up\b", re.I), "rise"),
    (re.compile(r"\bsit down\b", re.I), "sit"),
    (re.compile(r"\bwake up\b", re.I), "wake"),
    (re.compile(r"\bgrow up\b", re.I), "mature"),
    (re.compile(r"\bshow up\b", re.I), "appear"),
    (re.compile(r"\bshow me\b", re.I), "prove"),
    (re.compile(r"\btell me\b", re.I), "say"),
    (re.compile(r"\bgive me\b", re.I), "give"),
    (re.compile(r"\blet me\b", re.I), "allow"),
    (re.compile(r"\bhelp me\b", re.I), "help"),
    (re.compile(r"\bexcuse me\b", re.I), "pardon"),
    (re.compile(r"\bthank you\b", re.I), "thanks"),
    (re.compile(r"\bthanks to\b", re.I), "due"),
    (re.compile(r"\bbecause of\b", re.I), "from"),
    (re.compile(r"\binstead of\b", re.I), "not"),
    (re.compile(r"\bregardless of\b", re.I), "despite"),
    (re.compile(r"\baccording to\b", re.I), "per"),
    (re.compile(r"\bdue to\b", re.I), "from"),
    (re.compile(r"\bthanks to\b", re.I), "from"),
    (re.compile(r"\bwith respect to\b", re.I), "re"),
    (re.compile(r"\bwith regard to\b", re.I), "re"),
    (re.compile(r"\bwhen it comes to\b", re.I), "re"),
    (re.compile(r"\bwhat kind of\b", re.I), "which"),
    (re.compile(r"\bwhat sort of\b", re.I), "which"),
    (re.compile(r"\bwhat type of\b", re.I), "which"),
    (re.compile(r"\bdo you know\b", re.I), "know"),
    (re.compile(r"\bdo you think\b", re.I), "think"),
    (re.compile(r"\bdo you want\b", re.I), "want"),
    (re.compile(r"\bdo you have\b", re.I), "have"),
    (re.compile(r"\bdo you remember\b", re.I), "recall"),
    (re.compile(r"\bI think that\b", re.I), "I think"),
    (re.compile(r"\bI believe that\b", re.I), "I think"),
    (re.compile(r"\bI suppose that\b", re.I), "I guess"),
    (re.compile(r"\bI guess that\b", re.I), "I guess"),
    (re.compile(r"\bI heard that\b", re.I), "I heard"),
    (re.compile(r"\bI remember that\b", re.I), "I recall"),
    (re.compile(r"\bIt seems that\b", re.I), "Seems"),
    (re.compile(r"\bIt appears that\b", re.I), "Seems"),
    (re.compile(r"\bIt is said that\b", re.I), "They say"),
    (re.compile(r"\bIt is known that\b", re.I), "Known"),
    (re.compile(r"\bThere is a\b", re.I), "A"),
    (re.compile(r"\bThere is an\b", re.I), "An"),
    (re.compile(r"\bThere are\b", re.I), "Are"),
    (re.compile(r"\bThere was a\b", re.I), "Was a"),
    (re.compile(r"\bThere was an\b", re.I), "Was an"),
    (re.compile(r"\bThere were\b", re.I), "Were"),
    (re.compile(r"\bThat is to say\b", re.I), "Meaning"),
    (re.compile(r"\bIn other words\b", re.I), "Meaning"),
    (re.compile(r"\bneed to\b", re.I), "must"),
    (re.compile(r"\bought to\b", re.I), "should"),
    (re.compile(r"\bsupposed to\b", re.I), "should"),
    (re.compile(r"\bused to\b", re.I), "did"),
]

# Pass 5: Drop leading pronouns where context implies subject
PRONOUN_DROPS = [
    (re.compile(r"^I think\b"), "Think"),
    (re.compile(r"^I believe\b"), "Believe"),
    (re.compile(r"^I guess\b"), "Guess"),
    (re.compile(r"^I suppose\b"), "Suppose"),
    (re.compile(r"^I heard\b"), "Heard"),
    (re.compile(r"^I remember\b"), "Recall"),
    (re.compile(r"^I know\b"), "Know"),
    (re.compile(r"^I see\b"), "See"),
    (re.compile(r"^I feel\b"), "Feel"),
]

# Pass 5b: Cyberpunk disemvowel — strip vowels from long words, keeping first/last char
# e.g. "independent" -> "indpndnt", "rushing" -> "rshng", "train" -> "trn"
def disemvowel_text(text):
    """Remove vowels from words longer than 3 chars, preserving first and last char.
    Preserves control codes {XXXX} and punctuation."""
    def disemvowel_word(m):
        word = m.group(0)
        if len(word) <= 3:
            return word
        # Keep first and last char, strip vowels from middle
        mid = word[1:-1]
        mid = re.sub(r'[aeiouAEIOU]', '', mid)
        return word[0] + mid + word[-1]
    
    # Split into control codes and non-control-code segments
    parts = re.split(r'(\{[0-9a-fA-F]+\})', text)
    result = []
    for part in parts:
        if part.startswith('{') and part.endswith('}'):
            result.append(part)
        else:
            # Apply disemvowel to each word, preserving spaces and punctuation
            result.append(re.sub(r"[A-Za-z]{4,}", disemvowel_word, part))
    return ''.join(result)

# Pass 5c: Aggressive adverb removal
ADVERB_DROPS = [
    (re.compile(r"\bactually\b", re.I), ""),
    (re.compile(r"\bfinally\b", re.I), ""),
    (re.compile(r"\bsuddenly\b", re.I), ""),
    (re.compile(r"\bquickly\b", re.I), ""),
    (re.compile(r"\bslowly\b", re.I), ""),
    (re.compile(r"\bcarefully\b", re.I), ""),
    (re.compile(r"\bquietly\b", re.I), ""),
    (re.compile(r"\breally\b", re.I), ""),
    (re.compile(r"\bvery\b", re.I), ""),
    (re.compile(r"\bquite\b", re.I), ""),
    (re.compile(r"\bjust\b", re.I), ""),
    (re.compile(r"\bstill\b", re.I), ""),
    (re.compile(r"\balso\b", re.I), ""),
    (re.compile(r"\beven\b", re.I), ""),
    (re.compile(r"\balready\b", re.I), ""),
    (re.compile(r"\balmost\b", re.I), ""),
    (re.compile(r"\balways\b", re.I), ""),
    (re.compile(r"\bnever\b", re.I), ""),
    (re.compile(r"\bsometimes\b", re.I), ""),
    (re.compile(r"\busually\b", re.I), ""),
    (re.compile(r"\bperhaps\b", re.I), ""),
    (re.compile(r"\bmaybe\b", re.I), ""),
    (re.compile(r"\bprobably\b", re.I), ""),
    (re.compile(r"\bpossibly\b", re.I), ""),
    (re.compile(r"\bcompletely\b", re.I), ""),
    (re.compile(r"\btotally\b", re.I), ""),
    (re.compile(r"\babsolutely\b", re.I), ""),
    (re.compile(r"\bdefinitely\b", re.I), ""),
    (re.compile(r"\bcertainly\b", re.I), ""),
    (re.compile(r"\bcurrently\b", re.I), ""),
    (re.compile(r"\bpreviously\b", re.I), ""),
    (re.compile(r"\bshortly\b", re.I), ""),
    (re.compile(r"\bsoon\b", re.I), ""),
    (re.compile(r"\blater\b", re.I), ""),
    (re.compile(r"\bnow\b", re.I), ""),
    (re.compile(r"\bthen\b", re.I), ""),
    (re.compile(r"\bhere\b", re.I), ""),
    (re.compile(r"\bthere\b", re.I), ""),
]

# Pass 5d: Preposition removal (aggressive — drop where meaning is implied)
PREP_DROPS = [
    (re.compile(r"(?<!^)\bto\b", re.I), ""),
    (re.compile(r"(?<!^)\bat\b", re.I), ""),
    (re.compile(r"(?<!^)\bin\b", re.I), ""),
    (re.compile(r"(?<!^)\bon\b", re.I), ""),
    (re.compile(r"(?<!^)\bof\b", re.I), ""),
    (re.compile(r"(?<!^)\bfor\b", re.I), ""),
    (re.compile(r"(?<!^)\bwith\b", re.I), ""),
    (re.compile(r"(?<!^)\bfrom\b", re.I), ""),
    (re.compile(r"(?<!^)\bby\b", re.I), ""),
    (re.compile(r"(?<!^)\babout\b", re.I), ""),
    (re.compile(r"(?<!^)\binto\b", re.I), ""),
    (re.compile(r"(?<!^)\bthrough\b", re.I), ""),
    (re.compile(r"(?<!^)\bduring\b", re.I), ""),
    (re.compile(r"(?<!^)\bbefore\b", re.I), ""),
    (re.compile(r"(?<!^)\bafter\b", re.I), ""),
    (re.compile(r"(?<!^)\babove\b", re.I), ""),
    (re.compile(r"(?<!^)\bbelow\b", re.I), ""),
    (re.compile(r"(?<!^)\bbetween\b", re.I), ""),
    (re.compile(r"(?<!^)\bagainst\b", re.I), ""),
    (re.compile(r"(?<!^)\bupon\b", re.I), ""),
    (re.compile(r"(?<!^)\bwithin\b", re.I), ""),
    (re.compile(r"(?<!^)\bwithout\b", re.I), ""),
    (re.compile(r"(?<!^)\btoward\b", re.I), ""),
    (re.compile(r"(?<!^)\btowards\b", re.I), ""),
]

# Pass 5e: Conjunction removal
CONJ_DROPS = [
    (re.compile(r"\band\b", re.I), ""),
    (re.compile(r"\bbut\b", re.I), ""),
    (re.compile(r"\bor\b", re.I), ""),
    (re.compile(r"\bso\b", re.I), ""),
    (re.compile(r"\bbecause\b", re.I), ""),
    (re.compile(r"\balthough\b", re.I), ""),
    (re.compile(r"\bhowever\b", re.I), ""),
    (re.compile(r"\btherefore\b", re.I), ""),
    (re.compile(r"\bmeanwhile\b", re.I), ""),
    (re.compile(r"\bwhile\b", re.I), ""),
    (re.compile(r"\bsince\b", re.I), ""),
    (re.compile(r"\bunless\b", re.I), ""),
    (re.compile(r"\buntil\b", re.I), ""),
    (re.compile(r"\bonce\b", re.I), ""),
]

# Pass 5f: Cyberpunk trollwave — short punchy replacements for common verbose phrases
TROLLWAVE = [
    (re.compile(r"\bI was like\b", re.I), "I was"),
    (re.compile(r"\bit turned out\b", re.I), "turns out"),
    (re.compile(r"\bit seems\b", re.I), "seems"),
    (re.compile(r"\bit appears\b", re.I), "seems"),
    (re.compile(r"\bI suppose\b", re.I), "guess"),
    (re.compile(r"\bI believe\b", re.I), "think"),
    (re.compile(r"\bI wonder\b", re.I), "wonder"),
    (re.compile(r"\bdo you think\b", re.I), "think"),
    (re.compile(r"\bdo you know\b", re.I), "know"),
    (re.compile(r"\bdo you want\b", re.I), "want"),
    (re.compile(r"\bdo you remember\b", re.I), "recall"),
    (re.compile(r"\bwhat happened\b", re.I), "what hapnd"),
    (re.compile(r"\bwhat do you mean\b", re.I), "huh"),
    (re.compile(r"\bI do not know\b", re.I), "dunno"),
    (re.compile(r"\bI dont know\b", re.I), "dunno"),
    (re.compile(r"\bI am not sure\b", re.I), "unsure"),
    (re.compile(r"\bI am sorry\b", re.I), "sry"),
    (re.compile(r"\bthank you\b", re.I), "thx"),
    (re.compile(r"\bthanks\b", re.I), "thx"),
    (re.compile(r"\bexcuse me\b", re.I), "eh"),
    (re.compile(r"\bgood morning\b", re.I), "morn"),
    (re.compile(r"\bgood evening\b", re.I), "eve"),
    (re.compile(r"\bgood night\b", re.I), "night"),
    (re.compile(r"\bgoodbye\b", re.I), "bye"),
    (re.compile(r"\bsee you\b", re.I), "cya"),
    (re.compile(r"\bsee you later\b", re.I), "cya"),
    (re.compile(r"\btake care\b", re.I), "care"),
    (re.compile(r"\bbe careful\b", re.I), "careful"),
    (re.compile(r"\bwatch out\b", re.I), "watch"),
    (re.compile(r"\blook out\b", re.I), "watch"),
    (re.compile(r"\bhold on\b", re.I), "wait"),
    (re.compile(r"\bwait a minute\b", re.I), "wait"),
    (re.compile(r"\bjust a moment\b", re.I), "wait"),
    (re.compile(r"\bone moment\b", re.I), "wait"),
    (re.compile(r"\bthat is right\b", re.I), "right"),
    (re.compile(r"\bof course\b", re.I), "sure"),
    (re.compile(r"\bno problem\b", re.I), "ok"),
    (re.compile(r"\bno way\b", re.I), "nah"),
    (re.compile(r"\bnot at all\b", re.I), "nah"),
    (re.compile(r"\bnot really\b", re.I), "nah"),
    (re.compile(r"\byes indeed\b", re.I), "yep"),
    (re.compile(r"\bthats true\b", re.I), "true"),
    (re.compile(r"\bthat is true\b", re.I), "true"),
    (re.compile(r"\bI see\b", re.I), "c"),
    (re.compile(r"\bI understand\b", re.I), "got it"),
    (re.compile(r"\bI got it\b", re.I), "got it"),
    (re.compile(r"\bI see now\b", re.I), "got it"),
    (re.compile(r"\bnow I see\b", re.I), "got it"),
    (re.compile(r"\bwhat is going on\b", re.I), "huh"),
    (re.compile(r"\bwhat is happening\b", re.I), "huh"),
    (re.compile(r"\bwhat is wrong\b", re.I), "huh"),
    (re.compile(r"\bis something wrong\b", re.I), "ok?"),
    (re.compile(r"\bis everything ok\b", re.I), "ok?"),
    (re.compile(r"\bare you ok\b", re.I), "ok?"),
    (re.compile(r"\bare you sure\b", re.I), "sure?"),
    (re.compile(r"\bare you ready\b", re.I), "ready?"),
    (re.compile(r"\bwhat do you want\b", re.I), "want?"),
    (re.compile(r"\bwhat can I do\b", re.I), "help?"),
    (re.compile(r"\bhow can I help\b", re.I), "help?"),
    (re.compile(r"\bmay I help you\b", re.I), "help?"),
    (re.compile(r"\bcan I help\b", re.I), "help?"),
    (re.compile(r"\blet me see\b", re.I), "c"),
    (re.compile(r"\blet me think\b", re.I), "hmm"),
    (re.compile(r"\bgive me a second\b", re.I), "wait"),
    (re.compile(r"\bgive me a moment\b", re.I), "wait"),
    (re.compile(r"\bjust a second\b", re.I), "wait"),
    (re.compile(r"\bone more thing\b", re.I), "also"),
    (re.compile(r"\bby the way\b", re.I), "also"),
    (re.compile(r"\bspeaking of\b", re.I), "re"),
    (re.compile(r"\banyway\b", re.I), ""),
    (re.compile(r"\banyways\b", re.I), ""),
    (re.compile(r"\bwell then\b", re.I), "so"),
    (re.compile(r"\bthen again\b", re.I), ""),
    (re.compile(r"\bafter all\b", re.I), ""),
    (re.compile(r"\ball in all\b", re.I), ""),
    (re.compile(r"\bin fact\b", re.I), ""),
    (re.compile(r"\bas a matter of fact\b", re.I), ""),
    (re.compile(r"\bto be honest\b", re.I), "honestly"),
    (re.compile(r"\bto tell the truth\b", re.I), "truly"),
    (re.compile(r"\bfrankly\b", re.I), ""),
    (re.compile(r"\bhonestly\b", re.I), ""),
    (re.compile(r"\btruly\b", re.I), ""),
    (re.compile(r"\bindeed\b", re.I), ""),
    (re.compile(r"\bactually\b", re.I), ""),
    (re.compile(r"\bliterally\b", re.I), ""),
    (re.compile(r"\bbasically\b", re.I), ""),
    (re.compile(r"\bessentially\b", re.I), ""),
    (re.compile(r"\bobviously\b", re.I), ""),
    (re.compile(r"\bclearly\b", re.I), ""),
    (re.compile(r"\bapparently\b", re.I), ""),
    (re.compile(r"\bsupposedly\b", re.I), ""),
    (re.compile(r"\breportedly\b", re.I), ""),
    (re.compile(r"\ballegedly\b", re.I), ""),
    (re.compile(r"\bfortunately\b", re.I), "lucky"),
    (re.compile(r"\bunfortunately\b", re.I), "unlucky"),
    (re.compile(r"\bluckily\b", re.I), "lucky"),
    (re.compile(r"\bsadly\b", re.I), "sad"),
    (re.compile(r"\bhappily\b", re.I), "yay"),
    (re.compile(r"\bsurprisingly\b", re.I), "wow"),
    (re.compile(r"\binterestingly\b", re.I), "huh"),
    (re.compile(r"\bnaturally\b", re.I), ""),
    (re.compile(r"\bnaturally enough\b", re.I), ""),
    (re.compile(r"\bneedless to say\b", re.I), ""),
    (re.compile(r"\bit goes without saying\b", re.I), ""),
    (re.compile(r"\bas you know\b", re.I), ""),
    (re.compile(r"\bas you can see\b", re.I), ""),
    (re.compile(r"\bas I said\b", re.I), ""),
    (re.compile(r"\bas mentioned\b", re.I), ""),
    (re.compile(r"\bfor now\b", re.I), ""),
    (re.compile(r"\bfor the time being\b", re.I), ""),
    (re.compile(r"\bat this point\b", re.I), ""),
    (re.compile(r"\bat that point\b", re.I), ""),
    (re.compile(r"\bin the end\b", re.I), ""),
    (re.compile(r"\bat last\b", re.I), "finally"),
    (re.compile(r"\bin short\b", re.I), ""),
    (re.compile(r"\bin brief\b", re.I), ""),
    (re.compile(r"\bin conclusion\b", re.I), ""),
    (re.compile(r"\bto sum up\b", re.I), ""),
    (re.compile(r"\bas a result\b", re.I), "so"),
    (re.compile(r"\bas expected\b", re.I), ""),
    (re.compile(r"\bas usual\b", re.I), ""),
    (re.compile(r"\bas always\b", re.I), ""),
    (re.compile(r"\bonce again\b", re.I), "again"),
    (re.compile(r"\btime and again\b", re.I), "again"),
    (re.compile(r"\bover and over\b", re.I), "often"),
    (re.compile(r"\bagain and again\b", re.I), "often"),
    (re.compile(r"\bnot yet\b", re.I), "not yet"),
    (re.compile(r"\bnot anymore\b", re.I), "no more"),
    (re.compile(r"\bno longer\b", re.I), "no more"),
    (re.compile(r"\bany longer\b", re.I), ""),
    (re.compile(r"\bany more\b", re.I), "more"),
    (re.compile(r"\beven now\b", re.I), "still"),
    (re.compile(r"\beven so\b", re.I), "still"),
    (re.compile(r"\beven then\b", re.I), "still"),
    (re.compile(r"\bup to now\b", re.I), "till now"),
    (re.compile(r"\bso far\b", re.I), "till now"),
    (re.compile(r"\bthus far\b", re.I), "till now"),
    (re.compile(r"\bto date\b", re.I), "till now"),
    (re.compile(r"\bfrom now on\b", re.I), "now"),
    (re.compile(r"\bfrom then on\b", re.I), "then"),
    (re.compile(r"\bfrom here on\b", re.I), "now"),
    (re.compile(r"\bstarting now\b", re.I), "now"),
    (re.compile(r"\bbeginning now\b", re.I), "now"),
    (re.compile(r"\bright away\b", re.I), "now"),
    (re.compile(r"\bright now\b", re.I), "now"),
    (re.compile(r"\bat once\b", re.I), "now"),
    (re.compile(r"\bimmediately\b", re.I), "now"),
    (re.compile(r"\binstantly\b", re.I), "now"),
    (re.compile(r"\bshortly\b", re.I), "soon"),
    (re.compile(r"\bbriefly\b", re.I), ""),
    (re.compile(r"\bquickly\b", re.I), "fast"),
    (re.compile(r"\bslowly\b", re.I), "slow"),
    (re.compile(r"\bsuddenly\b", re.I), ""),
    (re.compile(r"\bgradually\b", re.I), ""),
    (re.compile(r"\beventually\b", re.I), "finally"),
    (re.compile(r"\bultimately\b", re.I), "finally"),
    (re.compile(r"\bfirst of all\b", re.I), "first"),
    (re.compile(r"\bfirst thing\b", re.I), "first"),
    (re.compile(r"\bfor a start\b", re.I), "first"),
    (re.compile(r"\bto begin with\b", re.I), "first"),
    (re.compile(r"\bto start with\b", re.I), "first"),
    (re.compile(r"\bfor one thing\b", re.I), "first"),
    (re.compile(r"\bfor another\b", re.I), "also"),
    (re.compile(r"\bmore importantly\b", re.I), "key"),
    (re.compile(r"\bmost importantly\b", re.I), "key"),
    (re.compile(r"\babove all\b", re.I), "key"),
    (re.compile(r"\bbeyond that\b", re.I), "also"),
    (re.compile(r"\bin addition to\b", re.I), "plus"),
    (re.compile(r"\balong with\b", re.I), "plus"),
    (re.compile(r"\btogether with\b", re.I), "plus"),
    (re.compile(r"\bnot to mention\b", re.I), "also"),
    (re.compile(r"\blet alone\b", re.I), ""),
    (re.compile(r"\bmuch less\b", re.I), ""),
    (re.compile(r"\bstill less\b", re.I), ""),
    (re.compile(r"\blet us\b", re.I), "lets"),
    (re.compile(r"\ballow me\b", re.I), "let me"),
    (re.compile(r"\bpermit me\b", re.I), "let me"),
    (re.compile(r"\bif you do not mind\b", re.I), "please"),
    (re.compile(r"\bif you please\b", re.I), "please"),
    (re.compile(r"\bif it pleases you\b", re.I), "please"),
    (re.compile(r"\bwith your permission\b", re.I), "please"),
    (re.compile(r"\bby your leave\b", re.I), "please"),
    (re.compile(r"\bI am afraid\b", re.I), ""),
    (re.compile(r"\bI am glad\b", re.I), "glad"),
    (re.compile(r"\bI am happy\b", re.I), "happy"),
    (re.compile(r"\bI am pleased\b", re.I), "pleased"),
    (re.compile(r"\bI am delighted\b", re.I), "glad"),
    (re.compile(r"\bI am relieved\b", re.I), "relieved"),
    (re.compile(r"\bI am worried\b", re.I), "worried"),
    (re.compile(r"\bI am concerned\b", re.I), "concerned"),
    (re.compile(r"\bI am surprised\b", re.I), "surprised"),
    (re.compile(r"\bI am shocked\b", re.I), "shocked"),
    (re.compile(r"\bI am amazed\b", re.I), "amazed"),
    (re.compile(r"\bI am astonished\b", re.I), "amazed"),
    (re.compile(r"\bI am disappointed\b", re.I), "disappointed"),
    (re.compile(r"\bI am embarrassed\b", re.I), "embarrassed"),
    (re.compile(r"\bI am exhausted\b", re.I), "tired"),
    (re.compile(r"\bI am tired\b", re.I), "tired"),
    (re.compile(r"\bI am hungry\b", re.I), "hungry"),
    (re.compile(r"\bI am thirsty\b", re.I), "thirsty"),
    (re.compile(r"\bI am cold\b", re.I), "cold"),
    (re.compile(r"\bI am hot\b", re.I), "hot"),
    (re.compile(r"\bI am fine\b", re.I), "fine"),
    (re.compile(r"\bI am ok\b", re.I), "ok"),
    (re.compile(r"\bI am alright\b", re.I), "ok"),
    (re.compile(r"\bI am ready\b", re.I), "ready"),
    (re.compile(r"\bI am done\b", re.I), "done"),
    (re.compile(r"\bI am finished\b", re.I), "done"),
    (re.compile(r"\bI am here\b", re.I), "here"),
    (re.compile(r"\bI am back\b", re.I), "back"),
    (re.compile(r"\bI am going\b", re.I), "going"),
    (re.compile(r"\bI am coming\b", re.I), "coming"),
    (re.compile(r"\bI am leaving\b", re.I), "leaving"),
    (re.compile(r"\bI am returning\b", re.I), "returning"),
    (re.compile(r"\bI am waiting\b", re.I), "waiting"),
    (re.compile(r"\bI am looking\b", re.I), "looking"),
    (re.compile(r"\bI am searching\b", re.I), "searching"),
    (re.compile(r"\bI am trying\b", re.I), "trying"),
    (re.compile(r"\bI am thinking\b", re.I), "thinking"),
    (re.compile(r"\bI am feeling\b", re.I), "feeling"),
    (re.compile(r"\bI am hoping\b", re.I), "hoping"),
    (re.compile(r"\bI am wondering\b", re.I), "wondering"),
    (re.compile(r"\bI am asking\b", re.I), "asking"),
    (re.compile(r"\bI am talking\b", re.I), "talking"),
    (re.compile(r"\bI am listening\b", re.I), "listening"),
    (re.compile(r"\bI am watching\b", re.I), "watching"),
    (re.compile(r"\bI am following\b", re.I), "following"),
    (re.compile(r"\bI am running\b", re.I), "running"),
    (re.compile(r"\bI am walking\b", re.I), "walking"),
    (re.compile(r"\bI am standing\b", re.I), "standing"),
    (re.compile(r"\bI am sitting\b", re.I), "sitting"),
    (re.compile(r"\bI am resting\b", re.I), "resting"),
    (re.compile(r"\bI am sleeping\b", re.I), "sleeping"),
    (re.compile(r"\bI am dreaming\b", re.I), "dreaming"),
    (re.compile(r"\bI am remembering\b", re.I), "recalling"),
    (re.compile(r"\bI am forgetting\b", re.I), "forgetting"),
    (re.compile(r"\bI am learning\b", re.I), "learning"),
    (re.compile(r"\bI am studying\b", re.I), "studying"),
    (re.compile(r"\bI am practicing\b", re.I), "practicing"),
    (re.compile(r"\bI am training\b", re.I), "training"),
    (re.compile(r"\bI am fighting\b", re.I), "fighting"),
    (re.compile(r"\bI am working\b", re.I), "working"),
    (re.compile(r"\bI am helping\b", re.I), "helping"),
    (re.compile(r"\bI am looking for\b", re.I), "seeking"),
    (re.compile(r"\bI am going to\b", re.I), "I will"),
    (re.compile(r"\bI am about to\b", re.I), "I will"),
    (re.compile(r"\bI am supposed to\b", re.I), "I should"),
    (re.compile(r"\bI am expected to\b", re.I), "I should"),
    (re.compile(r"\bI am required to\b", re.I), "I must"),
    (re.compile(r"\bI am forced to\b", re.I), "I must"),
    (re.compile(r"\bI am able to\b", re.I), "I can"),
    (re.compile(r"\bI am unable to\b", re.I), "I cant"),
    (re.compile(r"\bI am not able to\b", re.I), "I cant"),
    (re.compile(r"\bI am willing to\b", re.I), "I will"),
    (re.compile(r"\bI am ready to\b", re.I), "I will"),
    (re.compile(r"\bI am prepared to\b", re.I), "I will"),
    (re.compile(r"\bI am determined to\b", re.I), "I will"),
    (re.compile(r"\bI am trying to\b", re.I), "I try"),
    (re.compile(r"\bI am planning to\b", re.I), "I plan"),
    (re.compile(r"\bI am hoping to\b", re.I), "I hope"),
    (re.compile(r"\bI am wanting to\b", re.I), "I want"),
    (re.compile(r"\bI am needing to\b", re.I), "I need"),
    (re.compile(r"\bI am getting\b", re.I), "I get"),
    (re.compile(r"\bI am becoming\b", re.I), "I become"),
    (re.compile(r"\bI am starting to\b", re.I), "I start"),
    (re.compile(r"\bI am beginning to\b", re.I), "I begin"),
    (re.compile(r"\bI am continuing to\b", re.I), "I continue"),
    (re.compile(r"\bI am stopping\b", re.I), "I stop"),
    (re.compile(r"\bI am quitting\b", re.I), "I quit"),
    (re.compile(r"\bI am giving up\b", re.I), "I quit"),
    (re.compile(r"\bI am not giving up\b", re.I), "I wont quit"),
    (re.compile(r"\bI am not going to\b", re.I), "I wont"),
    (re.compile(r"\bI am not about to\b", re.I), "I wont"),
    (re.compile(r"\bI am not supposed to\b", re.I), "I shouldnt"),
    (re.compile(r"\bI am not expected to\b", re.I), "I shouldnt"),
    (re.compile(r"\bI am not required to\b", re.I), "I dont have to"),
    (re.compile(r"\bI am not forced to\b", re.I), "I dont have to"),
    (re.compile(r"\bI am not willing to\b", re.I), "I wont"),
    (re.compile(r"\bI am not ready to\b", re.I), "I wont"),
    (re.compile(r"\bI am not prepared to\b", re.I), "I wont"),
    (re.compile(r"\bI am not determined to\b", re.I), "I wont"),
    (re.compile(r"\bI am not trying to\b", re.I), "I dont try"),
    (re.compile(r"\bI am not planning to\b", re.I), "I dont plan"),
    (re.compile(r"\bI am not hoping to\b", re.I), "I dont hope"),
    (re.compile(r"\bI am not wanting to\b", re.I), "I dont want"),
    (re.compile(r"\bI am not needing to\b", re.I), "I dont need"),
    (re.compile(r"\bI am not getting\b", re.I), "I dont get"),
    (re.compile(r"\bI am not becoming\b", re.I), "I dont become"),
    (re.compile(r"\bI am not starting to\b", re.I), "I dont start"),
    (re.compile(r"\bI am not beginning to\b", re.I), "I dont begin"),
    (re.compile(r"\bI am not continuing to\b", re.I), "I dont continue"),
    (re.compile(r"\bI am not stopping\b", re.I), "I dont stop"),
    (re.compile(r"\bI am not quitting\b", re.I), "I dont quit"),
    (re.compile(r"\bthat is\b", re.I), "thats"),
    (re.compile(r"\bthere is\b", re.I), "theres"),
    (re.compile(r"\bwho is\b", re.I), "whos"),
    (re.compile(r"\bwhat is\b", re.I), "whats"),
    (re.compile(r"\bwhere is\b", re.I), "wheres"),
    (re.compile(r"\bwhen is\b", re.I), "whens"),
    (re.compile(r"\bwhy is\b", re.I), "whys"),
    (re.compile(r"\bhow is\b", re.I), "hows"),
    (re.compile(r"\bit has\b", re.I), "its"),
    (re.compile(r"\bshe has\b", re.I), "shes"),
    (re.compile(r"\bhe has\b", re.I), "hes"),
    (re.compile(r"\bwe have\b", re.I), "weve"),
    (re.compile(r"\bthey have\b", re.I), "theyve"),
    (re.compile(r"\byou have\b", re.I), "youve"),
    (re.compile(r"\bI had\b", re.I), "Id"),
    (re.compile(r"\byou had\b", re.I), "youd"),
    (re.compile(r"\bhe had\b", re.I), "hed"),
    (re.compile(r"\bshe had\b", re.I), "shed"),
    (re.compile(r"\bwe had\b", re.I), "wed"),
    (re.compile(r"\bthey had\b", re.I), "theyd"),
    (re.compile(r"\bI would have\b", re.I), "Idve"),
    (re.compile(r"\bI could have\b", re.I), "I couldve"),
    (re.compile(r"\bI should have\b", re.I), "I shouldve"),
    (re.compile(r"\bI might have\b", re.I), "I mightve"),
    (re.compile(r"\bI must have\b", re.I), "I mustve"),
    (re.compile(r"\byou would have\b", re.I), "youdve"),
    (re.compile(r"\bhe would have\b", re.I), "hedve"),
    (re.compile(r"\bshe would have\b", re.I), "shedve"),
    (re.compile(r"\bwe would have\b", re.I), "wedve"),
    (re.compile(r"\bthey would have\b", re.I), "theydve"),
    (re.compile(r"\bshould not have\b", re.I), "shouldntve"),
    (re.compile(r"\bcould not have\b", re.I), "couldntve"),
    (re.compile(r"\bwould not have\b", re.I), "wouldntve"),
    (re.compile(r"\bmust not have\b", re.I), "mustntve"),
    (re.compile(r"\bmight not have\b", re.I), "mightntve"),
    (re.compile(r"\bthat would be\b", re.I), "thatd be"),
    (re.compile(r"\bit would be\b", re.I), "itd be"),
    (re.compile(r"\bthere would be\b", re.I), "thered be"),
    (re.compile(r"\bthere will be\b", re.I), "therell be"),
    (re.compile(r"\bthat will be\b", re.I), "thatll be"),
    (re.compile(r"\bit will be\b", re.I), "itll be"),
    (re.compile(r"\bwho will be\b", re.I), "wholl be"),
    (re.compile(r"\bwhat will be\b", re.I), "whatll be"),
    (re.compile(r"\bwhich will be\b", re.I), "whichll be"),
    (re.compile(r"\bshe will be\b", re.I), "shell be"),
    (re.compile(r"\bhe will be\b", re.I), "hell be"),
    (re.compile(r"\bwe will be\b", re.I), "well be"),
    (re.compile(r"\bthey will be\b", re.I), "theyll be"),
    (re.compile(r"\byou will be\b", re.I), "youll be"),
    (re.compile(r"\bI will be\b", re.I), "Ill be"),
    (re.compile(r"\bI will have\b", re.I), "Ill have"),
    (re.compile(r"\byou will have\b", re.I), "youll have"),
    (re.compile(r"\bhe will have\b", re.I), "hell have"),
    (re.compile(r"\bshe will have\b", re.I), "shell have"),
    (re.compile(r"\bwe will have\b", re.I), "well have"),
    (re.compile(r"\bthey will have\b", re.I), "theyll have"),
    (re.compile(r"\bthere will have\b", re.I), "therell have"),
    (re.compile(r"\bthat will have\b", re.I), "thatll have"),
    (re.compile(r"\bit will have\b", re.I), "itll have"),
    (re.compile(r"\bwho will have\b", re.I), "wholl have"),
    (re.compile(r"\bwhat will have\b", re.I), "whatll have"),
    (re.compile(r"\bwhich will have\b", re.I), "whichll have"),
    (re.compile(r"\bnot at all\b", re.I), "nah"),
    (re.compile(r"\bnot really\b", re.I), "nah"),
    (re.compile(r"\bnot exactly\b", re.I), "nah"),
    (re.compile(r"\bnot quite\b", re.I), "nah"),
    (re.compile(r"\bnot so much\b", re.I), "nah"),
    (re.compile(r"\bnot so\b", re.I), "nah"),
    (re.compile(r"\bnot really\b", re.I), "nah"),
    (re.compile(r"\bnot particularly\b", re.I), "nah"),
    (re.compile(r"\bnot especially\b", re.I), "nah"),
    (re.compile(r"\bnot specially\b", re.I), "nah"),
    (re.compile(r"\bnot specifically\b", re.I), "nah"),
    (re.compile(r"\bnot especially\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in particular\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
    (re.compile(r"\bnot in general\b", re.I), "nah"),
]

def visible_len(text):
    return len(CONTROL_CODE.sub("", text))

def byte_len(text):
    """Estimate the encoded byte length of text.
    Control codes {XXXX} = 2 bytes each (encoded as raw bytes).
    ASCII chars = 1 byte, SJIS chars = 2 bytes."""
    result = 0
    for m in re.finditer(r"\{[0-9a-fA-F]+\}|.", text):
        token = m.group(0)
        if token.startswith("{"):
            result += 2  # control codes encode as 2 bytes
        else:
            if ord(token) > 0x7F:
                result += 2  # SJIS
            else:
                result += 1  # ASCII
    return result

def split_text_controls(text):
    """Split into list of (type, value) where type is 'text' or 'ctrl'."""
    tokens = []
    last = 0
    for m in CONTROL_CODE.finditer(text):
        if m.start() > last:
            tokens.append(("text", text[last:m.start()]))
        tokens.append(("ctrl", m.group(0)))
        last = m.end()
    if last < len(text):
        tokens.append(("text", text[last:]))
    return tokens

def join_text_controls(tokens):
    return "".join(v for _, v in tokens)

def redistribute_control_codes(eng_text, jp_text):
    """Redistribute control codes from the original Japanese text into the English translation.
    
    The game engine has a per-line display buffer (~30 chars). If all English text is in one
    segment before the control codes, it overflows. This function breaks the English text
    into segments that match the original Japanese line structure.
    
    Returns the English text with control codes properly interspersed."""
    # Parse Japanese text into segments and control codes
    jp_tokens = split_text_controls(jp_text)
    
    # Build a template: list of (segment_length, [control_codes_after_segment])
    # from the original Japanese text
    template = []
    cur_len = 0
    cur_ctrls = []
    for typ, val in jp_tokens:
        if typ == "text":
            if cur_len > 0 or cur_ctrls:
                template.append((cur_len, cur_ctrls))
                cur_ctrls = []
            cur_len = len(val.strip())
        else:
            cur_ctrls.append(val)
    # Don't forget the last segment
    if cur_len > 0 or cur_ctrls:
        template.append((cur_len, cur_ctrls))
    
    if len(template) <= 1:
        return eng_text  # single segment, no redistribution needed
    
    # Parse English text: check if control codes are already interspersed
    eng_ctrls = list(CONTROL_CODE.finditer(eng_text))
    if not eng_ctrls:
        return eng_text
    
    # Check if already interspersed
    for i in range(len(eng_ctrls) - 1):
        between = eng_text[eng_ctrls[i].end():eng_ctrls[i+1].start()]
        if len(between.strip()) > 2:
            return eng_text  # already has text between control codes
    
    # Get English visible text (before first control code)
    eng_visible = eng_text[:eng_ctrls[0].start()].strip()
    eng_trailing = [m.group(0) for m in eng_ctrls]
    
    words = eng_visible.split()
    if len(words) < len(template):
        return eng_text  # not enough words to split into segments
    
    # Distribute words proportionally based on Japanese segment lengths
    total_jp = sum(l for l, _ in template)
    if total_jp == 0:
        return eng_text
    
    result = []
    word_idx = 0
    for i, (seg_len, seg_ctrls) in enumerate(template):
        remaining_segs = len(template) - i
        if remaining_segs > 1:
            proportion = seg_len / total_jp
            num_words = max(1, round(proportion * len(words)))
            num_words = min(num_words, len(words) - word_idx - (remaining_segs - 1))
            num_words = max(1, num_words)
        else:
            num_words = len(words) - word_idx
        
        if word_idx < len(words) and num_words > 0:
            seg_words = words[word_idx:word_idx + num_words]
            word_idx += num_words
            if seg_len > 0:
                result.append(" ".join(seg_words))
        
        # Add control codes from the Japanese template for this segment
        for cc in seg_ctrls:
            result.append(cc)
    
    # Add any remaining words
    if word_idx < len(words):
        result.append(" ".join(words[word_idx:]))
    
    # Add any remaining English control codes not covered by the template
    total_template_ctrls = sum(len(cs) for _, cs in template)
    if len(eng_trailing) > total_template_ctrls:
        for i in range(total_template_ctrls, len(eng_trailing)):
            result.append(eng_trailing[i])
    
    return "".join(result)

def apply_passes(text, passes):
    """Apply a list of (regex, replacement) to text segments, preserving control codes.
    Single pass only - no re-iteration for speed."""
    tokens = split_text_controls(text)
    new_tokens = []
    for typ, val in tokens:
        if typ == "text":
            new_val = val
            for rx, repl in passes:
                new_val = rx.sub(repl, new_val)
            new_val = re.sub(r"  +", " ", new_val)
            new_val = re.sub(r" ,", ",", new_val)
            new_val = re.sub(r" \.", ".", new_val)
            new_val = re.sub(r" \?", "?", new_val)
            new_val = re.sub(r" !", "!", new_val)
            new_val = re.sub(r" ;", ";", new_val)
            new_val = re.sub(r" :", ":", new_val)
            new_tokens.append(("text", new_val))
        else:
            new_tokens.append((typ, val))
    result = join_text_controls(new_tokens)
    result = re.sub(r" \{7f02\}", "{7f02}", result)
    result = re.sub(r"\{7f02\} ", "{7f02}", result)
    result = re.sub(r" \{7f0a\}", "{7f0a}", result)
    result = re.sub(r"\{7f0a\} ", "{7f0a}", result)
    result = re.sub(r" \{7f0b\}", "{7f0b}", result)
    result = re.sub(r"\{7f0b\} ", "{7f0b}", result)
    result = re.sub(r"  +", " ", result).strip()
    return result

def truncate_smart(text, max_len):
    """Truncate text to max_len visible chars, trying to break at sentence/clause boundary."""
    has_term = TERMINATOR.search(text)
    suffix = "{0000}" if has_term else ""
    if suffix:
        text = text[:-6]

    # Extract trailing control codes (after last visible char) to preserve them
    # These are critical game formatting codes ({7f0a} page break, {7f0b} end dialogue, etc.)
    trailing_ctrls = ""
    ctrl_match = re.search(r"(\{[0-9a-fA-F]+\})+$", text)
    if ctrl_match:
        trailing_ctrls = ctrl_match.group(0)
        text = text[:ctrl_match.start()]

    vlen = visible_len(text)
    if vlen <= max_len:
        return text + trailing_ctrls + suffix

    # Try to find a sentence boundary (. ! ?) before max_len
    visible = CONTROL_CODE.sub("", text)
    # Find last sentence end before max_len
    best_break = -1
    for i in range(min(max_len, len(visible)) - 1, 0, -1):
        if visible[i] in ".!?":
            # Include the punctuation
            best_break = i + 1
            break

    if best_break > max_len // 2:
        # Rebuild text up to visible position best_break
        result = []
        v_count = 0
        for m in re.finditer(r"[^{}]+|\{[0-9a-fA-F]+\}", text):
            token = m.group(0)
            if token.startswith("{"):
                if v_count < best_break:
                    result.append(token)
            else:
                take = best_break - v_count
                if take <= 0:
                    break
                if take >= len(token):
                    result.append(token)
                    v_count += len(token)
                else:
                    result.append(token[:take])
                    v_count += take
                    break
        truncated = "".join(result).strip()
        return truncated + trailing_ctrls + suffix

    # Try clause boundary (comma, semicolon)
    for i in range(min(max_len, len(visible)) - 1, 0, -1):
        if visible[i] in ",;:":
            best_break = i
            break

    if best_break > max_len // 3:
        result = []
        v_count = 0
        for m in re.finditer(r"[^{}]+|\{[0-9a-fA-F]+\}", text):
            token = m.group(0)
            if token.startswith("{"):
                if v_count < best_break:
                    result.append(token)
            else:
                take = best_break - v_count
                if take <= 0:
                    break
                if take >= len(token):
                    result.append(token)
                    v_count += len(token)
                else:
                    result.append(token[:take])
                    v_count += take
                    break
        truncated = "".join(result).strip().rstrip(",;:")
        return truncated + trailing_ctrls + suffix

    # Try word boundary
    truncated_visible = visible[:max_len]
    last_space = truncated_visible.rfind(" ")
    if last_space > max_len // 4:
        truncated_visible = truncated_visible[:last_space]

    # Rebuild with control codes
    result = []
    v_count = 0
    for m in re.finditer(r"[^{}]+|\{[0-9a-fA-F]+\}", text):
        token = m.group(0)
        if token.startswith("{"):
            if v_count < len(truncated_visible):
                result.append(token)
        else:
            take = len(truncated_visible) - v_count
            if take <= 0:
                break
            if take >= len(token):
                result.append(token)
                v_count += len(token)
            else:
                result.append(token[:take])
                v_count += take
                break
    truncated = "".join(result).strip()
    return truncated + trailing_ctrls + suffix

def compress_story_line(text, max_len):
    """Progressively compress a story line to fit within max_len visible chars."""
    if visible_len(text) <= max_len:
        return text, 0

    # Pass 1: Contractions
    text = apply_passes(text, CONTRACTIONS)
    if visible_len(text) <= max_len:
        return text, 1

    # Pass 2: Filler drops
    text = apply_passes(text, FILLER_DROPS)
    if visible_len(text) <= max_len:
        return text, 2

    # Pass 3: Article drops
    text = apply_passes(text, ARTICLE_DROPS)
    if visible_len(text) <= max_len:
        return text, 3

    # Pass 4: Phrase shorts
    text = apply_passes(text, PHRASE_SHORTS)
    if visible_len(text) <= max_len:
        return text, 4

    # Pass 5: Pronoun drops
    text = apply_passes(text, PRONOUN_DROPS)
    if visible_len(text) <= max_len:
        return text, 5

    # Pass 5c: Aggressive adverb removal
    text = apply_passes(text, ADVERB_DROPS)
    if visible_len(text) <= max_len:
        return text, 51

    # Pass 5d: Preposition removal
    text = apply_passes(text, PREP_DROPS)
    if visible_len(text) <= max_len:
        return text, 52

    # Pass 5e: Conjunction removal
    text = apply_passes(text, CONJ_DROPS)
    if visible_len(text) <= max_len:
        return text, 53

    # Pass 5f: Trollwave phrase replacements
    text = apply_passes(text, TROLLWAVE)
    if visible_len(text) <= max_len:
        return text, 54

    # Pass 5b: Cyberpunk disemvowel
    text = disemvowel_text(text)
    if visible_len(text) <= max_len:
        return text, 55

    # Pass 6: Smart truncation
    text = truncate_smart(text, max_len)
    if visible_len(text) <= max_len:
        return text, 6

    # Pass 7: Hard truncate (shouldn't reach here normally)
    text = truncate_smart(text, max_len - 3)
    return text, 7

def translate_system_segment(seg, mapping):
    """Translate a Japanese segment to short English menu term."""
    seg = seg.replace("\u3000", " ").strip()
    if not seg:
        return seg
    if seg in MENU_SHORT:
        return MENU_SHORT[seg]
    clean = CONTROL_CODE.sub("", seg).strip()
    if clean in mapping:
        eng = mapping[clean].strip()
        eng = re.sub(r"\{0000\}$", "", eng)
        if len(eng) > 10:
            words = eng.split()
            if len(words) > 1:
                first = words[0]
                if len(first) <= 8:
                    return first
            return eng[:10].rstrip()
        return eng
    if all(ord(c) < 0x3000 for c in seg):
        return seg[:8].strip()
    return seg[:6].strip() if seg.strip() else ""

def rewrite_system_line(jp_text, mapping):
    """Preserve control codes, replace each visible segment with short English."""
    tokens = split_text_controls(jp_text)
    out = []
    for typ, val in tokens:
        if typ == "ctrl":
            out.append(val)
        else:
            if val.strip():
                out.append(translate_system_segment(val, mapping))
            else:
                out.append(val)
    return "".join(out)

def classify_block(rows):
    """Classify block as 'system' or 'story'."""
    if not rows:
        return "system"
    total = len(rows)
    avg_len = sum(len(r.get("original", "")) for r in rows) / total
    has_7f0a = sum(1 for r in rows if "{7f0a}" in r.get("original", ""))
    has_7e = sum(1 for r in rows if "{7e" in r.get("original", ""))
    if avg_len < 40 and has_7f0a == 0 and has_7e == 0:
        return "system"
    return "story"

def load_csv_data():
    """Load original Japanese text, visible lengths, and byte lengths from CSVs."""
    orig_text = {}
    orig_len = {}
    orig_bytes = {}
    block_rows = {}
    for csv_path in sorted(glob.glob(os.path.join(CSV_DIR, "*.csv"))):
        block_id = os.path.basename(csv_path).replace(".csv", "").lower()
        with open(csv_path, encoding="utf-8") as f:
            rows = list(csv.DictReader(f))
        block_rows[block_id] = rows
        for row in rows:
            ln = row["lineNumber"]
            orig = row.get("original", "")
            orig_text[(block_id, ln)] = orig
            orig_len[(block_id, ln)] = visible_len(orig)
            orig_bytes[(block_id, ln)] = byte_len(orig)
    return orig_text, orig_len, orig_bytes, block_rows

def main():
    print("Loading original translations...", flush=True)
    with open(FT_ORIG_PATH, encoding="utf-8") as f:
        ft_orig = json.load(f)

    mapping_path = r"C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\translation\translation_mapping.json"
    print("Loading JP->EN mapping...", flush=True)
    with open(mapping_path, encoding="utf-8") as f:
        mapping = json.load(f)

    print("Loading CSV data...", flush=True)
    orig_text, orig_len, orig_bytes, block_rows = load_csv_data()

    # Classify blocks
    block_type = {}
    for bid, rows in block_rows.items():
        block_type[bid] = classify_block(rows)

    system_count = sum(1 for v in block_type.values() if v == "system")
    story_count = sum(1 for v in block_type.values() if v == "story")
    print(f"System blocks: {system_count}, Story blocks: {story_count}", flush=True)

    # Process blocks in batches, writing results incrementally
    all_block_ids = sorted(ft_orig.keys())
    total_blocks = len(all_block_ids)

    stats = {
        "total": 0,
        "system_lines": 0,
        "story_lines": 0,
        "story_fits_as_is": 0,
        "story_pass0": 0, "story_pass1": 0, "story_pass2": 0, "story_pass3": 0,
        "story_pass4": 0, "story_pass5": 0, "story_pass51": 0, "story_pass52": 0,
        "story_pass53": 0, "story_pass54": 0, "story_pass55": 0, "story_pass6": 0, "story_pass7": 0,
        "still_over": 0,
    }
    overflow_before = []
    overflow_after = []

    # Build output dict incrementally
    ft_out = {}

    for batch_start in range(0, total_blocks, BATCH_SIZE):
        batch_end = min(batch_start + BATCH_SIZE, total_blocks)
        batch_ids = all_block_ids[batch_start:batch_end]

        for block_id in batch_ids:
            btype = block_type.get(block_id, "story")
            block_data = {}

            for ln, entry in ft_orig[block_id].items():
                stats["total"] += 1
                trans = entry.get("translation", "")
                if not trans:
                    block_data[ln] = entry
                    continue

                # Clean up unsupported Unicode characters
                # (only for English text — Japanese fallback uses original CSV text which is safe)
                trans = trans.replace("\u2019", "'")   # right single quote -> '
                trans = trans.replace("\u2018", "'")   # left single quote -> '
                trans = trans.replace("\u201c", "\"")  # left double quote -> "
                trans = trans.replace("\u201d", "\"")  # right double quote -> "
                trans = trans.replace("\u2014", "--")  # em dash -> --
                trans = trans.replace("\u2013", "-")   # en dash -> -
                trans = trans.replace("\u2026", "...") # ellipsis -> ...
                trans = trans.replace("\u00a0", " ")   # nbsp -> space
                entry = dict(entry)
                entry["translation"] = trans

                key = (block_id, ln)
                if key not in orig_len:
                    block_data[ln] = entry
                    continue

                # Redistribute control codes to match original Japanese line structure
                # This prevents per-line buffer overflows in the game engine
                jp_orig = orig_text.get(key, "")
                if jp_orig and trans:
                    trans = redistribute_control_codes(trans, jp_orig)
                    entry["translation"] = trans

                # Use visible char count for budgeting (NOT byte count).
                # The game display buffer is based on visible chars, not bytes.
                # Japanese SJIS = 2 bytes/char, English ASCII = 1 byte/char.
                # Budgeting by bytes lets English be 2x too long for the display buffer.
                max_vis = orig_len[key]  # Japanese visible char count
                # Huffman grace: English ASCII compresses better than SJIS kanji,
                # so we get ~30% extra headroom for short entries
                if max_vis <= 30:
                    max_vis = int(max_vis * 1.3)

                if btype == "system":
                    stats["system_lines"] += 1
                else:
                    stats["story_lines"] += 1

                eng_vis = visible_len(trans)
                if eng_vis <= max_vis:
                    stats["story_fits_as_is"] += 1
                else:
                    if len(overflow_before) < 30:
                        overflow_before.append((block_id, ln, max_vis, eng_vis, trans[:100]))

                    # Always compress — never fall back to Japanese
                    new_trans, pass_num = compress_story_line(trans, max_vis)
                    entry = dict(entry)
                    entry["translation"] = new_trans
                    stats[f"story_pass{pass_num}"] += 1

                    new_vis = visible_len(new_trans)
                    if new_vis > max_vis:
                        stats["still_over"] += 1
                        if len(overflow_after) < 30:
                            overflow_after.append((block_id, ln, max_vis, new_vis, new_trans[:100]))

                # Safety: remove middle {0000} terminators - only keep the final one
                # Middle {0000} creates extra sequences causing patcher mismatch errors
                cur_trans = entry.get("translation", "")
                if cur_trans.count("{0000}") > 1:
                    parts = cur_trans.split("{0000}")
                    entry = dict(entry)
                    entry["translation"] = parts[0] + "{0000}" + parts[-1]

                block_data[ln] = entry

            # Per-block Huffman safety: only pad if the ENTIRE block has < 3 unique
            # alpha chars. The Huffman tree is shared across all entries in the block.
            # Note: padding is disabled because it causes Huffman roundtrip failures
            # in the patcher. Degenerate blocks will be skipped by the patcher instead.
            # all_vis = CONTROL_CODE.sub("", " ".join(
            #     e.get("translation", "") for e in block_data.values()
            # )).strip()
            # block_alpha = set(c for c in all_vis if c.isalpha())
            # if len(block_alpha) < 3:
            #     first_ln = next(iter(block_data))
            #     entry = dict(block_data[first_ln])
            #     entry["translation"] = "abc " + entry.get("translation", "")
            #     block_data[first_ln] = entry

            ft_out[block_id] = block_data

        print(f"  Processed {batch_end}/{total_blocks} blocks ({stats['story_lines']} story, {stats['system_lines']} system)...", flush=True)

    print("Writing output JSON...", flush=True)
    with open(OUT_PATH, "w", encoding="utf-8") as f:
        json.dump(ft_out, f, ensure_ascii=False, indent=0)

    print("Writing report...", flush=True)
    report = []
    report.append("=== Hybrid Playable Translation Report ===\n\n")
    report.append(f"Total entries: {stats['total']}\n")
    report.append(f"System lines (menu truncation): {stats['system_lines']}\n")
    report.append(f"Story lines: {stats['story_lines']}\n")
    report.append(f"  Fits as-is: {stats['story_fits_as_is']}\n")
    report.append(f"  Pass 1 (contractions): {stats['story_pass1']}\n")
    report.append(f"  Pass 2 (filler drop): {stats['story_pass2']}\n")
    report.append(f"  Pass 3 (article drop): {stats['story_pass3']}\n")
    report.append(f"  Pass 4 (phrase short): {stats['story_pass4']}\n")
    report.append(f"  Pass 5 (pronoun drop): {stats['story_pass5']}\n")
    report.append(f"  Pass 5c (adverb drop): {stats['story_pass51']}\n")
    report.append(f"  Pass 5d (prep drop): {stats['story_pass52']}\n")
    report.append(f"  Pass 5e (conj drop): {stats['story_pass53']}\n")
    report.append(f"  Pass 5f (trollwave): {stats['story_pass54']}\n")
    report.append(f"  Pass 5b (disemvowel): {stats['story_pass55']}\n")
    report.append(f"  Pass 6 (smart truncate): {stats['story_pass6']}\n")
    report.append(f"  Pass 7 (hard truncate): {stats['story_pass7']}\n")
    report.append(f"  STILL OVER BUDGET: {stats['still_over']}\n\n")

    report.append("--- Before compression (samples) ---\n")
    for b, l, jp, en, t in overflow_before:
        report.append(f"  {b}:{l} jp={jp} en={en} | {t}\n")

    report.append("\n--- After compression (samples) ---\n")
    for b, l, jp, en, t in overflow_after:
        report.append(f"  {b}:{l} jp={jp} en={en} | {t}\n")

    with open(REPORT_PATH, "w", encoding="utf-8") as f:
        f.writelines(report)

    print(f"\nOutput: {OUT_PATH}", flush=True)
    print(f"Report: {REPORT_PATH}", flush=True)
    print(f"\nStats:", flush=True)
    print(f"  System lines: {stats['system_lines']}", flush=True)
    print(f"  Story lines: {stats['story_lines']}", flush=True)
    print(f"    Fits as-is: {stats['story_fits_as_is']}", flush=True)
    print(f"    Pass 1-7: {stats['story_pass1']}, {stats['story_pass2']}, {stats['story_pass3']}, {stats['story_pass4']}, {stats['story_pass5']}, {stats['story_pass51']}, {stats['story_pass52']}, {stats['story_pass53']}, {stats['story_pass54']}, {stats['story_pass55']}, {stats['story_pass6']}, {stats['story_pass7']}", flush=True)
    print(f"    STILL OVER: {stats['still_over']}", flush=True)

if __name__ == "__main__":
    main()
