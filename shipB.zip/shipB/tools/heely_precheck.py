#!/usr/bin/env python3
"""
heely_precheck.py — Static validator for Heely/Izmit map overlay alignment.

Verifies that the Heely map overlay and dialogue sectors are properly aligned
and terminated before the ISO is generated.  This is a PRE-RAM-DUMP static
analysis tool: it checks the disc image for structural integrity without
requiring a live DuckStation session.

Checks performed:
  1. ISO TOC integrity: verify the HBD archive LBA and sector count.
  2. Overlay sector alignment: verify that map overlay files are sector-aligned
     and that no sector padding errors were introduced during the build.
  3. 048B block integrity: verify the battle overlay block header is valid
     and the Huffman tree is parseable.
  4. 048F block integrity: verify the EXE-resident church/priest block is
     intact and all freeze tokens are present.
  5. NPC script termination: scan for malformed control codes or missing
     {0000} terminators in the dialogue blocks referenced by town maps.
  6. DMA alignment: verify that all archive sectors are 2048-byte aligned
     within the MODE2/2352 container (user data at offset 24, 2048 bytes).
  7. Message module protection: verify that no patch step wrote data into the
     0x80011F00-0x80012EFF region (the resident message module).
  8. 048C delta-lock: verify bit-offset deltas for SIDs 773-778.
  9. Level sector table: verify the EXE-resident map jump table (3,283 entries
     at offset 0x935F4-0x9693C) is intact — every entry's LBA points to a valid
     HBD block header with matching sector count.  This is the table the engine
     uses for EV_MAP_JUMP opcodes (stairs/doors/warps).  A corrupted entry here
     causes the CD drive to seek a misaligned sector and spin in an infinite
     wait loop (0x1F8010F0 busy flag never clears) — the Heely stairs freeze.
 10. Sub-map overlay boundary: verify that no HBD block crosses a sector
     boundary that would shift its data past the entry declared in the level
     sector table.  This catches the case where a text re-encode grew a block
     by a few bytes, pushing sub-map geometry/collision data past the sector
     count the engine expects to DMA.

Usage:
  python heely_precheck.py --disc <master.bin>
  python heely_precheck.py --disc <master.bin> --base <pristine.bin>
  python heely_precheck.py --disc <master.bin> --base <pristine.bin> --save-baseline <path.json>
  python heely_precheck.py --disc <master.bin> --base <pristine.bin> --json <path.json>
"""

import argparse
import hashlib
import json
import os
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")
sys.stderr.reconfigure(encoding="utf-8")

# --- psx_tools integration ---
_REPO = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
_PSX_TOOLS = os.path.join(_REPO, "psx_tools")
if os.path.isdir(_PSX_TOOLS):
    sys.path.insert(0, _PSX_TOOLS)
try:
    from dq4 import sectortable as ST
    from dq4 import hbd as HBD_MOD
    _HAVE_PSX_TOOLS = True
except Exception:
    _HAVE_PSX_TOOLS = False

RAW = 2352
UOFF = 24
USZ = 2048

# --- DQ4 disc geometry ---
HBD_LBA = 362           # HBD archive starts at LBA 362
EXE_LBA = 24            # SLPM_869.16 starts at LBA 24
EXE_SECTORS = 338       # EXE spans 338 sectors
EXE_SIZE = EXE_SECTORS * USZ
RAM_BASE = 0x80017700   # PS-X EXE load address (t_addr - 0x800)

# --- Block IDs ---
BLOCK_048B = 0x048B     # Battle overlay (archive-resident)
BLOCK_048C = 0x048C     # Font 1 menus/items (EXE-resident)
BLOCK_048F = 0x048F     # Church/priest save-load (EXE-resident)

# --- 048F block offset in EXE ---
BLOCK_048F_OFF = 0x99624

# --- Freeze tokens that must be present in 048F ---
FREEZE_TOKENS = [0x7F06, 0x7F10, 0x7F19, 0x7F1B, 0x7F1C, 0x7F1E, 0x7F35]

# --- Message module protection zone (RAM addresses) ---
MSG_MODULE_START = 0x80011F00
MSG_MODULE_END   = 0x80012EFF
MSG_MODULE_EXE_START = MSG_MODULE_START - RAM_BASE  # 0x9800
MSG_MODULE_EXE_END   = MSG_MODULE_END - RAM_BASE    # 0xA7FF

# --- Control codes ---
CTRL_LINE_BREAK = 0x7F01
CTRL_BOX_WAIT   = 0x7F02
CTRL_PAGE_BREAK_A = 0x7F0A
CTRL_PAGE_BREAK_B = 0x7F0B
CTRL_TERMINATOR = 0x0000

# --- Level sector table (EXE-resident map jump table) ---
# See psx_tools/dq4/sectortable.py for full format details.
# The engine uses this table for EV_MAP_JUMP opcodes (stairs, doors, warps).
# Each entry: (flag_bit << 31) | (length << 20) | disc_lba
#   length: 11-bit sector count (0x7FF max = 2047 sectors)
#   lba:    20-bit absolute disc LBA (0xFFFFF max)
#   flag:   bit 31, set on 2 entries that read as KSEG0 addresses
SECTOR_TABLE_START = 0x935F4
SECTOR_TABLE_END   = 0x9693C
SECTOR_TABLE_ENTRY_COUNT = (SECTOR_TABLE_END - SECTOR_TABLE_START) // 4 + 1  # 3283
ARCHIVE_LBA_BASE   = 362
LEN_SHIFT = 20
LEN_MASK  = 0x7FF
LBA_MASK  = 0xFFFFF
FLAG_BIT  = 0x80000000
FLAGGED_INDEXES = (3281, 3282)

# --- Baseline artifact path (stored by STEP -2, consumed by STEP 6c) ---
BASELINE_JSON = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(
    os.path.abspath(__file__)))), "study", "heely_baseline.json")


def read_sector(disc_path, lba, count=1):
    """Read user data from one or more sectors."""
    data = bytearray()
    with open(disc_path, "rb") as f:
        for i in range(count):
            f.seek((lba + i) * RAW + UOFF)
            data.extend(f.read(USZ))
    return bytes(data)


def read_exe(disc_path):
    """Read the full EXE from the disc."""
    return read_sector(disc_path, EXE_LBA, EXE_SECTORS)[:EXE_SIZE]


def find_block_in_exe(exe_data, block_id):
    """Find a block by its ID within the EXE data.

    Returns (offset, (end, bid, hts, te, txe, unk)) or (None, None).
    """
    for x in range(0, len(exe_data) - 24, 4):
        end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe_data, x)
        if (bid & 0xFFFF) == block_id and hts == 24 and 24 < txe < end <= 8192:
            return x, (end, bid, hts, te, txe, unk)
    return None, None


def find_block_048b_in_archive(disc_path):
    """Find the 048B block in the HBD archive on disc.

    Returns (sector, user_offset, header) or (None, None, None).
    """
    target = b"\x8b\x04\x00\x00\x18\x00\x00\x00"
    with open(disc_path, "rb") as f:
        f.seek(105000 * RAW)
        raw = f.read(1500 * RAW)
        u_data = bytearray()
        for i in range(1500):
            u_data.extend(raw[i * RAW + UOFF: i * RAW + UOFF + USZ])
        idx = u_data.find(target)
        if idx != -1:
            hdr_off = idx - 4
            sec = 105000 + (hdr_off // USZ)
            u_off = hdr_off % USZ
            hdr = struct.unpack_from("<6I", u_data, hdr_off)
            return sec, u_off, hdr
    return None, None, None


# --- Individual checks ---

def check_iso_toc(disc_path):
    """Check 1: ISO TOC integrity — HBD archive LBA and sector count."""
    issues = []
    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_size = f.tell()
        total_sectors = total_size // RAW

    if total_sectors < HBD_LBA + 1:
        issues.append("Disc too small: %d sectors (need > %d)" % (total_sectors, HBD_LBA))

    # Check that the HBD archive starts at LBA 362
    hbd_data = read_sector(disc_path, HBD_LBA, 1)
    if len(hbd_data) < 4:
        issues.append("Cannot read HBD archive header at LBA %d" % HBD_LBA)

    # Verify the EXE is at LBA 24
    exe_data = read_sector(disc_path, EXE_LBA, 1)
    if exe_data[:8] == b"PS-X EXE":
        pass  # EXE header found
    else:
        # Some DQ4 images don't have the PS-X EXE magic at the very start
        # of LBA 24; the actual EXE might be found via the ISO directory.
        issues.append("PS-X EXE magic not at LBA %d (may be directory-referenced)" % EXE_LBA)

    passed = len(issues) == 0
    return passed, issues


def check_overlay_alignment(disc_path):
    """Check 2: Overlay sector alignment — verify no padding errors."""
    issues = []

    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_sectors = f.tell() // RAW

    # Check that every sector in the HBD archive has valid sync/header
    # by spot-checking the first 12 bytes of each sector's raw data
    bad_sectors = []
    for sec in range(HBD_LBA, min(HBD_LBA + 100, total_sectors)):
        with open(disc_path, "rb") as f:
            f.seek(sec * RAW)
            raw_header = f.read(12)
        # MODE2/2352 sectors start with 0x00FFFFFFFFFFFFFF00 (sync)
        if raw_header[:12] != b"\x00\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x00":
            # Not all sectors may have sync (form 2 sectors can differ)
            # Only flag if the user data area is all-zero (padding artifact)
            user_data = read_sector(disc_path, sec, 1)
            if all(b == 0 for b in user_data):
                bad_sectors.append(sec)

    if bad_sectors:
        issues.append("All-zero user data sectors in HBD archive: %s" %
                       ", ".join(str(s) for s in bad_sectors[:10]))

    passed = len(issues) == 0
    return passed, issues


def check_048b_block(disc_path):
    """Check 3: 048B block integrity — header valid, tree parseable."""
    issues = []

    sec, off, hdr = find_block_048b_in_archive(disc_path)
    if sec is None:
        issues.append("Block 0x048B not found in archive")
        return False, issues

    end, bid, hts, tre, txe, unk = hdr
    if (bid & 0xFFFF) != BLOCK_048B:
        issues.append("048B block ID mismatch: 0x%04X" % (bid & 0xFFFF))
    if hts != 24:
        issues.append("048B header size != 24 (got %d)" % hts)
    if txe <= 24 or txe >= end:
        issues.append("048B text end out of range: %d (end=%d)" % (txe, end))

    # Read the block data and try to parse the Huffman tree
    nsec = ((off + end + USZ - 1) // USZ) + 1
    block_data = read_sector(disc_path, sec, nsec)
    block_bytes = block_data[off:off + end]

    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
        from hbe.huffman.dq4 import DQ4Schema
        sc = DQ4Schema()
        tree_end_off = (tre if tre else end)
        tree_bytes = block_bytes[txe + 10:tree_end_off]
        tree = sc.parse_tree(tree_bytes)
        if tree is None:
            issues.append("048B Huffman tree parsed as None")
    except Exception as e:
        issues.append("048B Huffman tree parse error: %s" % str(e))

    passed = len(issues) == 0
    return passed, issues


def check_048f_block(disc_path):
    """Check 4: 048F block integrity — freeze tokens present."""
    issues = []

    exe = read_exe(disc_path)
    if len(exe) < BLOCK_048F_OFF + 4:
        issues.append("EXE too small for 048F block (need offset 0x%X, got %d)" % (BLOCK_048F_OFF, len(exe)))
        return False, issues

    end_048f = struct.unpack_from("<I", exe, BLOCK_048F_OFF)[0]
    blk_size = min(end_048f + 4, len(exe) - BLOCK_048F_OFF)
    block_data = exe[BLOCK_048F_OFF:BLOCK_048F_OFF + blk_size]

    missing_tokens = []
    for token in FREEZE_TOKENS:
        hi = (token >> 8) & 0xFF
        lo = token & 0xFF
        pattern = bytes([hi, lo])
        if pattern not in block_data:
            missing_tokens.append("0x%04X" % token)

    if missing_tokens:
        issues.append("Missing freeze tokens in 048F: %s" % ", ".join(missing_tokens))

    passed = len(issues) == 0
    return passed, issues


def check_npc_script_termination(disc_path):
    """Check 5: NPC script termination — scan for missing {0000} terminators.

    This checks the 048C block (Font 1) for strings that don't terminate
    with {0000}.  The 048B block is also checked.
    """
    issues = []

    exe = read_exe(disc_path)

    # Check 048C block
    o, hdr = find_block_in_exe(exe, BLOCK_048C)
    if o is not None:
        end, bid, hts, te, txe, unk = hdr
        try:
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
            from hbe.huffman.dq4 import DQ4Schema
            import dq4_hbd_patcher as P
            sc = DQ4Schema()
            tree_end_off = o + (te if te else end)
            tree = sc.parse_tree(exe[o + txe + 10:tree_end_off])
            leaves = sc.decode(exe[o + hts:o + txe], tree)

            # Check that every string ends with {0000}
            strings = []
            cur = []
            for l in leaves:
                cur.append(l)
                val = (l.content[0] << 8) | l.content[1]
                if val == 0:
                    strings.append(cur)
                    cur = []
            if cur:
                # Last string without terminator
                issues.append("048C: final string (SID %d) missing {0000} terminator" % len(strings))

            # Check for control codes without closing tokens
            for i, s in enumerate(strings):
                has_7f01 = any((l.content[0] << 8 | l.content[1]) == CTRL_LINE_BREAK for l in s)
                has_7f02 = any((l.content[0] << 8 | l.content[1]) == CTRL_BOX_WAIT for l in s)
                # Each {7F01} line break should be followed by more text or {7F02}/{0000}
                # This is a soft check — we flag strings that end with {7F01} without {7F02}/{0000}
                if s and (s[-1].content[0] << 8 | s[-1].content[1]) == CTRL_LINE_BREAK:
                    issues.append("048C SID %d ends with {7F01} (missing closing token)" % i)

        except Exception as e:
            issues.append("048C parse error during terminator check: %s" % str(e))
    else:
        issues.append("048C block not found in EXE")

    passed = len(issues) == 0
    return passed, issues


def check_dma_alignment(disc_path):
    """Check 6: DMA alignment — verify all archive sectors are 2048-byte aligned."""
    issues = []

    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_sectors = f.tell() // RAW

    # Spot-check: verify that user data in HBD sectors starts at offset 24
    # and is exactly 2048 bytes (no misaligned DMA reads)
    for sec in [HBD_LBA, HBD_LBA + 1, HBD_LBA + 100, HBD_LBA + 500]:
        if sec >= total_sectors:
            continue
        with open(disc_path, "rb") as f:
            f.seek(sec * RAW)
            raw = f.read(RAW)
        if len(raw) < RAW:
            issues.append("Sector %d: short read (%d < %d)" % (sec, len(raw), RAW))
            continue
        # Check MODE2 header: bytes 0-11 = sync, 12-15 = header, 16-23 = sub-header
        if raw[:4] != b"\x00\xff\xff\xff":
            # Not a standard MODE2 sync — could be a different mode
            pass  # Soft check, don't flag
        # Verify user data area is present
        user_data = raw[UOFF:UOFF + USZ]
        if len(user_data) != USZ:
            issues.append("Sector %d: user data area is %d bytes (expected %d)" %
                          (sec, len(user_data), USZ))

    passed = len(issues) == 0
    return passed, issues


def check_message_module_protection(disc_path):
    """Check 7: Message module protection — verify no patch wrote into the
    0x80011F00-0x80012EFF region of the EXE.

    The message module lives at RAM 0x80011F00-0x80012EFF, which maps to
    EXE file offsets 0x9800-0xA7FF.  No pipeline step should modify this
    region (it is the resident message module, not a text block).
    """
    issues = []

    exe = read_exe(disc_path)

    # The message module region in the EXE
    mod_start = MSG_MODULE_EXE_START
    mod_end = MSG_MODULE_EXE_END

    if mod_end > len(exe):
        issues.append("EXE too small for message module check")
        return False, issues

    # Check that the region contains code-like data (not zeros, not text)
    # We can't compare to pristine without the base, but we can check
    # that it's not obviously corrupted (all zeros or all 0xFF)
    region = exe[mod_start:mod_end]
    if all(b == 0 for b in region):
        issues.append("Message module region (0x%X-0x%X) is all zeros — likely clobbered" %
                      (mod_start, mod_end))
    if all(b == 0xFF for b in region):
        issues.append("Message module region (0x%X-0x%X) is all 0xFF — likely corrupted" %
                      (mod_start, mod_end))

    # Check for the specific clobber pattern: archive header at 0x80011F00
    # would be a 0x200-byte block of structured data.  If the first 16 bytes
    # look like a block header (end, bid, hts, ...), that's suspicious.
    if len(region) >= 24:
        end, bid, hts = struct.unpack_from("<3I", region, 0)
        if hts == 24 and 24 < (end & 0xFFFF) < 8192:
            # This looks like a text block header — the module may have been
            # clobbered by an archive header load
            issues.append("Message module region starts with block-like header "
                          "(end=%d, bid=0x%04X, hts=%d) — possible archive clobber" %
                          (end, bid & 0xFFFF, hts))

    passed = len(issues) == 0
    return passed, issues


def check_048c_delta_lock(disc_path):
    """Check 8: 048C delta-lock — verify bit-offset deltas for SIDs 773-778."""
    issues = []

    exe = read_exe(disc_path)
    o, hdr = find_block_in_exe(exe, BLOCK_048C)
    if o is None:
        issues.append("048C block not found in EXE")
        return False, issues

    end, bid, hts, te, txe, unk = hdr
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
        from hbe.huffman.dq4 import DQ4Schema
        import dq4_hbd_patcher as P
        sc = DQ4Schema()
        tree_end_off = o + (te if te else end)
        tree = sc.parse_tree(exe[o + txe + 10:tree_end_off])
        leaves = sc.decode(exe[o + hts:o + txe], tree)
        offsets = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]

        if len(offsets) < 779:
            issues.append("048C has only %d strings (need >= 779 for delta check)" % len(offsets))
            return False, issues

        deltas = {
            "774-773": offsets[774] - offsets[773],
            "776-775": offsets[776] - offsets[775],
            "777-775": offsets[777] - offsets[775],
            "778-775": offsets[778] - offsets[775],
        }
        expected = {"774-773": 44, "776-775": 36, "777-775": 50, "778-775": 66}
        for k, v in deltas.items():
            if v != expected[k]:
                issues.append("Delta %s = %d (expected %d) — DRIFT DETECTED" % (k, v, expected[k]))

    except Exception as e:
        issues.append("048C delta-lock check error: %s" % str(e))

    passed = len(issues) == 0
    return passed, issues


# --- Level sector table checks ---

def _parse_sector_table(exe):
    """Parse the level sector table from the EXE.
    Returns list of (offset, raw, length, lba, flag, archive_sector).
    """
    entries = []
    for off in range(SECTOR_TABLE_START, SECTOR_TABLE_END + 4, 4):
        v = struct.unpack_from("<I", exe, off)[0]
        length = (v >> LEN_SHIFT) & LEN_MASK
        lba = v & LBA_MASK
        flg = (v >> 31) & 1
        archive_sector = lba - ARCHIVE_LBA_BASE
        entries.append((off, v, length, lba, flg, archive_sector))
    return entries


def _read_hbd_archive(disc_path, max_sectors=200000):
    """Read the HBD archive user data from disc."""
    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_sectors = f.tell() // RAW
    nsec = min(max_sectors, total_sectors - HBD_LBA)
    return read_sector(disc_path, HBD_LBA, nsec)


def _scan_hbd_blocks(disc_path):
    """Scan the HBD archive for valid block headers.
    Returns {archive_sector: block_dict} keyed by sector within the archive.

    Delegates to psx_tools.dq4.hbd.scan_blocks() when available for canonical
    parsing, falling back to the inline parser otherwise.
    """
    arch = _read_hbd_archive(disc_path)
    if _HAVE_PSX_TOOLS:
        return HBD_MOD.scan_blocks(arch)
    # Fallback inline parser (same logic as hbd.parse_block)
    blocks = {}
    nsec = len(arch) // USZ
    for s in range(nsec):
        o = s * USZ
        if o + 16 > len(arch):
            break
        b = arch[o:o + 4]
        if b[1] or b[2] or b[3] or not b[0]:
            continue
        nsub, nsec_blk, total_len, zero = struct.unpack_from("<4I", arch, o)
        if zero != 0 or nsub == 0 or nsec_blk == 0:
            continue
        header = 16 + nsub * 16
        if o + header > len(arch):
            continue
        running = 0
        for i in range(nsub):
            so = o + 16 + i * 16
            dlen = struct.unpack_from("<I", arch, so)[0]
            running += dlen
        if running != total_len:
            continue
        if (header + total_len + USZ - 1) // USZ != nsec_blk:
            continue
        blocks[s] = {"sector": s, "nsub": nsub, "nsec": nsec_blk, "tlen": total_len}
    return blocks


def _compute_table_hash(exe):
    """SHA-256 of the raw sector table bytes (for baseline storage)."""
    table_bytes = exe[SECTOR_TABLE_START:SECTOR_TABLE_END + 4]
    return hashlib.sha256(table_bytes).hexdigest().upper()


def _block_map_summary(blocks):
    """Summarize block map as {sector: {nsec, nsub, tlen}} for JSON storage."""
    out = {}
    for sec, blk in sorted(blocks.items()):
        out[str(sec)] = {"nsec": blk["nsec"], "nsub": blk["nsub"], "tlen": blk["tlen"]}
    return out


def save_baseline(disc_path, baseline_path):
    """Save sector table hash + block allocation map to JSON for post-build diff."""
    exe = read_exe(disc_path)
    blocks = _scan_hbd_blocks(disc_path)
    table_hash = _compute_table_hash(exe)
    block_map = _block_map_summary(blocks)
    data = {
        "table_hash": table_hash,
        "table_start": SECTOR_TABLE_START,
        "table_end": SECTOR_TABLE_END,
        "entry_count": SECTOR_TABLE_ENTRY_COUNT,
        "block_count": len(block_map),
        "block_map": block_map,
    }
    os.makedirs(os.path.dirname(baseline_path), exist_ok=True)
    with open(baseline_path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=2, sort_keys=True)
    print("  [BASELINE] Saved sector table hash %s... (%d blocks) to %s" %
          (table_hash[:16], len(block_map), baseline_path))
    return data


def check_sector_table(disc_path, pristine_path=None):
    """Check 9: Level sector table — verify every non-flagged entry's LBA
    points to a valid HBD block header with matching sector count.

    Delegates to psx_tools.dq4.sectortable.check_table() when available for
    the canonical 5-check validation (round-trip, flag preservation, no
    overlap, text reach, entry count), then adds pristine-comparison checks.
    """
    issues = []
    exe = read_exe(disc_path)

    if len(exe) < SECTOR_TABLE_END + 4:
        issues.append("EXE too small for sector table (need 0x%X, got %d)" %
                      (SECTOR_TABLE_END + 4, len(exe)))
        return False, issues

    # --- Canonical check via sectortable.check_table() ---
    blocks = _scan_hbd_blocks(disc_path)
    if _HAVE_PSX_TOOLS:
        base_exe = exe
        base_blocks = blocks
        if pristine_path and os.path.exists(pristine_path):
            base_exe = read_exe(pristine_path)
            base_blocks = _scan_hbd_blocks(pristine_path)
        report = ST.check_table(base_exe, exe, blocks, base_blocks=base_blocks)
        if not report.ok:
            for c in report.failures:
                issues.append("[%s] %s" % (c.name, c.detail[:3] if c.detail else ""))
                for d in c.detail[:5]:
                    issues.append("  %s" % d)
        # Also compute table hash for comparison
        table_hash = _compute_table_hash(exe)
        if pristine_path and os.path.exists(pristine_path):
            pristine_hash = _compute_table_hash(read_exe(pristine_path))
            if table_hash != pristine_hash:
                # Hash mismatch is expected after build (EXE blocks patched),
                # but the sector TABLE region should be unchanged unless
                # a patch touched it. Flag only if the table region differs.
                # Check just the table bytes, not the full EXE.
                pristine_table = read_exe(pristine_path)[SECTOR_TABLE_START:SECTOR_TABLE_END + 4]
                built_table = exe[SECTOR_TABLE_START:SECTOR_TABLE_END + 4]
                if pristine_table != built_table:
                    issues.append("Sector table bytes differ from pristine — "
                                 "a patch step modified the map jump table")
    else:
        # Fallback: inline validation (same logic as before)
        entries = _parse_sector_table(exe)
        if len(entries) != SECTOR_TABLE_ENTRY_COUNT:
            issues.append("Sector table entry count %d != expected %d" %
                          (len(entries), SECTOR_TABLE_ENTRY_COUNT))

        for idx in FLAGGED_INDEXES:
            if idx < len(entries):
                _, raw, _, _, flg, _ = entries[idx]
                if not flg:
                    issues.append("Flag DROPPED at sector table index %d (offset 0x%X) "
                                  "— this entry must carry bit 31" %
                                  (idx, SECTOR_TABLE_START + idx * 4))

        live_count = 0
        dead_entries = []
        for off, raw, length, lba, flg, arch_sec in entries:
            if flg:
                continue
            blk = blocks.get(arch_sec)
            if blk is not None:
                live_count += 1
                if blk["nsec"] != length:
                    issues.append("Sector count mismatch at offset 0x%X: entry says %d "
                                 "sectors, block header at LBA %d says %d" %
                                 (off, length, lba, blk["nsec"]))
            else:
                dead_entries.append((off, lba, arch_sec))

        if pristine_path and os.path.exists(pristine_path) and dead_entries:
            pristine_blocks = _scan_hbd_blocks(pristine_path)
            for off, lba, arch_sec in dead_entries:
                if arch_sec in pristine_blocks:
                    issues.append("Entry at offset 0x%X (LBA %d) named a valid block "
                                 "on the pristine disc but names none now — "
                                 "BUILD CLOBBERED A MAP DESCRIPTOR" %
                                 (off, lba))

        live = [(e[5], e[2], e[0]) for e in entries if not e[4] and e[5] in blocks]
        live.sort()
        for k in range(len(live) - 1):
            s0, n0, o0 = live[k]
            s1, n1, o1 = live[k + 1]
            if s0 + n0 > s1:
                issues.append("Sector extent overlap: entry at 0x%X claims sectors "
                             "%d-%d, entry at 0x%X starts at sector %d" %
                             (o0, s0, s0 + n0 - 1, o1, s1))

    passed = len(issues) == 0
    return passed, issues


def check_submap_boundary(disc_path, pristine_path=None):
    """Check 10: Sub-map overlay boundary — verify no HBD block crosses a
    sector boundary that would shift map data past the engine's expected DMA
    read range.

    Each HBD block declares nsec (sector count) in its header. The engine
    DMA-reads exactly nsec sectors for that block. If a text re-encode grew
    the block's content past nsec * 2048 bytes, the trailing map
    geometry/collision data is silently truncated — the engine loads a
    partial map and freezes on floor transition.

    When --base is provided, also compares block sizes against the pristine
    disc to detect any block that grew during the build.
    """
    issues = []
    blocks = _scan_hbd_blocks(disc_path)

    if not blocks:
        issues.append("No valid HBD blocks found on disc")
        return False, issues

    # Read the HBD archive and check each block's actual data extent
    max_arch_sector = max(blocks.keys()) + max(b["nsec"] for b in blocks.values())
    arch = read_sector(disc_path, HBD_LBA, min(max_arch_sector + 10, 200000))

    for sec, blk in sorted(blocks.items()):
        o = sec * USZ
        nsec = blk["nsec"]
        tlen = blk["tlen"]
        header = 16 + blk["nsub"] * 16
        total_data = header + tlen
        declared_extent = nsec * USZ

        if total_data > declared_extent:
            issues.append("Block at archive sector %d: data %d bytes exceeds "
                         "declared %d sectors (%d bytes) by %d — MAP DATA "
                         "TRUNCATED ON DMA READ" %
                         (sec, total_data, nsec, declared_extent,
                          total_data - declared_extent))

    # When pristine is available, detect blocks that grew during the build
    if pristine_path and os.path.exists(pristine_path):
        pristine_blocks = _scan_hbd_blocks(pristine_path)
        for sec in sorted(set(blocks) & set(pristine_blocks)):
            pb = pristine_blocks[sec]
            bb = blocks[sec]
            if bb["tlen"] > pb["tlen"]:
                issues.append("Block at archive sector %d grew from %d to %d bytes "
                             "(%d byte increase) — verify in-place patcher "
                             "respected orig_total_block" %
                             (sec, pb["tlen"], bb["tlen"], bb["tlen"] - pb["tlen"]))

    passed = len(issues) == 0
    return passed, issues


# --- Main ---

CHECKS = [
    ("ISO TOC integrity",            check_iso_toc),
    ("Overlay sector alignment",     check_overlay_alignment),
    ("048B block integrity",         check_048b_block),
    ("048F block integrity",         check_048f_block),
    ("048C delta-lock",              check_048c_delta_lock),
    ("NPC script termination",       check_npc_script_termination),
    ("DMA sector alignment",         check_dma_alignment),
    ("Message module protection",    check_message_module_protection),
    ("Level sector table",           check_sector_table),
    ("Sub-map overlay boundary",     check_submap_boundary),
]


def main():
    ap = argparse.ArgumentParser(description="Heely/Izmit map overlay static validator (pre-RAM-dump)")
    ap.add_argument("--disc", required=True, help="Master disc image to validate")
    ap.add_argument("--base", default=None, help="Pristine Japanese disc image (for sector table comparison)")
    ap.add_argument("--save-baseline", default=None, metavar="PATH",
                    help="Save sector table hash + block map to JSON for post-build diff")
    ap.add_argument("--json", default=None, metavar="PATH",
                    help="Write full check results to JSON")
    args = ap.parse_args()

    if not os.path.exists(args.disc):
        print("[FAIL] Disc not found: %s" % args.disc)
        sys.exit(1)

    # Save baseline if requested (STEP -2 pre-build)
    if args.save_baseline:
        save_baseline(args.disc, args.save_baseline)

    print("=" * 66)
    print("  HEELY PRE-CHECK — Static Overlay Alignment Validator")
    print("  Disc: %s" % args.disc)
    if args.base:
        print("  Base: %s" % args.base)
    if _HAVE_PSX_TOOLS:
        print("  psx_tools: integrated (sectortable.check_table + hbd.scan_blocks)")
    else:
        print("  psx_tools: not found — using fallback inline parsers")
    print("=" * 66)

    all_passed = True
    results = []
    for name, check_fn in CHECKS:
        print("\n  [CHECK] %s" % name)
        try:
            if name in ("Level sector table", "Sub-map overlay boundary"):
                passed, issues = check_fn(args.disc, args.base)
            else:
                passed, issues = check_fn(args.disc)
        except Exception as e:
            passed = False
            issues = ["Check raised exception: %s" % str(e)]

        status = "PASS" if passed else "FAIL"
        print("  [%s] %s" % (status, name))
        results.append({"name": name, "passed": passed, "issues": issues})
        if issues:
            all_passed = False
            for issue in issues:
                print("         - %s" % issue)
                sys.stderr.write("  [HEELY] %s: %s\n" % (name, issue))

    print("\n" + "=" * 66)
    if all_passed:
        print("  OVERALL: PASS — All static checks passed.")
        print("  The disc is structurally sound for Heely/Izmit transition.")
        print("  NOTE: Runtime freeze may still occur due to overlay-residency")
        print("        collision at 0x80011F00 (requires RAM dump to diagnose).")
    else:
        print("  OVERALL: FAIL — Static checks found issues.")
        print("  Fix the flagged issues before attempting to boot the disc.")
    print("=" * 66)

    # Write JSON report if requested
    if args.json:
        report = {
            "disc": args.disc,
            "base": args.base,
            "all_passed": all_passed,
            "checks": results,
        }
        os.makedirs(os.path.dirname(args.json) or ".", exist_ok=True)
        with open(args.json, "w", encoding="utf-8") as f:
            json.dump(report, f, indent=2)
        print("  [JSON] Report written to %s" % args.json)

    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
