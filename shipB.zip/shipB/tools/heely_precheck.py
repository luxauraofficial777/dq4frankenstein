#!/usr/bin/env python3
"""
heely_precheck.py — Static validator for Heely/Izmit map overlay alignment.

Verifies that the Heely map overlay and dialogue sectors are properly aligned
and terminated before the ISO is generated.  This is a PRE-RAM-DUMP static
analysis tool: it checks the disc image for structural integrity without
requiring a live DuckStation session.

Checks performed:
  1. ISO TOC integrity: verify the HBD archive LBA and sector count.
  2. Overlay sector alignment: verify that map overlay files are sector-aligned
     and that no sector padding errors were introduced during the build.
  3. 048B block integrity: verify the battle overlay block header is valid
     and the Huffman tree is parseable.
  4. 048F block integrity: verify the EXE-resident church/priest block is
     intact and all freeze tokens are present.
  5. NPC script termination: scan for malformed control codes or missing
     {0000} terminators in the dialogue blocks referenced by town maps.
  6. DMA alignment: verify that all archive sectors are 2048-byte aligned
     within the MODE2/2352 container (user data at offset 24, 2048 bytes).
  7. Message module protection: verify that no patch step wrote data into the
     0x80011F00-0x80012EFF region (the resident message module).

Usage:
  python heely_precheck.py --disc <master.bin>
  python heely_precheck.py --disc <master.bin> --base <pristine.bin>
"""

import argparse
import os
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")

RAW = 2352
UOFF = 24
USZ = 2048

# --- DQ4 disc geometry ---
HBD_LBA = 362           # HBD archive starts at LBA 362
EXE_LBA = 24            # SLPM_869.16 starts at LBA 24
EXE_SECTORS = 338       # EXE spans 338 sectors
EXE_SIZE = EXE_SECTORS * USZ
RAM_BASE = 0x80017700   # PS-X EXE load address (t_addr - 0x800)

# --- Block IDs ---
BLOCK_048B = 0x048B     # Battle overlay (archive-resident)
BLOCK_048C = 0x048C     # Font 1 menus/items (EXE-resident)
BLOCK_048F = 0x048F     # Church/priest save-load (EXE-resident)

# --- 048F block offset in EXE ---
BLOCK_048F_OFF = 0x99624

# --- Freeze tokens that must be present in 048F ---
FREEZE_TOKENS = [0x7F06, 0x7F10, 0x7F19, 0x7F1B, 0x7F1C, 0x7F1E, 0x7F35]

# --- Message module protection zone (RAM addresses) ---
MSG_MODULE_START = 0x80011F00
MSG_MODULE_END   = 0x80012EFF
MSG_MODULE_EXE_START = MSG_MODULE_START - RAM_BASE  # 0x9800
MSG_MODULE_EXE_END   = MSG_MODULE_END - RAM_BASE    # 0xA7FF

# --- Control codes ---
CTRL_LINE_BREAK = 0x7F01
CTRL_BOX_WAIT   = 0x7F02
CTRL_PAGE_BREAK_A = 0x7F0A
CTRL_PAGE_BREAK_B = 0x7F0B
CTRL_TERMINATOR = 0x0000


def read_sector(disc_path, lba, count=1):
    """Read user data from one or more sectors."""
    data = bytearray()
    with open(disc_path, "rb") as f:
        for i in range(count):
            f.seek((lba + i) * RAW + UOFF)
            data.extend(f.read(USZ))
    return bytes(data)


def read_exe(disc_path):
    """Read the full EXE from the disc."""
    return read_sector(disc_path, EXE_LBA, EXE_SECTORS)[:EXE_SIZE]


def find_block_in_exe(exe_data, block_id):
    """Find a block by its ID within the EXE data.

    Returns (offset, (end, bid, hts, te, txe, unk)) or (None, None).
    """
    for x in range(0, len(exe_data) - 24, 4):
        end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe_data, x)
        if (bid & 0xFFFF) == block_id and hts == 24 and 24 < txe < end <= 8192:
            return x, (end, bid, hts, te, txe, unk)
    return None, None


def find_block_048b_in_archive(disc_path):
    """Find the 048B block in the HBD archive on disc.

    Returns (sector, user_offset, header) or (None, None, None).
    """
    target = b"\x8b\x04\x00\x00\x18\x00\x00\x00"
    with open(disc_path, "rb") as f:
        f.seek(105000 * RAW)
        raw = f.read(1500 * RAW)
        u_data = bytearray()
        for i in range(1500):
            u_data.extend(raw[i * RAW + UOFF: i * RAW + UOFF + USZ])
        idx = u_data.find(target)
        if idx != -1:
            hdr_off = idx - 4
            sec = 105000 + (hdr_off // USZ)
            u_off = hdr_off % USZ
            hdr = struct.unpack_from("<6I", u_data, hdr_off)
            return sec, u_off, hdr
    return None, None, None


# --- Individual checks ---

def check_iso_toc(disc_path):
    """Check 1: ISO TOC integrity — HBD archive LBA and sector count."""
    issues = []
    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_size = f.tell()
        total_sectors = total_size // RAW

    if total_sectors < HBD_LBA + 1:
        issues.append("Disc too small: %d sectors (need > %d)" % (total_sectors, HBD_LBA))

    # Check that the HBD archive starts at LBA 362
    hbd_data = read_sector(disc_path, HBD_LBA, 1)
    if len(hbd_data) < 4:
        issues.append("Cannot read HBD archive header at LBA %d" % HBD_LBA)

    # Verify the EXE is at LBA 24
    exe_data = read_sector(disc_path, EXE_LBA, 1)
    if exe_data[:8] == b"PS-X EXE":
        pass  # EXE header found
    else:
        # Some DQ4 images don't have the PS-X EXE magic at the very start
        # of LBA 24; the actual EXE might be found via the ISO directory.
        issues.append("PS-X EXE magic not at LBA %d (may be directory-referenced)" % EXE_LBA)

    passed = len(issues) == 0
    return passed, issues


def check_overlay_alignment(disc_path):
    """Check 2: Overlay sector alignment — verify no padding errors."""
    issues = []

    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_sectors = f.tell() // RAW

    # Check that every sector in the HBD archive has valid sync/header
    # by spot-checking the first 12 bytes of each sector's raw data
    bad_sectors = []
    for sec in range(HBD_LBA, min(HBD_LBA + 100, total_sectors)):
        with open(disc_path, "rb") as f:
            f.seek(sec * RAW)
            raw_header = f.read(12)
        # MODE2/2352 sectors start with 0x00FFFFFFFFFFFFFF00 (sync)
        if raw_header[:12] != b"\x00\xff\xff\xff\xff\xff\xff\xff\xff\xff\x00\x00":
            # Not all sectors may have sync (form 2 sectors can differ)
            # Only flag if the user data area is all-zero (padding artifact)
            user_data = read_sector(disc_path, sec, 1)
            if all(b == 0 for b in user_data):
                bad_sectors.append(sec)

    if bad_sectors:
        issues.append("All-zero user data sectors in HBD archive: %s" %
                       ", ".join(str(s) for s in bad_sectors[:10]))

    passed = len(issues) == 0
    return passed, issues


def check_048b_block(disc_path):
    """Check 3: 048B block integrity — header valid, tree parseable."""
    issues = []

    sec, off, hdr = find_block_048b_in_archive(disc_path)
    if sec is None:
        issues.append("Block 0x048B not found in archive")
        return False, issues

    end, bid, hts, tre, txe, unk = hdr
    if (bid & 0xFFFF) != BLOCK_048B:
        issues.append("048B block ID mismatch: 0x%04X" % (bid & 0xFFFF))
    if hts != 24:
        issues.append("048B header size != 24 (got %d)" % hts)
    if txe <= 24 or txe >= end:
        issues.append("048B text end out of range: %d (end=%d)" % (txe, end))

    # Read the block data and try to parse the Huffman tree
    nsec = ((off + end + USZ - 1) // USZ) + 1
    block_data = read_sector(disc_path, sec, nsec)
    block_bytes = block_data[off:off + end]

    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
        from hbe.huffman.dq4 import DQ4Schema
        sc = DQ4Schema()
        tree_end_off = (tre if tre else end)
        tree_bytes = block_bytes[txe + 10:tree_end_off]
        tree = sc.parse_tree(tree_bytes)
        if tree is None:
            issues.append("048B Huffman tree parsed as None")
    except Exception as e:
        issues.append("048B Huffman tree parse error: %s" % str(e))

    passed = len(issues) == 0
    return passed, issues


def check_048f_block(disc_path):
    """Check 4: 048F block integrity — freeze tokens present."""
    issues = []

    exe = read_exe(disc_path)
    if len(exe) < BLOCK_048F_OFF + 4:
        issues.append("EXE too small for 048F block (need offset 0x%X, got %d)" % (BLOCK_048F_OFF, len(exe)))
        return False, issues

    end_048f = struct.unpack_from("<I", exe, BLOCK_048F_OFF)[0]
    blk_size = min(end_048f + 4, len(exe) - BLOCK_048F_OFF)
    block_data = exe[BLOCK_048F_OFF:BLOCK_048F_OFF + blk_size]

    missing_tokens = []
    for token in FREEZE_TOKENS:
        hi = (token >> 8) & 0xFF
        lo = token & 0xFF
        pattern = bytes([hi, lo])
        if pattern not in block_data:
            missing_tokens.append("0x%04X" % token)

    if missing_tokens:
        issues.append("Missing freeze tokens in 048F: %s" % ", ".join(missing_tokens))

    passed = len(issues) == 0
    return passed, issues


def check_npc_script_termination(disc_path):
    """Check 5: NPC script termination — scan for missing {0000} terminators.

    This checks the 048C block (Font 1) for strings that don't terminate
    with {0000}.  The 048B block is also checked.
    """
    issues = []

    exe = read_exe(disc_path)

    # Check 048C block
    o, hdr = find_block_in_exe(exe, BLOCK_048C)
    if o is not None:
        end, bid, hts, te, txe, unk = hdr
        try:
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
            from hbe.huffman.dq4 import DQ4Schema
            import dq4_hbd_patcher as P
            sc = DQ4Schema()
            tree_end_off = o + (te if te else end)
            tree = sc.parse_tree(exe[o + txe + 10:tree_end_off])
            leaves = sc.decode(exe[o + hts:o + txe], tree)

            # Check that every string ends with {0000}
            strings = []
            cur = []
            for l in leaves:
                cur.append(l)
                val = (l.content[0] << 8) | l.content[1]
                if val == 0:
                    strings.append(cur)
                    cur = []
            if cur:
                # Last string without terminator
                issues.append("048C: final string (SID %d) missing {0000} terminator" % len(strings))

            # Check for control codes without closing tokens
            for i, s in enumerate(strings):
                has_7f01 = any((l.content[0] << 8 | l.content[1]) == CTRL_LINE_BREAK for l in s)
                has_7f02 = any((l.content[0] << 8 | l.content[1]) == CTRL_BOX_WAIT for l in s)
                # Each {7F01} line break should be followed by more text or {7F02}/{0000}
                # This is a soft check — we flag strings that end with {7F01} without {7F02}/{0000}
                if s and (s[-1].content[0] << 8 | s[-1].content[1]) == CTRL_LINE_BREAK:
                    issues.append("048C SID %d ends with {7F01} (missing closing token)" % i)

        except Exception as e:
            issues.append("048C parse error during terminator check: %s" % str(e))
    else:
        issues.append("048C block not found in EXE")

    passed = len(issues) == 0
    return passed, issues


def check_dma_alignment(disc_path):
    """Check 6: DMA alignment — verify all archive sectors are 2048-byte aligned."""
    issues = []

    with open(disc_path, "rb") as f:
        f.seek(0, 2)
        total_sectors = f.tell() // RAW

    # Spot-check: verify that user data in HBD sectors starts at offset 24
    # and is exactly 2048 bytes (no misaligned DMA reads)
    for sec in [HBD_LBA, HBD_LBA + 1, HBD_LBA + 100, HBD_LBA + 500]:
        if sec >= total_sectors:
            continue
        with open(disc_path, "rb") as f:
            f.seek(sec * RAW)
            raw = f.read(RAW)
        if len(raw) < RAW:
            issues.append("Sector %d: short read (%d < %d)" % (sec, len(raw), RAW))
            continue
        # Check MODE2 header: bytes 0-11 = sync, 12-15 = header, 16-23 = sub-header
        if raw[:4] != b"\x00\xff\xff\xff":
            # Not a standard MODE2 sync — could be a different mode
            pass  # Soft check, don't flag
        # Verify user data area is present
        user_data = raw[UOFF:UOFF + USZ]
        if len(user_data) != USZ:
            issues.append("Sector %d: user data area is %d bytes (expected %d)" %
                          (sec, len(user_data), USZ))

    passed = len(issues) == 0
    return passed, issues


def check_message_module_protection(disc_path):
    """Check 7: Message module protection — verify no patch wrote into the
    0x80011F00-0x80012EFF region of the EXE.

    The message module lives at RAM 0x80011F00-0x80012EFF, which maps to
    EXE file offsets 0x9800-0xA7FF.  No pipeline step should modify this
    region (it is the resident message module, not a text block).
    """
    issues = []

    exe = read_exe(disc_path)

    # The message module region in the EXE
    mod_start = MSG_MODULE_EXE_START
    mod_end = MSG_MODULE_EXE_END

    if mod_end > len(exe):
        issues.append("EXE too small for message module check")
        return False, issues

    # Check that the region contains code-like data (not zeros, not text)
    # We can't compare to pristine without the base, but we can check
    # that it's not obviously corrupted (all zeros or all 0xFF)
    region = exe[mod_start:mod_end]
    if all(b == 0 for b in region):
        issues.append("Message module region (0x%X-0x%X) is all zeros — likely clobbered" %
                      (mod_start, mod_end))
    if all(b == 0xFF for b in region):
        issues.append("Message module region (0x%X-0x%X) is all 0xFF — likely corrupted" %
                      (mod_start, mod_end))

    # Check for the specific clobber pattern: archive header at 0x80011F00
    # would be a 0x200-byte block of structured data.  If the first 16 bytes
    # look like a block header (end, bid, hts, ...), that's suspicious.
    if len(region) >= 24:
        end, bid, hts = struct.unpack_from("<3I", region, 0)
        if hts == 24 and 24 < (end & 0xFFFF) < 8192:
            # This looks like a text block header — the module may have been
            # clobbered by an archive header load
            issues.append("Message module region starts with block-like header "
                          "(end=%d, bid=0x%04X, hts=%d) — possible archive clobber" %
                          (end, bid & 0xFFFF, hts))

    passed = len(issues) == 0
    return passed, issues


def check_048c_delta_lock(disc_path):
    """Check 8: 048C delta-lock — verify bit-offset deltas for SIDs 773-778."""
    issues = []

    exe = read_exe(disc_path)
    o, hdr = find_block_in_exe(exe, BLOCK_048C)
    if o is None:
        issues.append("048C block not found in EXE")
        return False, issues

    end, bid, hts, te, txe, unk = hdr
    try:
        sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
        from hbe.huffman.dq4 import DQ4Schema
        import dq4_hbd_patcher as P
        sc = DQ4Schema()
        tree_end_off = o + (te if te else end)
        tree = sc.parse_tree(exe[o + txe + 10:tree_end_off])
        leaves = sc.decode(exe[o + hts:o + txe], tree)
        offsets = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]

        if len(offsets) < 779:
            issues.append("048C has only %d strings (need >= 779 for delta check)" % len(offsets))
            return False, issues

        deltas = {
            "774-773": offsets[774] - offsets[773],
            "776-775": offsets[776] - offsets[775],
            "777-775": offsets[777] - offsets[775],
            "778-775": offsets[778] - offsets[775],
        }
        expected = {"774-773": 44, "776-775": 36, "777-775": 50, "778-775": 66}
        for k, v in deltas.items():
            if v != expected[k]:
                issues.append("Delta %s = %d (expected %d) — DRIFT DETECTED" % (k, v, expected[k]))

    except Exception as e:
        issues.append("048C delta-lock check error: %s" % str(e))

    passed = len(issues) == 0
    return passed, issues


# --- Main ---

CHECKS = [
    ("ISO TOC integrity",            check_iso_toc),
    ("Overlay sector alignment",     check_overlay_alignment),
    ("048B block integrity",         check_048b_block),
    ("048F block integrity",         check_048f_block),
    ("048C delta-lock",              check_048c_delta_lock),
    ("NPC script termination",       check_npc_script_termination),
    ("DMA sector alignment",         check_dma_alignment),
    ("Message module protection",    check_message_module_protection),
]


def main():
    ap = argparse.ArgumentParser(description="Heely/Izmit map overlay static validator (pre-RAM-dump)")
    ap.add_argument("--disc", required=True, help="Master disc image to validate")
    args = ap.parse_args()

    if not os.path.exists(args.disc):
        print("[FAIL] Disc not found: %s" % args.disc)
        sys.exit(1)

    print("=" * 66)
    print("  HEELY PRE-CHECK — Static Overlay Alignment Validator")
    print("  Disc: %s" % args.disc)
    print("=" * 66)

    all_passed = True
    for name, check_fn in CHECKS:
        print("\n  [CHECK] %s" % name)
        try:
            passed, issues = check_fn(args.disc)
        except Exception as e:
            passed = False
            issues = ["Check raised exception: %s" % str(e)]

        status = "PASS" if passed else "FAIL"
        print("  [%s] %s" % (status, name))
        if issues:
            all_passed = False
            for issue in issues:
                print("         - %s" % issue)

    print("\n" + "=" * 66)
    if all_passed:
        print("  OVERALL: PASS — All static checks passed.")
        print("  The disc is structurally sound for Heely/Izmit transition.")
        print("  NOTE: Runtime freeze may still occur due to overlay-residency")
        print("        collision at 0x80011F00 (requires RAM dump to diagnose).")
    else:
        print("  OVERALL: FAIL — Static checks found issues.")
        print("  Fix the flagged issues before attempting to boot the disc.")
    print("=" * 66)

    sys.exit(0 if all_passed else 1)


if __name__ == "__main__":
    main()
