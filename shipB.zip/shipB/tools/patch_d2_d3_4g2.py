#!/usr/bin/env python3
"""patch_d2_d3_4g2.py — STEP 4g-2 (H6 durability closure): D2/D3 stale-word
injection by sid-index identity.

Folds the v2.2 hotfix mechanism (study/fix_d2_d3_v22.py, KIMI's §2) into the
sovereign build so the 12+3 lost sectors are re-injected by construction on
every master build.

Defect class (REGRESSION_TRACKING_V23_RAM_DUMPS_Sep08_2026.md §2, §11.2):
the 048B referrer words 0x48B10018 / 0x48B10141 (D2 church offering) and
0x48B07187 (D3 victory) dispatch MID-stream — on the current re-aligned 048B
tree they land inside the battle-message band (sids 525-527). They are MID on
the PRISTINE tree too, which is why the G2 gate is structurally blind to them
(§11.3). Fix = decode each bad word's bit offset against the pristine 048B
layout -> identify intended sid -> point at that sid's START on the current
tree (sid-index identity, not a stale site list).

Unlike fix_d2_d3_v22.py this writer scans the WHOLE DISC user data (the
candidate carries 20 sites over 15 LBAs; the v2.2-era list only knew 12).

  report mode (default): scan, classify, prove. Writes nothing.
  --write: apply, run edcre, verify 0 bad words remain, print SHA-256.
"""
import argparse
import hashlib
import os
import struct
import subprocess
import sys

sys.stdout.reconfigure(encoding="utf-8")
HERE = os.path.dirname(os.path.abspath(__file__))          # ship/tools
SHIP = os.path.abspath(os.path.join(HERE, ".."))           # ship
ROOT = os.path.abspath(os.path.join(SHIP, ".."))           # repo root
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "translation-tools"))
sys.path.insert(0, os.path.join(ROOT, "psx_tools"))

import patch_battle_overlay as PBO                          # noqa: E402
from dq4 import textblock, huffman                          # noqa: E402

RAW, UOFF, USZ = 2352, 24, 2048
DEFAULT_BASE = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
EDCRE = os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe")

# bad word -> (label, block id). 048B = D2/D3 hotfix words; 048F = the priest
# residual (pristine sid 125 START) whose ad-hoc fix (v23_fix_48f_word.py) was
# never pipeline-folded — the from-source rebuild reintroduced it (G2 FAIL,
# ARCH+0x70E69F4, build 666D4C38). Sid-identity remap per block tree.
BAD_WORDS = {
    0x48B10018: ("D2-offering", 0x48B),
    0x48B10141: ("D2-offering-2", 0x48B),
    0x48B07187: ("D3-victory", 0x48B),
    0x48F052C8: ("048F-priest-residual", 0x48F),
    0x48F05C86: ("048F-D3-victory-residual", 0x48F),
}
BLOCK_EXE_OFF = {0x48F: 0x99624}   # EXE-resident blocks (048B lives in archive)


def read_block_048b(disc_path):
    """Load the 048B block: (tb, hts, c_bits)."""
    sec, off, hdr = PBO.find_block_048b(disc_path)
    if sec is None:
        raise SystemExit("[FAIL] Block 0x048B not found on %s" % disc_path)
    end, bid, hts, tre, txe, unk = hdr
    nsec = ((off + end + USZ - 1) // USZ) + 1
    acc = bytearray()
    with open(disc_path, "rb") as f:
        for s in range(sec, sec + nsec):
            f.seek(s * RAW + UOFF)
            acc.extend(f.read(USZ))
    tb = textblock.TextBlock(bytes(acc[off:off + end + 4]))
    return tb, hts, tb.c * 8


def load_block_any(disc_path, tid):
    """(string_offsets, c_bits) for the given block on this disc.
    0x048B lives in the archive (battle-overlay locator); 048F is EXE-resident."""
    if tid == 0x48B:
        tb, _hts, _c = read_block_048b(disc_path)
        return huffman.string_offsets(tb), tb.c * 8
    foff = BLOCK_EXE_OFF[tid]
    lba, uoff = 24 + foff // USZ, foff % USZ
    acc = bytearray()
    with open(disc_path, "rb") as f:
        for s in range(lba, lba + 8):
            f.seek(s * RAW + UOFF)
            acc.extend(f.read(USZ))
    end, bid, hts, d, e, f6 = struct.unpack_from("<6I", acc, uoff)
    tb = textblock.TextBlock(bytes(acc[uoff: uoff + end + 4]))
    return huffman.string_offsets(tb), tb.c * 8


def build_sid_identity(base_path, disc_path):
    """Per-block ordinal pairing of pristine vs current layouts."""
    tids = {t for _l, t in BAD_WORDS.values()}
    identity = {}
    for tid in sorted(tids):
        offs_p, c_p = load_block_any(base_path, tid)
        offs_s, c_s = load_block_any(disc_path, tid)
        identity[tid] = (offs_p, offs_s, c_p, c_s)
    return identity


def compute_remaps(identity):
    """bad word -> new word, by sid-index identity within its own block tree."""
    remap = {}
    for bw, (label, tid) in sorted(BAD_WORDS.items()):
        offs_p, offs_s, c_p, c_s = identity[tid]
        rel = (bw & 0xFFFFF) - c_p
        near = max((i for i, st in enumerate(offs_p) if st <= rel), default=-1)
        if near < 0:
            print("[FAIL] 0x%08X [%s]: no pristine sid for rel bit %d" % (bw, label, rel))
            continue
        intra = rel - offs_p[near]
        new_word = (tid << 20) | (offs_s[near] + c_s)
        remap[bw] = new_word
        print("  0x%08X [%s] -> 0x%08X  (pristine %03X sid %d START, intra=%d)"
              % (bw, label, new_word, tid, near, intra))
    return remap


def scan_disc(path, words):
    """Full-disc user-data scan, 4-byte aligned within each sector."""
    hits = {w: [] for w in words}
    with open(path, "rb") as f:
        data = f.read()
    nsec = len(data) // RAW
    for w in words:
        pat = struct.pack("<I", w)
        i = data.find(pat)
        while i != -1:
            rel = i - UOFF
            if rel >= 0:
                in_sec = rel % RAW
                if 24 <= in_sec < UOFF + USZ and (in_sec - UOFF) % 4 == 0 \
                        and (rel // RAW) < nsec:
                    hits[w].append((rel // RAW, in_sec))
            i = data.find(pat, i + 1)
    return hits


def write_sectors(path, writes):
    with open(path, "r+b") as f:
        for lba, uoff, word in writes:
            f.seek(lba * RAW + UOFF + uoff)
            f.write(struct.pack("<I", word))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--disc", required=True, help="master image to scan/patch")
    ap.add_argument("--base", default=DEFAULT_BASE, help="pristine JP image")
    ap.add_argument("--write", action="store_true")
    ap.add_argument("--no-edcre", action="store_true")
    args = ap.parse_args()

    print("=" * 70)
    print("  STEP 4g-2: D2/D3 sid-identity injection (%s)" %
          ("WRITE" if args.write else "REPORT"))
    print("  disc: %s" % args.disc)
    print("=" * 70)

    identity = build_sid_identity(args.base, args.disc)
    remap = compute_remaps(identity)
    if len(remap) != len(BAD_WORDS):
        print("[FAIL] could not compute remaps for all bad words")
        return 1

    hits = scan_disc(args.disc, list(BAD_WORDS))
    total = 0
    writes = []
    for w in sorted(BAD_WORDS):
        for lba, uoff in hits[w]:
            total += 1
            print("  site LBA %d u_off 0x%03X  0x%08X -> 0x%08X  [%s]"
                  % (lba, uoff, w, remap[w], BAD_WORDS[w][0]))
            writes.append((lba, uoff, remap[w]))
    print("  bad sites on disc: %d (over %d words)" %
          (total, len([w for w in BAD_WORDS if hits[w]])))
    if total == 0:
        print("  [PASS] 0 stale D2/D3 words on disc — nothing to do.")
        return 0
    if not args.write:
        print("  REPORT ONLY — nothing written.")
        return 0

    write_sectors(args.disc, writes)
    print("  wrote %d words across %d sectors" % (len(writes), len(set(
        (lba for lba, _, _ in writes)))))

    if not args.no_edcre and os.path.exists(EDCRE):
        r = subprocess.run([EDCRE, args.disc], capture_output=True, text=True, timeout=1800)
        print("  edcre: %s" % ("PASS" if r.returncode == 0 else "FAIL"))
        if r.returncode != 0:
            print("  stderr: %s" % r.stderr[:500])
            return 1

    # Per-sector readback: re-read each written sector and assert the old
    # word sequence is gone.
    post = scan_disc(args.disc, list(BAD_WORDS))
    remaining = sum(len(v) for v in post.values())
    if remaining:
        for w in BAD_WORDS:
            for lba, uoff in post[w]:
                print("  [FAIL] LBA %d u_off 0x%03X still 0x%08X" % (lba, uoff, w))
        return 1
    # Explicit per-sector readback for every sector we wrote
    written_lbas = set(lba for lba, _, _ in writes)
    for lba in sorted(written_lbas):
        with open(args.disc, "rb") as f:
            f.seek(lba * RAW + UOFF)
            sector = f.read(USZ)
        for w in BAD_WORDS:
            pat = struct.pack("<I", w)
            idx = sector.find(pat)
            while idx != -1:
                if idx % 4 == 0:
                    print("  [FAIL] per-sector readback LBA %d offset 0x%03X still has 0x%08X" % (lba, idx, w))
                    return 1
                idx = sector.find(pat, idx + 1)
    print("  [PASS] per-sector readback: 0 bad D2/D3 words in %d written sectors." % len(written_lbas))

    with open(args.disc, "rb") as f:
        sha = hashlib.sha256(f.read()).hexdigest().upper()
    print("  new disc SHA-256: %s" % sha)
    return 0


if __name__ == "__main__":
    sys.exit(main())
