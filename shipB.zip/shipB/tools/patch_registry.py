#!/usr/bin/env python3
"""
patch_registry.py — Deterministic offset/byte/pointer registry for DQ4 PSX.

Centralizes the exact offsets, corrected byte sequences, and pointer
recalculations for:
  - Item table (Font 1 / Block 0x048C) name entries
  - Battle victory string (D2/D3 / Block 0x048B) sid-identity remaps
  - Church facility (Block 0x047D) SID 54 canonical string
  - 048F EXE-resident freeze tokens (integrity check)
  - Delta-locked bit-offset assertions for SIDs 773-778

All values are derived from static analysis of the pristine disc and the
working Ship B baseline.  No speculative patches are included.

Usage:
  from patch_registry import PatchRegistry
  reg = PatchRegistry()
  reg.validate_disc(disc_path, pristine_path)

  # Or as a CLI validator:
  python patch_registry.py --disc <master.bin> --base <pristine.bin>
"""

import argparse
import hashlib
import os
import struct
import sys

sys.stdout.reconfigure(encoding="utf-8")

# --- Disc geometry (matches all pipeline tools) ---
RAW = 2352
UOFF = 24
USZ = 2048

# --- PS-X EXE geometry ---
EXE_LBA = 24
EXE_SECTORS = 338
EXE_SIZE = EXE_SECTORS * USZ
RAM_BASE = 0x80017700  # t_addr from EXE header

# --- Block offsets within the EXE ---
BLOCK_048C_FILE_OFF = 0x097AC8   # Font 1 menus/items/stats
BLOCK_048F_FILE_OFF = 0x99624    # Church/priest save-load (EXE-resident)
BLOCK_048C_ID = 0x048C
BLOCK_048F_ID = 0x048F
BLOCK_048B_ID = 0x048B

# --- Delta-locked bit-offset assertions (SIDs 773-778) ---
# These are engine-hardcoded bit deltas for cursor blink / command advance.
# If any drift, the title/menu freezes.
DELTA_LOCKS = {
    "774-773": 44,
    "776-775": 36,
    "777-775": 50,
    "778-775": 66,
}

# --- 048F freeze tokens (must be byte-identical before/after any patch) ---
FREEZE_TOKENS = [0x7F06, 0x7F10, 0x7F19, 0x7F1B, 0x7F1C, 0x7F1E, 0x7F35]

# --- D2/D3 stale-word remap table (sid-identity injection) ---
# These are the bad referrer words that dispatch MID-stream on the re-aligned
# 048B/048F trees.  The fix is to remap each to the START of its intended SID
# on the current tree (sid-index identity, not a stale site list).
#
# Format: bad_word -> (label, block_id)
BAD_WORDS = {
    0x48B10018: ("D2-offering",              0x048B),
    0x48B10141: ("D2-offering-2",            0x048B),
    0x48B07187: ("D3-victory",               0x048B),
    0x48F052C8: ("048F-priest-residual",     0x048F),
    0x48F05C86: ("048F-D3-victory-residual", 0x048F),
}

# --- Church facility SID 54 canonical string ---
# The naive modulo assignment in build_all_facilities.py was mapping SID 54
# to church_templates[3] ("Saving in progress...") instead of the memory card
# verification string.  This is the correct content.
SID_54_CANONICAL = (
    "{7F04}Checking the Memory Card."
    "{7F02}Please do not touch the"
    "{7F02}card or controller."
)

# --- Font 1 item name SID ranges (Block 0x048C) ---
# These are the SIDs that contain item/weapon/armor names translated to
# 3-char disemvowel abbreviations.
FONT1_ITEM_SID_RANGES = [
    (379, 401),   # Weapons / artifacts
    (444, 520),   # Armor / shields / helmets / accessories
    (265, 379),   # Spell names
    (150, 191),   # Hero / class names
]

# --- Font 1 command SIDs (manually authored labels) ---
# These are complete strings with control codes, not auto-abbreviated.
FONT1_COMMAND_SIDS = {
    # Search "nothing found"
    31: "NOT FND",
    35: "NOT FND",
    585: "NOT FND{7F0B}",
    598: "NOT FND{7F0B}",
    # Item/bag management
    730: "A-Z", 731: "TYP", 732: "ALL", 733: "WHO", 734: "WHO", 735: "EXT",
    736: "DRP", 737: "EQP", 738: "SHW", 739: "LUK",
    # Field menus
    740: "GIV", 741: "USE", 742: "ACT", 743: "REC", 744: "BAG", 745: "ITM",
    746: "VAR", 747: "ORD", 748: "TAC", 749: "FUL", 750: "TAC", 751: "SRC",
    752: "SPL", 753: "STS", 754: "ITM", 755: "TLK", 756: "PRT",
    # Status attributes
    663: "LVL", 664: "DEF", 665: "ATK", 666: "DEF", 667: "ATK",
    668: "LUK", 669: "WIS", 670: "RES", 671: "AGI", 672: "STR",
    673: "MP",  674: "HP",  675: "MMP", 676: "MHP",
    # Combat actions
    720: "DMG", 721: "DFD", 722: "SKL", 723: "ATK", 724: "RUN", 725: "SWP",
    726: "FGT", 727: "END", 728: "MP",  729: "---",
}

# --- Bare page remap (Class D) ---
# The 048B page-table remap must use the 362-sector base offset.
# Writing with stream index = disc LBA (without the base) clobbers wrong sectors.
BARE_PAGE_BASE_LBA = 362
BARE_PAGE_TARGET_LBA = 40217
BARE_PAGE_EXPECTED_ROWS = 18  # exactly 18 rows should change

# --- F6 patches (HELD — do not apply) ---
# These patches were proven to cause the prologue streaming crash.
# They are documented here for reference only.  Do NOT apply until
# watchpoint capture identifies the corrupting PC for [0x800C06B8].
F6_PATCHES_HELD = {
    "4h-2": {
        "name": "VSync timeout bypass",
        "tool": "patch_f6_vsync_timeout.py",
        "ram_target": 0x80099F60,
        "exe_offset": 0x82860,
        "original": (0x3C048002, 0x0C029728),
        "patch": (0x080267E8, 0x00000000),  # j 0x80099FA0 + nop
        "status": "HELD — causes prologue streaming crash",
    },
    "4h-3": {
        "name": "Overlay collision redirect (Theory B)",
        "tool": "patch_f6_overlay_collision.py",
        "patch_sites": [
            {
                "ram": 0x8005DC00,
                "exe_off": 0x46500,
                "original": 0x34841F00,  # ori $a0, $a0, 0x1F00
                "patch":   0x34844000,   # ori $a0, $a0, 0x4000
            },
            {
                "ram": 0x8005DC14,
                "exe_off": 0x46514,
                "original": 0x34A52300,  # ori $a1, $a1, 0x2300
                "patch":   0x34A54400,   # ori $a1, $a1, 0x4400
            },
        ],
        "status": "HELD — causes prologue streaming crash",
    },
    "4h-4": {
        "name": "KSEG0 allocator guard",
        "tool": "patch_f6_allocator_guard.py",
        "status": "HELD — causes prologue streaming crash",
    },
}

# --- Heely/Izmit freeze diagnostic data ---
# The freeze occurs when the async archive loader clobbers the resident
# message module at 0x80011F00-0x80012EFF.
HEELY_FREEZE = {
    "allocator_addr": 0x8009B138,
    "clobber_target": 0x80011F00,
    "clobber_size": 0x200,  # 512 bytes = 1 CD sector
    "message_module_range": (0x80011F00, 0x80012EFF),
    "free_redirect_target": 0x80014000,
    "bss_queue_pointer": 0x800C06B8,
    "spin_site": 0x80090308,
    "corrupted_read_addr": 0xFFFFFFF6,
}


class PatchRegistry:
    """Centralized registry of all deterministic patch offsets, byte sequences,
    and pointer recalculations for the DQ4 Ship B pipeline."""

    def __init__(self):
        self.delta_locks = DELTA_LOCKS
        self.freeze_tokens = FREEZE_TOKENS
        self.bad_words = BAD_WORDS
        self.sid_54_canonical = SID_54_CANONICAL
        self.font1_item_ranges = FONT1_ITEM_SID_RANGES
        self.font1_commands = FONT1_COMMAND_SIDS
        self.bare_page_base = BARE_PAGE_BASE_LBA
        self.bare_page_target = BARE_PAGE_TARGET_LBA
        self.bare_page_rows = BARE_PAGE_EXPECTED_ROWS
        self.f6_held = F6_PATCHES_HELD
        self.heely_freeze = HEELY_FREEZE

    # --- EXE extraction ---

    @staticmethod
    def read_exe_from_disc(disc_path):
        """Read the EXE from a MODE2/2352 disc image (LBA 24-361)."""
        exe = bytearray()
        with open(disc_path, "rb") as f:
            for i in range(EXE_SECTORS):
                f.seek((EXE_LBA + i) * RAW + UOFF)
                exe.extend(f.read(USZ))
        return exe[:EXE_SIZE]

    @staticmethod
    def write_exe_to_disc(disc_path, exe_data):
        """Write the EXE back to a MODE2/2352 disc image per-sector."""
        with open(disc_path, "r+b") as f:
            for i in range(EXE_SECTORS):
                f.seek((EXE_LBA + i) * RAW + UOFF)
                f.write(bytes(exe_data[i * USZ:(i + 1) * USZ]))

    # --- 048C delta-lock verification ---

    def verify_delta_lock(self, exe_data):
        """Verify the delta-locked bit offsets for SIDs 773-778.

        Returns (passed: bool, deltas: dict).
        """
        # Locate 0x048C block in EXE
        o = None
        for x in range(0, len(exe_data) - 24, 4):
            end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe_data, x)
            if (bid & 0xFFFF) == BLOCK_048C_ID and hts == 24 and 24 < txe < end <= 8192:
                o = x
                break
        if o is None:
            return False, {"error": "0x048C block not found in EXE"}

        # Parse tree and decode string offsets
        try:
            sys.path.insert(0, os.path.join(os.path.dirname(__file__), "..", "translation-tools"))
            from hbe.huffman.dq4 import DQ4Schema
            import dq4_hbd_patcher as P
        except ImportError:
            sys.path.insert(0, os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "translation-tools"))
            from hbe.huffman.dq4 import DQ4Schema
            import dq4_hbd_patcher as P

        sc = DQ4Schema()
        end, bid, hts, te, txe, unk = struct.unpack_from("<6I", exe_data, o)
        tree_end_off = o + (te if te else end)
        tree = sc.parse_tree(exe_data[o + txe + 10:tree_end_off])
        leaves = sc.decode(exe_data[o + hts:o + txe], tree)
        offsets = [bo for _i, bo in P.compute_sequence_bit_offsets(leaves, tree)]

        if len(offsets) < 779:
            return False, {"error": "only %d strings (need >= 779)" % len(offsets)}

        deltas = {
            "774-773": offsets[774] - offsets[773],
            "776-775": offsets[776] - offsets[775],
            "777-775": offsets[777] - offsets[775],
            "778-775": offsets[778] - offsets[775],
        }

        passed = all(deltas[k] == v for k, v in self.delta_locks.items())
        return passed, deltas

    # --- 048F freeze token verification ---

    def verify_freeze_tokens(self, exe_data):
        """Verify that the 048F block contains all expected freeze tokens.

        Returns (passed: bool, found: dict).
        """
        found = {}
        # Read the 048F block from the EXE
        off = BLOCK_048F_FILE_OFF
        if off + 4 > len(exe_data):
            return False, {"error": "048F offset beyond EXE size"}

        end_048f = struct.unpack_from("<I", exe_data, off)[0]
        blk_size = min(end_048f + 4, len(exe_data) - off)
        block_data = exe_data[off:off + blk_size]

        for token in self.freeze_tokens:
            hi = (token >> 8) & 0xFF
            lo = token & 0xFF
            pattern = bytes([hi, lo])
            count = 0
            idx = block_data.find(pattern)
            while idx != -1:
                count += 1
                idx = block_data.find(pattern, idx + 1)
            found["0x%04X" % token] = count

        passed = all(found["0x%04X" % t] > 0 for t in self.freeze_tokens)
        return passed, found

    # --- D2/D3 bad word scan ---

    def scan_bad_words(self, disc_path):
        """Scan the disc for D2/D3 stale referrer words.

        Returns dict: bad_word -> list of (lba, uoff) hits.
        """
        hits = {w: [] for w in self.bad_words}
        with open(disc_path, "rb") as f:
            data = f.read()
        nsec = len(data) // RAW
        for w in self.bad_words:
            pat = struct.pack("<I", w)
            i = data.find(pat)
            while i != -1:
                rel = i - UOFF
                if rel >= 0:
                    in_sec = rel % RAW
                    if 24 <= in_sec < UOFF + USZ and (in_sec - UOFF) % 4 == 0 \
                            and (rel // RAW) < nsec:
                        hits[w].append((rel // RAW, in_sec - UOFF))
                i = data.find(pat, i + 1)
        return hits

    # --- Bare page LBA verification ---

    def verify_bare_page_lba(self, disc_path, pristine_path):
        """Verify that the bare page remap targets the correct LBA (40217)
        and uses the 362-sector base offset.

        Returns (passed: bool, details: dict).
        """
        details = {
            "expected_target_lba": self.bare_page_target,
            "base_offset": self.bare_page_base,
            "expected_rows": self.bare_page_rows,
        }

        # Check that LBA 40217 is within the HBD archive (starts at LBA 362)
        with open(disc_path, "rb") as f:
            f.seek(0, 2)
            total_sectors = f.tell() // RAW

        if self.bare_page_target >= total_sectors:
            details["error"] = "Target LBA %d beyond disc size (%d sectors)" % (
                self.bare_page_target, total_sectors)
            return False, details

        # Verify the target LBA contains 048B page-table data
        with open(disc_path, "rb") as f:
            f.seek(self.bare_page_target * RAW + UOFF)
            sector_data = f.read(USZ)

        # The 048B block header starts with end, bid, hts, ...
        # Look for the 048B block ID (0x048B) in the target region
        found_048b = False
        for off in range(0, len(sector_data) - 24, 4):
            end, bid = struct.unpack_from("<II", sector_data, off)
            if (bid & 0xFFFF) == BLOCK_048B_ID:
                found_048b = True
                details["048b_found_at_lba"] = self.bare_page_target
                details["048b_offset_in_sector"] = off
                break

        if not found_048b:
            # The 048B block might be at a slightly different LBA
            # Search a small window around the expected LBA
            for search_lba in range(self.bare_page_target - 5, self.bare_page_target + 10):
                if search_lba < 0 or search_lba >= total_sectors:
                    continue
                with open(disc_path, "rb") as f:
                    f.seek(search_lba * RAW + UOFF)
                    sd = f.read(USZ)
                for off in range(0, len(sd) - 24, 4):
                    end, bid = struct.unpack_from("<II", sd, off)
                    if (bid & 0xFFFF) == BLOCK_048B_ID:
                        found_048b = True
                        details["048b_found_at_lba"] = search_lba
                        details["048b_offset_in_sector"] = off
                        details["lba_delta_from_expected"] = search_lba - self.bare_page_target
                        break
                if found_048b:
                    break

        details["048b_found"] = found_048b
        return found_048b, details

    # --- Full disc validation ---

    def validate_disc(self, disc_path, pristine_path=None):
        """Run all registered validations against a disc image.

        Returns (overall_passed: bool, results: dict).
        """
        results = {}

        # 1. Delta-lock verification
        exe = self.read_exe_from_disc(disc_path)
        passed, deltas = self.verify_delta_lock(exe)
        results["delta_lock"] = {"passed": passed, "deltas": deltas}

        # 2. Freeze token verification
        passed, tokens = self.verify_freeze_tokens(exe)
        results["freeze_tokens"] = {"passed": passed, "found": tokens}

        # 3. D2/D3 bad word scan
        hits = self.scan_bad_words(disc_path)
        total_bad = sum(len(v) for v in hits.values())
        results["bad_words"] = {
            "passed": total_bad == 0,
            "total_hits": total_bad,
            "details": {("0x%08X" % k): v for k, v in hits.items() if v},
        }

        # 4. Bare page LBA verification
        if pristine_path and os.path.exists(pristine_path):
            passed, details = self.verify_bare_page_lba(disc_path, pristine_path)
            results["bare_page_lba"] = {"passed": passed, "details": details}

        overall = all(r["passed"] for r in results.values())
        return overall, results

    # --- Summary printer ---

    @staticmethod
    def print_results(overall, results):
        print("=" * 66)
        print("  PATCH REGISTRY VALIDATION")
        print("=" * 66)
        for name, r in results.items():
            status = "PASS" if r["passed"] else "FAIL"
            print("  [%s] %s" % (status, name))
            if name == "delta_lock" and not r["passed"]:
                if "error" in r["deltas"]:
                    print("         %s" % r["deltas"]["error"])
                else:
                    for k, v in r["deltas"].items():
                        expected = DELTA_LOCKS.get(k, "?")
                        match = "OK" if v == expected else "MISMATCH (expected %s)" % expected
                        print("         %s = %d  %s" % (k, v, match))
            elif name == "freeze_tokens" and not r["passed"]:
                for k, v in r["found"].items():
                    print("         %s: %d occurrences" % (k, v))
            elif name == "bad_words" and not r["passed"]:
                for w, sites in r["details"].items():
                    for lba, uoff in sites:
                        print("         %s at LBA %d uoff 0x%03X" % (w, lba, uoff))
            elif name == "bare_page_lba" and not r["passed"]:
                for k, v in r["details"].items():
                    print("         %s: %s" % (k, v))
        print("=" * 66)
        print("  OVERALL: %s" % ("PASS" if overall else "FAIL"))
        print("=" * 66)


def main():
    ap = argparse.ArgumentParser(description="DQ4 Patch Registry — deterministic offset/byte/pointer validator")
    ap.add_argument("--disc", required=True, help="Master disc image to validate")
    ap.add_argument("--base", default=None, help="Pristine Japanese disc image (for bare page check)")
    args = ap.parse_args()

    if not os.path.exists(args.disc):
        print("[FAIL] Disc not found: %s" % args.disc)
        sys.exit(1)

    reg = PatchRegistry()
    overall, results = reg.validate_disc(args.disc, args.base)
    reg.print_results(overall, results)
    sys.exit(0 if overall else 1)


if __name__ == "__main__":
    main()
