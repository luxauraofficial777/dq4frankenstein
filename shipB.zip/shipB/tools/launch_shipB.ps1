# ShipB Quick Launch Script
# Usage: .\launch_shipB.ps1
# Launches DQ4 ShipB in DuckStation for testing

$duckExe = "C:\DuckStation\duckstation-qt-x64-ReleaseLTCG.exe"
$cuePath = "C:\LuxAura\VoidWalkers_Project\DQLOSTTRANSLATION\shipB\build\dq4_shipB.cue"
$logPath = "C:\DuckStation\duckstation.log"

if (-not (Test-Path $duckExe)) {
    Write-Host "ERROR: DuckStation not found at $duckExe" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $cuePath)) {
    Write-Host "ERROR: ShipB CUE not found at $cuePath" -ForegroundColor Red
    exit 1
}

# Clear old log
Remove-Item $logPath -Force -ErrorAction SilentlyContinue

Write-Host "Launching ShipB in DuckStation..." -ForegroundColor Green
Write-Host "  CUE: $cuePath"
Write-Host "  Log: $logPath"
Write-Host ""

Start-Process -FilePath $duckExe -ArgumentList "-batch", "-earlyconsole", $cuePath

Write-Host "DuckStation launched. Monitor log with:"
Write-Host "  Get-Content '$logPath' -Wait -Tail 20"
