#!/usr/bin/env python3
"""
tools/patch_block048c_verified.py -- Block 0x048C (Font 1 menus) injector.

Replaces tools/patch_complete_block_048c.py, which corrupted .text.

WHY THE OLD ONE CRASHED
-----------------------
SLPM_869.16 is a PS-X EXE. Its header gives t_addr = 0x80017F00 and the text
segment begins at file offset 0x800, so

    file_offset = va - 0x80017F00 + 0x800 = va - 0x80017700

The old patcher used 0x80017700 for its split-immediate fixups but 0x80017500
for the referrer table walk. Every referrer write therefore landed 0x200 bytes
past its target. Measured against the pristine executable, the old output
differed in 2,366 bytes OUTSIDE block 0x048C, the first at file 0x860
(VA 0x80017F60) -- the opening instructions of .text. That is the
ReservedInstruction / bus-error crash.

It also walked whole VA ranges 4 bytes at a time, several of which
(e.g. 0x80017D60) lie BELOW t_addr and are not in the loaded image at all.

WHAT THIS ONE DOES
------------------
1. Derives every offset from the PS-X EXE header and from the block's own
   6-int header. Nothing about the layout is hardcoded.
2. Refuses to run if the block header is not found. It never guesses a target.
3. Writes referrers ONLY through the two verified tables, walked by their
   stride and field offsets -- never a blind sweep of .text:
       EXE_TABLES[0]  base 0x800A9FA0  stride 48  fields (20, 24)
       EXE_TABLES[1]  base 0x80019CE4  stride 16  fields (8,)
   A word is rewritten only if it already decodes to (0x048C << 20 | offset)
   AND that offset lands exactly on a known string start.
4. Handles addiu sign-extension on split immediates: when the low half is
   >= 0x8000 the assembler's addiu will sign-extend, so the high half needs +1.
5. Preserves every string carrying a control code. Slots 13-60 hold live
   format specifiers (<7F15> gold, <7F1A> actor); overwriting them with plain
   text crashes the text-box parser.

Run with --report to measure and change nothing.
"""

import argparse
import collections
import os
import struct
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
sys.path.insert(0, ROOT)
sys.path.insert(0, os.path.join(ROOT, "psx_tools"))

from dq4 import iso as isomod, textblock, huffman, treebuild

DISC_JP_PATH = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
BLOCK_ID = 0x048C
BLOCK_SIZE = 6800

# The two tables the disassembly names, as (base VA, stride, fields).
EXE_TABLES = ((0x800A9FA0, 48, (20, 24)), (0x80019CE4, 16, (8,)))

# lui/addiu and lui/ori pairs that construct a reference to this block.
SPLIT_IMM_ADDRS = (0x8002C070, 0x8002C168, 0x8008D4AC)

# FONT 1 LABEL POLICY (user directive, 2026-09-02):
#   Font 1 is a fixed 8x14 cell in narrow windows and block 0x048C ships 100%
#   packed, so every Font 1 label is capped at THREE characters. Four is too
#   many. Font 2 dialogue is NOT affected and stays full English.
FONT1_MAX = 3
VOWELS = "AEIOUaeiou"

# WORD-level overrides, so a correction composes across every name that uses
# the word: "sword" -> SWD fixes Copper Sword, Iron Sword, Zenithian Sword at
# once. The skeleton below already yields Metal Slime -> MTL SLM and
# Copper -> CPR; only words it gets wrong need an entry here.
FONT1_WORDS = {
    "sword": "SWD",       # skeleton would give SWR
}

# Whole-name overrides, for names no per-word rule can reach.
FONT1_NAMES = {}


def font1_skeleton(word):
    """Algorithmic fallback for ONE word: keep the leading character, drop
    vowels, collapse a doubled consonant, hard-cap at FONT1_MAX.

    Metal -> MTL, Slime -> SLM, Copper -> CPR (the doubled p collapses).
    """
    if not word:
        return word
    if len(word) <= FONT1_MAX:
        return word.upper()          # INN stays INN, BAR stays BAR
    out = [word[0]]
    for ch in word[1:]:
        if ch in VOWELS:
            continue
        if out and ch.upper() == out[-1].upper():
            continue                      # copper -> C P R, not C P P
        out.append(ch)
    return "".join(out)[:FONT1_MAX].upper()


_STRIP = chr(39) + chr(34) + ".,()"


def font1_word(word):
    core = word.strip(_STRIP).lower()
    if core in FONT1_WORDS:
        return FONT1_WORDS[core]
    return font1_skeleton(word)


def font1_label(name):
    """Shorten a Font 1 name. Multi-word names abbreviate per word and keep the
    space: 'Copper Sword' -> 'CPR SWD', 'Metal Slime' -> 'MTL SLM'."""
    key = " ".join(name.split()).lower()
    if key in FONT1_NAMES:
        return FONT1_NAMES[key]
    return " ".join(font1_word(w) for w in name.split())


# Field / battle command labels, by string index. Hand-picked, exactly 3 chars.
FONT1_COMMANDS = {
    # field command menu
    755: "TLK",   # TALK
    754: "ITM",   # ITEM
    752: "SPL",   # SPELL
    753: "STS",   # STATUS
    751: "SRC",   # SEARCH
    750: "TCT",   # TACTIC
    756: "PRT",   # PARTY
    # battle
    726: "ATK",   # ATTACK
    721: "DFD",   # DEFEND
    724: "RUN",
    # confirm prompts are single letters
    757: "N",     # NO
    758: "Y",     # YES
    # shop / status duplicates of the same verbs
    558: "ITM",
    562: "STS",
    565: "SPL",
    568: "TCT",
}


NAME_SOURCES = ("exe_block_048c_master.json", "exe_block_048c_translated.json",
                "exe_block_048c_font1_names.json")
JP_RE = __import__("re").compile(u"[\u3040-\u30ff\u4e00-\u9fff]")


def load_name_translations():
    """{string index: English name} for 0x048C items / monsters / spells.

    Merges the 0x048C dumps, newest-usable-wins, and drops anything that is a
    stub ("STR 123") or still carries Japanese.
    """
    import json
    out = {}
    for fn in NAME_SOURCES:
        path = os.path.join(ROOT, "translation", fn)
        if not os.path.exists(path):
            continue
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
        except Exception:
            continue
        if not isinstance(data, dict):
            continue
        for k, v in data.items():
            if not str(k).isdigit() or not isinstance(v, dict):
                continue
            en = (v.get("en") or "").strip()
            if not en or en.startswith("STR ") or JP_RE.search(en):
                continue
            key = int(k)
            if fn == NAME_SOURCES[-1]:
                out[key] = en          # explicit names file overrides everything
            else:
                out.setdefault(key, en)
    return out


def to_fullwidth(text):
    """ASCII -> fullwidth Shift-JIS. Font 1 is keyed by fullwidth codes only:
    the Huffman leaf decoder ORs 0x8000 into every non-zero leaf, so no code
    below 0x8000 is reachable from compressed text."""
    out = []
    for ch in text:
        o = ord(ch)
        if 0x41 <= o <= 0x5A:
            out.append(0x8260 + o - 0x41)
        elif 0x61 <= o <= 0x7A:
            out.append(0x8281 + o - 0x61)
        elif 0x30 <= o <= 0x39:
            out.append(0x824F + o - 0x30)
        else:
            out.append({' ': 0x8140, '!': 0x8149, '?': 0x8148, ':': 0x8146,
                        '-': 0x815B, '/': 0x815E, '&': 0x8195, '.': 0x8144,
                        ',': 0x8143, "'": 0x8166}.get(ch, 0x8140))
    return out


def read_exe():
    with isomod.RawISO(DISC_JP_PATH) as disc:
        found = disc.find("SLPM_869.16")
        if not found:
            raise SystemExit("[FAIL] SLPM_869.16 not found on the source disc")
        return bytearray(disc.read(found[0], found[1]))


def exe_geometry(exe):
    """(load_va, text_file_off, text_size) from the PS-X EXE header."""
    if bytes(exe[:8]) != b"PS-X EXE":
        raise SystemExit("[FAIL] not a PS-X EXE image")
    pc, gp, t_addr, t_size = struct.unpack_from("<4I", exe, 0x10)
    return t_addr, 0x800, t_size


def find_block(exe):
    """File offset of the 0x048C header. Hard failure if absent."""
    for off in range(0, len(exe) - 24, 4):
        a, bid, c, d, e, f6 = struct.unpack_from("<6I", exe, off)
        if (bid & 0xFFFF) == BLOCK_ID and 24 < e < a <= BLOCK_SIZE and c == 24:
            return off
    raise SystemExit("[FAIL] block 0x048C header not found; refusing to guess a target")


def _measure(streams, tb_orig):
    """(pairs, m, root, body, e, c) if this stream set fits, else None."""
    symbols = []
    for st in streams:
        symbols.extend(st)
        symbols.append((huffman.END, 0))
    pairs, m, root = treebuild.build(collections.Counter(symbols), min_depth=2)
    tree_end = tb_orig.d if tb_orig.d else tb_orig.a
    e = tree_end - len(pairs) * 2 - 10
    c = tb_orig.c
    if e <= c:
        return None
    codes = huffman.HuffmanTree(
        treebuild._Shim(pairs, m, root, tb_orig.raw, c, e)).codes()
    bits = "".join(codes[sym] for sym in symbols)
    body = bytearray()
    cur = nb = 0
    for b in bits:
        if b == "1":
            cur |= 1 << nb
        nb += 1
        if nb == 8:
            body.append(cur)
            cur = nb = 0
    if nb:
        body.append(cur)
    if len(body) > e - c:
        return None
    return pairs, m, root, bytes(body), e, c


def reachable_strings(exe, load, toff, tsize, tb):
    """Indices of 0x048C strings reachable from the executable.

    Deliberately the UNION of two scans, because a false NEGATIVE here would
    truncate a string the game still reads:
      a) the two named tables, walked by stride/field;
      b) every word-aligned dword in .text that decodes to this block AND
         lands exactly on a string start.
    (b) is too loose to drive WRITES, but as a keep-alive filter being
    over-inclusive is the safe direction.
    """
    offs = huffman.string_offsets(tb)
    pos = {o: i for i, o in enumerate(offs)}
    live = set()
    for base_va, stride, fields in EXE_TABLES:
        for i in range(4096):
            stop = False
            for f in fields:
                rel = base_va + stride * i + f - load
                if not (0 <= rel < tsize - 3):
                    stop = True
                    break
                w = struct.unpack_from("<I", exe, toff + rel)[0]
                if (w >> 20) != BLOCK_ID:
                    continue
                idx = pos.get((w & 0xFFFFF) - tb.c * 8)
                if idx is not None:
                    live.add(idx)
            if stop:
                break
    for o in range(0, tsize - 3, 4):
        w = struct.unpack_from("<I", exe, toff + o)[0]
        if (w >> 20) != BLOCK_ID:
            continue
        idx = pos.get((w & 0xFFFFF) - tb.c * 8)
        if idx is not None:
            live.add(idx)
    return live


def build_block_same_tree(tb_orig, report, live=None, commands=None, names=None):
    """Rebuild 0x048C translating strings, KEEPING the existing Huffman tree.

    The engine hardcodes bit-offset deltas across SIDs 773-778 (cursor blink /
    menu advancement: 774-773==44, 776-775==36, 777-775==50, 778-775==66). A
    rebuilt tree can drift those deltas (measured drift 43/57 on 2026-09-07 =
    title-menu freeze). Re-encoding the (possibly translated) strings under the
    ORIGINAL tree preserves them by construction: the untouched anchor strings
    keep their exact bit lengths, and the tree bytes stay byte-identical.
    """
    strings, _ = huffman.split_strings(huffman.HuffmanTree(tb_orig).decode())
    orig_count = len(strings)
    commands = FONT1_COMMANDS if commands is None else commands
    names = {} if names is None else names
    live = set(range(orig_count)) if live is None else live

    streams = []
    translated = protected = 0
    applied_names = {}
    for i, st in enumerate(strings):
        has_ctrl = any(k in (huffman.CTRL, huffman.DICT) for k, _ in st)
        if has_ctrl or i in range(769, 780):
            # ctrl-bearing and the 773-778 UI delta-anchor band stay original
            # (font1_ourway rule: translating these drifts the hardcoded deltas)
            streams.append(st)
            protected += 1
        elif i in commands:
            streams.append([(huffman.SJIS, c) for c in to_fullwidth(commands[i])])
            translated += 1
        elif i in names:
            lbl = font1_label(names[i])
            streams.append([(huffman.SJIS, c) for c in to_fullwidth(lbl)])
            translated += 1
            applied_names[i] = (names[i], lbl)
        else:
            streams.append(st)
    report["orig_strings"] = orig_count
    report["translated"] = translated
    report["protected_ctrl"] = protected
    report["applied_names"] = applied_names
    report["truncated"] = []
    report["truncated_glyphs"] = 0

    codes = huffman.HuffmanTree(tb_orig).codes()
    missing = set()
    all_syms = []
    for st in streams:
        seq = list(st) + [(huffman.END, 0)]
        for sym in seq:
            if sym not in codes:
                missing.add(sym)
        all_syms.extend(seq)
    if missing:
        raise SystemExit("[FAIL] glyphs absent from the existing 0x048C tree: %s "
                         "(adjust labels or fall back to a delta-locked search)"
                         % sorted(missing))
    bits = "".join(codes[s] for s in all_syms)
    packed = bytearray()
    cur = nb = 0
    for b in bits:
        if b == "1":
            cur |= 1 << nb
        nb += 1
        if nb == 8:
            packed.append(cur)
            cur = nb = 0
    if nb:
        packed.append(cur)

    e_old = tb_orig.e if tb_orig.e else tb_orig.a
    a = tb_orig.a
    if 24 + len(packed) > e_old:
        raise SystemExit("[FAIL] 0x048C same-tree re-encode overflow: %d > %d bytes"
                         % (len(packed), e_old - 24))
    e_new = 24 + len(packed)
    # relocate the (byte-identical) tree: header follows the text immediately,
    # base/mid repointed to the new location, pairs zero-padded up to `a`.
    old_base, old_mid, root = struct.unpack_from("<IIH", tb_orig.raw, e_old)
    pairs = tb_orig.raw[e_old + 10: a]
    m2 = old_mid - old_base
    new_base = e_new + 10
    hdr = struct.pack("<6I", tb_orig.a, BLOCK_ID, tb_orig.c, tb_orig.d, e_new, tb_orig.f6)
    tree_hdr = struct.pack("<IIH", new_base, new_base + m2, root)
    pad = (a - new_base) - len(pairs)
    assert pad >= 0, "pair region underflow"
    raw = hdr + bytes(packed) + tree_hdr + pairs + b"\x00" * pad + tb_orig.raw[a:]

    assert len(raw) == len(tb_orig.raw), "size drift %d != %d" % (len(raw), len(tb_orig.raw))
    tb_new = textblock.TextBlock(raw)
    assert tb_new.invariants_hold(), "invariants failed on rebuilt 0x048C"
    assert tb_new.d == tb_orig.d and tb_new.a == tb_orig.a, "d/a drift"
    rt, _ = huffman.split_strings(huffman.HuffmanTree(tb_new).decode())
    assert len(rt) == orig_count, "round-trip drift %d != %d" % (len(rt), orig_count)

    new_offs = huffman.string_offsets(tb_new)
    assert new_offs[774] - new_offs[773] == 44, \
        "delta 774-773 = %d" % (new_offs[774] - new_offs[773])
    assert new_offs[776] - new_offs[775] == 36, \
        "delta 776-775 = %d" % (new_offs[776] - new_offs[775])
    assert new_offs[777] - new_offs[775] == 50, \
        "delta 777-775 = %d" % (new_offs[777] - new_offs[775])
    assert new_offs[778] - new_offs[775] == 66, \
        "delta 778-775 = %d" % (new_offs[778] - new_offs[775])
    report["code_bytes"] = len(packed)
    report["code_space"] = e_old - 24
    report["delta_lock"] = (44, 36, 50, 66)
    return bytes(raw), tb_new


def build_block(tb_orig, report, live=None, commands=None, names=None):
    """Rebuild 0x048C, translating only strings that carry no control code."""
    strings, _ = huffman.split_strings(huffman.HuffmanTree(tb_orig).decode())
    orig_count = len(strings)
    commands = FONT1_COMMANDS if commands is None else commands
    names = {} if names is None else names
    applied_names = {}
    live = set(range(orig_count)) if live is None else live

    streams = []
    translated = protected = 0
    for i, st in enumerate(strings):
        has_ctrl = any(k in (huffman.CTRL, huffman.DICT) for k, _ in st)
        if has_ctrl:
            # Live format specifier (<7F15> gold, <7F1A> actor) -- untouchable.
            streams.append(st)
            protected += 1
        elif i in commands:
            streams.append([(huffman.SJIS, c) for c in to_fullwidth(commands[i])])
            translated += 1
        elif i in names:
            # Items / monsters / spells: same Font 1 format as the commands,
            # 3 characters per word.
            lbl = font1_label(names[i])
            streams.append([(huffman.SJIS, c) for c in to_fullwidth(lbl)])
            translated += 1
            applied_names[i] = (names[i], lbl)
        else:
            streams.append(st)
    report["orig_strings"] = orig_count
    report["translated"] = translated
    report["protected_ctrl"] = protected

    # The block ships 100% packed: an identity rebuild is 5437 of 5440 bytes.
    # ANY Latin at all costs tree pairs (even YES/NO alone overflows by 13),
    # so space has to be freed before it can fit. Truncate ONLY strings that
    # are unreachable from the executable and carry no control code, largest
    # first, and only as many as needed to fit.
    protected_idx = set(
        i for i, st in enumerate(strings)
        if any(k in (huffman.CTRL, huffman.DICT) for k, _ in st))
    candidates = sorted(
        (i for i in range(orig_count)
         if i not in live and i not in protected_idx and i not in commands
         and i not in names and len(strings[i]) > 0),
        key=lambda i: -len(strings[i]))
    truncated = []
    while True:
        if _measure(streams, tb_orig) is not None:
            break
        if not candidates:
            raise SystemExit(
                "[FAIL] 0x048C still does not fit after truncating all %d "
                "unreferenced strings" % len(truncated))
        i = candidates.pop(0)
        streams[i] = []
        truncated.append(i)
    report["truncated"] = truncated
    report["truncated_glyphs"] = sum(len(strings[i]) for i in truncated)
    report["applied_names"] = applied_names

    symbols = []
    for st in streams:
        symbols.extend(st)
        symbols.append((huffman.END, 0))

    built, _ = huffman.split_strings(symbols)
    assert len(built) == orig_count, (
        "string count drift: %d != %d" % (len(built), orig_count))

    fit = _measure(streams, tb_orig)
    if fit is None:
        raise SystemExit("[FAIL] 0x048C does not fit")
    pairs, m, root, body, e, c = fit
    code_space = e - c
    report["code_bytes"] = len(body)
    report["code_space"] = code_space
    body = bytes(body) + b"\x00" * (code_space - len(body))

    tree_end = tb_orig.d if tb_orig.d else tb_orig.a
    base = e + 10
    pair_bytes = bytearray()
    for p0, p1 in pairs:
        pair_bytes += bytes((p0, p1))
    pair_bytes += b"\x00" * ((tree_end - base) - len(pair_bytes))

    header = struct.pack("<6I", tb_orig.a, BLOCK_ID, c, tb_orig.d, e, tb_orig.f6)
    record = tb_orig.raw[tb_orig.d:tb_orig.a] if tb_orig.d else b""
    tail = tb_orig.raw[tb_orig.a:]
    raw = header + bytes(body) + struct.pack("<IIH", base, base + m * 2, root) \
        + bytes(pair_bytes) + record + tail

    assert len(raw) == len(tb_orig.raw), "size drift %d != %d" % (len(raw), len(tb_orig.raw))
    tb_new = textblock.TextBlock(raw)
    assert tb_new.invariants_hold(), "invariants failed on rebuilt 0x048C"
    assert tb_new.d == tb_orig.d and tb_new.a == tb_orig.a, "d/a drift"
    rt, _ = huffman.split_strings(huffman.HuffmanTree(tb_new).decode())
    assert len(rt) == orig_count, "round-trip drift %d != %d" % (len(rt), orig_count)
    return bytes(raw), tb_new


def rewrite_referrers(exe, load, toff, tsize, tb_orig, tb_new, block_off, apply_writes, report):
    """Rewrite (0x048C<<20|off) words, ONLY inside the two named tables."""
    old_offs = huffman.string_offsets(tb_orig)
    new_offs = huffman.string_offsets(tb_new)
    old_pos = {o: i for i, o in enumerate(old_offs)}

    # MEASURED 2026-09-02, and this is why the scan is image-wide rather than
    # table-only. 1,202 words in .text resolve to an EXACT 0x048C string start.
    # Controls: block ids 0x048B / 0x048D / 0x0500 -> 0 hits; the same 0x048C
    # words with the offsets shifted a single bit -> 0 hits. The filter's
    # false-positive rate is zero, because a word must both carry 0x048C in its
    # top 12 bits AND land on one of 780 starts out of ~44,000 bit positions.
    #
    # 411 of those words sit in the two named tables and 791 elsewhere. Writing
    # only the tables leaves 791 references pointing into a rebuilt stream, and
    # the menus then draw garbage kana. The original patcher found this same set
    # of 1,202; what broke it was the 0x200 load-base skew that sent the writes
    # to the wrong addresses, not the way it chose them.
    hits, skipped = 0, 0
    locations = []
    block_lo, block_hi = block_off, block_off + BLOCK_SIZE
    for o in range(toff, toff + tsize - 3, 4):
        if block_lo <= o < block_hi:
            continue                      # never rewrite the block's own bytes
        w = struct.unpack_from("<I", exe, o)[0]
        if (w >> 20) != BLOCK_ID:
            continue
        idx = old_pos.get((w & 0xFFFFF) - tb_orig.c * 8)
        if idx is None:
            continue                      # not a string start: not a reference
        if idx >= len(new_offs):
            skipped += 1
            continue
        new_w = (BLOCK_ID << 20) | ((new_offs[idx] + tb_new.c * 8) & 0xFFFFF)
        if apply_writes:
            struct.pack_into("<I", exe, o, new_w)
        hits += 1
        locations.append((load + (o - toff), o, idx))
    report["referrers_rewritten"] = hits
    report["referrers_unresolved"] = skipped
    report["referrer_locations"] = locations
    return hits


def rewrite_split_imms(exe, load, toff, tsize, tb_orig, tb_new, apply_writes, report):
    """lui/addiu and lui/ori pairs, with the addiu sign-extension rule."""
    old_offs = huffman.string_offsets(tb_orig)
    new_offs = huffman.string_offsets(tb_new)
    old_pos = {o: i for i, o in enumerate(old_offs)}

    done = []
    for va in SPLIT_IMM_ADDRS:
        rel = va - load
        if not (0 <= rel and rel + 12 <= tsize):
            report.setdefault("split_out_of_range", []).append(va)
            continue
        o = toff + rel
        w_hi = struct.unpack_from("<I", exe, o)[0]
        w_lo = struct.unpack_from("<I", exe, o + 8)[0]
        if (w_hi >> 26) != 0x0F:               # must be lui
            report.setdefault("split_not_lui", []).append(va)
            continue
        op = (w_lo >> 26) & 0x3F
        if op not in (0x09, 0x0D):             # addiu / ori
            report.setdefault("split_bad_op", []).append(va)
            continue

        hi, lo = w_hi & 0xFFFF, w_lo & 0xFFFF
        if op == 0x09 and hi:                  # addiu: undo sign extension
            word = ((hi - 1 if lo >= 0x8000 else hi) << 16) | lo
        else:
            word = (hi << 16) | lo
        if (word >> 20) != BLOCK_ID:
            report.setdefault("split_not_048c", []).append((va, word))
            continue
        idx = old_pos.get((word & 0xFFFFF) - tb_orig.c * 8)
        if idx is None:
            report.setdefault("split_unresolved", []).append((va, word))
            continue

        new_word = (BLOCK_ID << 20) | ((new_offs[idx] + tb_new.c * 8) & 0xFFFFF)
        n_hi, n_lo = (new_word >> 16) & 0xFFFF, new_word & 0xFFFF
        if op == 0x09 and n_lo >= 0x8000:
            n_hi = (n_hi + 1) & 0xFFFF         # addiu will sign-extend
        if apply_writes:
            struct.pack_into("<I", exe, o, (w_hi & 0xFFFF0000) | n_hi)
            struct.pack_into("<I", exe, o + 8, (w_lo & 0xFFFF0000) | n_lo)
        done.append((va, idx))
    report["split_imms_rewritten"] = len(done)
    return len(done)


def patch(apply_writes=True, out_path=None, base_path=None):
    # Build ON TOP OF an already-patched executable when one exists, so
    # earlier work (the title-menu strings at file 0x0B7BD) survives.
    if base_path and os.path.exists(base_path):
        with open(base_path, 'rb') as f:
            exe = bytearray(f.read())
    else:
        exe = read_exe()
    pristine = bytes(exe)
    load, toff, tsize = exe_geometry(exe)
    pos = find_block(exe)

    report = {"load_va": load, "text_file_off": toff, "text_size": tsize,
              "block_file_off": pos, "block_va": pos - toff + load}

    tb_orig = textblock.TextBlock(bytes(exe[pos:pos + BLOCK_SIZE]))
    live = reachable_strings(exe, load, toff, tsize, tb_orig)
    report["reachable"] = len(live)
    names = load_name_translations()
    report["name_candidates"] = len(names)
    # Same-tree rebuild ONLY: the engine-hardcoded UI deltas (773-778) must
    # survive every rebuild; a free tree rebuild broke them (43/57 vs 44/66)
    # and froze the title menu (fixed 2026-09-07).
    raw_new, tb_new = build_block_same_tree(tb_orig, report, live=live, names=names)
    if apply_writes:
        exe[pos:pos + BLOCK_SIZE] = raw_new

    rewrite_referrers(exe, load, toff, tsize, tb_orig, tb_new, pos, apply_writes, report)
    rewrite_split_imms(exe, load, toff, tsize, tb_orig, tb_new, apply_writes, report)

    # Containment gate: nothing outside the block and the named referrer words
    # may differ from pristine.
    allowed = set(range(pos, pos + BLOCK_SIZE))
    for _va, o, _i in report["referrer_locations"]:
        allowed.update(range(o, o + 4))
    for va in SPLIT_IMM_ADDRS:
        o = toff + (va - load)
        if 0 <= o and o + 12 <= len(exe):
            allowed.update(range(o, o + 4))
            allowed.update(range(o + 8, o + 12))
    stray = [i for i in range(min(len(exe), len(pristine)))
             if exe[i] != pristine[i] and i not in allowed]
    report["stray_writes"] = len(stray)
    report["stray_first"] = [hex(x) for x in stray[:8]]

    if apply_writes and stray:
        raise SystemExit("[FAIL] containment gate: %d bytes written outside the "
                         "block and its verified referrers (first: %s)"
                         % (len(stray), report["stray_first"]))

    if apply_writes and out_path:
        with open(out_path, "wb") as f:
            f.write(bytes(exe))
    return bytes(exe), report


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--report", action="store_true",
                    help="measure and print; write nothing")
    ap.add_argument("--out", default=os.path.join(ROOT, "build", "SLPM_869.16"))
    ap.add_argument("--base", default=os.path.join(ROOT, "build", "SLPM_869.16"),
                    help="executable to patch on top of; pristine if absent")
    ap.add_argument("--names-review",
                    default=os.path.join(ROOT, "study", "FONT1_NAME_REVIEW.tsv"),
                    help="write index/English/abbreviation for hand-correction")
    args = ap.parse_args()

    exe, rep = patch(apply_writes=not args.report,
                     out_path=None if args.report else args.out,
                     base_path=args.base)

    print("=" * 72)
    print("  BLOCK 0x048C -- %s" % ("REPORT ONLY" if args.report else "PATCH APPLIED"))
    print("=" * 72)
    print("  load VA            0x%08X   text at file 0x%X, %d bytes"
          % (rep["load_va"], rep["text_file_off"], rep["text_size"]))
    print("  VA -> file         va - 0x%08X" % (rep["load_va"] - rep["text_file_off"]))
    print("  block 0x048C at    file 0x%06X  (VA 0x%08X)"
          % (rep["block_file_off"], rep["block_va"]))
    print("  strings            %d" % rep["orig_strings"])
    print("    translated       %d" % rep["translated"])
    print("    ctrl-protected   %d" % rep["protected_ctrl"])
    print("  reachable strings  %d (unreferenced: %d)"
          % (rep["reachable"], rep["orig_strings"] - rep["reachable"]))
    print("  truncated to fit   %d strings / %d glyphs %s"
          % (len(rep["truncated"]), rep["truncated_glyphs"],
             rep["truncated"][:12] if rep["truncated"] else ""))
    print("  name candidates    %d  (applied: %d)"
          % (rep["name_candidates"], len(rep["applied_names"])))
    print("  code stream        %d / %d bytes" % (rep["code_bytes"], rep["code_space"]))
    print("  referrers rewrit.  %d   (unresolved in-table words: %d)"
          % (rep["referrers_rewritten"], rep["referrers_unresolved"]))
    print("  split imms rewrit. %d" % rep["split_imms_rewritten"])
    for k in ("split_out_of_range", "split_not_lui", "split_bad_op",
              "split_not_048c", "split_unresolved"):
        if rep.get(k):
            print("    %-20s %s" % (k, rep[k]))
    print("  stray writes       %d %s"
          % (rep["stray_writes"], rep["stray_first"] if rep["stray_writes"] else ""))
    if args.names_review and rep.get("applied_names"):
        with open(args.names_review, "w", encoding="utf-8") as fh:
            fh.write("index\tenglish\tfont1\toverridden\n")
            for i in sorted(rep["applied_names"]):
                en, lbl = rep["applied_names"][i]
                ov = "yes" if " ".join(en.split()).lower() in FONT1_NAMES else "no"
                fh.write("%d\t%s\t%s\t%s\n" % (i, en, lbl, ov))
        print("  name review        %s" % args.names_review)
    if not args.report:
        print("  wrote              %s" % args.out)
    print("=" * 72)
    return 0


if __name__ == "__main__":
    sys.exit(main())
