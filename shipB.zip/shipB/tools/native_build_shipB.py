﻿#!/usr/bin/env python3
"""
tools/native_build_shipB.py

SHIPB BUILD PIPELINE â€” Rebuild B Baseline (No F6 Patches)
=========================================================

This pipeline is derived from ship/tools/native_build.py but with critical
differences:

  1. F6 patches (VSync timeout bypass, overlay collision redirect, allocator
     guard) are REMOVED. Runtime testing on 2026-09-09 proved these patches
     cause the prologue streaming crash (LBA 106958+, all sectors dropped,
     FPS 0.00). Rebuild B without these patches runs at 59.82 FPS with zero
     missed sectors.

  2. The base binary is dq4_rebuildB_sealed.bin (SHA AC9F94A1...), the
     verified known-good baseline from the forensic audit.

  3. Output goes to shipB/build/dq4_shipB.bin

Pipeline Steps (F6 patches STRUCK THROUGH):
  STEP -2  heely pre-check (static overlay alignment validator)
  STEP 0a  facility corpus generation (Inn/Bank/MedalKing/Casino/Church 047C-047D)
  STEP 0   corpus validation
  STEP 1   native dialogue
  STEP 1c  type-39 script remap
  STEP 2   font 1 menus/items/stats
  STEP 3   save menu 0x0474
  STEP 4   battle overlay 0x048B
  STEP 4b  overlay refs (Class A)
  STEP 4c  overlay duplicates (Class B)
  STEP 4e  048C same-tree rebuild
  STEP 4d  stale word-table sweep
  STEP 4h  bare pages remap
  STEP 1e  EXE blocks 0x048F
  STEP 4f  D4 splitimm fix
  STEP 4g  table/roster/exe stale ref remap
  STEP 4g-2  D2/D3 sid-identity injection
  ~~STEP 4h-2  F6 VSync timeout bypass~~     REMOVED â€” causes crash
  ~~STEP 4h-3  F6 overlay collision redirect~~ REMOVED â€” causes crash
  ~~STEP 4h-4  KSEG0 allocator guard~~       REMOVED â€” causes crash
  STEP 5   CUE + final EDC/ECC
  STEP 6   verification gates (G2, G10, G5)
  STEP 6b  patch registry validation (delta-lock, freeze tokens, bad words, bare page LBA)
  STEP 6c  Heely post-build check (sector table integrity + sub-map overlay boundary)
  STEP 7   seal gate (G11 residency)

Usage:
  python tools/native_build_shipB.py                    # Full build
  python tools/native_build_shipB.py --skip-dialogue    # Reuse existing dialogue bin
  python tools/native_build_shipB.py --from-step 4g      # Resume at step 4g
  python tools/native_build_shipB.py --g11-dumps d1.bin d2.bin  # Seal with RAM dumps
"""

import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

sys.stdout.reconfigure(encoding="utf-8")

ROOT = os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
SHIPB_ROOT = os.path.join(ROOT, "shipB")
PY = sys.executable

BASE_BIN = os.path.join(ROOT, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
if not os.path.exists(BASE_BIN):
    _parent_base = os.path.join(os.path.dirname(ROOT), "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
    if os.path.exists(_parent_base):
        BASE_BIN = _parent_base

INPUT_JSON = os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json")
DIALOGUE_BIN = os.path.join(SHIPB_ROOT, "build", "dq4_dialogue_en.bin")
MASTER_BIN = os.path.join(SHIPB_ROOT, "build", "dq4_shipB.bin")
MASTER_CUE = os.path.join(SHIPB_ROOT, "build", "dq4_shipB.cue")
LOG_DIR = os.path.join(SHIPB_ROOT, "build")

REBUILD_B_BIN = os.path.join(ROOT, "build", "dq4_rebuildB_sealed.bin")
REBUILD_B_SHA = "AC9F94A13A5627C30013FB0D13C88CD96F4BCEC878A2DA6E7B1978E1CD4E5703"

# --- self-contained path resolution: prefer SHIPB-local trees, fall back to repo ---
def _pref(local, repo):
    return local if os.path.exists(local) else repo

SHIPB_TT = _pref(os.path.join(SHIPB_ROOT, "translation-tools"), os.path.join(ROOT, "translation-tools"))
SHIPB_STUDY = _pref(os.path.join(SHIPB_ROOT, "study"), os.path.join(ROOT, "study"))
SHIPB_TOOLS = _pref(os.path.join(SHIPB_ROOT, "tools"), os.path.join(ROOT, "tools"))

EDCRE = _pref(os.path.join(SHIPB_ROOT, "edcre", "edcre.exe"),
              os.path.join(ROOT, "edcre", "edcre-v1.1.0-windows-x86_64-static", "edcre.exe"))
NATIVE_PATCHER = os.path.join(SHIPB_TT, "dq4_hbd_patcher.py")
PATCH_TYPE39 = os.path.join(SHIPB_TT, "patch_type39_scripts.py")
PATCH_FONT1 = os.path.join(SHIPB_TT, "patch_font1_ourway.py")
PATCH_SAVE_MENU = os.path.join(SHIPB_TT, "patch_save_menu.py")
PATCH_BATTLE = os.path.join(SHIPB_TT, "patch_battle_overlay.py")
PATCH_OVERLAY_REFS = os.path.join(SHIPB_TT, "patch_overlay_refs.py")
PATCH_OVERLAY_DUPLICATES = os.path.join(SHIPB_TT, "patch_overlay_duplicates.py")
PATCH_EXE_BLOCKS = os.path.join(SHIPB_TT, "patch_exe_blocks.py")
PATCH_D4_SPLITIMM = os.path.join(SHIPB_TT, "patch_d4_splitimm.py")
PATCH_TABLE_REFS = os.path.join(SHIPB_TT, "patch_table_refs.py")
VALIDATE_CORPUS = os.path.join(SHIPB_TT, "validate_corpus.py")
BUILD_FACILITIES = os.path.join(SHIPB_ROOT, "tools", "build_all_facilities.py")
PATCH_048C_SAMETREE = os.path.join(SHIPB_TOOLS, "patch_block048c_verified.py")
PATCH_D2_D3 = os.path.join(SHIPB_TOOLS, "patch_d2_d3_4g2.py")
SWEEP_WORDS = os.path.join(SHIPB_STUDY, "sweep_word_tables.py")
SWEEP_CACHE = os.path.join(SHIPB_ROOT, "build", "ram_scan_2_cache.pkl")
REMAP_BARE_PAGES = os.path.join(SHIPB_STUDY, "remap_bare_pages.py")
HEELY_PRECHECK = os.path.join(SHIPB_ROOT, "tools", "heely_precheck.py")
PATCH_REGISTRY = os.path.join(SHIPB_ROOT, "tools", "patch_registry.py")

# corpus: work on a SHIPB-LOCAL copy (never mutate the shared repo corpus)
INPUT_JSON = os.path.join(SHIPB_ROOT, "translation", "full_translation_boot_with_0069.json")
if not os.path.exists(INPUT_JSON):
    os.makedirs(os.path.dirname(INPUT_JSON), exist_ok=True)
    shutil.copy2(os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json"), INPUT_JSON)


def _run(cmd, log_path=None, timeout=1800):
    print("  $ " + " ".join('"%s"' % c if " " in c else c for c in cmd))
    t0 = time.time()
    if log_path:
        with open(log_path, "w", encoding="utf-8") as lf:
            proc = subprocess.run(cmd, cwd=ROOT, stdout=lf, stderr=subprocess.STDOUT,
                                  text=True, timeout=timeout)
    else:
        proc = subprocess.run(cmd, cwd=ROOT, text=True, timeout=timeout)
    dt = time.time() - t0
    print("  -> exit %d in %.1fs" % (proc.returncode, dt))
    return proc.returncode


def _hr(title):
    print("\n" + "=" * 72)
    print(title)
    print("=" * 72)


def _sha256(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest().upper()


def step_neg2_heely_precheck():
    _hr("STEP -2: Heely/Izmit static overlay alignment pre-check")
    if not os.path.exists(HEELY_PRECHECK):
        print("  [WARN] heely_precheck.py absent -- skipped")
        return
    baseline = os.path.join(SHIPB_STUDY, "heely_baseline.json")
    rc = _run([PY, HEELY_PRECHECK, "--disc", BASE_BIN, "--base", BASE_BIN,
               "--save-baseline", baseline])
    if rc != 0:
        print("  [WARN] heely pre-check found issues in pristine disc -- continuing")
    else:
        print("  [PASS] pristine disc passes Heely static alignment checks")
        print("  [BASELINE] sector table hash + block map saved to %s" % baseline)


def step_neg1_verify_rebuild_b():
    _hr("STEP -1: Verify Rebuild B baseline integrity (optional reference check)")
    if not os.path.exists(REBUILD_B_BIN):
        print("  [INFO] Rebuild B reference binary not present -- SKIPPING (pipeline-only")
        print("         distribution: the build runs from YOUR pristine image, no bin needed).")
        return
    sha = _sha256(REBUILD_B_BIN)
    if sha != REBUILD_B_SHA:
        print("[FAIL] Rebuild B SHA mismatch!")
        print("  Expected: %s" % REBUILD_B_SHA)
        print("  Actual:   %s" % sha)
        sys.exit(1)
    print("  [PASS] Rebuild B verified: %s" % sha[:16])


def _check_edcre():
    if os.path.exists(EDCRE):
        return True
    print("  [WARN] edcre.exe not found at: %s" % EDCRE)
    print("         Download edcre (RadMage, PSX EDC/ECC recalculator) and place it there.")
    print("         Without it, EDC/ECC steps are SKIPPED -- the output is NOT hardware-safe.")
    return False


def step0a_build_facilities(corpus=INPUT_JSON):
    _hr("STEP 0a: Facility corpus generation (Inn/Bank/MedalKing/Casino/Church 047C-047D)")
    if not os.path.exists(BUILD_FACILITIES):
        print("  [WARN] build_all_facilities.py absent -- facility text will use stale corpus")
        return
    rc = _run([PY, BUILD_FACILITIES])
    if rc != 0:
        print("[FAIL] build_all_facilities exit %d" % rc)
        sys.exit(1)
    if os.path.exists(corpus):
        csha = _sha256(corpus)
        print("  [PASS] facility corpus merged into translation JSON")
        print("  corpus sha256: %s" % csha[:16])
    else:
        print("  [FAIL] corpus file not found after facility generation: %s" % corpus)
        sys.exit(1)


def step0_validate_corpus(corpus):
    _hr("STEP 0: Pre-flight corpus validation")
    rc = _run([PY, VALIDATE_CORPUS, corpus])
    if rc != 0:
        print("[FAIL] corpus validation found FATAL control-code errors.")
        sys.exit(1)
    print("   [PASS] corpus is structurally clean.")
    g8 = os.path.join(SHIPB_STUDY, "g8_marker_parity.py")
    if os.path.isfile(g8):
        rc = _run([PY, g8])
        if rc != 0:
            print("[FAIL] G8 marker-parity gate failed.")
            sys.exit(1)


def step1_native_dialogue(corpus):
    _hr("STEP 1: Native dialogue (dq4_hbd_patcher.py)")
    log = os.path.join(LOG_DIR, "native_dialogue.log")
    rc = _run([PY, NATIVE_PATCHER, "--input", BASE_BIN,
               "--translations", corpus, "--output", DIALOGUE_BIN], log_path=log)
    if rc != 0:
        print("[FAIL] native dialogue patcher exit %d" % rc)
        sys.exit(1)
    with open(log, "r", encoding="utf-8", errors="ignore") as f:
        txt = f.read()
    for key in ("Found ", "Translatable", "Patched:", "Skipped:", "EDC/ECC:"):
        for line in txt.splitlines():
            if key in line:
                print("   " + line.strip())
                break


def step1c_remap_type39_scripts():
    _hr("STEP 1c: Type-39 compressed-script referrer remap")
    rc = _run([PY, PATCH_TYPE39, DIALOGUE_BIN])
    if rc != 0:
        print("[FAIL] patch_type39_scripts exit %d" % rc)
        sys.exit(1)


def step2_font1():
    _hr("STEP 2: Font 1 menus/items/stats + 0x048C referrers")
    rc = _run([PY, PATCH_FONT1, "--disc", DIALOGUE_BIN, "--out", MASTER_BIN])
    if rc != 0:
        print("[FAIL] patch_font1_ourway exit %d" % rc)
        sys.exit(1)


def step3_save_menu():
    _hr("STEP 3: Save menu 0x0474")
    rc = _run([PY, PATCH_SAVE_MENU, "--disc", MASTER_BIN])
    if rc != 0:
        print("[FAIL] patch_save_menu exit %d" % rc)
        sys.exit(1)


def step4_battle():
    _hr("STEP 4: Battle overlay 0x048B + monster DB referrers")
    rc = _run([PY, PATCH_BATTLE, "--disc", MASTER_BIN])
    if rc != 0:
        print("[FAIL] patch_battle_overlay exit %d" % rc)
        sys.exit(1)


def step4b_overlay_refs():
    _hr("STEP 4b: Overlay & EXE stale referrers (Class A)")
    rc = _run([PY, PATCH_OVERLAY_REFS, "--disc", MASTER_BIN, "--base", BASE_BIN])
    if rc != 0:
        print("[FAIL] patch_overlay_refs exit %d" % rc)
        sys.exit(1)


def step4c_overlay_duplicates():
    _hr("STEP 4c: Type-46 overlay duplicate blocks & internal refs (Class B)")
    rc = _run([PY, PATCH_OVERLAY_DUPLICATES, "--disc", MASTER_BIN, "--base", BASE_BIN])
    if rc != 0:
        print("[FAIL] patch_overlay_duplicates exit %d" % rc)
        sys.exit(1)


def step4e_048c_sametree():
    """STEP 4e: 048C same-tree rebuild â€” REAL WRITER.

    Runs patch_block048c_verified.py to produce a patched EXE, then commits
    the patched EXE back into the master disc image.  Verifies:
      1. Delta-lock: bit deltas across SIDs 773-778 strictly equal 44/36/50/66.
      2. 048F freeze tokens (7F06, 7F10, 7F19, 7F1B, 7F1C, 7F1E, 7F35) untouched.
      3. EDC/ECC recalculated after writeback.
    """
    import struct as _struct
    _hr("STEP 4e: 048C same-tree rebuild (REAL WRITER â€” commits to master disc)")
    t = PATCH_048C_SAMETREE
    if not os.path.exists(t):
        print("  [WARN] patch_block048c_verified.py absent -- skipped")
        return

    exe_extract = os.path.join(SHIPB_ROOT, "build", "vp_native_exe.extract")
    exe_patched = os.path.join(SHIPB_ROOT, "build", "vp_native_exe.extract.patched")

    # If the extracted EXE does not exist, extract it from the master disc.
    if not os.path.exists(exe_extract):
        sys.path.insert(0, os.path.join(ROOT, "psx_tools"))
        from dq4 import iso as _isomod
        with _isomod.RawISO(MASTER_BIN) as _disc:
            _found = _disc.find("SLPM_869.16")
            if not _found:
                print("[FAIL] SLPM_869.16 not found in master disc")
                sys.exit(1)
            _exe_data = _disc.read(_found[0], _found[1])
        with open(exe_extract, "wb") as _f:
            _f.write(_exe_data)
        print("  extracted EXE from master disc (%d bytes)" % len(_exe_data))

    # Run the patcher (same-tree rebuild with delta-lock assertions built in).
    rc = _run([PY, t, "--base", exe_extract, "--out", exe_patched])
    if rc != 0:
        print("[FAIL] patch_block048c_verified (STEP 4e) exit %d" % rc)
        sys.exit(1)

    # ---- Verify 048F freeze tokens are byte-identical (untouched) ----
    BLOCK_048F_OFF = 0x99624
    FREEZE_TOKENS = [0x7F06, 0x7F10, 0x7F19, 0x7F1B, 0x7F1C, 0x7F1E, 0x7F35]

    with open(exe_extract, "rb") as _f:
        _orig_exe = _f.read()
    with open(exe_patched, "rb") as _f:
        _patched_exe = _f.read()

    # Compare the 048F block region byte-for-byte.
    _end_048f = _struct.unpack_from("<I", _orig_exe, BLOCK_048F_OFF)[0]
    _blk_size = _end_048f + 4
    _orig_048f = _orig_exe[BLOCK_048F_OFF:BLOCK_048F_OFF + _blk_size]
    _patched_048f = _patched_exe[BLOCK_048F_OFF:BLOCK_048F_OFF + _blk_size]
    if _orig_048f != _patched_048f:
        print("[FAIL] 048F block was modified by STEP 4e")
        print("  freeze tokens may be corrupted: %s" % 
              ", ".join("0x%04X" % t for t in FREEZE_TOKENS))
        sys.exit(1)
    print("  [PASS] 048F block byte-identical (7 freeze tokens untouched: %s)" %
          ", ".join("0x%04X" % t for t in FREEZE_TOKENS))

    # Delta-lock is already asserted inside the patcher (44/36/50/66).
    # If it exited 0, the deltas passed.
    print("  [PASS] delta-lock verified: 774-773=44, 776-775=36, 777-775=50, 778-775=66")

    # ---- Write patched EXE back into the master disc image ----
    sys.path.insert(0, os.path.join(ROOT, "psx_tools"))
    from dq4 import iso as _isomod2
    with _isomod2.RawISO(MASTER_BIN) as _disc:
        _found = _disc.find("SLPM_869.16")
        if not _found:
            print("[FAIL] SLPM_869.16 not found in master disc for writeback")
            sys.exit(1)
        _exe_lba = _found[0]

    _RAW, _UOFF, _USZ = 2352, 24, 2048
    _n_sectors = (len(_patched_exe) + _USZ - 1) // _USZ
    with open(MASTER_BIN, "r+b") as _f:
        for _i in range(_n_sectors):
            _offset = _i * _USZ
            _chunk = _patched_exe[_offset:_offset + _USZ]
            if not _chunk:
                break
            _f.seek((_exe_lba + _i) * _RAW + _UOFF)
            _f.write(_chunk)
    print("  wrote patched EXE (%d bytes, %d sectors) to master disc at LBA %d" %
          (len(_patched_exe), _n_sectors, _exe_lba))

    # Readback verification: re-read the written sectors and compare.
    with open(MASTER_BIN, "rb") as _f:
        for _i in range(_n_sectors):
            _offset = _i * _USZ
            _expected = _patched_exe[_offset:_offset + _USZ]
            _f.seek((_exe_lba + _i) * _RAW + _UOFF)
            _actual = _f.read(_USZ)
            if _actual != _expected:
                print("[FAIL] EXE writeback readback mismatch at LBA %d" % (_exe_lba + _i))
                sys.exit(1)
    print("  [PASS] EXE writeback readback verified (%d sectors)" % _n_sectors)

    # Run EDC/ECC fixup on the modified sectors.
    if os.path.exists(EDCRE):
        _proc = subprocess.run([EDCRE, MASTER_BIN], capture_output=True, text=True, timeout=900)
        print("  [%s] EDC/ECC fixup after EXE writeback" %
              ("PASS" if _proc.returncode == 0 else "FAIL"))
        if _proc.returncode != 0:
            print("  stderr: %s" % _proc.stderr[:400])
            sys.exit(1)


def step4d_sweep():
    _hr("STEP 4d: stale word-table sweep (fixed-point to 0)")
    t = SWEEP_WORDS
    cache = SWEEP_CACHE
    if not os.path.exists(t) or not os.path.exists(cache):
        print("  [WARN] sweep tooling/cache missing -- skipped")
        return
    for i in (1, 2):
        rc = _run([PY, t, "--write", "--disc", MASTER_BIN, "--cache", cache])
        if rc != 0:
            print("[FAIL] sweep_word_tables (write pass %d) exit %d" % (i, rc))
            sys.exit(1)
    rc = _run([PY, t, "--disc", MASTER_BIN, "--cache", cache])
    if rc != 0:
        print("[FAIL] sweep_word_tables (verify pass) exit %d" % rc)
        sys.exit(1)


def step4h_bare_pages():
    _hr("STEP 4h: 048B page-table row remap (Class D)")
    t = REMAP_BARE_PAGES
    if not os.path.exists(t):
        print("  [WARN] remap_bare_pages.py absent -- skipped")
        return
    rc = _run([PY, t, "--write", "--disc", MASTER_BIN, "--pristine", BASE_BIN])
    if rc != 0:
        print("[FAIL] remap_bare_pages exit %d" % rc)
        sys.exit(1)


def step1e_exe_blocks(corpus):
    _hr("STEP 1e: EXE block 0x048F (church/priest save-load)")
    if not os.path.exists(PATCH_EXE_BLOCKS):
        print("  [SKIP] patch_exe_blocks.py absent")
        return
    rc = _run([PY, PATCH_EXE_BLOCKS, "--disc", MASTER_BIN, "--corpus", corpus, "--no-edc"])
    if rc != 0:
        print("[FAIL] patch_exe_blocks exit %d" % rc)
        sys.exit(1)


def step4f_d4_splitimm():
    _hr("STEP 4f: D4 fix (048C/048F split-imm + direct + type-39 scripts)")
    if not os.path.exists(PATCH_D4_SPLITIMM):
        print("  [WARN] patch_d4_splitimm.py absent -- skipped")
        return
    rc = _run([PY, PATCH_D4_SPLITIMM, "--disc", MASTER_BIN, "--base", BASE_BIN, "--write"])
    if rc != 0:
        print("[FAIL] patch_d4_splitimm exit %d" % rc)
        sys.exit(1)


def step4g_table_refs():
    _hr("STEP 4g: TABLE/ROSTER/EXE stale ref remap")
    if not os.path.exists(PATCH_TABLE_REFS):
        print("  [WARN] patch_table_refs.py absent -- skipped")
        return
    rc = _run([PY, PATCH_TABLE_REFS, "--disc", MASTER_BIN, "--base", BASE_BIN, "--write"])
    if rc != 0:
        print("[FAIL] patch_table_refs (write) exit %d" % rc)
        sys.exit(1)
    rc = _run([PY, PATCH_TABLE_REFS, "--disc", MASTER_BIN, "--base", BASE_BIN])
    if rc != 0:
        print("[FAIL] patch_table_refs (verify) exit %d" % rc)
        sys.exit(1)


def step4g2_d2_d3():
    _hr("STEP 4g-2: D2/D3 sid-identity injection (church offering + victory)")
    t = PATCH_D2_D3
    if not os.path.exists(t):
        print("  [WARN] patch_d2_d3_4g2.py absent -- skipped")
        return
    rc = _run([PY, t, "--disc", MASTER_BIN, "--base", BASE_BIN, "--write"])
    if rc != 0:
        print("[FAIL] patch_d2_d3_4g2 exit %d" % rc)
        sys.exit(1)


def step5_cue_and_verify():
    _hr("STEP 5: CUE + final EDC/ECC (runs LAST)")
    cue = ('FILE "%s" BINARY\n'
           '  TRACK 01 MODE2/2352\n'
           '    INDEX 01 00:00:00\n') % os.path.basename(MASTER_BIN)
    with open(MASTER_CUE, "w", encoding="ascii") as f:
        f.write(cue)
    print("  wrote %s" % MASTER_CUE)
    if os.path.exists(EDCRE):
        proc = subprocess.run([EDCRE, MASTER_BIN], capture_output=True, text=True, timeout=900)
        if proc.stdout.strip():
            print("  " + proc.stdout.strip().splitlines()[-1])
        print("  [%s] final EDC/ECC" % ("PASS" if proc.returncode == 0 else "FAIL"))
        if proc.returncode != 0:
            print("  stderr: %s" % proc.stderr[:400])
            sys.exit(1)
    sz = os.path.getsize(MASTER_BIN)
    print("\nSHIPB MASTER READY:")
    print("  BIN: %s (%s bytes)" % (MASTER_BIN, format(sz, ",")))
    print("  CUE: %s" % MASTER_CUE)


def step6b_patch_registry():
    _hr("STEP 6b: Patch registry validation (delta-lock, freeze tokens, bad words)")
    if not os.path.exists(PATCH_REGISTRY):
        print("  [WARN] patch_registry.py absent -- skipped")
        return
    rc = _run([PY, PATCH_REGISTRY, "--disc", MASTER_BIN, "--base", BASE_BIN])
    if rc != 0:
        print("[FAIL] patch registry validation failed")
        sys.exit(1)


def step6c_heely_postcheck():
    _hr("STEP 6c: Heely post-build overlay alignment check (sector table + sub-map boundary)")
    if not os.path.exists(HEELY_PRECHECK):
        print("  [WARN] heely_precheck.py absent -- skipped")
        return
    report_json = os.path.join(SHIPB_STUDY, "heely_postcheck_report.json")
    rc = _run([PY, HEELY_PRECHECK, "--disc", MASTER_BIN, "--base", BASE_BIN,
               "--json", report_json])
    if rc != 0:
        print("[FAIL] Heely post-build check failed — sector table or sub-map boundary corrupted", file=sys.stderr)
        print("[FAIL] See report: %s" % report_json, file=sys.stderr)
        sys.exit(1)
    print("  [PASS] post-build disc passes Heely overlay alignment checks")
    print("  [REPORT] %s" % report_json)


def step6_gates(corpus):
    _hr("STEP 6: G2 multi-tree dispatch gate + G10 census + G5 EDC sweep")
    g2 = os.path.join(SHIPB_STUDY, "g2_dispatch_gate.py")
    if os.path.exists(g2):
        rc = _run([PY, g2, "--disc", MASTER_BIN, "--pristine", BASE_BIN])
        if rc != 0:
            print("[FAIL] G2 dispatch gate.")
            sys.exit(1)
    g10 = os.path.join(SHIPB_STUDY, "g10_corpus_census.py")
    if os.path.exists(g10):
        rc = _run([PY, g10, "--disc", MASTER_BIN, "--corpus", corpus], timeout=3600)
        if rc != 0:
            print("[FAIL] G10 corpus census.")
            sys.exit(1)
    e3 = os.path.join(SHIPB_STUDY, "check_edc3.py")
    if os.path.exists(e3):
        rc = _run([PY, e3, MASTER_BIN])
        if rc != 0:
            print("[FAIL] check_edc3 (G5 EDC sweep)")
            sys.exit(1)


def _write_g11_pending(sha):
    p = os.path.join(LOG_DIR, "G11_PENDING")
    with open(p, "w", encoding="ascii") as f:
        f.write("master sha256=%s\n" % sha)
    print("  [DEFER] G11 residency not yet verified for this master (sha %s)." % sha[:16])


def step7_seal(g11_dumps, label="shipB"):
    _hr("STEP 7: SEAL GATE (G11 residency -> release label)")
    sha = _sha256(MASTER_BIN)
    g11 = os.path.join(SHIPB_STUDY, "g11_menu_residency_gate.py")
    rec = os.path.join(LOG_DIR, "G11_PASS.json")
    if g11_dumps:
        rc = _run([PY, g11, "--disc", MASTER_BIN, "--ram", *g11_dumps,
                   "--record", rec], timeout=1800)
        if rc != 0:
            print("[FAIL] G11 menu-residency gate -- seal BLOCKED.")
            sys.exit(1)
    elif os.path.exists(rec):
        with open(rec, encoding="utf-8") as f:
            old = json.load(f)
        if old.get("disc_sha256_16") != sha[:16]:
            print("[DEFER] existing G11 record is for %s, master is %s." % (old.get("disc_sha256_16"), sha[:16]))
            _write_g11_pending(sha)
            return
        print("  [PASS] valid G11 record on file for this master")
    else:
        _write_g11_pending(sha)
        return
    rel_dir = os.path.join(SHIPB_ROOT, "release")
    os.makedirs(rel_dir, exist_ok=True)
    stem = "DQ4_%s_%s" % (label, sha[:8])
    rel_bin = os.path.join(rel_dir, stem + ".bin")
    rel_cue = os.path.join(rel_dir, stem + ".cue")
    rel_sha = os.path.join(rel_dir, stem + ".sha256")
    shutil.copyfile(MASTER_BIN, rel_bin)
    with open(rel_cue, "w", encoding="ascii") as f:
        f.write('FILE "%s" BINARY\n  TRACK 01 MODE2/2352\n    INDEX 01 00:00:00\n'
                % os.path.basename(rel_bin))
    with open(rel_sha, "w", encoding="ascii") as f:
        f.write("%s  %s\n" % (sha, os.path.basename(rel_bin)))
    print("  RELEASED: %s" % rel_bin)
    print("  SHA-256: %s" % sha)


def main():
    import argparse
    ap = argparse.ArgumentParser(description="ShipB native DQ4 build (Rebuild B baseline, no F6 patches)")
    ap.add_argument("--corpus", default=INPUT_JSON, help="dialogue corpus JSON")
    ap.add_argument("--skip-dialogue", action="store_true",
                    help="Reuse existing dialogue bin, jump to Font1")
    ap.add_argument("--from-step", default=None, metavar="NAME",
                    help="Resume at named step")
    ap.add_argument("--g11-dumps", nargs="*", default=None, metavar="DUMP.bin",
                    help="Post-battle menu RAM dumps for G11 seal gate")
    ap.add_argument("--verify-all", action="store_true",
                    help="Run full validation suite (STEP -2 + 6b + 6c) without building")
    args = ap.parse_args()

    _hr("SHIPB NATIVE BUILD -- Dragon Quest IV (PSX) English [Rebuild B Baseline]")
    print("  corpus : %s" % args.corpus)
    with open(args.corpus, "rb") as _cf:
        print("  corpus sha256 : %s" % hashlib.sha256(_cf.read()).hexdigest().upper()[:16])
    print("  output : %s" % MASTER_BIN)
    print("  F6 patches: DISABLED (proven to cause prologue streaming crash)")
    _check_edcre()
    if not os.path.exists(BASE_BIN):
        print("[FAIL] pristine Japanese image not found: %s" % BASE_BIN)
        print("       Supply YOUR OWN pristine disc image (SHA-1 85064625AFA12219880FC8D07047A3CC1C595CB9)")
        sys.exit(1)

    if args.verify_all:
        _hr("VERIFY-ALL: Running validation suite only (no build)")
        step_neg2_heely_precheck()
        if os.path.exists(MASTER_BIN):
            step6b_patch_registry()
            step6c_heely_postcheck()
        else:
            print("  [SKIP] STEP 6b/6c — master bin not built yet (run full build first)")
        _hr("VERIFY-ALL COMPLETE")
        return

    step_neg2_heely_precheck()
    step_neg1_verify_rebuild_b()

    if args.from_step:
        _seq = [
            ("-2", step_neg2_heely_precheck),
            ("0a", lambda: step0a_build_facilities(args.corpus)),
            ("0", lambda: step0_validate_corpus(args.corpus)),
            ("1", lambda: step1_native_dialogue(args.corpus)),
            ("1c", step1c_remap_type39_scripts),
            ("2", step2_font1),
            ("3", step3_save_menu),
            ("4", step4_battle),
            ("4b", step4b_overlay_refs),
            ("4c", step4c_overlay_duplicates),
            ("4e", step4e_048c_sametree),
            ("4d", step4d_sweep),
            ("4h", step4h_bare_pages),
            ("1e", lambda: step1e_exe_blocks(args.corpus)),
            ("4f", step4f_d4_splitimm),
            ("4g", step4g_table_refs),
            ("4g-2", step4g2_d2_d3),
            ("5", step5_cue_and_verify),
            ("6", lambda: step6_gates(args.corpus)),
            ("6b", step6b_patch_registry),
            ("6c", step6c_heely_postcheck),
            ("7", lambda: step7_seal(args.g11_dumps or [])),
        ]
        _names = [n for n, _ in _seq]
        if args.from_step not in _names:
            print("[FAIL] --from-step %r not in %s" % (args.from_step, _names))
            sys.exit(1)
        _hr("RESUME AT STEP %s" % args.from_step)
        for _n, _fn in _seq[_names.index(args.from_step):]:
            _fn()
        _hr("SHIPB BUILD COMPLETE -- ready for DuckStation")
        return

    if not args.skip_dialogue:
        step0a_build_facilities(args.corpus)
        step0_validate_corpus(args.corpus)
        step1_native_dialogue(args.corpus)
        step1c_remap_type39_scripts()
    else:
        print("\n  (reusing existing %s)" % DIALOGUE_BIN)
        step0a_build_facilities(args.corpus)
        step1c_remap_type39_scripts()

    step2_font1()
    step3_save_menu()
    step4_battle()
    step4b_overlay_refs()
    step4c_overlay_duplicates()
    step4e_048c_sametree()
    step4d_sweep()
    step4h_bare_pages()
    step1e_exe_blocks(args.corpus)
    step4f_d4_splitimm()
    step4g_table_refs()
    step4g2_d2_d3()
    # F6 PATCHES REMOVED â€” steps 4h-2, 4h-3, 4h-4 are NOT called.
    # Runtime testing 2026-09-09 proved these cause the prologue streaming crash.
    step5_cue_and_verify()
    step6_gates(args.corpus)
    step6b_patch_registry()
    step6c_heely_postcheck()
    step7_seal(args.g11_dumps or [])

    _hr("SHIPB BUILD COMPLETE -- ready for DuckStation")


if __name__ == "__main__":
    main()

