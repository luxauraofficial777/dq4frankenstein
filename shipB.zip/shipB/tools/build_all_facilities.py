import os, sys, json, re

HERE = os.path.dirname(os.path.abspath(__file__))
PARENT = os.path.dirname(HERE)
WORKSPACE = os.environ.get("WORKSPACE", PARENT)

tt_candidates = [
    os.path.join(WORKSPACE, "translation-tools"),
    os.path.join(PARENT, "translation-tools"),
    os.path.join(PARENT, "..", "translation-tools"),
]
tt_dir = next((p for p in tt_candidates if os.path.isdir(p)), None)
if tt_dir and tt_dir not in sys.path:
    sys.path.insert(0, tt_dir)

from hbe.huffman.dq4 import DQ4Schema
import dq4_hbd_patcher as P

# Clean text: remove apostrophes, ensure proper termination
def clean_f2(text):
    text = text.replace("'", "")
    text = text.replace("’", "")
    text = text.replace("`", "")
    # eliminate any accidental double spaces
    text = re.sub(r' +', ' ', text)
    if not text.endswith("{0000}"):
        text += "{0000}"
    return text

# Load dumped sequences to get exact sequence counts
dump_candidates = [
    os.path.join(WORKSPACE, "translation", "facilities_all_sequences_dump.json"),
    os.path.join(PARENT, "translation", "facilities_all_sequences_dump.json"),
    os.path.join(PARENT, "..", "translation", "facilities_all_sequences_dump.json"),
]
dump_path = next((p for p in dump_candidates if os.path.isfile(p)), None)
if not dump_path:
    raise FileNotFoundError("Cannot locate facilities_all_sequences_dump.json")
with open(dump_path, "r", encoding="utf-8") as f:
    dump = json.load(f)

facility_corpus = {}

# =============================================================================
# BLOCK 047C: INN (20 sequences)
# =============================================================================
facility_corpus["047c"] = {
    "1": clean_f2("Did you sleep well?{7F02}May fortune favor your quest!!{7F0B}"),
    "2": clean_f2("Please rest and take your time.{0000}"),
    "3": clean_f2("Oh? What a pity...{7F02}You do not have enough gold.{7F0A}"),
    "4": clean_f2("Take care on your journey!{7F0B}"),
    "5": clean_f2("Traveling alone?{7F02}Would you care to rest?{7F0A}"),
    "6": clean_f2("Welcome to our traveler inn!{7F0A}"),
    "7": clean_f2("Good morning!{7F02}Did you sleep well?"),
    "8": clean_f2("Need anything else?{7F02}Call on me anytime."),
    "9": clean_f2("Just a moment, please..."),
    "10": clean_f2("Sorry to keep you waiting.{7F0A}"),
    "11": clean_f2("Welcome! Arriving so late,{7F02}you must be exhausted!"),
    "12": clean_f2("Please rest well tonight."),
    "13": clean_f2("Take care and travel safely."),
    "14": clean_f2("How many guests will stay?{7F02}Please visit again anytime!"),
    "15": clean_f2("It is {7F15} gold for one night.{7F02}Would you like to stay?"),
    "16": clean_f2("Hello! Welcome to the inn."),
    "17": clean_f2("Mooo...{7F0B}"),
    "18": clean_f2("Neigh... Mooo."),
    "19": clean_f2("Mooo? Mooo!"),
    "20": clean_f2("Mooo...{7F0A}"),
}

# =============================================================================
# BLOCK 0478: BANK (17 sequences)
# =============================================================================
facility_corpus["0478"] = {
    "1": clean_f2("We look forward to{7F02}serving you again."),
    "2": clean_f2("Thank you very much."),
    "3": clean_f2("Changed your mind, then?"),
    "4": clean_f2("Very well. Here you are."),
    "5": clean_f2("You cannot hold any more."),
    "6": clean_f2("You cannot carry{7F02}that much gold..."),
    "7": clean_f2("How much gold would you{7F02}like to withdraw?"),
    "8": clean_f2("What? You do not have{7F02}any gold deposited with us."),
    "9": clean_f2("Very well.{7F02}We will keep it safe.{7F0A}"),
    "10": clean_f2("We only have room for{7F02}{7F15} more gold in our vault."),
    "11": clean_f2("Excuse me, but you do not{7F02}have that much gold on you.{7F0A}"),
    "12": clean_f2("How much gold would you{7F02}like to deposit?"),
    "13": clean_f2("Our vault is full!{7F02}We cannot accept more gold."),
    "14": clean_f2("What else can we do for you?"),
    "15": clean_f2("You have {7F15} gold{7F02}deposited with us.{7F02}Anything else?"),
    "16": clean_f2("Welcome to the vault!"),
    "17": clean_f2("Welcome to the Vault of Love{7F02}and Trust! We keep your gold{7F02}safe from monsters.{7F0A}{7F02}Transactions are handled in{7F02}increments of 1000 gold.{7F0A}{7F02}And of course, we never{7F02}charge any handling fee!{7F0A}{7F02}What can we do for you today?"),
}

# =============================================================================
# BLOCK 0479: MEDAL KING (23 sequences)
# =============================================================================
facility_corpus["0479"] = {
    "1": clean_f2("{7F04}{7F4B}Here, receive this!"),
    "2": clean_f2("Wahahaha!{7F02}{7F4B}, you have done well{7F02}to collect so many medals!{7F0A}{7F02}I have no more items left{7F02}to bestow upon you.{7F02}Truly magnificent!{7F0A}{7F02}May the treasures I gave you{7F02}aid you on your journey!{7F02}Give it your all!{7F02}Wahahaha!{7F0B}"),
    "3": clean_f2("Go forth and make good use{7F02}of the rewards I gave you!{7F0B}"),
    "4": clean_f2("Well now. Currently you have{7F02}brought me {7F15} medals."),
    "5": clean_f2("Splendid! In exchange for{7F02}those, take this reward!"),
    "6": clean_f2("Hmm. With these medals, you{7F02}have brought me {7F17} in all!"),
    "7": clean_f2("Oho! Good, good!{7F02}You brought more medals!"),
    "8": clean_f2("Good, good!{7F02}I gladly accept them!"),
    "9": clean_f2("Oho! What is this?{7F02}You brought more medals!"),
    "10": clean_f2("Whoever brings medals to me{7F02}shall receive wonderful prizes!"),
    "11": clean_f2("Welcome! I collect the Small{7F02}Medals scattered worldwide!"),
    "12": clean_f2("{7F34} inspected the shelf{7F02}and found the medal prize list!{7F0A}"),
    "13": clean_f2("{7F4B}! You have gathered{7F02}all the medals! Wonderful!{7F02}Keep helping the world!"),
    "14": clean_f2("Keep searching for more!{7F0B}"),
    "15": clean_f2("{7F4B}, you currently have{7F02}brought me {7F15} medals."),
    "16": clean_f2("{7F4B}, receive this reward!"),
    "17": clean_f2("Splendid! Here is your reward!"),
    "18": clean_f2("Oho! What do you seek?{7F0A}"),
    "19": clean_f2("Hmm. You have brought me{7F02}{7F15} medals so far."),
    "20": clean_f2("Hmm? You brought more medals!{7F0A}"),
    "21": clean_f2("Bring me Small Medals and I{7F02}shall reward you handsomely!"),
    "22": clean_f2("Welcome! I am the king who{7F02}collects Small Medals!"),
    "23": clean_f2("!"),
}

# =============================================================================
# BLOCK 0477: CASINO (30 sequences)
# =============================================================================
facility_corpus["0477"] = {
    "1": clean_f2("Please come again!{7F0B}"),
    "2": clean_f2("Oh dear, you do not have{7F02}enough gold."),
    "3": clean_f2("Good luck to you!{7F02}May fortune smile upon you!"),
    "4": clean_f2("That will be {7F15} coins{7F02}for {7F16} gold. Alright?"),
    "5": clean_f2("Coins are {7F16} gold each.{7F02}How many would you like?"),
    "6": clean_f2("Welcome to the Casino!"),
    "7": clean_f2("{7F04}This is the {7F15} coin slot.{7F02}Insert {7F15} coins to play!"),
    "8": clean_f2("{7F43}I see. See you later!{7F0B}"),
    "9": clean_f2("{7F43}Step right up to the{7F02}Lucky Panel table!{7F02}Care to try your luck?"),
    "10": clean_f2("Come back and play anytime!{7F0B}"),
    "11": clean_f2("Enjoy the poker tables!"),
    "12": clean_f2("Oh!? That {7F17} is cursed{7F02}and cannot be unequipped!{7F0A}{7F02}Well, nothing for it.{7F02}Please take it for now."),
    "13": clean_f2("I placed it inside the{7F02}coffin for {7F1A}."),
    "14": clean_f2("Here you are!"),
    "15": clean_f2("Style went from {7F15}{7F02}to {7F16}!{7F0A}"),
    "16": clean_f2("{7F1A} equipped the {7F17}!{7F0A}"),
    "17": clean_f2("{7F1A} cannot equip this.{7F02}Are you sure you want it?{7F0B}"),
    "18": clean_f2("Oh my, your bag is full!{7F02}Give it to someone else?"),
    "19": clean_f2("Will you equip it right away?"),
    "20": clean_f2("I will put it into the{7F02}{7F1E} for you."),
    "21": clean_f2("Who will take this item?"),
    "22": clean_f2("You received the {7F17}!{7F0A}"),
    "23": clean_f2("Sorry, but {7F17} is{7F02}currently out of stock!"),
    "24": clean_f2("Any leftover coins will be{7F02}kept in your account.{7F0B}"),
    "25": clean_f2("You do not have enough coins{7F02}for the {7F17}."),
    "26": clean_f2("That is {7F17}. Alright?"),
    "27": clean_f2("Which prize would you like?"),
    "28": clean_f2("Here is our list of prizes!"),
    "29": clean_f2("Oh? You do not have any coins!{7F02}Buy some coins first!"),
    "30": clean_f2("Welcome to the Casino prize{7F02}exchange counter!"),
}

# =============================================================================
# BLOCK 047B: SHOPS (251 sequences)
# =============================================================================
# 37 core actions across standard shopkeepers, budgeted to fit slot <= 4656
shop_templates = [
    clean_f2("{7F1A} can only carry {7F16}{7F02}more. Is that fine?"),
    clean_f2("Who will take this?{7F0A}"),
    clean_f2("You carry too much!{7F02}Make room first."),
    clean_f2("Sorry, {7F1A} cannot{7F02}carry any more."),
    clean_f2("..."),
    clean_f2("Style: {7F15} -> {7F16}!"),
    clean_f2("{7F1A} equipped {7F17}!"),
    clean_f2("Come again anytime!"),
    clean_f2("What can I do for you?"),
    clean_f2("What will you buy?{7F0A}"),
    clean_f2("Whoa! It is cursed!{7F02}I cannot buy that!"),
    clean_f2("You cannot hold more gold!{7F02}Spend some first!"),
    clean_f2("That is out of stock."),
    clean_f2("Sold! Thank you kindly."),
    clean_f2("I can pay {7F16} gold for{7F02}the {7F17}. Deal?"),
    clean_f2("That is very rare!{7F02}Are you sure to sell it?"),
    clean_f2("Sorry, I cannot buy that."),
    clean_f2("The {7F1E} is empty."),
    clean_f2("{7F1A} has nothing."),
    clean_f2("Who will sell?{7F0A}"),
    clean_f2("What will you buy?{7F0A}"),
    clean_f2("Sent to the {7F1E}."),
    clean_f2("Sent to the wagon!"),
    clean_f2("Placed in the bag."),
    clean_f2("Here you go!"),
    clean_f2("Whoa! That {7F18} is{7F02}cursed and stuck! Take it."),
    clean_f2("Equip it now?"),
    clean_f2("{7F1A} cannot equip this.{7F02}Buy it anyway?"),
    clean_f2("Put in the {7F1E}."),
    clean_f2("Who will take this?"),
    clean_f2("The {7F1E} is full!{7F02}Make room first."),
    clean_f2("I will buy that from you!"),
    clean_f2("{7F1A} cannot equip this.{7F02}Are you sure?"),
    clean_f2("Which will you sell?{7F0A}"),
    clean_f2("Who will equip this?"),
    clean_f2("{7F17} is {7F15} gold.{7F02}Alright?"),
    clean_f2("I can buy {7F17}{7F02}for {7F15} gold."),
]

t_047b = {}
# Fill sequences 1 to 220 using the 37 templates
for idx in range(1, 221):
    step = (idx - 1) % 37
    txt = shop_templates[step]
    if idx == 40:
        txt = clean_f2("This is the weapon shop.{7F02}What can I do for you?")
    elif idx == 114:
        txt = clean_f2("Welcome to the store!{7F02}Need supplies?")
    elif idx == 147:
        txt = clean_f2("Welcome to the item shop!{7F02}What will you buy?")
    elif idx == 184:
        txt = clean_f2("Welcome to the armor shop!{7F02}What do you need?")
    elif idx == 217:
        txt = clean_f2("Weapon and armor shop.{7F02}What can I do for you?")
    t_047b[str(idx)] = txt

# Monster / Duck shopkeeper (221 to 251)
for idx in range(221, 252):
    if idx == 233:
        t_047b[str(idx)] = clean_f2("...")
    elif idx == 221:
        t_047b[str(idx)] = clean_f2("Kwa! Welcome, kwa!")
    elif idx == 226:
        t_047b[str(idx)] = clean_f2("Kwee! Need tools, kwa?")
    elif idx == 227:
        t_047b[str(idx)] = clean_f2("Kwaaar! Good deal, kwa!")
    elif idx == 228:
        t_047b[str(idx)] = clean_f2("Kwa? Not enough gold, kwa!")
    elif idx == 229:
        t_047b[str(idx)] = clean_f2("Kwee! Bag is full, kwa!")
    elif idx == 230:
        t_047b[str(idx)] = clean_f2("Kwa kwa kwa! Sold, kwa!")
    elif idx == 234:
        t_047b[str(idx)] = clean_f2("Kwark! Come again, kwa!{7F0A}")
    elif idx == 241:
        t_047b[str(idx)] = clean_f2("Kwa? Anything else, kwa?")
    elif idx == 245:
        t_047b[str(idx)] = clean_f2("Kwa! Good bye, kwa!")
    elif idx == 248:
        t_047b[str(idx)] = clean_f2("Kwaaar! Thanks, kwa!")
    else:
        t_047b[str(idx)] = clean_f2("Kwa! Good items, kwa!")

facility_corpus["047b"] = t_047b

# =============================================================================
# BLOCK 047D: CHURCH (291 sequences)
# =============================================================================
# 48 core actions across church / priest personalities
church_templates = [
    clean_f2("{7F04}{7F07}{7F47}Thank you for playing.{7F02}You may now safely turn off{7F02}the power.{7F0B}"), # 1
    clean_f2("{7F04}{7F07}{7F47}The Memory Card was removed.{7F02}Operation canceled."),                   # 2
    clean_f2("{7F04}{7F07}{7F47}Saving to Adventure Log.{7F02}Do not touch the Memory Card{7F02}or reset the power."), # 3
    clean_f2("{7F04}{7F07}{7F47}Saving in progress...{7F02}Do not touch the Memory Card{7F02}or the controller."), # 4
    clean_f2("Forgive me, I asked for a{7F02}donation when you are in need.{7F02}Go in peace, traveler."),  # 5
    clean_f2("You do not have enough gold{7F02}for the offering!{7F02}O Lord, forgive them!"),              # 6
    clean_f2("An offering is gratitude to{7F02}God. Do not be ungrateful."),                                # 7
    clean_f2("Will you donate {7F15} gold{7F02}to our holy church?"),                                       # 8
    clean_f2("By holy power! Cast out the{7F02}foul curse from {7F1A}!"),                                   # 9
    clean_f2("{7F1A} is not cursed."),                                                                     # 10
    clean_f2("Whose curse shall I lift?"),                                                                  # 11
    clean_f2("By holy power! Purge the{7F02}poison from {7F1A}!"),                                          # 12
    clean_f2("{7F1A} is not poisoned."),                                                                    # 13
    clean_f2("Whose poison shall I purge?"),                                                                # 14
    clean_f2("{7F1A} was revived!"),                                                                        # 15
    clean_f2("Faithful servant of God,{7F02}summon back the soul of {7F1A}!"),                              # 16
    clean_f2("O Lord, almighty God!"),                                                                      # 17
    clean_f2("You joke! {7F1A} is already{7F02}among the living."),                                         # 18
    clean_f2("You have changed your mind?"),                                                                # 19
    clean_f2("Whom shall I return to{7F02}this world?"),                                                    # 20
    clean_f2("Once you battle monsters,{7F02}fortune will bear fruit."),                                    # 21
    clean_f2("{7F11} has gained joyful{7F02}experience."),                                                  # 22
    clean_f2("{7F11}, you are already{7F02}strong enough."),                                                # 23
    clean_f2("{7F11}, you need {7F15} more{7F02}experience for next level."),                               # 24
    clean_f2("The voice of God speaks..."),                                                                 # 25
    clean_f2("Oh my! The saving operation{7F02}has failed!"),                                               # 26
    clean_f2("May God grant you peace!"),                                                                   # 27
    clean_f2("Adventure Log{7F0A}"),                                                                        # 28
    clean_f2("Would you like to record{7F02}on {7F15}?"),                                                   # 29
    clean_f2("You have not yet received{7F02}Gods blessing."),                                              # 30
    clean_f2("No Memory Card is inserted{7F02}in {7F15}."),                                                 # 31
    clean_f2("May God grant rest to{7F02}these travelers.{7F0B}"),                                          # 32
    clean_f2("Will you return to your{7F02}previous save point?"),                                          # 33
    clean_f2("You wish to rest without{7F02}saving your deeds?"),                                           # 34
    clean_f2("Your deeds have been recorded.{7F02}Will you continue your quest?"),                          # 35
    clean_f2("Oh dear! The operation{7F02}has failed!"),                                                    # 36
    clean_f2("Adventure Log{7F0A}"),                                                                        # 37
    clean_f2("Overwrite this log?"),                                                                        # 38
    clean_f2("Overwrite Chapter {7F15}?"),                                                                  # 39
    clean_f2("Overwrite {7F15}: {7F11}, {7F12}?"),                                                          # 40
    clean_f2("Will you continue your quest?"),                                                              # 41
    clean_f2("Very well. May God guide you."),                                                              # 42
    clean_f2("Which slot will you format?"),                                                                # 43
    clean_f2("There is not enough room on{7F02}{7F15} to record your deeds."),                              # 44
    clean_f2("Which log will you record?"),                                                                 # 45
    clean_f2("Adventure Log{7F0A}"),                                                                        # 46
    clean_f2("Record your adventure?"),                                                                     # 47
    clean_f2("Confess your deeds before God."),                                                             # 48
]

t_047d = {}

# ── Explicit structural mapping (replaces naive modulo) ──────────────
# Each personality has a different number of custom preamble/postamble
# lines and may skip certain templates.  Mapping derived from
# study/047d_pristine_dump.tsv keyword classification.
# None = custom text; integer = church_templates[index]

# Personality 1 (SIDs 1-48): direct mapping, no drift
for idx in range(1, 49):
    t_047d[str(idx)] = church_templates[idx - 1]

# Personality 2 (SIDs 49-95): 5-line preamble + 1 custom at 57
_p2 = {
    54: 3, 55: 4, 56: 5, 58: 7, 59: 8, 60: 9, 61: 10,
    62: 11, 63: 12, 64: 13, 65: 14, 66: 15, 67: 16, 68: 17,
    69: 18, 70: 19, 71: 22, 72: 23, 73: 24, 74: 25,
    75: 26, 76: 27, 77: 28, 78: 29, 79: 30, 80: 31,
    81: 32, 82: 33, 83: 34, 84: 35, 85: 36, 86: 37,
    87: 38, 88: 39, 89: 40, 90: 41, 91: 42, 92: 43,
    93: 44, 94: 45, 95: 46,
}
_p2_custom = {
    49: "Go in peace. May the blessing{7F02}of God be with you.",
    50: "Do you have other business?",
    51: "Visiting our church at such a{7F02}late hour... Are you in need?",
    52: "Welcome, reliable servant of{7F02}God! What is your business?",
    53: "...",
    54: "{7F04}Checking the Memory Card.{7F02}Please do not touch the{7F02}card or controller.",
    57: "If you cannot donate,{7F02}I am truly sorry...{7F05}",
    72: "{7F11}, you need{7F02}another {7F15} experience{7F02}to reach the next level.",
    84: "{7F11}, overwrite this adventure log?",
    85: "Overwrite {7F11} Chapter {7F15}?",
    86: "Overwrite {7F11}: {7F15}?",
}
for idx in range(49, 96):
    if idx in _p2_custom:
        t_047d[str(idx)] = clean_f2(_p2_custom[idx])
    else:
        t_047d[str(idx)] = church_templates[_p2[idx]]

# Personality 3 (SIDs 96-143): 2-line preamble, custom at 135, 142-143
_p3 = {
    98: 1, 99: 2, 100: 3, 101: 4, 102: 5, 103: 6, 104: 7,
    105: 8, 106: 9, 107: 10, 108: 11, 109: 12, 110: 13,
    111: 14, 112: 15, 113: 16, 114: 17, 115: 18,
    117: 23, 118: 24, 119: 25, 120: 26, 121: 27, 122: 28,
    123: 29, 124: 30, 125: 31, 126: 32, 127: 33, 128: 34,
    129: 35, 130: 36, 131: 37, 132: 38, 133: 39, 134: 40,
    136: 42, 137: 43, 138: 44, 139: 45, 140: 46, 141: 47,
}
_p3_custom = {
    96: "Ah, faithful children of God!{7F02}Welcome to our church.{7F02}What brings you here?",
    97: "O God! Grant these weary{7F02}travelers a brief rest.{7F0B}",
    116: "{7F11}, you are already{7F02}strong enough.",
    117: "{7F11}, you need{7F02}another {7F15} experience{7F02}to reach the next level.",
    135: "Let us leave what has{7F02}passed behind us.{7F05}",
    142: "May God always watch over us.{7F02}Please come again soon.",
    143: "Do you have other business?",
}
for idx in range(96, 144):
    if idx in _p3_custom:
        t_047d[str(idx)] = clean_f2(_p3_custom[idx])
    else:
        t_047d[str(idx)] = church_templates[_p3[idx]]

# Personality 4 (SIDs 144-191): 2-line preamble, custom at 188-191
_p4 = {
    146: 4, 147: 5, 148: 6, 149: 7, 150: 8, 151: 9, 152: 10,
    153: 11, 154: 12, 155: 13, 156: 14, 157: 15, 158: 16,
    159: 17, 160: 18, 161: 19, 162: 22, 163: 23, 164: 24,
    165: 25, 166: 26, 167: 27, 168: 28, 169: 29, 170: 30,
    171: 31, 172: 32, 173: 33, 174: 34, 175: 35, 176: 36,
    177: 37, 178: 38, 179: 39, 180: 40, 181: 41, 182: 42,
    183: 43, 184: 44, 185: 45, 186: 46, 187: 47,
}
_p4_custom = {
    144: "My, visiting our church at{7F02}such a late hour... Welcome.{7F02}What is your business?",
    145: "God has guided you here,{7F02}lost lamb. Welcome to{7F02}our church. What can I do?",
    188: "Take care on your journey.{7F02}May the spirits of the earth{7F02}guide and protect you.",
    189: "Do you have other business?",
    190: "Traveler, what do you{7F02}seek from God today?",
    191: "O God! Grant these{7F02}travelers a brief rest.{7F0B}",
}
for idx in range(144, 192):
    if idx in _p4_custom:
        t_047d[str(idx)] = clean_f2(_p4_custom[idx])
    else:
        t_047d[str(idx)] = church_templates[_p4[idx]]

# Personality 5 (SIDs 192-243): tail of save flow + custom break + main flow
_p5 = {
    192: 32, 193: 33, 194: 40,
    197: 34, 198: 41,
    199: 4, 200: 5, 201: 6, 202: 7, 203: 8, 204: 9, 205: 10,
    206: 11, 207: 12, 208: 13, 209: 14, 210: 15, 211: 16,
    212: 17, 213: 18, 214: 19, 215: 22, 216: 23, 217: 24,
    218: 25, 219: 26, 220: 27, 221: 28, 222: 29, 223: 30,
    224: 31, 225: 32, 226: 33, 227: 34, 228: 35, 229: 36,
    230: 37, 231: 38, 232: 39, 233: 40, 234: 41, 235: 42,
    236: 43, 237: 44, 238: 45, 239: 46, 240: 47,
}
_p5_custom = {
    195: "Take care. May Gods{7F02}blessing be with you.",
    196: "...",
    241: "Take care. May Gods{7F02}blessing be with you.",
    242: "Do you have other business?",
    243: "Welcome, brave traveler!{7F02}What brings you to our church?",
}
for idx in range(192, 244):
    if idx in _p5_custom:
        t_047d[str(idx)] = clean_f2(_p5_custom[idx])
    else:
        t_047d[str(idx)] = church_templates[_p5[idx]]

# Fire Shrine Priest (SIDs 244-267)
_pfire = {
    245: 32, 246: 33, 247: 40, 249: 25,
    251: 27, 252: 28, 253: 29, 254: 30,
    255: 34, 256: 35, 257: 36, 258: 37, 259: 38, 260: 39,
    261: 41, 262: 42, 263: 43, 264: 44, 265: 45, 266: 46,
}
_pfire_custom = {
    244: "O God of Fire! Grant rest{7F02}unto this traveler.{7F0B}",
    248: "Go forth and investigate{7F02}the depths of the volcano.",
    250: "O God of Fire! Bestow your{7F02}blessing upon {7F14}!",
    260: "{7F11}, overwrite {7F15}?",
    267: "Report your deeds to me{7F02}before the sacred flame.",
}
for idx in range(244, 268):
    if idx in _pfire_custom:
        t_047d[str(idx)] = clean_f2(_pfire_custom[idx])
    else:
        base = church_templates[_pfire[idx]]
        if "{7F11}" not in base:
            base = "{7F11}" + base
        t_047d[str(idx)] = clean_f2(base)

# Save Handler / Memory Card / Pamela (SIDs 268-291)
_psave = {
    268: 25, 269: 1, 271: 28, 272: 29, 273: 30,
    275: 32, 277: 34, 278: 35,
    280: 37, 281: 38, 282: 39, 283: 40,
    285: 42, 286: 43, 287: 44, 289: 1,
}
_psave_custom = {
    270: "{7F04}{7F07}Saved.{7F0B}",
    274: "{7F04}{7F07}Saved.{7F0B}",
    276: "{7F04}{7F07}Saved.{7F0B}",
    279: "{7F04}{7F07}Saved.{7F0B}",
    284: "{7F04}{7F07}Saved.{7F0B}",
    286: "{7F04}{7F07}Not enough space on {7F15}{7F02}to record the Adventure Log.",
    288: "{7F04}{7F07}Saved.{7F0B}",
    290: "{7F04}{7F07}Saved.{7F0B}",
    291: "...",
}
for idx in range(268, 292):
    if idx in _psave_custom:
        t_047d[str(idx)] = clean_f2(_psave_custom[idx])
    else:
        base = church_templates[_psave[idx]]
        if "{7F04}" not in base:
            base = "{7F04}{7F07}" + base
        t_047d[str(idx)] = clean_f2(base)

facility_corpus["047d"] = t_047d

# Validate all sequences in all facility blocks
print("Validating all generated facility sequences...")
for bid, block in facility_corpus.items():
    for sid, txt in block.items():
        if "'" in txt or "’" in txt or "`" in txt:
            raise ValueError(f"Apostrophe in block {bid} seq {sid}: {txt}")
        if not txt.endswith("{0000}"):
            raise ValueError(f"Missing terminator in block {bid} seq {sid}: {txt}")
print(f"Validation successful! All {sum(len(b) for b in facility_corpus.values())} facility sequences passed.")

# =============================================================================
# MERGE INTO MASTER CORPUS: translation/full_translation_boot_with_0069.json
# =============================================================================
if len(sys.argv) > 1:
    corpus_path = sys.argv[1]
else:
    corpus_candidates = [
        os.path.join(WORKSPACE, "translation", "full_translation_boot_with_0069.json"),
        os.path.join(PARENT, "translation", "full_translation_boot_with_0069.json"),
    ]
    corpus_path = next((p for p in corpus_candidates if os.path.isfile(p)), corpus_candidates[0])
with open(corpus_path, "r", encoding="utf-8") as f:
    master_corpus = json.load(f)

for bid, block in facility_corpus.items():
    master_corpus[bid] = {sid: {"translation": txt} for sid, txt in block.items()}

# Also update signpost sequences in 017b and 01e9
for sign_bid in ["017b", "01e9"]:
    if sign_bid in master_corpus:
        master_corpus[sign_bid]["4"] = {
            "translation": clean_f2("East of here:{7F02}Tempe Village.{7F02}Burland Castle.{7F0B}")
        }
        master_corpus[sign_bid]["6"] = {
            "translation": clean_f2("Report suspicious{7F02}persons to the castle!{7F02}- King of Burland{7F0B}")
        }
        print(f"Updated signpost sequences 4 and 6 in block {sign_bid}.")

with open(corpus_path, "w", encoding="utf-8") as f:
    json.dump(master_corpus, f, ensure_ascii=False, indent=2)

print(f"Successfully merged all facilities into {corpus_path}!")
print(f"Total blocks in master corpus: {len(master_corpus)}")
