#!/usr/bin/env python3
"""tools/native_build.py -- PINNED REBUILD B step sequence (distribution edition).

Reproduces the verified Rebuild B build from the tester's own pristine Japanese
image. Step chain = exactly the verified sequence:
  0  validate_corpus      1  native HBD dialogue     1c type-39 remap
  2  Font 1 (0x048C)      3  save menu (0x0474)      4  battle overlay (0x048B)
  4b overlay refs (A)     4c overlay duplicates (B)  1e EXE 0x048F
  5  cue + final EDC/ECC (edcre)
NO RC3/v2.x manual-lane steps (sweep, same-tree 048C, bare pages, D4 split-imm).

Usage:
  python tools/native_build.py --image "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin"

Input requirement: pristine Japanese DQ4 PSX image
  SHA-1   85064625AFA12219880FC8D07047A3CC1C595CB9
  SHA-256 100D87DB9DEADF8F9FA4BB891D3A5D0BB112ACBF5ADBCBC93C637848ED9C7531

Reference output (the sealed delta inside VoidPatcher_RB1.exe):
  SHA-256 AC9F94A13A5627C30013FB0D13C88CD96F4BCEC878A2DA6E7B1978E1CD4E5703
If your self-built master hashes differently, script evolution drifted from the
pinned state -- the VoidPatcher sealed payload remains the authoritative bytes.
"""
import argparse, os, subprocess, sys, time

sys.stdout.reconfigure(encoding="utf-8")
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PY = sys.executable

TT = os.path.join(ROOT, "translation-tools")
EDCRE = os.path.join(ROOT, "edcre", "edcre.exe")
BUILD = os.path.join(ROOT, "build")


def _run(cmd, log_path=None, timeout=3600):
    print("  $ " + " ".join('"%s"' % c if " " in c else c for c in cmd))
    t0 = time.time()
    if log_path:
        with open(log_path, "w", encoding="utf-8") as lf:
            proc = subprocess.run(cmd, cwd=ROOT, stdout=lf, stderr=subprocess.STDOUT, text=True, timeout=timeout)
    else:
        proc = subprocess.run(cmd, cwd=ROOT, text=True, timeout=timeout)
    print("  -> exit %d in %.1fs" % (proc.returncode, time.time() - t0))
    return proc.returncode


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--image", required=True, help="pristine Japanese disc image (.bin)")
    ap.add_argument("--corpus", default=os.path.join(ROOT, "translation", "full_translation_boot_with_0069.json"))
    args = ap.parse_args()
    os.makedirs(BUILD, exist_ok=True)
    dlg = os.path.join(BUILD, "dq4_dialogue_en.bin")
    master = os.path.join(BUILD, "dq4_rebuild_b_master.bin")
    cue = os.path.join(BUILD, "dq4_rebuild_b_master.cue")

    steps = [
        ("STEP 0 corpus validation", [PY, os.path.join(TT, "validate_corpus.py"), args.corpus]),
        ("STEP 1 native dialogue", [PY, os.path.join(TT, "dq4_hbd_patcher.py"), "--input", args.image,
                                    "--translations", args.corpus, "--output", dlg]),
        ("STEP 1c type-39 remap", [PY, os.path.join(TT, "patch_type39_scripts.py"), dlg]),
        ("STEP 2 Font 1 / 0x048C", [PY, os.path.join(TT, "patch_font1_ourway.py"), "--disc", dlg, "--out", master]),
        ("STEP 3 save menu 0x0474", [PY, os.path.join(TT, "patch_save_menu.py"), "--disc", master]),
        ("STEP 4 battle overlay 0x048B", [PY, os.path.join(TT, "patch_battle_overlay.py"), "--disc", master]),
        ("STEP 4b overlay refs (Class A)", [PY, os.path.join(TT, "patch_overlay_refs.py"), "--disc", master, "--base", args.image]),
        ("STEP 4c overlay duplicates (Class B)", [PY, os.path.join(TT, "patch_overlay_duplicates.py"), "--disc", master, "--base", args.image]),
        ("STEP 1e EXE 0x048F", [PY, os.path.join(TT, "patch_exe_blocks.py"), "--disc", master, "--corpus", args.corpus, "--no-edc"]),
    ]
    for label, cmd in steps:
        print("\n== %s ==" % label)
        rc = _run(cmd, log_path=os.path.join(BUILD, label.split()[1].lower() + ".log") if "STEP 1 " in label else None)
        if rc != 0:
            print("[FAIL] %s exit %d -- build aborted." % (label, rc))
            sys.exit(1)

    print("\n== STEP 5 cue + final EDC/ECC ==")
    with open(cue, "w", encoding="ascii") as f:
        f.write('FILE "%s" BINARY\n  TRACK 01 MODE2/2352\n    INDEX 01 00:00:00\n' % os.path.basename(master))
    print("  wrote %s" % cue)
    rc = _run([EDCRE, master], timeout=900)
    if rc != 0:
        print("[FAIL] final EDC/ECC")
        sys.exit(1)
    import hashlib
    h = hashlib.sha256()
    with open(master, "rb") as f:
        for c in iter(lambda: f.read(1 << 23), b""):
            h.update(c)
    print("\nREBUILD B MASTER READY: %s" % master)
    print("SHA-256: %s" % h.hexdigest().upper())
    print("(reference sealed Rebuild B: AC9F94A13A5627C30013FB0D13C88CD96F4BCEC878A2DA6E7B1978E1CD4E5703)")


if __name__ == "__main__":
    main()
