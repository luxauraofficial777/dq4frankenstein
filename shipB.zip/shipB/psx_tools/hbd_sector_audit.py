#!/usr/bin/env python3
"""
psx_tools/hbd_sector_audit.py -- PSX HBD Sector & Dialogue Audit
Verifies TextBlock 0x006C directly from the built disc image:
- Validates header invariants (invariant_order, invariant_self_pointer)
- Verifies Huffman decoding of all English strings (11+ strings)
- Verifies Cynthia & Master English dialogue content
"""

import os
import sys

PSX_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PSX_TOOLS_DIR)
sys.path.insert(0, PSX_TOOLS_DIR)

from dq4 import iso as isomod, hbd, textblock, huffman

DISC_OUT_PATH = os.path.join(ROOT_DIR, "build", "dq4_psx_english.bin")
HBD_FILE_NAME = "HBD1PS1D.Q41"

def run_hbd_sector_audit():
    print("==========================================================================")
    print("  PSX HBD SECTOR AUDIT -- TEXTBLOCK 0x006C ENGLISH DECODE VERIFICATION")
    print("==========================================================================")

    if not os.path.exists(DISC_OUT_PATH):
        print(f"  [FAIL] Built disc missing: {DISC_OUT_PATH}")
        return 1

    with isomod.RawISO(DISC_OUT_PATH) as disc:
        found = disc.find(HBD_FILE_NAME)
        if not found:
            print(f"  [FAIL] {HBD_FILE_NAME} not found on built disc!")
            return 1
        payload = disc.read(found[0], found[1])

    blocks = hbd.scan_blocks(payload)
    if 106502 not in blocks:
        print("  [FAIL] Sector 106502 not found in valid blocks!")
        return 1

    b = blocks[106502]
    sub = b['subs'][13]
    raw = hbd.sub_bytes(payload, sub)
    tb = textblock.TextBlock(raw)

    if tb.id != 0x006C:
        print(f"  [FAIL] Block ID mismatch: 0x{tb.id:04X} (expected 0x006C)")
        return 1

    if not tb.invariants_hold():
        print("  [FAIL] TextBlock header invariants violated!")
        return 1

    tree = huffman.HuffmanTree(tb)
    syms = tree.decode()
    strings, residue = huffman.split_strings(syms)

    print(f"  TextBlock 0x006C: {len(raw)} B, Invariants OK, {len(strings)} strings decoded")
    if len(strings) < 11:
        print(f"  [FAIL] Expected at least 11 strings, got {len(strings)}")
        return 1

    # Verify English content in key strings
    s0 = huffman.render(strings[0])
    s1 = huffman.render(strings[1])

    print(f"  String [00]: {s0.encode('unicode-escape').decode('ascii')[:60]}...")
    print(f"  String [01]: {s1.encode('unicode-escape').decode('ascii')[:60]}...")

    # Check that strings are English (fullwidth ASCII range 0x8260-0x829A)
    has_english = any(0x8260 <= sym[1] <= 0x829A for s in strings for sym in s if sym[0] == huffman.SJIS)
    if not has_english:
        print("  [FAIL] No English fullwidth characters found in TextBlock 0x006C!")
        return 1

    print("==========================================================================")
    print("  RESULT: PASS (PSX HBD Sector & English Dialogue Fully Validated)")
    print("==========================================================================")
    return 0

if __name__ == "__main__":
    sys.exit(run_hbd_sector_audit())
