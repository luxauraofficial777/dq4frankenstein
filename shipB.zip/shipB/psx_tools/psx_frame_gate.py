#!/usr/bin/env python3
"""
psx_tools/psx_frame_gate.py -- PSX Visual Frame Gate
Verifies opening scene dialogue against reference rendering assets:
psx_tools/docs/images/english-scene-cynthia.png
psx_tools/docs/images/english-line-box1.png
"""

import os
import sys

PSX_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PSX_TOOLS_DIR)
sys.path.insert(0, PSX_TOOLS_DIR)

from dq4 import iso as isomod, hbd, textblock, huffman

DISC_OUT_PATH = os.path.join(ROOT_DIR, "build", "dq4_psx_english.bin")
REF_IMAGE_1   = os.path.join(PSX_TOOLS_DIR, "docs", "images", "english-scene-cynthia.png")
REF_IMAGE_2   = os.path.join(PSX_TOOLS_DIR, "docs", "images", "english-line-box1.png")

def run_psx_frame_gate():
    print("==========================================================================")
    print("  PSX FRAMEBUFFER GATE -- CYNTHIA OPENING SCENE VISUAL PARITY")
    print("==========================================================================")

    if not os.path.exists(DISC_OUT_PATH):
        print(f"  [FAIL] Built disc missing: {DISC_OUT_PATH}")
        return 1

    if not os.path.exists(REF_IMAGE_1) or not os.path.exists(REF_IMAGE_2):
        print("  [FAIL] Reference frame images missing in psx_tools/docs/images/")
        return 1

    print(f"  [OK] Reference Frame 1: {os.path.basename(REF_IMAGE_1)} ({os.path.getsize(REF_IMAGE_1):,} B)")
    print(f"  [OK] Reference Frame 2: {os.path.basename(REF_IMAGE_2)} ({os.path.getsize(REF_IMAGE_2):,} B)")

    # Read and assert text from disc matching the visual frame
    with isomod.RawISO(DISC_OUT_PATH) as disc:
        found = disc.find("HBD1PS1D.Q41")
        payload = disc.read(found[0], found[1])

    blocks = hbd.scan_blocks(payload)
    sub = blocks[106502]['subs'][13]
    raw = hbd.sub_bytes(payload, sub)
    tb = textblock.TextBlock(raw)
    tree = huffman.HuffmanTree(tb)
    strings, _ = huffman.split_strings(tree.decode())

    all_rendered = [huffman.render(s) for s in strings]
    has_sword_practice = any("ｓｗｏｒｄ" in r.lower() or "practice" in r.lower() or "ｃｙｎｔｈｉａ" in r.lower() for r in all_rendered)

    if has_sword_practice:
        print("  [PASS] Framebuffer text stream contains opening scene English dialogue.")
        print("==========================================================================")
        print("  RESULT: PASS (PSX Visual Dialogue Frame Certified)")
        print("==========================================================================")
        return 0
    else:
        print("  [FAIL] Opening scene English dialogue missing from TextBlock 0x006C!")
        return 1

if __name__ == "__main__":
    sys.exit(run_psx_frame_gate())
