#!/usr/bin/env python3
"""audit_track_type46.py -- identify which modified type-46 overlay sites carry our
facility/battle text block ids and what their LZS overrun is.

Scans every MODIFIED compressed type-46 sub-block of the master HBD archive,
decompresses it, and looks for an embedded text block header whose id is one of
the nine blocks STEP 4c patches (0x0474, 0x0477-0x047D, 0x048B, 0x048C).
Confirmation is a full textblock.TextBlock parse with invariants_hold() so a
random id match cannot count.
"""
import os
import sys
import struct
import collections

PSX_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PSX_TOOLS_DIR)
sys.path.insert(0, PSX_TOOLS_DIR)

from dq4 import iso as isomod, hbd, lzs, textblock  # noqa: E402

JP_PATH = os.path.join(ROOT_DIR, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
MASTER_PATH = os.path.join(ROOT_DIR, "build", "dq4_sovereign_master.bin")
HBD_NAME = "HBD1PS1D.Q41"

TARGET_IDS = {0x0474, 0x0477, 0x0478, 0x0479, 0x047B, 0x047C, 0x047D, 0x048B, 0x048C}


def load_payload(path):
    with isomod.RawISO(path) as disc:
        found = disc.find(HBD_NAME)
        return bytearray(disc.read(found[0], found[1]))


def find_embedded_ids(data, wanted):
    """ids present in `data` as a real text-block header, brute-force parsed."""
    out = []
    for target in wanted:
        pat = struct.pack("<H", target)
        start = 0
        while True:
            i = data.find(pat, start)
            if i < 0:
                break
            start = i + 2
            # header starts 4 bytes earlier: a u32 `a` then the id word `id` (+2 zero)
            cand = i - 4
            if cand < 0:
                continue
            snippet = data[cand:]
            try:
                tb = textblock.TextBlock(snippet)
                if tb.id == target and tb.invariants_hold():
                    out.append(target)
                    break
            except Exception:
                continue
    return sorted(out)


def main():
    j = load_payload(JP_PATH)
    m = load_payload(MASTER_PATH)
    jb = hbd.scan_blocks(j)
    mb = hbd.scan_blocks(m)

    rows = []
    groups = collections.Counter()
    by_target = collections.defaultdict(list)
    for s in sorted(jb):
        for pj, pm in zip(jb[s]["subs"], mb[s]["subs"]):
            if pj["type"] != 46 or not pj["compressed"]:
                continue
            key = (pj["dlen"], pj["ulen"])
            bm = bytes(m[pm["off"]:pm["off"] + pm["dlen"]])
            bj = bytes(j[pj["off"]:pj["off"] + pj["dlen"]])
            if bj == bm:
                continue
            groups[key] += 1
            orj = lzs.overrun(bj, pj["ulen"])
            orm = lzs.overrun(bm, pm["ulen"])
            hit_j = find_embedded_ids(lzs.decompress_exact(bj, pj["ulen"]), TARGET_IDS)
            hit_m = find_embedded_ids(lzs.decompress_exact(bm, pm["ulen"]), TARGET_IDS)
            rows.append((s, pj["idx"], pj["dlen"], pj["ulen"], orj, orm, hit_j, hit_m))
            for t in hit_m:
                by_target[t].append((s, pj["idx"], orm))

    print(f"modified type-46 compressed sites: {len(rows)}")
    print("module groups (dlen, ulen) -> site count:")
    for (d, u), n in sorted(groups.items(), key=lambda kv: (-kv[0][0], -kv[0][1])):
        print(f"  dlen {d:6d} ulen {u:6d}: {n:3d} sites")

    for t in sorted(by_target):
        site = by_target[t]
        worst = max(o for _, _, o in site)
        print(f"\nid 0x{t:04X}: {len(site)} sites, worst overrun +{worst}")
        for s, idx, o in sorted(site, key=lambda r: -r[2])[:8]:
            print(f"    sector {s:6d} sub {idx:2d} overrun +{o}")
        if len(site) > 8:
            print(f"    ... and {len(site)-8} more")

    # does 0x047D share a module group with the freeze worst +2970 bands?
    by_group = collections.defaultdict(set)
    for s, idx, d, u, orj, orm, h_j, h_m in rows:
        for t in h_m:
            by_group[(d, u)].add(t)
    print("\nmodule groups carrying target ids:")
    for (d, u), ids in sorted(by_group.items()):
        print(f"  dlen {d:6d} ulen {u:6d}: ids {[f'0x{x:04X}' for x in sorted(ids)]}")


if __name__ == "__main__":
    main()