#!/usr/bin/env python3
"""
psx_tools/anti_null_gate.py -- Anti-Null Gate for PSX Disc Mastering
Ensures built English disc is NOT a null build (output SHA != source SHA)
and verifies that sector modifications exist and EDC/ECC is valid.
"""

import os
import sys
import hashlib

PSX_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PSX_TOOLS_DIR)
sys.path.insert(0, PSX_TOOLS_DIR)

from dq4 import discbuild, iso as isomod

DISC_JP_PATH   = os.path.join(ROOT_DIR, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
DISC_OUT_PATH  = os.path.join(ROOT_DIR, "build", "dq4_psx_english.bin")
JP_SOURCE_SHA  = "100d87db9deadf8f9fa4bb891d3a5d0bb112acbf5adbcbc93c637848ed9c7531"

def run_anti_null_gate():
    print("==========================================================================")
    print("  PSX ANTI-NULL GATE -- ZERO-TRUST SOURCE DEVIATION AUDIT")
    print("==========================================================================")

    if not os.path.exists(DISC_OUT_PATH):
        print(f"  [FAIL] Built disc missing: {DISC_OUT_PATH}")
        return 1

    out_size = os.path.getsize(DISC_OUT_PATH)
    if out_size != 368057424:
        print(f"  [FAIL] Built disc size mismatch: {out_size:,} B (expected 368,057,424 B)")
        return 1

    out_hash = discbuild.sha256(DISC_OUT_PATH)
    print(f"  Built PSX Disc SHA256: {out_hash}")
    print(f"  Source JP Disc SHA256: {JP_SOURCE_SHA}")

    if out_hash == JP_SOURCE_SHA:
        print("  [FAIL] ANTI-NULL GATE REJECTED: Output disc SHA matches untouched JP source!")
        return 1

    # Check sector differences
    if os.path.exists(DISC_JP_PATH):
        diffs = discbuild.diff_sectors(DISC_JP_PATH, DISC_OUT_PATH, limit=10)
        print(f"  Modified Sectors Found: {len(diffs)} (Sample: LBA {diffs[0][0] if diffs else 'N/A'})")
        if len(diffs) == 0:
            print("  [FAIL] ANTI-NULL GATE REJECTED: 0 differing sectors found!")
            return 1

    print("==========================================================================")
    print("  RESULT: PASS (Anti-Null Invariant Verified: Disc is English-Modified)")
    print("==========================================================================")
    return 0

if __name__ == "__main__":
    sys.exit(run_anti_null_gate())
