"""Corpus generator.

Regenerates the whole decoded corpus from a disc image in one command:

    python -m dq4.corpus --disc <path to .bin> --out <dir>

Everything under the output directory is derived. Nothing is hand edited, and
the tree is reproducible byte for byte from the same disc and the same library,
which is what makes the roll-up hash in MANIFEST.md meaningful.

The output is a complete decoded script of a copyrighted game. It does not
belong in any repository. See the README.
"""

import argparse
import collections
import hashlib
import os
import struct
import sys

from . import iso as isomod
from . import hbd, textblock, huffman, dictionary, sectortable, codes
from . import mips, referrers
from . import overlay as overlaymod

# Baseline roll-up. Stored in the LIBRARY, not in the corpus, so the corpus
# cannot silently update its own expectation. If a library change moves this,
# diff the corpus and review before accepting a new value.
# MOVED DELIBERATELY, Phase 33, after a line-by-line manifest review.
# Previous: ced6d48f69ebfe5e93e6b50f8830120588fa88f4c70aef9b12b7e170219945e3
#           fea89bdaa08b339cf381cbc3afbfb1ca3411381d76d4ea8a5a0a369833b443d2
# Four rows changed, none added, none removed. Cause: text block 0x048D has
# e == 0, carries no Huffman tree, and is raw NULL-terminated Shift-JIS. It was
# reported as zero strings for thirty-two phases. It holds five strings and 80
# characters: the fullwidth Latin alphabets and the digit and hex sets. The
# archive roll-up moves for exactly one reason, dq4-side-by-side.txt, which
# lists every string including the executable ones.
# Phase 46: both pins moved deliberately. A third executable-resident text block
# was found, 0x048F at 0x800B0D24, and it was invisible because the structural
# test required c == 24. That is only true of a block with NO dictionary; one
# that has a dictionary carries it in [24, c), so c is larger and f6 is 24.
# The manifest diff was 2 rows added, exe/raw/048F.txt and exe/expanded/048F.txt,
# and 2 rows changed, dq4-side-by-side.txt and exe/blockindex.txt. Nothing else.
#   previous archive pin  5d40cd227973ae70011eb834c1edfb916041847b1084d8d1bcb78c8d0a2f1c41
#   previous exe pin      5f88b66228987cd9392fbb23592b8ff4b19933a9edd0900debb9d1e22b0090b2
# NOTE the archive pin moved for an executable-side reason: dq4-side-by-side.txt
# holds both populations and is counted as an archive file, so the separation
# between the two roll-ups is not as clean as the comment below claims.
# Phase 53: the archive pin moved DELIBERATELY, after a line-by-line manifest
# review. 43 rows added, ALL of them under overlay/; 0 removed; exactly ONE
# changed, dq4-side-by-side.txt, which is the same cross-population leak noted
# above. editorial/ contributed 0 rows, checked rather than assumed. The EXE
# pin did NOT move, which is the evidence that the subtrees stay separate.
#   previous archive pin  2e60b20c5f9cc27c33854024385ff6bc9a53dad80a487d71e52ee944259b8bf6
ROLLUP_EXPECTED = "fb5d80d14cf91abe438444dff04714444f8e666a879f7e6566e83afda0de3510"
EXE_ROLLUP_EXPECTED = "b663c7abde4c355b0262241213f847714480b575167ca10098eb7837cac2a6e7"
# Phase 53 added a THIRD population, the type 46 MIPS overlays. Set on first
# generation, after the manifest diff was reviewed line by line.
OVERLAY_ROLLUP_EXPECTED = "085185a4fd7fd61edf40ee71d682a5f0f1cd1855359ec5d3f446958cb6905e9c"

DUMMY_MARK = "ダミー"          # katakana damii
NUL = bytes([0])


def raw_sjis_strings(raw, start, end):
    """[str] NULL-terminated Shift-JIS strings in [start, end).

    Used for text blocks with e == 0, which carry no Huffman tree. Block 0x048D
    is the only one: five strings, 80 characters, the fullwidth Latin alphabets
    and digit sets. It read as empty until Phase 33 because the generator only
    knew how to walk a tree.
    """
    out = []
    i = start
    while i < end:
        j = raw.find(NUL, i, end)
        if j < 0:
            j = end
        if j > i:
            try:
                out.append(raw[i:j].decode("shift_jis"))
            except UnicodeDecodeError:
                pass
        i = j + 1
    return out


def _sjis_codes(text):
    """[int] the two-byte Shift-JIS code for each character of text."""
    out = []
    for ch in text:
        b = ch.encode("shift_jis")
        if len(b) == 2:
            out.append((b[0] << 8) | b[1])
    return out
DUMMY, EMPTY, CONTROL, UNRESOLVED = "DUMMY", "EMPTY", "CONTROL", "UNRESOLVED"

# Phase 12 did not establish ordinal addressing for any string, so there is no
# ORDINAL status. Everything with no measured referrer is UNRESOLVED, which
# covers both "reached by position" and "referrer not yet found" without
# guessing the split.
STATUS_ORDER = (referrers.LOOKUP, referrers.TABLE, referrers.ROSTER,
                referrers.SCRIPT, UNRESOLVED, CONTROL, EMPTY, DUMMY)


def string_status(refs, tid, i, nchar, nctrl, is_dummy):
    """(status, ' (where)') for one string.

    EMPTY and CONTROL are both zero displayed characters and are NOT the same
    thing. EMPTY carries no symbols at all, just the terminator. CONTROL carries
    at least one control code, so it encodes something and occupies real bits.
    Exactly 2 strings on the disc are CONTROL and 1,914 are EMPTY.
    """
    if is_dummy:
        return DUMMY, ""
    if not nchar:
        return (CONTROL if nctrl else EMPTY), ""
    got = refs.get((tid, i))
    if not got:
        return UNRESOLVED, ""
    for system in (referrers.LOOKUP, referrers.TABLE, referrers.ROSTER,
                   referrers.SCRIPT):
        here = [w for sysname, w in got if sysname == system]
        if here:
            extra = "" if len(got) == 1 else ", %d refs" % len(got)
            return system, " (%s%s)" % (here[0], extra)
    return UNRESOLVED, ""

CTRL_RANGE_SUB = set(range(0x7F11, 0x7F15)) | {0x7F1F, 0x7F42, 0x7F4B, 0x7F4C} \
    | set(range(0x7F20, 0x7F35))


def sym_text(kind, value):
    """Corpus rendering: control codes {7Fxx}, dictionary refs {7Exx}."""
    if kind in (huffman.CTRL, huffman.DICT):
        return "{%04X}" % value
    if kind == huffman.END:
        return ""
    try:
        return bytes([value >> 8, value & 0xFF]).decode("shift_jis")
    except Exception:
        return "{!%04X}" % value


def render(symbols):
    return "".join(sym_text(k, v) for k, v in symbols)


def write(path, lines):
    """Deterministic write: LF endings, no trailing whitespace, no timestamps."""
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "wb") as f:
        for ln in lines:
            f.write((ln.rstrip() + "\n").encode("utf-8"))


class Block:
    """One decoded text sub-block."""

    def __init__(self, arch, sector, sub):
        self.sector = sector
        self.sub = sub
        self.raw = hbd.sub_bytes(arch, sub)
        self.tb = textblock.TextBlock(self.raw)
        self.tree = huffman.HuffmanTree(self.tb)
        self.leaves, _, _ = self.tree.walk()
        self.symbols = self.tree.decode()
        self.entries = dictionary.parse(self.raw, self.tb)
        self.expanded, self.unresolved = dictionary.expand(self.symbols, self.entries)
        self.raw_strings, self.raw_tail = huffman.split_strings(self.symbols)
        self.exp_strings, self.exp_tail = huffman.split_strings(self.expanded)

    @property
    def id(self):
        return self.tb.id

    def records(self):
        """[(index, u32, char, extra)] from the table at d + 32."""
        tb = self.tb
        if tb.a - tb.tree_end < 48:
            return []
        try:
            _, _, p2 = struct.unpack_from("<3I", self.raw, tb.tree_end)
        except Exception:
            return []
        start = tb.tree_end + 32
        if not (start < p2 <= tb.a):
            return []
        out = []
        for i in range((p2 - start) // 8):
            o = start + 8 * i
            if o + 8 > len(self.raw):
                break
            v, w = struct.unpack_from("<2I", self.raw, o)
            out.append((i, v, w & 0xFFFF, w >> 16))
        return out


def build(disc_path, out_dir):
    with isomod.RawISO(disc_path) as disc:
        found = disc.find("HBD1PS1D.Q41")
        if not found:
            raise SystemExit("HBD1PS1D.Q41 not found in %s" % disc_path)
        arch = disc.extract(*found)
        exe_at = disc.find("SLPM_869.16")
        exe = disc.extract(*exe_at) if exe_at else b""

    blocks = hbd.scan_blocks(arch)
    texts = hbd.text_sub_blocks(blocks)

    by_id = collections.defaultdict(list)
    for sector, sub in texts:
        by_id[textblock.TextBlock(hbd.sub_bytes(arch, sub)).id].append((sector, sub))

    ctrl = collections.Counter()       # one block per distinct text id
    ctrl_all = collections.Counter()   # every sub-block, duplicates included
    for sector, sub in texts:
        b = Block(arch, sector, sub)
        for k, v in b.expanded:
            if k == huffman.CTRL:
                ctrl_all[v] += 1
    index = referrers.block_index(arch, blocks)
    nids_seen = len(index)
    refs = referrers.build(arch, blocks, index)

    variants = []
    dup_by_name = {}
    side_rows = []
    block_rows = []
    placeholders = []
    ph_cross = collections.Counter()
    ed_chars = [0, 0]         # [editable, frozen], non-dummy only
    ed_strings = [0, 0]
    chars_clean = [0, 0]      # [non-dummy, dummy]
    chars_blocked = [0, 0]
    total_chars = 0
    str_lengths = []

    for tid in sorted(by_id):
        group = by_id[tid]
        # group byte-identical copies
        seen = {}
        for sector, sub in group:
            digest = hashlib.sha256(hbd.sub_bytes(arch, sub)).hexdigest()
            seen.setdefault(digest, []).append((sector, sub))
        for vi, digest in enumerate(sorted(seen)):
            members = sorted(seen[digest])
            sector, sub = members[0]
            b = Block(arch, sector, sub)
            suffix = "" if len(seen) == 1 else "_v%d" % vi
            name = "%04X%s" % (tid, suffix)
            if len(seen) > 1:
                variants.append((tid, vi, sector, sub["idx"], digest[:16]))

            raw_lines = ["# id %04X sector %d sub %d type %d dlen %d"
                         % (tid, sector, sub["idx"], sub["type"], sub["dlen"]),
                         "# symbols %d strings %d unresolved %d"
                         % (len(b.symbols), len(b.raw_strings), b.unresolved)]
            for i, st in enumerate(b.raw_strings):
                raw_lines.append("[%02d] %s" % (i, render(st)))
            if b.raw_tail:
                raw_lines.append("[tail] %s" % render(b.raw_tail))
            write(os.path.join(out_dir, "raw", name + ".txt"), raw_lines)

            exp_lines = [raw_lines[0], raw_lines[1]]
            rendered = []
            for i, st in enumerate(b.exp_strings):
                text = render(st)
                exp_lines.append("[%02d] %s" % (i, text))
                nchar = sum(1 for k, v in st if k == huffman.SJIS)
                total_chars += nchar
                str_lengths.append(nchar)
                rendered.append((i, st, text, nchar))
            if b.exp_tail:
                exp_lines.append("[tail] %s" % render(b.exp_tail))
            write(os.path.join(out_dir, "expanded", name + ".txt"), exp_lines)

            # A block is DUMMY when every non-empty string carries the ダミー
            # marker. That rule selects 181 ids with no false positives, which
            # is the set the phase reports use.
            body = [t for _i, _st, t, n in rendered if n]
            is_dummy = bool(body) and all(DUMMY_MARK in t for t in body)

            # Bit budget. A string's encoded length is the span from its start
            # offset to the next END inclusive. Offsets are absolute from the
            # block base, so this span is exactly the room a re-encoding has.
            offs = huffman.string_offsets(b.tb)
            region_bits = (b.tb.e - b.tb.c) * 8
            consumed_bits = offs[-1]
            residue_bits = region_bits - consumed_bits
            strbits = [offs[n + 1] - offs[n] for n in range(len(offs) - 1)]
            if sum(strbits) + residue_bits != region_bits:
                raise SystemExit("bit budget arithmetic failed for id %04X" % tid)

            counts = collections.Counter()
            rows = []
            for i, st, text, nchar in rendered:
                nctrl = sum(1 for k, _v in st if k == huffman.CTRL)
                status, where = string_status(refs, tid, i, nchar, nctrl, is_dummy)
                counts[status] += 1
                rows.append((i, text, nchar, status, where, st,
                             strbits[i] if i < len(strbits) else 0))
            # THE SUFFIX RULE. Offsets are absolute from the block base, so
            # lengthening string i shifts i+1..N-1 and nothing before i. String i
            # itself never moves, so its own referrer is never invalidated.
            # Therefore a string is editable exactly when no unresolved string sits
            # AFTER it, and the whole suffix from the LAST unresolved index onward
            # is editable, that index included.
            #
            # Read from the referrer map, not the status column: DUMMY takes
            # precedence in the status field and would mask an unresolved string.
            # A zero-symbol string cannot change length, so it is never a barrier.
            unres = [r[0] for r in rows
                     if not refs.get((tid, r[0]))
                     and (r[2] or sum(1 for k, _v in r[5] if k == huffman.CTRL))]
            uk = max(unres) if unres else None
            N = len(rows)
            if uk is None:
                resolution = "RESOLVED"
            elif uk >= N - 1:
                resolution = "TAIL-ONLY"
            else:
                resolution = "CUTOFF"
            blocked = any(st == UNRESOLVED for _i, _t, n, st, _w, _s, _b in rows if n)
            edit = "BLOCKED" if blocked else "CLEAN"
            # "wholly unreferenced" means the block HAS non-empty strings and none
            # of them is referenced. A block with nothing but empty strings is a
            # different case and is not counted here, which is the definition the
            # phase reports use.
            # Read this off the referrer map, not the status column: DUMMY takes
            # precedence in the status field, so a dummy block that does contain a
            # referenced string would otherwise be misreported as wholly
            # unreferenced. Two blocks are in exactly that position.
            ne_rows = [r for r in rows if r[2]]
            wholly = bool(ne_rows) and not any(refs.get((tid, r[0])) for r in ne_rows)
            block_rows.append((tid, suffix, sector, sub, b, counts, edit,
                               wholly, is_dummy, region_bits, consumed_bits,
                               residue_bits, uk, resolution, N))

            for i, text, nchar, status, where, st, nbits in rows:
                head = ("[id %04X / str %02d / sector %d / sub %d]"
                        % (tid, i, sector, sub["idx"]))
                subs = sorted({v for k, v in st
                               if k == huffman.CTRL and v in CTRL_RANGE_SUB})
                editable = uk is None or i >= uk
                rec = [head,
                       "STATUS: %s%s" % (status, where),
                       "EDITABLE: %s  BLOCK: %s%s%s"
                       % ("yes" if editable else "no", resolution,
                          "" if uk is None else " uk=%d of N=%d" % (uk, N),
                          "  (dummy-only block)" if is_dummy else "")]
                # omitted entirely when the string carries none, so the file stays
                # scannable
                if subs:
                    rec.append("SUBS: %s" % ", ".join("%04X" % v for v in subs))
                rec.append("BITS: %d%s" % (nbits, "" if not nchar else
                                           "  (%.2f per displayed character)"
                                           % (nbits / nchar)))
                rec += ["JP: %s" % text, "EN:", "NOTE:", ""]
                side_rows.append((0 if editable else 1, tid, i, rec))
                # Dummy blocks are trivially CLEAN, so every CLEAN total is split
                # into real and dummy. Reporting only the combined figure inflates
                # it, which is exactly what happened to the published 139,735.
                bucket = chars_clean if edit == "CLEAN" else chars_blocked
                bucket[1 if is_dummy else 0] += nchar
                if not is_dummy:
                    if editable:
                        ed_chars[0] += nchar
                        ed_strings[0] += 1
                    else:
                        ed_chars[1] += nchar
                        ed_strings[1] += 1
                if subs:
                    placeholders.append(head)
                    placeholders.append("STATUS: %s  BLOCK: %s" % (status, edit))
                    placeholders.append("SUBS: %s" % ", ".join("%04X" % v for v in subs))
                    placeholders.append(text)
                    placeholders.append("")
                    ph_cross[(edit, "dummy" if is_dummy else "real")] += 1

            for k, v in b.expanded:
                if k == huffman.CTRL:
                    ctrl[v] += 1

            bits = (b.tb.e - b.tb.c) * 8
            kraft = sum(2.0 ** -d for d, _, _, _, _ in b.leaves)
            tree_lines = [
                "# id %04X sector %d sub %d" % (tid, sector, sub["idx"]),
                "pairs           %d" % b.tree.n,
                "m               %d" % b.tree.m,
                "root            %d" % b.tree.root,
                "leaves          %d" % len(b.leaves),
                "kraft_sum       %.12f" % kraft,
                "code_bits       %d" % bits,
                "symbols         %d" % len(b.symbols),
                "bits_per_symbol %.4f" % (bits / len(b.symbols) if b.symbols else 0.0),
                "min_leaf_depth  %d" % min(d for d, _, _, _, _ in b.leaves),
            ]
            write(os.path.join(out_dir, "trees", name + ".txt"), tree_lines)

            if b.entries:
                dl = ["# id %04X  %d entries  table at %d" % (tid, len(b.entries), b.tb.f6)]
                for i, seq in enumerate(b.entries):
                    w = struct.unpack_from("<H", b.raw, b.tb.f6 + 2 * i)[0]
                    dl.append("{7E%02X} len=%d off=%d  %s"
                              % (i + 1, (w >> 12) & 0xF, w & 0x0FFF,
                                 "".join(sym_text(huffman.CTRL if k == "CTRL" else huffman.SJIS, v)
                                         for k, v in seq)))
                write(os.path.join(out_dir, "dictionaries", name + ".txt"), dl)

            recs = b.records()
            if recs:
                rl = ["# id %04X  %d records at d+32" % (tid, len(recs)),
                      "# index | u32 | char | extra"]
                for i, v, ch, ex in recs:
                    rl.append("%3d  %10d  %04X  %04X" % (i, v, ch, ex))
                write(os.path.join(out_dir, "records", name + ".txt"), rl)

            dups = ",".join(str(s) for s, _ in members[1:]) or "-"
            dup_by_name[name] = dups

    index_lines = [
        "# per-block editability. A block is CLEAN when every non-empty string has a",
        "# measured referrer, BLOCKED when at least one is UNRESOLVED.",
        "#",
        "# Bit offsets are absolute from the block base, so changing one string's",
        "# encoded length shifts every later string in the same block. That is why the",
        "# unit of safety is the block and not the string.",
        "#",
        "#",
        "# THE SUFFIX RULE. Lengthening string i shifts i+1..N-1 and nothing before",
        "# it, so a string is editable exactly when no unresolved string sits after",
        "# it. uk is the last unresolved index; every string from uk onward is",
        "# editable, uk included. resolution is RESOLVED (uk none), CUTOFF (a suffix",
        "# is editable) or TAIL-ONLY (uk = N-1, only the final string).",
        "#",
        "# A dummy-only block is trivially CLEAN because it holds nothing unresolved.",
        "# 447 blocks are CLEAN, of which 181 are dummy-only; 266 CLEAN non-dummy.",
        "# Quote the non-dummy figure when the question is what can be edited.",
        "#",
        "# Bit budget: region bits is (e - c) * 8, the whole code stream. consumed is",
        "# the span to the last END. residue is what follows it, trailing symbols plus",
        "# pad. sum of per-string bits + residue == region, exactly, for every block.",
        "#",
        "# text id | sector | sub | type | dlen | symbols | strings | non-empty"
        " | LOOKUP | TABLE | ROSTER | SCRIPT | UNRESOLVED | EMPTY | DUMMY"
        " | region bits | consumed bits | residue bits | editability"
        " | uk | resolution | editable strings | dummy-only"
        " | wholly unreferenced | duplicate sectors",
    ]
    for (tid, suffix, sector, sub, b, counts, edit, wholly, is_dummy,
         region_bits, consumed_bits, residue_bits, uk, resolution, N) in block_rows:
        name = "%04X%s" % (tid, suffix)
        ne = sum(v for k, v in counts.items() if k not in (EMPTY,))
        index_lines.append(
            "%04X%s | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d | %d"
            " | %d | %d | %d | %s | %s | %s | %d | %s | %s | %s"
            % (tid, suffix, sector, sub["idx"], sub["type"], sub["dlen"],
               len(b.symbols), len(b.raw_strings), ne,
               counts.get(referrers.LOOKUP, 0), counts.get(referrers.TABLE, 0),
               counts.get(referrers.ROSTER, 0), counts.get(referrers.SCRIPT, 0),
               counts.get(UNRESOLVED, 0),
               counts.get(EMPTY, 0), counts.get(DUMMY, 0),
               region_bits, consumed_bits, residue_bits, edit,
               "none" if uk is None else str(uk), resolution,
               N if uk is None else N - uk,
               "yes" if is_dummy else "no",
               "yes" if wholly else "no", dup_by_name.get(name, "-")))
    write(os.path.join(out_dir, "meta", "blockindex.txt"), index_lines)

    cl = ["# control code census, dictionary expanded",
          "#",
          "# two bases, and they are not interchangeable:",
          "#   per_id   counts one block per distinct text id (%d blocks)" % len(by_id),
          "#   all      counts every text sub-block on the disc (%d blocks)" % len(texts),
          "# published phase figures use the 'all' basis.",
          "#",
          "# code | per_id | all | meaning"]
    for v in sorted(set(ctrl) | set(ctrl_all)):
        cl.append("%04X | %d | %d | %s" % (v, ctrl.get(v, 0), ctrl_all.get(v, 0),
                                           codes.describe(v)))
    write(os.path.join(out_dir, "meta", "controlcodes.txt"), cl)

    st = ["# sector table from SLPM_869.16, %d entries" % 0]
    if exe:
        rows = sectortable.entries(exe)
        st = ["# sector table from SLPM_869.16, %d entries" % len(rows),
              "# offset | raw | length | disc lba | archive sector | resolves"]
        for off, v, length, lba, sec in rows:
            blk = blocks.get(sec)
            ok = "yes" if blk is not None and blk["nsec"] == length else "no"
            st.append("%06X | %08X | %d | %d | %d | %s" % (off, v, length, lba, sec, ok))
    write(os.path.join(out_dir, "meta", "sectortable.txt"), st)

    write(os.path.join(out_dir, "dq4-placeholder-extract.txt"), placeholders)

    gl = ["# name and substitution codes. English column intentionally empty.",
          "#",
          "# per_id counts one block per distinct text id; all counts every sub-block.",
          "# published phase figures use the 'all' basis.",
          "#",
          "# code | japanese | per_id | all | english"]
    for v in codes.NAME_CODES:
        if v not in codes.MANDY and not ctrl_all.get(v):
            gl.append("%04X | not present in data | 0 | 0 |" % v)
            continue
        gl.append("%04X | %s | %d | %d |" % (v, codes.MANDY.get(v, "?"),
                                             ctrl.get(v, 0), ctrl_all.get(v, 0)))
    gl.append("")
    gl.append("# codes present in the data and absent from the published table.")
    gl.append("# no meanings are proposed.")
    for v in codes.EXTRA:
        gl.append("%04X | unknown | %d | %d |" % (v, ctrl.get(v, 0), ctrl_all.get(v, 0)))
    write(os.path.join(out_dir, "dq4-name-glossary.txt"), gl)

    write(os.path.join(out_dir, "dq4-voice-sheet.txt"), voice_sheet(ctrl_all))

    # ------------------------------------------------------------------ exe
    # Kept in its own subtree so the two source media never mix silently. The
    # archive roll-up keeps exactly the meaning it had; the executable gets a
    # second figure of its own.
    exe_stats = {"blocks": 0, "strings": 0, "chars": 0, "referenced": 0}
    exe_index_lines = [
        "# text blocks embedded in SLPM_869.16, located by the six-u32 header",
        "# signature (c == 24, plausible a, e zero or inside a).",
        "#",
        "# These are NOT in the archive and are NOT covered by the archive roll-up.",
        "#",
        "# va | text id | a | c | d | e | f6 | symbols | strings | referenced"
        " | dictionary | records",
    ]
    if exe:
        load, _entry, tsize, toff = mips.exe_mapping(exe)
        eblocks = referrers.exe_blocks(exe, load, toff, tsize)
        eindex = {}
        for va, tb in eblocks:
            offs = huffman.string_offsets(tb)
            eindex[tb.id] = (tb, offs, {o: i for i, o in enumerate(offs)})
        erefs = referrers.exe_refs(exe, load, toff, tsize, eindex)
        for va, tb in eblocks:
            if tb.e == 0:
                # A text block with e == 0 carries NO Huffman tree. Its body is
                # raw NULL-TERMINATED Shift-JIS. Block 0x048D is the only one on
                # this disc, and it was reported as empty for thirty-two phases
                # because this branch did not exist. MEASURED, Phase 33.
                syms = []
                rstr = [[(huffman.SJIS, c) for c in _sjis_codes(s)]
                        for s in raw_sjis_strings(tb.raw, tb.c, tb.a)]
                rtail = []
                estr, etail = list(rstr), []
            else:
                tree = huffman.HuffmanTree(tb)
                syms = tree.decode()
                entries = dictionary.parse(tb.raw, tb)
                expanded, _unres = dictionary.expand(syms, entries)
                rstr, rtail = huffman.split_strings(syms)
                estr, etail = huffman.split_strings(expanded)
            nm = "%04X" % tb.id
            head = ["# exe text block id %04X at va 0x%08X" % (tb.id, va),
                    "# symbols %d strings %d" % (len(syms), len(rstr))]
            rl = list(head)
            for i2, stx in enumerate(rstr):
                rl.append("[%02d] %s" % (i2, render(stx)))
            if rtail:
                rl.append("[tail] %s" % render(rtail))
            write(os.path.join(out_dir, "exe", "raw", nm + ".txt"), rl)
            el = list(head)
            nch = 0
            for i2, stx in enumerate(estr):
                text = render(stx)
                el.append("[%02d] %s" % (i2, text))
                n_i = sum(1 for k, _v in stx if k == huffman.SJIS)
                nch += n_i
                # Rank 2, so executable material sorts after everything from the
                # archive. Status comes from the Phase 11 executable-table
                # measurement, which was gated; strings that measurement does not
                # reach are UNRESOLVED and nothing is inferred for them.
                got = erefs.get((tb.id, i2))
                if got:
                    st_name = got[0][0]
                    where = " (%s%s)" % (got[0][1], "" if len(got) == 1
                                         else ", %d refs" % len(got))
                elif not n_i:
                    st_name, where = (CONTROL if any(
                        k == huffman.CTRL for k, _v in stx) else EMPTY), ""
                else:
                    st_name, where = UNRESOLVED, ""
                subs = sorted({v for k, v in stx
                               if k == huffman.CTRL and v in CTRL_RANGE_SUB})
                rec = ["[id %04X / str %02d / source EXE @ 0x%08X]" % (tb.id, i2, va),
                       "STATUS: %s%s  BLOCK: EXE (not covered by Phase 10-12)"
                       % (st_name, where)]
                if subs:
                    rec.append("SUBS: %s" % ", ".join("%04X" % v for v in subs))
                rec += ["JP: %s" % text, "EN:", "NOTE:", ""]
                side_rows.append((2, tb.id, i2, rec))
            if etail:
                el.append("[tail] %s" % render(etail))
            write(os.path.join(out_dir, "exe", "expanded", nm + ".txt"), el)
            nref = sum(1 for (t, _i) in erefs if t == tb.id)
            exe_stats["blocks"] += 1
            exe_stats["strings"] += len(rstr)
            exe_stats["chars"] += nch
            exe_stats["referenced"] += nref
            exe_index_lines.append(
                "0x%08X | %04X | %d | %d | %d | %d | %d | %d | %d | %d | %s | %s"
                % (va, tb.id, tb.a, tb.c, tb.d, tb.e, tb.f6, len(syms), len(rstr),
                   nref, "yes" if tb.f6 else "no", "yes" if tb.d else "no"))
    write(os.path.join(out_dir, "exe", "blockindex.txt"), exe_index_lines)

    # -------------------------------------------------------------- overlay
    # A THIRD subtree, and a third roll-up. The type 46 MIPS overlays hold text
    # blocks in this same format, ids 0x0473 to 0x048B, and not one of those ids
    # occurs in the archive or the executable. Kept separate for the same reason
    # exe/ is: a moved archive roll-up must keep meaning exactly one thing.
    #
    # dq4/overlay.py is a LOCATOR. Everything below decodes with the same
    # TextBlock, HuffmanTree and dictionary as the archive, which is why type 46
    # needed no new format work. MEASURED, Phase 52.
    ov_stats = {"blocks": 0, "strings": 0, "chars": 0, "occurrences": 0}
    ov_index_lines = [
        "# text blocks embedded in the type 46 MIPS overlays, located by the",
        "# six-u32 header plus a valid self pointer at a, then decoded.",
        "#",
        "# These are NOT in the archive, NOT in the executable, and NOT covered",
        "# by either roll-up above.",
        "#",
        "# text id | a | c | d | e | f6 | symbols | strings | characters |"
        " dictionary | occurrences | first site",
    ]
    for tb, sites in overlaymod.blocks(arch, blocks):
        tree = huffman.HuffmanTree(tb)
        syms = tree.decode()
        entries = dictionary.parse(tb.raw, tb)
        expanded, _unres = dictionary.expand(syms, entries)
        rstr, rtail = huffman.split_strings(syms)
        estr, etail = huffman.split_strings(expanded)
        nm = "%04X" % tb.id
        sec0, idx0, off0 = sites[0]
        head = ["# overlay text block id %04X, sector %d sub %d +0x%X"
                % (tb.id, sec0, idx0, off0),
                "# symbols %d strings %d occurrences %d" % (len(syms), len(rstr), len(sites))]
        rl = list(head)
        for i2, stx in enumerate(rstr):
            rl.append("[%02d] %s" % (i2, render(stx)))
        if rtail:
            rl.append("[tail] %s" % render(rtail))
        write(os.path.join(out_dir, "overlay", "raw", nm + ".txt"), rl)
        el = list(head)
        nch = 0
        for i2, stx in enumerate(estr):
            text = render(stx)
            el.append("[%02d] %s" % (i2, text))
            n_i = sum(1 for k, _v in stx if k == huffman.SJIS)
            nch += n_i
            # Rank 3, so overlay material sorts after the archive and the
            # executable. No referrer measurement is claimed: the 1,781 packed
            # reference words Phase 52 measured live in overlay CODE, and no
            # gate covers them, so every string here is UNRESOLVED rather than
            # given a status this corpus cannot support.
            if not n_i:
                st_name = CONTROL if any(k == huffman.CTRL for k, _v in stx) else EMPTY
            else:
                st_name = UNRESOLVED
            subs = sorted({v for k, v in stx
                           if k == huffman.CTRL and v in CTRL_RANGE_SUB})
            rec = ["[id %04X / str %02d / source OVERLAY sector %d sub %d +0x%X]"
                   % (tb.id, i2, sec0, idx0, off0),
                   "STATUS: %s  BLOCK: OVERLAY (no referrer gate covers these)"
                   % st_name]
            if subs:
                rec.append("SUBS: %s" % ", ".join("%04X" % v for v in subs))
            rec += ["JP: %s" % text, "EN:", "NOTE:", ""]
            side_rows.append((3, tb.id, i2, rec))
        if etail:
            el.append("[tail] %s" % render(etail))
        write(os.path.join(out_dir, "overlay", "expanded", nm + ".txt"), el)
        if entries:
            dl = ["# overlay id %04X phrase dictionary, %d entries" % (tb.id, len(entries)),
                  "# index | phrase"]
            for di, ent in enumerate(entries):
                dl.append("%3d | %s" % (di, render(ent)))
            write(os.path.join(out_dir, "overlay", "dictionaries", nm + ".txt"), dl)
        ov_stats["blocks"] += 1
        ov_stats["strings"] += len(rstr)
        ov_stats["chars"] += nch
        ov_stats["occurrences"] += len(sites)
        ov_index_lines.append(
            "%04X | %d | %d | %d | %d | %d | %d | %d | %d | %s | %d | sector %d sub %d +0x%X"
            % (tb.id, tb.a, tb.c, tb.d, tb.e, tb.f6, len(syms), len(rstr), nch,
               "yes" if tb.f6 else "no", len(sites), sec0, idx0, off0))
    write(os.path.join(out_dir, "overlay", "blockindex.txt"), ov_index_lines)

    n_dummy_ids = sum(1 for r in block_rows if r[8])
    n_dummy_strings = sum(r[5].get(DUMMY, 0) for r in block_rows)
    n_clean = sum(1 for r in block_rows if r[6] == "CLEAN")
    n_clean_nd = sum(1 for r in block_rows if r[6] == "CLEAN" and not r[8])
    n_total_nd = sum(1 for r in block_rows if not r[8])
    n_empty = sum(r[5].get(EMPTY, 0) for r in block_rows)
    n_control = sum(r[5].get(CONTROL, 0) for r in block_rows)
    side = [
        "# DQ4 side-by-side. EN and NOTE are intentionally empty; nothing here is",
        "# translated.",
        "#",
        "# ORDER: EDITABLE strings first, then frozen, then executable-resident",
        "# blocks. Within each group, by text id then string index.",
        "#",
        "# THE SUFFIX RULE, and why a partly-unresolved block still has editable text.",
        "#   Offsets are absolute from the block base, so lengthening string i shifts",
        "#   strings i+1..N-1 and nothing before i. String i itself does not move, so",
        "#   its own referrer never needs updating. A string is therefore editable",
        "#   exactly when NO unresolved string appears after it: the whole suffix from",
        "#   the last unresolved index uk onward is editable, uk included.",
        "#",
        "#   EDITABLE is that per-string verdict. BLOCK reports the block's shape:",
        "#   RESOLVED (nothing unresolved), CUTOFF uk=i of N=n (the suffix from i is",
        "#   editable), or TAIL-ONLY (uk = N-1, only the final string). BLOCK is not",
        "#   an editability verdict and does not contradict EDITABLE.",
        "#",
        "# SOURCE COVERAGE",
        "#   archive HBD1PS1D.Q41, all %d distinct text ids, ids 0x0020 to 0x0482" % nids_seen,
        "#   executable SLPM_869.16, text blocks 0x048C and 0x048D, marked",
        "#     'source EXE @ <address>' in the record header",
        "#   Executable blocks were NOT covered by the Phase 10 to 12 referrer",
        "#     analysis. Their STATUS comes from the separate Phase 11 executable-table",
        "#     measurement where it reaches them, and is UNRESOLVED where it does not.",
        "#",
        "# DEDUPLICATION",
        "#   One record per text id. Blocks sharing an id are byte-identical on this",
        "#   disc, 0 ids have differing copies. Duplicate sectors are listed in",
        "#   meta/blockindex.txt, not repeated here.",
        "#",
        "# DUMMY HANDLING",
        "#   %d text ids are dummy-only, every non-empty string carrying the ダミー" % n_dummy_ids,
        "#   marker. They appear once each here and account for %d strings." % n_dummy_strings,
        "#   They are trivially CLEAN because they hold nothing unresolved, so they",
        "#   are flagged '(dummy-only block)' and excluded from the operative counts.",
        "#",
        "# EMPTY AND CONTROL",
        "#   %d strings are EMPTY: no symbols at all, only the terminator." % n_empty,
        "#   %d strings are CONTROL: zero displayed characters but at least one" % n_control,
        "#   control code, so they encode something and occupy real bits. Both are",
        "#   present; neither is filtered out.",
        "#",
        "# WHAT THE SUFFIX RULE DOES NOT CHANGE",
        "#   A frozen prefix still cannot grow. Those lines stay Japanese unless a",
        "#   further referrer system is found. Phase 13 stands: English does not fit",
        "#   the original bit budget, so every edited string does move what follows",
        "#   it. The wholly-unreferenced ids remain effectively closed.",
        "#",
        "# BLOCK COUNTS, BOTH BASES",
        "#   %d CLEAN blocks, of which %d are dummy-only;" % (n_clean, n_clean - n_clean_nd),
        "#   %d CLEAN non-dummy blocks of %d. Quote the second when the question" % (n_clean_nd, n_total_nd),
        "#   is what can actually be edited.",
        "#",
        "# STATUS is a MEASURED referrer, gated: the reference must land exactly on a",
        "# string start and a one-bit shift must destroy the match. UNRESOLVED means",
        "# no referrer was found, NOT that none exists. There is no ORDINAL status:",
        "# Phase 12 established none, so UNRESOLVED covers both possibilities without",
        "# guessing the split.",
        "#",
        "# BITS is the encoded length, the span to the next END inclusive. Offsets are",
        "# absolute from the block base, so that span is the room a re-encoding has.",
        "# SUBS lists substitution codes and is omitted when the string carries none.",
        "",
    ]
    for _rank, _tid, _i, lines in sorted(side_rows, key=lambda r: (r[0], r[1], r[2])):
        side.extend(lines)
    write(os.path.join(out_dir, "dq4-side-by-side.txt"), side)

    status_totals = collections.Counter()
    for row in block_rows:
        counts = row[5]
        status_totals.update(counts)
    clean = sum(1 for r in block_rows if r[6] == "CLEAN")
    clean_nd = sum(1 for r in block_rows if r[6] == "CLEAN" and not r[8])
    total_nd = sum(1 for r in block_rows if not r[8])

    rollup, exe_rollup, ov_rollup, nfiles = manifest(
                              out_dir, len(by_id), total_chars, str_lengths, variants,
                              status_totals, clean, clean_nd, total_nd,
                              chars_clean, chars_blocked, ph_cross, exe_stats,
                              ed_strings, ed_chars, ov_stats)
    return dict(rollup=rollup, exe_rollup=exe_rollup, ov_rollup=ov_rollup, nfiles=nfiles, nids=len(by_id), chars=total_chars,
                lengths=str_lengths, variants=variants,
                records=len(side_rows), placeholders=len(placeholders) // 4,
                status=status_totals, clean=clean, clean_nd=clean_nd,
                total_nd=total_nd, chars_clean=chars_clean[0],
                chars_clean_dummy=chars_clean[1],
                chars_blocked=chars_blocked[0], ph_cross=ph_cross, exe=exe_stats,
                overlay=ov_stats,
                ed_strings=ed_strings, ed_chars=ed_chars,
                blocks=block_rows)


def voice_sheet(ctrl):
    return [
        "# DQ4 voice sheet: engine constraints only.",
        "# Each entry: constraint, measured evidence, reference, status.",
        "# Nothing is RULE until it is decided and verified. All three start OPEN.",
        "",
        "## 1. Enumeration slots",
        "constraint: 0x7F11 through 0x7F14 appear as a comma separated list.",
        "evidence:   {7F04}　　{7F11}、{7F12}、{7F13}、{7F14}。{7F05}",
        "            in the 0x039E block family, alongside",
        "            {7F24}「これを装備できるのは{7F05}.",
        "            Japanese enumerates with 、 and closes with 。. English needs a",
        "            conjunction before the final element, which requires knowing the",
        "            element count at render time.",
        "reference:  Phase 2 control code census; Phase 6 for the code counts.",
        "status:     OPEN",
        "",
        "## 2. Name slot in running text",
        "constraint: 0x7F12 substitutes a name inside running prose.",
        "evidence:   %d occurrences after dictionary expansion, counting every" % ctrl.get(0x7F12, 0),
        "            sub-block on the disc.",
        "            preceded by 　 31360 / {7F02} 16307 / の 11631",
        "            followed by で 14131 / 。 12002 / だ 9634",
        "            Genitive and copula constructions that do not survive a",
        "            word for word rendering.",
        "reference:  Phase 2 section E.",
        "status:     OPEN",
        "",
        "## 3. Line metrics",
        "constraint: glyph cell advance is 8 px, body 6 px, column 7 is drop shadow.",
        "evidence:   Phase 3b per column intensity across the 13 known capitals.",
        "            Column 0 empty on 11 of 13. Column 7 carries the shadow of",
        "            column 6. Bottom row is the shadow of the row above.",
        "            The per line character budget is UNKNOWN until the renderer",
        "            is understood.",
        "reference:  FORMAT.md section 8, gate 17.",
        "status:     OPEN",
        "",
        "## 4. String offsets are absolute within a block",
        "constraint: a string is addressed by its BIT OFFSET from the block base,",
        "            not by its index. Changing any string's encoded length shifts",
        "            every later string in the same block, and every referrer to",
        "            them must be rewritten. A block may only be re-encoded if all",
        "            of its non-empty strings have a known referrer: that is the",
        "            CLEAN flag in meta/blockindex.txt.",
        "evidence:   the resolver at 0x8008F280 computes byte = block + (value >> 3)",
        "            and bit = value & 7. Gated at 9371 of 9371 tail records on a",
        "            string start, with plus and minus one bit at 0.00 percent.",
        "reference:  FORMAT.md sections 12 to 14, gates 30 to 32.",
        "status:     OPEN",
        "",
        "## Not added: the ordinal constraint",
        "",
        "A constraint was proposed reading: ordinal-addressed strings are selected by",
        "position, so their index and count must be preserved exactly.",
        "",
        "It is NOT recorded here, because its precondition failed. Phase 12 searched",
        "for an ordinal walker and did not find one, and the content evidence that",
        "suggested ordinal addressing (place names in 0x0020, person types in 0x0026)",
        "turned out to be referenced by type 44 pointer tables after all. No string on",
        "this disc is established as ordinal-addressed.",
        "",
        "Constraint 4 above is the stronger and measured statement, and it already",
        "forbids reordering in any block that is not CLEAN. If ordinal addressing is",
        "ever established, this section is where the constraint goes.",
    ]


def manifest(out_dir, nids, total_chars, str_lengths, variants,
             status, clean, clean_nd, total_nd, chars_clean, chars_blocked,
             ph_cross, exe_stats, ed_strings, ed_chars, ov_stats=None):
    files = []
    for root, dirs, names in os.walk(out_dir):
        # editorial/ holds HAND-AUTHORED work: the voice sheet, the name glossary,
        # English columns filled in over months. It must never enter the roll-up.
        # The roll-up answers "did the decoder change", and editing prose must not
        # be able to move it. Phase 33 caught it entering by accident.
        dirs[:] = [x for x in dirs if x != "editorial"]
        for n in sorted(names):
            if n.startswith("MANIFEST"):
                continue
            p = os.path.join(root, n)
            rel = os.path.relpath(p, out_dir).replace("\\", "/")
            with open(p, "rb") as f:
                files.append((rel, hashlib.sha256(f.read()).hexdigest()))
    files.sort()
    write(os.path.join(out_dir, "MANIFEST.sha256"),
          ["%s  %s" % (h, rel) for rel, h in files])

    # THREE roll-ups, deliberately. The archive roll-up must keep exactly the
    # meaning it had, so exe/ and overlay/ are both excluded from it: a moved
    # archive hash then still means "the archive decode changed" and nothing
    # else. Phase 53 added the third; the caveat above about
    # dq4-side-by-side.txt now applies to three populations, not two.
    def _roll(rows):
        joined = "\n".join("%s  %s" % (h, rel) for rel, h in rows)
        return hashlib.sha256(joined.encode("utf-8")).hexdigest()

    arch_files = [r for r in files
                  if not r[0].startswith("exe/") and not r[0].startswith("overlay/")]
    exe_files = [r for r in files if r[0].startswith("exe/")]
    ov_files = [r for r in files if r[0].startswith("overlay/")]
    roll = _roll(arch_files)
    exe_roll = _roll(exe_files) if exe_files else ""
    ov_roll = _roll(ov_files) if ov_files else ""
    sl = sorted(str_lengths)
    md = [
        "# DQ4 corpus manifest",
        "",
        "Regenerate with:",
        "",
        "    python -m dq4.corpus --disc <path to .bin> --out <dir>",
        "",
        "## Roll-up hash",
        "",
        "    %s" % roll,
        "",
        "SHA-256 over the sorted per-file hashes in MANIFEST.sha256, EXCLUDING",
        "exe/ and overlay/. If this value moves, the archive decode changed.",
        "Diff before accepting",
        "a new one; never accept a moved hash by regenerating the expectation.",
        "",
        "The executable-resident blocks carry their own roll-up, so that the two",
        "source media never mix into one number:",
        "",
        "    %s" % exe_roll,
        "",
        "SHA-256 over the exe/ rows of MANIFEST.sha256 alone.",
        "",
        "## Totals",
        "",
        "| Metric | Value |",
        "|---|---:|",
        "| files | %d |" % len(files),
        "| files under exe/ | %d |" % len(exe_files),
        "| distinct text ids | %d |" % nids,
        "| stored blocks | %d |" % (nids + len(variants)),
        "| strings | %d |" % len(str_lengths),
        "| displayed characters | %d |" % total_chars,
        "| characters per string, min | %d |" % (sl[0] if sl else 0),
        "| characters per string, median | %d |" % (sl[len(sl) // 2] if sl else 0),
        "| characters per string, mean | %.1f |" % (sum(sl) / len(sl) if sl else 0),
        "| characters per string, max | %d |" % (sl[-1] if sl else 0),
        "| text ids with differing copies | %d |" % len(set(v[0] for v in variants)),
        "",
        "## Referrer status, per string",
        "",
        "Measured only. Every LOOKUP, TABLE and ROSTER entry was gated: the reference",
        "must land exactly on a string start, and a one-bit shift in either direction",
        "must destroy the match.",
        "",
        "**There is no ORDINAL status.** Phase 12 looked for an ordinal walker and did",
        "not find one, and the content evidence that suggested ordinal addressing turned",
        "out to be type 44 pointers. So UNRESOLVED covers both \"reached by position\"",
        "and \"referrer not yet found\", and the split is not guessed.",
        "",
        "| Status | Strings | Meaning |",
        "|---|---:|---|",
        "| LOOKUP | %d | tail record table, Phase 10 |" % status.get("LOOKUP", 0),
        "| TABLE | %d | type 26 record field, Phase 11 and 12 |" % status.get("TABLE", 0),
        "| ROSTER | %d | type 44 roster table, Phase 12 |" % status.get("ROSTER", 0),
        "| SCRIPT | %d | type 39 cutscene command C0 21 A0, Phase 15 |"
        % status.get("SCRIPT", 0),
        "| UNRESOLVED | %d | no measured referrer |" % status.get(UNRESOLVED, 0),
        "| EMPTY | %d | zero displayed characters |" % status.get(EMPTY, 0),
        "| DUMMY | %d | in a block whose every non-empty string is a dummy |"
        % status.get(DUMMY, 0),
        "",
        "## Editability, per block",
        "",
        "Bit offsets are absolute from the block base, so changing one string's encoded",
        "length shifts every later string in the same block. The unit of safety is the",
        "block, not the string.",
        "",
        "| Metric | Value |",
        "|---|---:|",
        "| blocks CLEAN, all blocks | %d, of which %d are dummy-only |"
        % (clean, clean - clean_nd),
        "| **blocks CLEAN, non-dummy** | **%d of %d** |" % (clean_nd, total_nd),
        "| **displayed characters in CLEAN non-dummy blocks** | **%d** |"
        % chars_clean[0],
        "| displayed characters in dummy-only blocks | %d |" % chars_clean[1],
        "| displayed characters in BLOCKED blocks | %d |" % chars_blocked[0],
        "",
        "## Editable under the suffix rule, non-dummy blocks",
        "",
        "Lengthening string i shifts i+1..N-1 and nothing before it, so a string is",
        "editable exactly when no unresolved string sits after it. The whole suffix from",
        "the last unresolved index is editable, that index included.",
        "",
        "| Metric | Value |",
        "|---|---:|",
        "| **editable strings** | **%d of %d** |" % (ed_strings[0], ed_strings[0] + ed_strings[1]),
        "| **editable displayed characters** | **%d of %d** |"
        % (ed_chars[0], ed_chars[0] + ed_chars[1]),
        "| frozen displayed characters | %d |" % ed_chars[1],
        "| substitution-bearing strings in CLEAN non-dummy blocks | %d |"
        % ph_cross.get(("CLEAN", "real"), 0),
        "| substitution-bearing strings in BLOCKED blocks | %d |"
        % ph_cross.get(("BLOCKED", "real"), 0),
        "",
        "## Executable-resident blocks",
        "",
        "Held in `exe/`, deliberately outside the archive subtree and outside the",
        "roll-up above, so a moved archive hash keeps exactly one meaning.",
        "",
        "| Metric | Value |",
        "|---|---:|",
        "| blocks | %d |" % exe_stats["blocks"],
        "| strings | %d |" % exe_stats["strings"],
        "| displayed characters | %d |" % exe_stats["chars"],
        "| strings with a measured referrer | %d |" % exe_stats["referenced"],
        "",
        "Combined with the archive: %d strings, %d displayed characters."
        % (len(str_lengths) + exe_stats["strings"], total_chars + exe_stats["chars"]),
        "",
        "## Overlay-resident blocks",
        "",
        "Held in `overlay/`, outside both roll-ups above, for the same reason",
        "`exe/` is. These are the text blocks embedded in the type 46 MIPS",
        "overlays, ids 0x0473 to 0x048B. MEASURED, Phase 52.",
        "",
        "    %s" % ov_roll,
        "",
        "SHA-256 over the overlay/ rows of MANIFEST.sha256 alone.",
        "",
        "| Metric | Value |",
        "|---|---:|",
        "| distinct blocks | %d |" % (ov_stats or {}).get("blocks", 0),
        "| occurrences across the 612 type 46 sub-blocks | %d |"
        % (ov_stats or {}).get("occurrences", 0),
        "| strings | %d |" % (ov_stats or {}).get("strings", 0),
        "| displayed characters | %d |" % (ov_stats or {}).get("chars", 0),
        "",
        "NOT folded in: 1,565 characters of plain Shift-JIS that sit outside every",
        "text block in those overlays. They are the memory card save-file title and",
        "the labels the console's own BIOS manager renders, not game text.",
        "MEASURED, Phase 52. OUT OF SCOPE, recorded rather than extracted.",
        "",
        "## All three populations",
        "",
        "| Population | strings | displayed characters |",
        "|---|---:|---:|",
        "| archive | %d | %d |" % (len(str_lengths), total_chars),
        "| executable | %d | %d |" % (exe_stats["strings"], exe_stats["chars"]),
        "| overlay | %d | %d |"
        % ((ov_stats or {}).get("strings", 0), (ov_stats or {}).get("chars", 0)),
        "| **total** | **%d** | **%d** |"
        % (len(str_lengths) + exe_stats["strings"] + (ov_stats or {}).get("strings", 0),
           total_chars + exe_stats["chars"] + (ov_stats or {}).get("chars", 0)),
    ]
    write(os.path.join(out_dir, "MANIFEST.md"), md)
    return roll, exe_roll, ov_roll, len(files)


def main(argv=None):
    ap = argparse.ArgumentParser(description="regenerate the DQ4 decoded corpus")
    ap.add_argument("--disc", required=True, help="path to the DQ4 (Japan) .bin disc image")
    ap.add_argument("--out", required=True, help="output directory")
    args = ap.parse_args(argv)
    r = build(args.disc, args.out)
    sl = sorted(r["lengths"])
    print("corpus written to %s" % args.out)
    print("  files                 %d" % r["nfiles"])
    print("  distinct text ids     %d" % r["nids"])
    print("  strings               %d" % len(sl))
    print("  displayed characters  %d" % r["chars"])
    print("  chars per string      min=%d median=%d mean=%.1f max=%d"
          % (sl[0], sl[len(sl) // 2], sum(sl) / len(sl), sl[-1]))
    print("  side-by-side records  %d" % r["records"])
    print("  placeholder strings   %d" % r["placeholders"])
    print("  ids with differing copies %d" % len(set(v[0] for v in r["variants"])))
    for tid, vi, sector, idx, dg in r["variants"][:10]:
        print("     FINDING id %04X variant %d at sector %d sub %d (%s)"
              % (tid, vi, sector, idx, dg))
    print("  status  " + "  ".join("%s=%d" % (k, r["status"].get(k, 0))
                                   for k in STATUS_ORDER))
    print("  blocks CLEAN          %d of %d non-dummy" % (r["clean_nd"], r["total_nd"]))
    print("  characters CLEAN      %d   BLOCKED %d"
          % (r["chars_clean"], r["chars_blocked"]))
    print("  EDITABLE (suffix rule) %d strings, %d characters; frozen %d characters"
          % (r["ed_strings"][0], r["ed_chars"][0], r["ed_chars"][1]))
    print("  exe blocks            %d, %d strings, %d characters, %d referenced"
          % (r["exe"]["blocks"], r["exe"]["strings"], r["exe"]["chars"],
             r["exe"]["referenced"]))
    print("  overlay blocks        %d, %d strings, %d characters, %d occurrences"
          % (r["overlay"]["blocks"], r["overlay"]["strings"], r["overlay"]["chars"],
             r["overlay"]["occurrences"]))
    print("  ALL THREE             %d strings, %d characters"
          % (len(sl) + r["exe"]["strings"] + r["overlay"]["strings"],
             r["chars"] + r["exe"]["chars"] + r["overlay"]["chars"]))
    print("")
    print("  ROLL-UP     %s" % r["rollup"])
    print("  EXE ROLL-UP %s" % r["exe_rollup"])
    print("  OVL ROLL-UP %s" % r["ov_rollup"])
    if OVERLAY_ROLLUP_EXPECTED and r["ov_rollup"] != OVERLAY_ROLLUP_EXPECTED:
        print("  overlay roll-up does not match the value stored in the library.")
    if EXE_ROLLUP_EXPECTED and r["exe_rollup"] != EXE_ROLLUP_EXPECTED:
        print("  exe roll-up does not match the value stored in the library.")
    if r["rollup"] != ROLLUP_EXPECTED:
        print("  expected %s" % ROLLUP_EXPECTED)
        print("  roll-up does not match the value stored in the library.")
    return 0


if __name__ == "__main__":
    sys.exit(main())
