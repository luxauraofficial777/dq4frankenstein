#!/usr/bin/env python3
"""
tools/build_radmage_disc.py -- RadMageIRL PSX English Disc Builder
Builds the standalone English PSX disc for Dragon Quest IV (SLPM-86916)
using project opening scene English text (Text ID 0x006C),
Huffman tree compiler, and in-place EDC/ECC regenerator.
"""

import os
import sys
import struct
import collections
import hashlib
import shutil
from typing import List, Any, Tuple

# Locate ROOT_DIR and PSX_TOOLS_DIR
SCRIPT_DIR = os.path.dirname(os.path.abspath(__file__))
if os.path.basename(SCRIPT_DIR) in ("tools", "psx_tools"):
    ROOT_DIR = os.path.dirname(SCRIPT_DIR)
else:
    ROOT_DIR = SCRIPT_DIR

PSX_TOOLS_DIR = os.path.join(ROOT_DIR, "psx_tools")
sys.path.insert(0, PSX_TOOLS_DIR)

from dq4 import iso as isomod
from dq4 import hbd, discbuild, textblock, huffman, treebuild

DISC_JP_PATH   = os.path.join(ROOT_DIR, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
DISC_OUT_PATH  = os.path.join(ROOT_DIR, "build", "dq4_psx_radmage_english.bin")
CUE_OUT_PATH   = os.path.join(ROOT_DIR, "build", "dq4_psx_radmage_english.cue")
HBD_FILE_NAME  = "HBD1PS1D.Q41"
JP_SOURCE_SHA  = "100d87db9deadf8f9fa4bb891d3a5d0bb112acbf5adbcbc93c637848ed9c7531"

def to_fw_sjis(char: str) -> int:
    """Map ASCII character to fullwidth Shift-JIS code."""
    if 'A' <= char <= 'Z': return 0x8260 + (ord(char) - ord('A'))
    if 'a' <= char <= 'z': return 0x8281 + (ord(char) - ord('a'))
    if '0' <= char <= '9': return 0x824F + (ord(char) - ord('0'))
    if char == ' ': return 0x8140
    if char == ',': return 0x8143
    if char == '.': return 0x8144
    if char == '!': return 0x8149
    if char == '?': return 0x8148
    if char == "'": return 0x8166
    if char == '-': return 0x815B
    if char == ':': return 0x8146
    if char == ';': return 0x8147
    if char == '"': return 0x8168
    if char == '(': return 0x8169
    if char == ')': return 0x816A
    return 0x8140

def text_to_symbols(text_lines: List[List[Any]]) -> List[Tuple[str, int]]:
    sym_list = []
    for line in text_lines:
        for item in line:
            if isinstance(item, tuple):
                sym_list.append(item)
            elif isinstance(item, str):
                for ch in item:
                    sym_list.append((huffman.SJIS, to_fw_sjis(ch)))
        sym_list.append((huffman.END, 0))
    return sym_list

def pack_bits(bit_string: str) -> bytes:
    out = bytearray()
    cur_byte = 0
    cur_bit = 0
    for b in bit_string:
        if b == '1':
            cur_byte |= (1 << cur_bit)
        cur_bit += 1
        if cur_bit == 8:
            out.append(cur_byte)
            cur_byte = 0
            cur_bit = 0
    if cur_bit > 0:
        out.append(cur_byte)
    return bytes(out)

class MockTB:
    def __init__(self, pairs, m, root):
        self.pairs = pairs
        self.m = m
        self.root = root
        self.npairs = len(pairs)

def build_radmage_006c_subblock(raw_orig: bytes) -> bytes:
    """Builds a valid 1680-byte English TextBlock for ID 0x006C."""
    tb_orig = textblock.TextBlock(raw_orig)

    # Text ID 0x006C Cynthia / Master prologue lines (VoidWalkers Project Translation)
    # Note: RadMageIRL's proprietary translation lines have been removed per author request.
    PROJECT_ENGLISH_LINES = [
        # 00: Cynthia - Mother calling
        [(huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Ah! That is right! ", (huffman.CTRL, 0x7F1F), " mother was calling you. ", (huffman.CTRL, 0x7F02), "Dinner is ready now. ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Well then, ", (huffman.CTRL, 0x7F1F), (huffman.CTRL, 0x7F02), "see you tomorrow! ", (huffman.CTRL, 0x7F0B)],
        # 01: Cynthia - Leaving
        [(huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Well, I am off! ", (huffman.CTRL, 0x7F0B)],
        # 02: Cynthia - Morph spell explanation
        [(huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Oh, sorry. Actually, I could not think of anything beyond that. ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "I wanted to show ", (huffman.CTRL, 0x7F1F), " quickly. ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Surprised? I learned how to turn into different things! ", (huffman.CTRL, 0x7F0A)],
        # 03: Cynthia - Peaceful life
        [(huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "I was living peacefully, but something happened... ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "And that is... ", (huffman.CTRL, 0x7F0A)],
        # 04: Cynthia - Spell cast narration
        [(huffman.CTRL, 0x7F04), "Cynthia casts Morph! ", (huffman.CTRL, 0x7F0B)],
        # 05: Cynthia - Laughing about the frog
        [(huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Oops! Hahaha! I cannot keep a straight face! ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "What you saw was that frog, right? ", (huffman.CTRL, 0x7F0A)],
        # 06: Cynthia - Opening Scene (Sword practice)
        [(huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Ah, ", (huffman.CTRL, 0x7F1F), "! Sword practice is already over? ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "What is wrong? A big frog? What do you mean? ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "I have been here the whole time, and I have not seen any frogs... ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), (huffman.CTRL, 0x7F04), "Cynthia", (huffman.CTRL, 0x7F02), "Have not seen any at all... ", (huffman.CTRL, 0x7F0B)],
        # 07: Master - Training praise
        ["Great job today! You really gave it your all! ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), "Let us wrap it up for today. ", (huffman.CTRL, 0x7F0A)],
        # 08: Master - Duty as mentor
        ["My duty is to raise you into a fine hero as soon as possible, but there is no rushing it. ", (huffman.CTRL, 0x7F0A), (huffman.CTRL, 0x7F02), "Time to head back. Go home and get some rest, ", (huffman.CTRL, 0x7F1F), ". ", (huffman.CTRL, 0x7F0B)],
        # 09: Master - Wrap up
        ["That is right. That is enough training for today... ", (huffman.CTRL, 0x7F0A)],
        # 10: Master - Yield already?
        ["What is the matter, ", (huffman.CTRL, 0x7F1F), "? ", (huffman.CTRL, 0x7F02), "Yield already? ", (huffman.CTRL, 0x7F0B)],
    ]

    symbols = text_to_symbols(PROJECT_ENGLISH_LINES)
    freqs = collections.Counter(symbols)
    pairs, m, root = treebuild.build(freqs, min_depth=2)

    mock_tb = MockTB(pairs, m, root)
    tree = huffman.HuffmanTree(mock_tb)
    codes_dict = tree.codes()
    bit_str = "".join(codes_dict[s] for s in symbols)
    code_bytes = pack_bits(bit_str)

    c = 24
    record_table = raw_orig[tb_orig.d:tb_orig.a]
    unpadded_size = c + len(code_bytes) + 10 + len(pairs) * 2 + len(record_table) + 4 + 4
    if unpadded_size < len(raw_orig):
        pad_len = len(raw_orig) - unpadded_size
        code_bytes += b"\x00" * pad_len

    e = c + len(code_bytes)
    base = e + 10
    mid = base + m * 2
    d = base + len(pairs) * 2
    a = d + len(record_table)

    tree_header = struct.pack("<IIH", base, mid, root)
    pair_bytes = bytearray()
    for p0, p1 in pairs:
        pair_bytes.append(p0)
        pair_bytes.append(p1)

    self_ptr = struct.pack("<I", a)
    tail = b"\x00\x00\x00\x00"
    header = struct.pack("<6I", a, 0x006C, c, d, e, 0)

    new_raw = header + code_bytes + tree_header + bytes(pair_bytes) + record_table + self_ptr + tail
    assert len(new_raw) == len(raw_orig), f"Size mismatch: {len(new_raw)} vs {len(raw_orig)}"
    
    tb_check = textblock.TextBlock(new_raw)
    assert tb_check.invariants_hold(), "Header invariants failed on newly built TextBlock"
    return bytes(new_raw)

def build_radmage_disc() -> bool:
    print("==========================================================================")
    print("  BUILD RADMAGE ENGLISH PSX DISC (SLPM-86916) -- STANDALONE TOOL")
    print("==========================================================================")

    if not os.path.exists(DISC_JP_PATH):
        print(f"[FAIL] Missing source disc image: {DISC_JP_PATH}")
        return False

    # 1. Load archive
    print("[+] Step 1: Reading HBD1PS1D.Q41 archive from source disc...")
    with isomod.RawISO(DISC_JP_PATH) as disc:
        found = disc.find(HBD_FILE_NAME)
        if not found:
            print(f"[FAIL] {HBD_FILE_NAME} not found on disc!")
            return False
        lba, size = found[0], found[1]
        payload = bytearray(disc.read(lba, size))

    blocks = hbd.scan_blocks(payload)
    print(f"    Read {len(payload):,} bytes from LBA {lba} ({len(blocks):,} valid blocks).")

    # 2. Build and inject English sub-block
    print("[+] Step 2: Compiling English TextBlock 0x006C (Cynthia Opening Scene)...")
    target_sector = 106502
    target_sub_idx = 13
    sub = blocks[target_sector]['subs'][target_sub_idx]
    raw_orig = hbd.sub_bytes(payload, sub)

    new_subblock = build_radmage_006c_subblock(raw_orig)
    sub_off = sub['off']
    payload[sub_off:sub_off + len(new_subblock)] = new_subblock
    print(f"    Injected 1,680-byte English sub-block at HBD offset 0x{sub_off:08X}.")

    # 3. Master disc
    print(f"[+] Step 3: Mastering English Disc Image -> {DISC_OUT_PATH}...")
    os.makedirs(os.path.dirname(DISC_OUT_PATH), exist_ok=True)
    lba_out, nsectors, changed_sectors = discbuild.inject(
        DISC_JP_PATH, DISC_OUT_PATH, HBD_FILE_NAME, bytes(payload)
    )
    discbuild.write_cue(CUE_OUT_PATH, os.path.basename(DISC_OUT_PATH))

    # Also copy to build/dq4_psx_english.bin/cue for full project integration
    canon_bin = os.path.join(ROOT_DIR, "build", "dq4_psx_english.bin")
    canon_cue = os.path.join(ROOT_DIR, "build", "dq4_psx_english.cue")
    shutil.copyfile(DISC_OUT_PATH, canon_bin)
    discbuild.write_cue(canon_cue, os.path.basename(canon_bin))

    # 4. Hash and Verify
    out_hash = discbuild.sha256(DISC_OUT_PATH)
    out_size = os.path.getsize(DISC_OUT_PATH)
    print("[+] Step 4: Verification and Hash Certification...")
    print(f"    Built Disc Path:     {DISC_OUT_PATH}")
    print(f"    Built Disc Size:     {out_size:,} bytes")
    print(f"    Built Disc SHA-256:  {out_hash}")
    print(f"    Source Disc SHA-256: {JP_SOURCE_SHA}")
    print(f"    Modified Sectors:    {changed_sectors:,} of {nsectors:,} (LBA {lba_out + target_sector})")

    if out_hash == JP_SOURCE_SHA:
        print("[FAIL] Output disc is identical to Japanese source!")
        return False
    if changed_sectors == 0:
        print("[FAIL] No sectors were modified!")
        return False

    # 5. Direct verification from built disc
    with isomod.RawISO(DISC_OUT_PATH) as disc:
        f = disc.find(HBD_FILE_NAME)
        p = disc.read(f[0], f[1])
        b_raw = p[sub_off:sub_off + len(new_subblock)]
        tb_b = textblock.TextBlock(b_raw)
        tree_b = huffman.HuffmanTree(tb_b)
        strings_b, _ = huffman.split_strings(tree_b.decode())

    print("[+] Step 5: Direct In-Disc Dialogue Verification:")
    for i in [0, 6, 10]:
        r = huffman.render(strings_b[i])
        print(f"    String [{i:02d}]: {r.encode('unicode-escape').decode('ascii')}")

    print("==========================================================================")
    print("  RESULT: PASS (RadMage English Disc Built, Mastered, and Certified)")
    print("==========================================================================")
    return True

if __name__ == "__main__":
    success = build_radmage_disc()
    sys.exit(0 if success else 1)
