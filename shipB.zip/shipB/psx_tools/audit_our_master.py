#!/usr/bin/env python3
"""audit_our_master.py -- EMPIRICAL AUDIT of our final master vs the pristine JP disc.

Answers three questions the report needs numbers for:

  1. LZS overrun. Every compressed sub-block we recompressed (type-39 scripts,
     type-46 overlay modules, text) is clamped to its original slot with trailing
     zero padding.  lzs.overrun() measures how far the natural decompression
     output runs past the DECLARED uncompressed length.  RadMage measures
     shipped pristine blocks at 0 or +3 only; padding can push this to +50..+110.
     A block whose master overrun exceeds +3 is a hardware overrun risk
     (writes past the ulen buffer in RAM) and a prime suspect for the church-exit
     freeze if 0x047D is among them.

  2. Per-block font-record region [d, a) movement.  Our lineage-1 native patcher
     relocates the preserved region to a NEW d'; RadMage's model and our earlier
     psx_tools-based builders keep d/a FIXED.  Stale block-relative pointers into
     the moved region are corruption (and a zero modulus traps with break 0x1C00).

  3. Change census by sub-block type so the report can state real numbers.

Output: study/audit_master_vs_pristine.csv + printed summary.
"""
import os
import sys
import csv
import collections

PSX_TOOLS_DIR = os.path.dirname(os.path.abspath(__file__))
ROOT_DIR = os.path.dirname(PSX_TOOLS_DIR)
sys.path.insert(0, PSX_TOOLS_DIR)

from dq4 import iso as isomod, hbd, lzs, textblock  # noqa: E402

JP_PATH = os.path.join(ROOT_DIR, "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin")
MASTER_PATH = os.path.join(ROOT_DIR, "build", "dq4_sovereign_master.bin")
HBD_NAME = "HBD1PS1D.Q41"
OUT_CSV = os.path.join(ROOT_DIR, "study", "audit_master_vs_pristine.csv")


def load_payload(path):
    with isomod.RawISO(path) as disc:
        found = disc.find(HBD_NAME)
        if not found:
            raise SystemExit(f"[FAIL] {HBD_NAME} not found in {path}")
        return bytearray(disc.read(found[0], found[1]))


def sub_bytes(buf, sb):
    return bytes(buf[sb["off"]:sb["off"] + sb["dlen"]])


def main():
    print("Loading pristine + master HBD payloads...")
    j = load_payload(JP_PATH)
    m = load_payload(MASTER_PATH)
    print(f"  pristine size {len(j):,} B, master size {len(m):,} B, equal = {len(j) == len(m)}")

    jb = hbd.scan_blocks(j)
    mb = hbd.scan_blocks(m)
    print(f"  blocks pristine={len(jb)} master={len(mb)}")
    if set(jb) != set(mb):
        print("  [WARN] block sets differ!")
    nsub = sum(len(b["subs"]) for b in jb.values())

    rows = []
    modified = collections.Counter()
    total = collections.Counter()
    overrun_issues = []
    text_moved = 0
    text_region_mismatch = 0
    text_total = 0
    text_compressed = 0
    padded_or_short = collections.Counter()
    changed_bytes = 0

    for s in sorted(jb):
        for pj, pm in zip(jb[s]["subs"], mb[s]["subs"]):
            typ = pj["type"]
            total[typ] += 1
            bj = sub_bytes(j, pj)
            bm = sub_bytes(m, pm)

            row = {
                "sector": s, "idx": pj["idx"], "type": typ, "id": None,
                "dlen": pj["dlen"], "ulen": pj["ulen"],
                "d_prist": None, "d_mast": None, "a_prist": None, "a_mast": None,
                "region_equal": None, "overrun_prist": None, "overrun_mast": None,
                "modified": False,
            }

            is_mod = bj != bm
            if is_mod:
                modified[typ] += 1
                row["modified"] = True
                changed_bytes += len(bj)

            if pj["compressed"] and pj["ulen"]:
                if is_mod or bj == bm:
                    orj = lzs.overrun(bj, pj["ulen"])
                    row["overrun_prist"] = orj
                    if is_mod:
                        orm = lzs.overrun(bm, pm["ulen"])
                        row["overrun_mast"] = orm
                        if orm > 3:
                            overrun_issues.append((s, pj["idx"], typ, pj.get("ulen"), orj, orm, pj["dlen"]))
                        if orj != orm:
                            padded_or_short[(orj, orm)] += 1

            if typ in hbd.TEXT_TYPES:
                text_total += 1
                if pj["compressed"]:
                    text_compressed += 1
                if is_mod:
                    try:
                        tj = textblock.TextBlock(bj)
                        tm = textblock.TextBlock(bm)
                    except Exception:
                        continue
                    row["id"] = f"0x{tj.id:04X}"
                    row["d_prist"], row["a_prist"] = tj.d, tj.a
                    row["d_mast"], row["a_mast"] = tm.d, tm.a
                    dj, aj, dm, am = tj.d, tj.a, tm.d, tm.a
                    if aj <= len(bj) and am <= len(bm):
                        re = bj[dj:aj] == bm[dm:am]
                        row["region_equal"] = re
                        if (dj, aj) != (dm, am):
                            text_moved += 1
                        if not re:
                            text_region_mismatch += 1
            rows.append(row)

    print(f"\n=== CHANGE CENSUS (HBD sub-blocks; pristine total {nsub}) ===")
    for typ in sorted(total):
        print(f"  type {typ:3d}: total {total[typ]:5d}  modified {modified.get(typ, 0):5d}")

    print(f"\nchanged HBD sub-block bytes: {changed_bytes:,} B across {sum(modified.values())} sub-blocks")
    print(f"text sub-blocks: {text_total} (compressed: {text_compressed})")
    print(f"  modified-with-region info: moved d/a pairs: {text_moved}, region bytes differ: {text_region_mismatch}")

    print(f"\n=== LZS OVERRUN ISSUES (master natural output > +3 past declared ulen) ===")
    if overrun_issues:
        for s, idx, typ, ulen, orj, orm, dlen in sorted(overrun_issues, key=lambda r: -r[5]):
            print(f"  sector {s:6d} sub {idx:2d} type {typ:3d} dlen {dlen:6d} ulen {ulen:6d} "
                  f"overrun prist {orj:+4d} -> master {orm:+4d}")
    else:
        print("  none")
    print(f"\noverrun-moved pairs (prist, mast): {dict(padded_or_short)}")

    os.makedirs(os.path.dirname(OUT_CSV), exist_ok=True)
    with open(OUT_CSV, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=[k for k in rows[0].keys()])
        w.writeheader()
        for r in rows:
            w.writerow(r)
    print(f"\nCSV written: {OUT_CSV}")


if __name__ == "__main__":
    main()