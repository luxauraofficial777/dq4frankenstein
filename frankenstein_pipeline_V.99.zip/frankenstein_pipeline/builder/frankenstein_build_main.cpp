// ============================================================
// frankenstein_build_main.cpp
//
// Gold Standard Build Path entry point.
// Executes the complete Frankenstein disc build pipeline:
//   1. Input validation
//   2. EXE patching (disc-check, LBA, tree, BSS, pointers)
//   3. HBD re-encoding (field swap + LBA relocation + Huffman)
//   4. Disc assembly (ISO write + PVD + EDC/ECC)
//
// Usage:
//   frankenstein_build.exe --profile gold --output dq4_gold.bin
//   frankenstein_build.exe --dw7-disc <path> --dw7-exe <path>
//                          --dq4-hbd <path> --hybrid-tree <path>
//                          --folder-map <path> --edcre <path>
//                          --output <path> [--output-cue <path>]
//                          [--tree-mode <0|1|2|3>]
//
// Default paths are auto-detected from the DQLOSTTRANSLATION directory.
// ============================================================

#include "psx_binary_ops.h"
#include <cstring>
#include <cstdio>
#include <string>
#include <filesystem>
#include <locale>
#include <codecvt>
#include <ctime>

namespace fs = std::filesystem;

struct BuildArgs {
    std::string dw7_disc_path;
    std::string dw7_exe_path;
    std::string dq4_hbd_disc_path;
    std::string hybrid_tree_path;
    std::string folder_map_path;
    std::string edcre_path;
    std::string output_bin_path;
    std::string output_cue_path;
    int tree_mode = 3;  // Default: tree@0x800BC700 + BSS narrow (current best)
    std::string profile;
    bool duckstation_mode = false;  // Skip CD-ROM stall bypass for DuckStation
    bool reverse_mode = false;      // Option A: DQ4 disc base + DW7 EXE swap
    bool cd_intercept = false;      // build_flags bit 0: CD-ROM Setloc FMV intercept
    bool stall_bypass = false;      // build_flags bit 1: CD-ROM stall bypass (BAD-3)
    bool reencode_hbd = true;       // build_flags bit 2: HBD re-encoding (DQ4→DW7 format)
    bool skip_hash_check = false;   // Skip FROZEN_INPUTS.json hash verification (M1)

    // Build pipeline isolation
    std::string staging_dir;        // --staging-dir: isolated output staging directory
    std::string master_source;      // --master-source: write-protected master source root
    bool purge = true;              // --purge / --no-purge: pre-build artifact purge (default: ON)
    std::string hotfix_file;        // --hotfixes: path to text file with dynamic hotfixes
    uint32_t hbd_lba_override = 0;  // --hbd-lba: force HBD to this LBA (0=dynamic)
    bool no_xa_stub = false;        // --no-xa-stub: skip XA stub (preserve FMV player)
    bool no_disc_checks = false;    // --no-disc-check: skip anti-piracy disc check patches
    std::string disasm_range;       // --disasm-range: RAM range to disassemble (0x8004F344:0x8004F4D8)
    std::string thread_blob_path;   // --thread-blob: path to thread_code_blob.bin (MISS-1)
};

static std::string find_dqlt_root() {
    // Walk up from current directory to find DQLOSTTRANSLATION
    fs::path cwd = fs::current_path();
    for (fs::path p = cwd; !p.empty(); p = p.parent_path()) {
        if (p.filename() == "DQLOSTTRANSLATION") return p.string();
        fs::path check = p / "DQLOSTTRANSLATION";
        if (fs::exists(check)) return check.string();
    }
    // Also check relative to the executable location
    return cwd.string();
}

static bool file_exists(const std::string& path) {
    return fs::exists(path) && !fs::is_empty(path);
}

static void print_usage() {
    printf("Usage: frankenstein_build.exe [options]\n\n");
    printf("Options:\n");
    printf("  --profile gold          Use Gold Standard profile (all defaults)\n");
    printf("  --dw7-disc <path>       DW7 US disc image (.bin)\n");
    printf("  --dw7-exe <path>        DW7 US executable (SLUSP012.06)\n");
    printf("  --dq4-hbd <path>        DQ4 HBD disc image (.bin)\n");
    printf("  --hybrid-tree <path>    Hybrid Huffman tree (dw7_hybrid_tree.bin)\n");
    printf("  --folder-map <path>     Folder mapping JSON (folder_mapping.json)\n");
    printf("  --edcre <path>          EDC/ECC tool (edcre.exe)\n");
    printf("  --output <path>         Output .bin path\n");
    printf("  --output-cue <path>     Output .cue path (default: <output>.cue)\n");
    printf("  --tree-mode <0-3>       Tree placement mode (default: 3)\n");
    printf("    0 = no tree (Option C)\n");
    printf("    1 = tree@0x800F4980 + copy routine\n");
    printf("    2 = tree@0x80100000 + copy routine\n");
    printf("    3 = tree@0x800BC700 + BSS narrow (GOLD STANDARD)\n");
    printf("  --duckstation           DuckStation compatibility mode\n");
    printf("  --reverse               Option A: DQ4 disc as base, DW7 EXE swapped in\n");
    printf("  --cd-intercept          Redirect FMV Setloc (min>=0x32) to DQ4 23:31:15 (build_flags bit 0)\n");
    printf("  --stall-bypass          Skip CD event-wait poll loop (build_flags bit 1, BAD-3)\n");
    printf("  --no-reencode           Disable HBD re-encoding (raw HBD move only)\n");
    printf("  --skip-hash-check       Skip FROZEN_INPUTS.json hash verification (NOT recommended)\n");
    printf("  --staging-dir <path>    Isolated staging directory for build outputs (default: <dqlt>/build_staging)\n");
    printf("  --master-source <path>  Write-protected master source root (default: <dqlt>)\n");
    printf("  --purge                 Purge staging dir before build (default: ON)\n");
    printf("  --no-purge              Skip pre-build staging purge (NOT recommended)\n");
    printf("  --hbd-lba <value>       Override HBD target LBA (0=dynamic, 160000=preserve FMV)\n");
    printf("  --no-xa-stub            Skip XA stub patch (preserve FMV player for GPU init)\n");
    printf("  --no-disc-check         Skip anti-piracy disc check patches\n");
    printf("  --disasm-range <start:end> Dump MIPS disassembly of RAM range to stdout during build\n");
    printf("  --thread-blob <path>     Path to thread_code_blob.bin for MISS-1 injection (default: auto-detect)\n");
    printf("  --help                  Show this help\n");
}

static BuildArgs parse_args(int argc, char* argv[]) {
    BuildArgs args;

    for (int i = 1; i < argc; i++) {
        std::string arg = argv[i];
        if (arg == "--help" || arg == "-h") {
            print_usage();
            exit(0);
        } else if (arg == "--profile" && i + 1 < argc) {
            args.profile = argv[++i];
        } else if (arg == "--dw7-disc" && i + 1 < argc) {
            args.dw7_disc_path = argv[++i];
        } else if (arg == "--dw7-exe" && i + 1 < argc) {
            args.dw7_exe_path = argv[++i];
        } else if (arg == "--dq4-hbd" && i + 1 < argc) {
            args.dq4_hbd_disc_path = argv[++i];
        } else if (arg == "--hybrid-tree" && i + 1 < argc) {
            args.hybrid_tree_path = argv[++i];
        } else if (arg == "--folder-map" && i + 1 < argc) {
            args.folder_map_path = argv[++i];
        } else if (arg == "--edcre" && i + 1 < argc) {
            args.edcre_path = argv[++i];
        } else if (arg == "--output" && i + 1 < argc) {
            args.output_bin_path = argv[++i];
        } else if (arg == "--output-cue" && i + 1 < argc) {
            args.output_cue_path = argv[++i];
        } else if (arg == "--tree-mode" && i + 1 < argc) {
            args.tree_mode = std::atoi(argv[++i]);
        } else if (arg == "--duckstation") {
            args.duckstation_mode = true;
        } else if (arg == "--reverse") {
            args.reverse_mode = true;
        } else if (arg == "--cd-intercept") {
            args.cd_intercept = true;
        } else if (arg == "--stall-bypass") {
            args.stall_bypass = true;
        } else if (arg == "--reencode-hbd") {
            args.reencode_hbd = true;
        } else if (arg == "--skip-hash-check") {
            args.skip_hash_check = true;
        } else if (arg == "--no-reencode") {
            args.reencode_hbd = false;
        } else if (arg == "--staging-dir" && i + 1 < argc) {
            args.staging_dir = argv[++i];
        } else if (arg == "--master-source" && i + 1 < argc) {
            args.master_source = argv[++i];
        } else if (arg == "--hotfixes" && i + 1 < argc) {
            args.hotfix_file = argv[++i];
        } else if (arg == "--hbd-lba" && i + 1 < argc) {
            args.hbd_lba_override = (uint32_t)std::strtoul(argv[++i], nullptr, 10);
        } else if (arg == "--no-xa-stub") {
            args.no_xa_stub = true;
        } else if (arg == "--no-disc-check") {
            args.no_disc_checks = true;
        } else if (arg == "--disasm-range" && i + 1 < argc) {
            args.disasm_range = argv[++i];
        } else if (arg == "--thread-blob" && i + 1 < argc) {
            args.thread_blob_path = argv[++i];
        } else if (arg == "--purge") {
            args.purge = true;
        } else if (arg == "--no-purge") {
            args.purge = false;
        }
    }

    return args;
}

static bool validate_inputs(const BuildArgs& args, std::string& error) {
    struct InputCheck {
        const std::string& path;
        const char* name;
    };
    InputCheck checks[] = {
        {args.dw7_disc_path,      "DW7 disc"},
        {args.dw7_exe_path,       "DW7 EXE (SLUSP012.06)"},
        {args.dq4_hbd_disc_path,  "DQ4 HBD disc"},
        {args.hybrid_tree_path,   "Hybrid Huffman tree"},
        {args.folder_map_path,    "Folder mapping JSON"},
    };

    for (auto& c : checks) {
        if (c.path.empty()) {
            error = std::string("Missing path: ") + c.name;
            return false;
        }
        if (!file_exists(c.path)) {
            error = std::string("File not found or empty: ") + c.name + " (" + c.path + ")";
            return false;
        }
    }

    if (args.output_bin_path.empty()) {
        error = "No output path specified";
        return false;
    }

    return true;
}

static std::string to_upper(std::string s) {
    for (auto& c : s) c = (char)toupper((unsigned char)c);
    return s;
}

static std::string compute_sha256_certutil(const std::string& filepath) {
    std::string cmd = "certutil -hashfile \"" + filepath + "\" SHA256 2>nul";
    FILE* pipe = _popen(cmd.c_str(), "r");
    if (!pipe) return "";
    char buffer[1024];
    std::string output;
    while (fgets(buffer, sizeof(buffer), pipe)) {
        output += buffer;
    }
    _pclose(pipe);
    size_t start = 0;
    while (start < output.length()) {
        size_t end = output.find('\n', start);
        if (end == std::string::npos) end = output.length();
        std::string line = output.substr(start, end - start);
        std::string hash;
        for (char c : line) {
            if ((c >= '0' && c <= '9') || (c >= 'A' && c <= 'F') || (c >= 'a' && c <= 'f')) {
                hash += (char)toupper((unsigned char)c);
            }
        }
        if (hash.length() == 64) {
            return hash;
        }
        start = end + 1;
    }
    return "";
}

struct FrozenInput {
    std::string path;
    std::string sha256;
    uint64_t size;
};

static std::vector<FrozenInput> parse_frozen_inputs(const std::string& json_path) {
    std::ifstream f(json_path);
    if (!f.is_open()) return {};
    std::string content((std::istreambuf_iterator<char>(f)), std::istreambuf_iterator<char>());
    f.close();
    std::vector<FrozenInput> inputs;
    size_t pos = 0;
    while (true) {
        size_t path_pos = content.find("\"path\":", pos);
        if (path_pos == std::string::npos) break;
        size_t q1 = content.find('"', path_pos + 7);
        if (q1 == std::string::npos) break;
        size_t q2 = content.find('"', q1 + 1);
        if (q2 == std::string::npos) break;
        std::string path = content.substr(q1 + 1, q2 - q1 - 1);

        size_t sha_pos = content.find("\"sha256\":", q2);
        if (sha_pos == std::string::npos || sha_pos > q2 + 200) { pos = q2 + 1; continue; }
        size_t q3 = content.find('"', sha_pos + 9);
        if (q3 == std::string::npos) break;
        size_t q4 = content.find('"', q3 + 1);
        if (q4 == std::string::npos) break;
        std::string sha = to_upper(content.substr(q3 + 1, q4 - q3 - 1));

        size_t size_pos = content.find("\"size\":", q4);
        if (size_pos == std::string::npos || size_pos > q4 + 200) { pos = q4 + 1; continue; }
        size_t num_start = size_pos + 7;
        while (num_start < content.size() && (content[num_start] == ' ' || content[num_start] == '\t')) num_start++;
        std::string size_str;
        while (num_start < content.size() && content[num_start] >= '0' && content[num_start] <= '9') {
            size_str += content[num_start++];
        }
        uint64_t sz = 0;
        try { sz = std::stoull(size_str); } catch (...) { sz = 0; }

        inputs.push_back({path, sha, sz});
        pos = num_start;
    }
    return inputs;
}

// ============================================================
// Build Pipeline Isolation
// ============================================================

static bool purge_staging_dir(const std::string& staging_dir) {
    printf("  Purging staging directory: %s\n", staging_dir.c_str());
    if (!fs::exists(staging_dir)) {
        fs::create_directories(staging_dir);
        printf("  Created fresh staging directory.\n");
        return true;
    }
    std::error_code ec;
    uint64_t purged_files = 0, purged_bytes = 0;
    for (auto& entry : fs::directory_iterator(staging_dir, ec)) {
        if (ec) break;
        if (entry.is_regular_file()) {
            purged_bytes += fs::file_size(entry.path(), ec);
            purged_files++;
        }
    }
    fs::remove_all(staging_dir, ec);
    if (ec) {
        printf("  WARNING: Could not fully remove staging dir (%s) — attempting recursive clear\n", ec.message().c_str());
        // Try clearing contents instead
        for (auto& entry : fs::directory_iterator(staging_dir, ec)) {
            fs::remove(entry.path(), ec);
        }
    }
    fs::create_directories(staging_dir);
    printf("  Purged %llu files (%.1f MB). Staging dir recreated clean.\n",
           (unsigned long long)purged_files, (double)purged_bytes / (1024*1024));
    return true;
}

static bool verify_staging_hash(const std::string& staging_dir, const std::string& output_bin_path,
    int argc, char** argv, const BuildResult& result) {
    // After build, compute SHA-256 of the output disc in staging and record it
    std::string disc_path = (fs::path(staging_dir) / fs::path(output_bin_path).filename()).string();
    if (!fs::exists(disc_path)) {
        // Output may be directly at output_bin_path, not in staging
        disc_path = output_bin_path;
    }
    if (!fs::exists(disc_path)) return false;
    std::string hash = compute_sha256_certutil(disc_path);
    if (hash.empty()) {
        printf("  WARNING: Could not compute SHA-256 of output disc\n");
        return false;
    }
    printf("  Output disc SHA-256: %s\n", hash.c_str());

    // F-9 fix: use real build time, not __TIMESTAMP__
    time_t now = time(nullptr);
    char timebuf[64];
    strftime(timebuf, sizeof(timebuf), "%Y-%m-%dT%H:%M:%S", localtime(&now));

    // Build full argv string for manifest
    std::string argv_str;
    for (int i = 0; i < argc; i++) {
        if (i > 0) argv_str += " ";
        argv_str += argv[i];
    }

    // Write hash manifest to staging dir
    std::string manifest_path = (fs::path(staging_dir) / "build_hash_manifest.json").string();
    FILE* mf = fopen(manifest_path.c_str(), "w");
    if (mf) {
        fprintf(mf, "{\n");
        fprintf(mf, "  \"disc_path\": \"%s\",\n", fs::path(disc_path).filename().string().c_str());
        fprintf(mf, "  \"sha256\": \"%s\",\n", hash.c_str());
        fprintf(mf, "  \"size\": %llu,\n", (unsigned long long)fs::file_size(disc_path));
        fprintf(mf, "  \"build_time\": \"%s\",\n", timebuf);
        fprintf(mf, "  \"argv\": \"%s\",\n", argv_str.c_str());
        fprintf(mf, "  \"patch_counts\": {\n");
        fprintf(mf, "    \"tree_patches\": %u,\n", result.tree_patches);
        fprintf(mf, "    \"disc_patches\": %u,\n", result.disc_patches);
        fprintf(mf, "    \"lba_patches\": %u,\n", result.lba_patches);
        fprintf(mf, "    \"seq_patches\": %u,\n", result.seq_patches);
        fprintf(mf, "    \"trampoline_patches\": %u,\n", result.trampoline_patches);
        fprintf(mf, "    \"hbd_blocks_processed\": %u,\n", result.hbd_blocks_processed);
        fprintf(mf, "    \"hbd_blocks_converted\": %u,\n", result.hbd_blocks_converted);
        fprintf(mf, "    \"hbd_subblock_swaps\": %u,\n", result.hbd_subblock_swaps);
        fprintf(mf, "    \"hbd_lba_patches\": %u\n", result.hbd_lba_patches);
        fprintf(mf, "  }\n");
        fprintf(mf, "}\n");
        fclose(mf);
        printf("  Hash manifest written to: %s\n", manifest_path.c_str());
    }
    return true;
}

static bool verify_frozen_inputs(const std::string& dqlt_root) {
    std::string frozen_path = (fs::path(dqlt_root) / "cybergrime" / "FROZEN_INPUTS.json").string();
    if (!fs::exists(frozen_path)) {
        printf("  ERROR: FROZEN_INPUTS.json not found at %s\n", frozen_path.c_str());
        return false;
    }
    auto inputs = parse_frozen_inputs(frozen_path);
    if (inputs.empty()) {
        printf("  ERROR: No inputs parsed from FROZEN_INPUTS.json\n");
        return false;
    }
    printf("  Verifying %zu frozen inputs...\n", inputs.size());
    bool all_ok = true;
    for (const auto& inp : inputs) {
        std::string full_path = (fs::path(dqlt_root) / inp.path).string();
        if (!fs::exists(full_path)) {
            printf("  FAIL: %s — file not found (%s)\n", inp.path.c_str(), full_path.c_str());
            all_ok = false;
            continue;
        }
        uint64_t actual_size = fs::file_size(full_path);
        if (actual_size != inp.size) {
            printf("  FAIL: %s — size mismatch (expected %llu, got %llu)\n", inp.path.c_str(), inp.size, actual_size);
            all_ok = false;
            continue;
        }
        std::string actual_hash = compute_sha256_certutil(full_path);
        if (actual_hash.empty()) {
            printf("  FAIL: %s — could not compute SHA-256\n", inp.path.c_str());
            all_ok = false;
            continue;
        }
        if (actual_hash != inp.sha256) {
            printf("  FAIL: %s — hash mismatch (expected %s, got %s)\n", inp.path.c_str(), inp.sha256.substr(0,12).c_str(), actual_hash.substr(0,12).c_str());
            all_ok = false;
            continue;
        }
        printf("  OK:   %s (%llu bytes, SHA256 %s...)\n", inp.path.c_str(), actual_size, actual_hash.substr(0,12).c_str());
    }
    return all_ok;
}

int main(int argc, char* argv[]) {
    printf("============================================================\n");
    printf("  FRANKENSTEIN BUILD — Gold Standard Pipeline\n");
    printf("  Native C++ EXE patching + HBD re-encoding + Disc assembly\n");
    printf("============================================================\n\n");

    BuildArgs args = parse_args(argc, argv);

    // Auto-detect paths if --profile gold or if paths are missing
    std::string dqlt_root = find_dqlt_root();
    printf("  Project root: %s\n\n", dqlt_root.c_str());

    if (args.dw7_disc_path.empty()) {
        args.dw7_disc_path = (fs::path(dqlt_root) / "DW7D1" / "DW7D1.bin").string();
    }
    if (args.dw7_exe_path.empty()) {
        // Try clean unpatched EXE first, then pre-patched versions
        const char* exe_candidates[] = {
            "translation/SLUSP012.06_clean.bin",
            "translation/SLUSP012.06",
            "translation/SLUSP012.06_disc_extract.bin",
        };
        for (auto& c : exe_candidates) {
            std::string p = (fs::path(dqlt_root) / c).string();
            if (file_exists(p)) {
                args.dw7_exe_path = p;
                break;
            }
        }
    }
    if (args.dq4_hbd_disc_path.empty()) {
        // DQ4 HBD disc — the original Japanese DQ4 disc
        std::string p1 = (fs::path(dqlt_root) / "Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin").string();
        std::string p2 = (fs::path(dqlt_root) / "dq4_heart_v17.bin").string();
        if (file_exists(p1)) args.dq4_hbd_disc_path = p1;
        else if (file_exists(p2)) args.dq4_hbd_disc_path = p2;
    }
    if (args.hybrid_tree_path.empty()) {
        // Prefer root dw7_hybrid_tree.bin (1480 bytes — verified correct size)
        std::string p1 = (fs::path(dqlt_root) / "dw7_hybrid_tree.bin").string();
        std::string p2 = (fs::path(dqlt_root) / "frozen" / "dw7_hybrid_tree.bin").string();
        if (file_exists(p1)) args.hybrid_tree_path = p1;
        else if (file_exists(p2)) args.hybrid_tree_path = p2;
    }
    if (args.folder_map_path.empty()) {
        args.folder_map_path = (fs::path(dqlt_root) / "translation" / "folder_mapping.json").string();
    }
    if (args.edcre_path.empty()) {
        args.edcre_path = (fs::path(dqlt_root) / "edcre" / "edcre-v1.1.0-windows-x86_64-static" / "edcre.exe").string();
    }
    if (args.output_bin_path.empty()) {
        args.output_bin_path = (fs::path(dqlt_root) / "dq4_gold.bin").string();
    }
    if (args.output_cue_path.empty()) {
        args.output_cue_path = args.output_bin_path + ".cue";
        // Replace .bin.cue with just .cue
        size_t pos = args.output_cue_path.find(".bin.cue");
        if (pos != std::string::npos) {
            args.output_cue_path = args.output_cue_path.substr(0, pos) + ".cue";
        }
    }

    // Print mode
    if (args.reverse_mode) {
        printf("  MODE: REVERSE FRANKENSTEIN (Option A)\n");
        printf("  DQ4 disc as base, DW7 EXE swapped in, HBD %s\n\n",
            args.reencode_hbd ? "RE-ENCODED" : "unmodified");
    }

    // Print resolved paths
    printf("=== Input Validation ===\n");
    printf("  DW7 disc:       %s\n", args.dw7_disc_path.c_str());
    printf("  DW7 EXE:        %s\n", args.dw7_exe_path.c_str());
    printf("  DQ4 HBD disc:   %s\n", args.dq4_hbd_disc_path.c_str());
    printf("  Hybrid tree:    %s\n", args.hybrid_tree_path.c_str());
    printf("  Folder map:     %s\n", args.folder_map_path.c_str());
    printf("  EDC/ECC tool:   %s\n", args.edcre_path.c_str());
    printf("  Output .bin:    %s\n", args.output_bin_path.c_str());
    printf("  Output .cue:    %s\n", args.output_cue_path.c_str());
    // F-8 fix: only print flags that are actually used in the current mode
    if (args.reverse_mode) {
        printf("  Mode:           REVERSE (Option A)\n");
        printf("  XA stub:        %s\n", args.no_xa_stub ? "DISABLED" : "ENABLED");
        printf("  HBD re-encode:  %s\n", args.reencode_hbd ? "YES" : "NO");
        printf("  Hotfixes:       %s\n\n", args.hotfix_file.empty() ? "NONE" : args.hotfix_file.c_str());
    } else {
        printf("  Tree mode:      %d\n", args.tree_mode);
        printf("  DuckStation mode: %s\n\n", args.duckstation_mode ? "YES" : "NO");
    }

    // Validate — reverse mode has different requirements
    std::string error;
    if (args.reverse_mode) {
        // Reverse mode needs: DQ4 disc, DW7 EXE, hybrid tree, edcre, output
        // Does NOT need: DW7 disc, folder mapping
        if (args.dq4_hbd_disc_path.empty()) {
            error = "Missing path: DQ4 disc (needed as base for reverse mode)";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        if (args.dw7_exe_path.empty()) {
            error = "Missing path: DW7 EXE";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        if (args.hybrid_tree_path.empty()) {
            error = "Missing path: Hybrid Huffman tree";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        if (args.output_bin_path.empty()) {
            error = "No output path specified";
            printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
            return 1;
        }
        // Check files exist
        const char* required[] = {args.dq4_hbd_disc_path.c_str(), args.dw7_exe_path.c_str(),
                                   args.hybrid_tree_path.c_str()};
        const char* names[] = {"DQ4 disc", "DW7 EXE", "Hybrid tree"};
        for (int i = 0; i < 3; i++) {
            if (!file_exists(required[i])) {
                printf("\n  INPUT VALIDATION FAILED: File not found: %s (%s)\n", names[i], required[i]);
                return 1;
            }
        }
        printf("  All inputs validated (reverse mode — folder mapping not needed).\n\n");
    } else if (!validate_inputs(args, error)) {
        printf("\n  INPUT VALIDATION FAILED: %s\n", error.c_str());
        printf("\n  Use --help for usage information.\n");
        return 1;
    }

    // Print file sizes
    printf("  File sizes:\n");
    printf("    DW7 disc:     %.1f MB\n", (double)fs::file_size(args.dw7_disc_path) / (1024*1024));
    printf("    DW7 EXE:      %.1f KB\n", (double)fs::file_size(args.dw7_exe_path) / 1024);
    printf("    DQ4 HBD:      %.1f MB\n", (double)fs::file_size(args.dq4_hbd_disc_path) / (1024*1024));
    printf("    Hybrid tree:  %llu bytes\n", (unsigned long long)fs::file_size(args.hybrid_tree_path));
    printf("    Folder map:   %.1f KB\n", (double)fs::file_size(args.folder_map_path) / 1024);
    printf("\n  All inputs validated.\n\n");

    // M1: Verify frozen inputs (SHA-256 hash assertion)
    if (!args.skip_hash_check) {
        printf("=== Frozen Input Verification (M1) ===\n");
        if (!verify_frozen_inputs(dqlt_root)) {
            printf("\n  FROZEN INPUT VERIFICATION FAILED — aborting build (M1)\n");
            printf("  Use --skip-hash-check to override (NOT recommended for production builds)\n");
            return 1;
        }
        printf("  All frozen inputs verified.\n\n");
    } else {
        printf("  WARNING: Frozen input hash check SKIPPED (--skip-hash-check)\n\n");
    }

    // ── Build Pipeline Isolation ──────────────────────────────────────
    // 1. Hard-partition staging directory (separate from master source)
    if (args.staging_dir.empty()) {
        args.staging_dir = (fs::path(dqlt_root) / "build_staging").string();
    }
    if (args.master_source.empty()) {
        args.master_source = dqlt_root;
    }
    printf("=== Build Pipeline Isolation ===\n");
    printf("  Master source: %s\n", args.master_source.c_str());
    printf("  Staging dir:   %s\n", args.staging_dir.c_str());

    // 2. Pre-build artifact purge — clear all intermediate files from staging
    if (args.purge) {
        purge_staging_dir(args.staging_dir);
    } else {
        printf("  WARNING: Pre-build purge SKIPPED (--no-purge)\n");
        if (!fs::exists(args.staging_dir)) fs::create_directories(args.staging_dir);
    }

    // Re-point output to staging directory if it's not already an absolute path
    // outside the staging dir. This ensures outputs go to the isolated location.
    fs::path out_path(args.output_bin_path);
    if (out_path.is_relative() || out_path.parent_path() == args.master_source || out_path.parent_path() == dqlt_root) {
        // Redirect output into staging dir
        args.output_bin_path = (fs::path(args.staging_dir) / out_path.filename()).string();
        // Fix cue path too
        if (args.output_cue_path.empty() || args.output_cue_path.find(".bin.cue") != std::string::npos) {
            fs::path cue_path = fs::path(args.output_bin_path);
            cue_path.replace_extension(".cue");
            args.output_cue_path = cue_path.string();
        } else {
            fs::path cue_out(args.output_cue_path);
            args.output_cue_path = (fs::path(args.staging_dir) / cue_out.filename()).string();
        }
        printf("  Output redirected to staging: %s\n", args.output_bin_path.c_str());
        printf("  CUE redirected to staging:    %s\n", args.output_cue_path.c_str());
    }
    printf("\n");

    // Execute the build
    BuildResult result;
    std::string translation_map_full = (fs::path(dqlt_root) / "cybergrime" / "translation_map.bin").string();
    if (args.reverse_mode) {
        printf("=== Executing Reverse Frankenstein Build (Option A) ===\n\n");
        if (!args.hotfix_file.empty()) {
            printf("  [HOTFIX] Injection enabled from: %s\n", args.hotfix_file.c_str());
        }
        std::string blob_path = args.thread_blob_path;
        if(blob_path.empty()){
            blob_path = (fs::path(dqlt_root) / "cybergrime" / "thread_code_blob.bin").string();
        }
        result = FrankensteinBuilder::build_reverse_option_a(
            args.dq4_hbd_disc_path.c_str(),
            args.dw7_exe_path.c_str(),
            args.hybrid_tree_path.c_str(),
            args.output_bin_path.c_str(),
            args.output_cue_path.c_str(),
            args.edcre_path.c_str(),
            (args.cd_intercept ? 1u : 0u) | (args.stall_bypass ? 2u : 0u) | (args.reencode_hbd ? 4u : 0u),
            translation_map_full.c_str(),
            args.hotfix_file.empty() ? nullptr : args.hotfix_file.c_str(),
            args.no_xa_stub,
            blob_path.c_str());
    } else {
        printf("=== Executing Gold Standard Build (tree_mode=%d) ===\n\n", args.tree_mode);
        if (!args.hotfix_file.empty()) {
            printf("  [HOTFIX] Injection enabled from: %s\n", args.hotfix_file.c_str());
        }
        uint32_t build_flags = (args.duckstation_mode ? 2 : 0) | (args.reencode_hbd ? 4 : 0);  // bit 1 = partial DS mode, bit 2 = HBD re-encode
        result = FrankensteinBuilder::build_v39(
            args.dw7_disc_path.c_str(),
            args.dw7_exe_path.c_str(),
            args.dq4_hbd_disc_path.c_str(),
            args.hybrid_tree_path.c_str(),
            args.folder_map_path.c_str(),
            args.output_bin_path.c_str(),
            args.output_cue_path.c_str(),
            args.edcre_path.c_str(),
            args.tree_mode,
            build_flags,
            translation_map_full.c_str(),
            args.hbd_lba_override,
            args.no_xa_stub,
            args.hotfix_file.empty() ? nullptr : args.hotfix_file.c_str(),
            args.no_disc_checks,
            args.disasm_range.empty() ? nullptr : args.disasm_range.c_str());
    }

    // Print final results
    printf("\n=== BUILD RESULTS ===\n");
    printf("  Success:          %s\n", result.disc_size > 0 ? "YES" : "NO");
    printf("  Disc size:        %u bytes (%.1f MB)\n", result.disc_size, (double)result.disc_size / (1024*1024));
    printf("  EXE size:         %u bytes\n", result.exe_size);
    printf("  PC0:              0x%08X\n", result.new_pc0);
    printf("  Tree patches:     %u\n", result.tree_patches);
    printf("  Disc-check patches: %u\n", result.disc_patches);
    printf("  LBA patches:      %u\n", result.lba_patches);
    printf("  Seq table patches: %u\n", result.seq_patches);
    printf("  HBD table patches: %u\n", result.hbd_table_patches);
    printf("  ABS matched:      %u (delta: %u)\n", result.abs_matched, result.abs_delta);
    printf("  REL matched:      %u\n", result.rel_matched);
    printf("  Trampoline patches: %u\n", result.trampoline_patches);
    printf("  HBD blocks:       %u processed, %u converted\n",
           result.hbd_blocks_processed, result.hbd_blocks_converted);
    printf("  HBD sub-block swaps: %u\n", result.hbd_subblock_swaps);
    printf("  HBD LBA patches:  %u\n", result.hbd_lba_patches);
    printf("  FMV BCD patches:  %u\n", result.fmv_bcd_patches);
    printf("  Output: %s + %s\n", args.output_bin_path.c_str(), args.output_cue_path.c_str());

    // Verification checks — HARD GATES (build aborts on critical failures)
    printf("\n=== VERIFICATION (HARD GATES) ===\n");
    int hard_fail_count = 0;

    // Gate 1: EXE header magic (sector-aware read)
    bool magic_ok = false;
    {
        std::ifstream f(args.output_bin_path, std::ios::binary);
        if (f.is_open()) {
            f.seekg(24LL * 2352 + 24);
            char magic[8];
            f.read(magic, 8);
            magic_ok = std::memcmp(magic, "PS-X EXE", 8) == 0;
            printf("  Gate 1  EXE magic: %s\n", magic_ok ? "PASS (PS-X EXE)" : "FAIL");
            if (!magic_ok) hard_fail_count++;
        } else {
            printf("  Gate 1  EXE magic: FAIL (cannot open)\n");
            hard_fail_count++;
        }
    }

    // Gate 2: Output file exists
    bool output_ok = file_exists(args.output_bin_path);
    printf("  Gate 2  Output disc exists: %s\n", output_ok ? "PASS" : "FAIL");
    if (!output_ok) hard_fail_count++;

    // Gate 3: CUE sheet exists
    bool cue_ok = file_exists(args.output_cue_path);
    printf("  Gate 3  CUE sheet exists: %s\n", cue_ok ? "PASS" : "FAIL");
    if (!cue_ok) hard_fail_count++;

    // Gate 4: Disc size > 350MB (must contain HBD)
    bool size_ok = false;
    if (output_ok) {
        uint64_t sz = fs::file_size(args.output_bin_path);
        size_ok = sz > 350ULL * 1024 * 1024;
        printf("  Gate 4  Disc size > 350MB: %s (%.1f MB)\n",
               size_ok ? "PASS" : "FAIL",
               (double)sz / (1024*1024));
        if (!size_ok) hard_fail_count++;
    } else { hard_fail_count++; }

    // Gate 5: Tree patches > 0
    bool tree_ok = result.tree_patches > 0;
    printf("  Gate 5  Tree patches > 0: %s (%u)\n",
           tree_ok ? "PASS" : (args.tree_mode == 0 ? "SKIP (no tree mode)" : "FAIL"),
           result.tree_patches);
    if (!tree_ok && args.tree_mode != 0) hard_fail_count++;

    // Gate 6: Disc-check patches applied (exactly 3)
    bool disc_ok = result.disc_patches == 3;
    printf("  Gate 6  Disc-check patches (==3): %s (%u)\n",
           disc_ok ? "PASS" : "FAIL",
           result.disc_patches);
    if (!disc_ok) hard_fail_count++;

    // Gate 7: HBD blocks processed > 0
    bool hbd_ok = result.hbd_blocks_processed > 0;
    printf("  Gate 7  HBD blocks processed > 0: %s (%u)\n",
           hbd_ok ? "PASS" : "FAIL",
           result.hbd_blocks_processed);
    if (!hbd_ok) hard_fail_count++;

    // Gate 8: HBD blocks converted > 0 (text injection happened)
    bool conv_ok = result.hbd_blocks_converted > 0;
    printf("  Gate 8  HBD blocks converted > 0: %s (%u)\n",
           conv_ok ? "PASS" : "FAIL",
           result.hbd_blocks_converted);
    if (!conv_ok) hard_fail_count++;

    // Gate 9: Sector-aware XA stub verification (D1 regression guard)
    // Read the XA stub at RAM 0x8008B334 from the output disc
    // Skip when --no-xa-stub is set (XA stub intentionally absent)
    bool xa_stub_ok = false;
    if (args.no_xa_stub) {
        printf("  Gate 9  XA stub sw_2038 (D1 guard): SKIP (--no-xa-stub)\n");
    } else if (output_ok) {
        std::ifstream f(args.output_bin_path, std::ios::binary);
        if (f.is_open()) {
            // RAM 0x8008B334, load_addr=0x80017F00, file_off = RAM - load + 0x800 = 0x73C34
            // Sector-aware: LBA = 24 + file_off / 2048, sector_offset = file_off % 2048
            uint32_t xa_file_off = 0x8008B334 - 0x80017F00 + 0x800;  // = 0x73C34
            uint32_t xa_lba = 24 + xa_file_off / 2048;
            uint32_t xa_sec_off = xa_file_off % 2048;
            f.seekg((uint64_t)xa_lba * 2352 + 24 + xa_sec_off);
            uint32_t xa_val = 0;
            f.read(reinterpret_cast<char*>(&xa_val), 4);
            xa_stub_ok = (xa_val == 0xAC222038);
            printf("  Gate 9  XA stub sw_2038 (D1 guard): %s (0x%08X)\n",
                   xa_stub_ok ? "PASS" : "FAIL", xa_val);
            if (!xa_stub_ok) hard_fail_count++;
        } else { hard_fail_count++; }
    } else { hard_fail_count++; }

    // Gate 10: MISS-1 boot copy stub load-delay check (D2 regression guard)
    // stub[7] should be ADDIU (opcode 0x09 in top 6 bits), not SW (0x2B)
    bool miss1_ok = false;
    if (output_ok && result.new_pc0 != 0) {
        std::ifstream f(args.output_bin_path, std::ios::binary);
        if (f.is_open()) {
            uint32_t stub_file_off = result.new_pc0 - 0x80017F00 + 0x800;
            uint32_t stub_lba = 24 + stub_file_off / 2048;
            uint32_t stub_sec_off = stub_file_off % 2048;
            // Read instruction at stub[7] (offset 28 bytes into stub)
            f.seekg((uint64_t)stub_lba * 2352 + 24 + stub_sec_off + 28);
            uint32_t insn7 = 0;
            f.read(reinterpret_cast<char*>(&insn7), 4);
            uint32_t opcode = (insn7 >> 26) & 0x3F;
            miss1_ok = (opcode == 0x09);  // ADDIU
            printf("  Gate 10 MISS-1 stub[7] ADDIU (D2 guard): %s (0x%08X op=%u)\n",
                   miss1_ok ? "PASS" : "FAIL", insn7, opcode);
            if (!miss1_ok) hard_fail_count++;
        } else { hard_fail_count++; }
    } else {
        printf("  Gate 10 MISS-1 stub[7] ADDIU (D2 guard): SKIP (no MISS-1)\n");
    }

    // Helper lambda: sector-aware read of a 32-bit word from output disc at given RAM address
    auto read_disc_word = [&](uint32_t ram_addr) -> uint32_t {
        if (!output_ok) return 0xDEADDEAD;
        std::ifstream f(args.output_bin_path, std::ios::binary);
        if (!f.is_open()) return 0xDEADDEAD;
        uint32_t file_off = ram_addr - 0x80017F00 + 0x800;
        uint32_t lba = 24 + file_off / 2048;
        uint32_t sec_off = file_off % 2048;
        f.seekg((uint64_t)lba * 2352 + 24 + sec_off);
        uint32_t val = 0;
        f.read(reinterpret_cast<char*>(&val), 4);
        return val;
    };

    // Gate 11: Disc-check patches (3 sites) — verify patched to 0x24020001
    if (output_ok) {
        uint32_t dc1 = read_disc_word(0x8007902C);
        uint32_t dc2 = read_disc_word(0x800790D8);
        uint32_t dc3 = read_disc_word(0x800792B8);
        bool dc_ok = (dc1 == 0x24020001 && dc2 == 0x24020001 && dc3 == 0x24020001);
        printf("  Gate 11 Disc-check 3 sites == 0x24020001: %s (0x%08X,0x%08X,0x%08X)\n",
               dc_ok ? "PASS" : "FAIL", dc1, dc2, dc3);
        if (!dc_ok) hard_fail_count++;
    }

    // Gate 12: Malloc clamp trampoline (9 words at 0x800BCF80)
    if (output_ok) {
        uint32_t mt[9];
        bool mt_ok = true;
        for (int i = 0; i < 9; i++) {
            mt[i] = read_disc_word(0x800BCF80 + i * 4);
            if (mt[i] == 0xDEADDEAD) mt_ok = false;
        }
        // Check first word is LUI (op=0x0F) and jump at [7] is J (op=0x02)
        uint32_t op0 = (mt[0] >> 26) & 0x3F;
        uint32_t op7 = (mt[7] >> 26) & 0x3F;
        bool mt_struct = (op0 == 0x0F && op7 == 0x02);
        printf("  Gate 12 Malloc clamp trampoline (9 words): %s (op0=0x%02X op7=0x%02X)\n",
               (mt_ok && mt_struct) ? "PASS" : "FAIL", op0, op7);
        if (!(mt_ok && mt_struct)) hard_fail_count++;
    }

    // Gate 13: Tree hook JAL at 0x800562B8
    if (output_ok) {
        uint32_t th = read_disc_word(0x800562B8);
        uint32_t th_op = (th >> 26) & 0x3F;
        bool th_ok = (th_op == 0x03);  // JAL
        printf("  Gate 13 Tree hook JAL at 0x800562B8: %s (0x%08X op=%u)\n",
               th_ok ? "PASS" : "FAIL", th, th_op);
        if (!th_ok) hard_fail_count++;
    }

    // Gate 14: FIFO drain jump at 0x8008B65C
    if (output_ok) {
        uint32_t fd = read_disc_word(0x8008B65C);
        uint32_t fd_op = (fd >> 26) & 0x3F;
        bool fd_ok = (fd_op == 0x02);  // J
        printf("  Gate 14 FIFO drain J at 0x8008B65C: %s (0x%08X op=%u)\n",
               fd_ok ? "PASS" : "FAIL", fd, fd_op);
        if (!fd_ok) hard_fail_count++;
    }

    // Gate 15: Decomp root ID runtime JAL at 0x80057FEC
    if (output_ok) {
        uint32_t dr = read_disc_word(0x80057FEC);
        uint32_t dr_op = (dr >> 26) & 0x3F;
        bool dr_ok = (dr_op == 0x03);  // JAL
        printf("  Gate 15 Decomp root ID JAL at 0x80057FEC: %s (0x%08X op=%u)\n",
               dr_ok ? "PASS" : "FAIL", dr, dr_op);
        if (!dr_ok) hard_fail_count++;
    }

    // Gate 16: BSS clear range (3 words at 0x8008E288-0x8008E290)
    if (output_ok) {
        uint32_t bs1 = read_disc_word(0x8008E288);
        uint32_t bs2 = read_disc_word(0x8008E28C);
        uint32_t bs3 = read_disc_word(0x8008E290);
        // bs1 should be ADDIU with narrowed start, bs2 should be LUI, bs3 should be ADDIU
        bool bs_ok = (((bs1 >> 26) & 0x3F) == 0x09 && ((bs2 >> 26) & 0x3F) == 0x0F && ((bs3 >> 26) & 0x3F) == 0x09);
        printf("  Gate 16 BSS clear range (3 words): %s (0x%08X,0x%08X,0x%08X)\n",
               bs_ok ? "PASS" : "FAIL", bs1, bs2, bs3);
        if (!bs_ok) hard_fail_count++;
    }

    // Gate 17: LBA reference at 0x8001B194
    if (output_ok) {
        uint32_t lba = read_disc_word(0x8001B194);
        bool lba_ok = (lba == 0x0000016A);  // expected patched value
        printf("  Gate 17 LBA ref at 0x8001B194 == 0x16A: %s (0x%08X)\n",
               lba_ok ? "PASS" : "FAIL", lba);
        if (!lba_ok) hard_fail_count++;
    }

    // Gate 18: Seq table first entry at 0x800BB0AA
    if (output_ok) {
        uint32_t st = read_disc_word(0x800BB0AA);
        bool st_ok = (st == 0x01660166);  // expected patched value
        printf("  Gate 18 Seq table[0] at 0x800BB0AA == 0x01660166: %s (0x%08X)\n",
               st_ok ? "PASS" : "FAIL", st);
        if (!st_ok) hard_fail_count++;
    }

    // Gate 19: Decomp tree ptr LUI at 0x800562EC (should be LUI rt=1, not rt=2)
    if (output_ok) {
        uint32_t dt = read_disc_word(0x800562EC);
        bool dt_ok = (((dt >> 26) & 0x3F) == 0x0F) && (((dt >> 16) & 0x1F) == 0x01);
        printf("  Gate 19 Decomp tree ptr LUI at 0x800562EC: %s (0x%08X)\n",
               dt_ok ? "PASS" : "FAIL", dt);
        if (!dt_ok) hard_fail_count++;
    }

    // 3. Post-build hash manifest — verify output integrity and write manifest
    if (result.disc_size > 0) {
        printf("\n=== Post-Build Hash Manifest ===\n");
        verify_staging_hash(args.staging_dir, args.output_bin_path, argc, argv, result);
    }

    printf("\n============================================================\n");
    if (hard_fail_count > 0) {
        printf("  Gold Standard Build REJECTED — %d hard gate failure(s)\n", hard_fail_count);
    } else {
        printf("  Gold Standard Build %s\n", result.disc_size > 0 ? "COMPLETE" : "FAILED");
    }
    printf("============================================================\n");

    return (result.disc_size > 0 && hard_fail_count == 0) ? 0 : 1;
}
