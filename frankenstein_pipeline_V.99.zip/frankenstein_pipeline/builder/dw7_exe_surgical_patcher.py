#!/usr/bin/env python3
"""
dw7_exe_surgical_patcher.py — Definitive DW7.EXE Binary Surgical Patching Tool

Handles three critical patch categories for the DQ4 Frankenstein build:
  1. File-Table Redirection (IFT Patching) — remap ABS/REL folder pointers + LBA refs
  2. Disc-Check Subroutine Bypass — NOP/branch-flip all disc identity checks
  3. TOC & Archive Header Accommodation — verify HBD archive integrity

Disc format: Mode 2 Form 1, 2352-byte sectors (24-byte header + 2048-byte data)
EXE location: LBA 24, load address 0x80017F00, 0x800-byte PS-X EXE header

Usage:
  python dw7_exe_surgical_patcher.py <disc.bin> [--verify-only] [--dump-tables]
  python dw7_exe_surgical_patcher.py <disc.bin> --apply-all
  python dw7_exe_surgical_patcher.py <disc.bin> --apply-disc-check
  python dw7_exe_surgical_patcher.py <disc.bin> --apply-file-table --folder-map <folder_mapping.json>
"""

import struct
import json
import os
import sys
import shutil
from typing import Optional

# ═══════════════════════════════════════════════════════════════════════════════
# CONSTANTS — Locked from Unified Blueprint (Jul 19, 2026)
# ═══════════════════════════════════════════════════════════════════════════════

SECTOR_SIZE = 0x930       # 2352 bytes (Mode 2 Form 1)
SECTOR_DATA = 0x800       # 2048 bytes user data
SECTOR_HEADER = 24        # sync(12) + header(4) + subheader(8)
EXE_LBA = 24
EXE_LOAD_ADDR = 0x80017F00
ORIGINAL_PC0 = 0x8008E284
PSX_RAM_SIZE = 0x200000   # 2MB

# HBD layout
HBD_LBA = 355             # Frankenstein HBD start (was 354 in original DW7)
DW7_HBD_SIZE = 618563584  # 618MB
DQ4_HBD_SIZE = 319436800  # 319MB
DQ4_HBD_DISC_START = 362  # Original DQ4 HBD LBA on source disc

# File table locations (EXE offsets, excluding 0x800 header)
ABS_TABLE_START = 0x4184  # Absolute folder pointer table
REL_TABLE_START = 0x511C  # Relative folder pointer table
TABLE_ENTRY_SIZE = 8      # Each entry: 4-byte LBA + 4-byte RAM address
MAX_TABLE_ENTRIES = 6000

# Sequential sector table (16-bit entries)
SEQ_TABLE_START = 0xA39AA
SEQ_TABLE_END = 0xA3A02
SEQ_TABLE_MIN = 300
SEQ_TABLE_MAX = 400

# BSS clear loop (EXE offsets)
BSS_LUI_V1_OFF = 0x76B8C    # lui $v1, BSS end upper
BSS_ADDIU_V1_OFF = 0x76B90  # addiu $v1, BSS end lower
BSS_LUI_ORIG = 0x3C03800F   # lui $v1, 0x800F
BSS_LUI_PATCHED = 0x3C03800C  # lui $v1, 0x800C
BSS_ADDIU_ORIG = 0x24634980   # addiu $v1, 0x4980
BSS_ADDIU_PATCHED = 0x2462CCC8  # addiu $v1, 0xCCC8 (signed: -0x3338)

# CD-ROM intercept
CDROM_CMD_WRITE_OFF = 0x80F64
CDROM_BRANCH_OFF = 0x80F68

# ═══════════════════════════════════════════════════════════════════════════════
# DISC-CHECK BYPASS PATCH TABLE
# ═══════════════════════════════════════════════════════════════════════════════
# Each patch is at a specific EXE offset (excluding 0x800 header).
# The disc-check subroutine verifies disc identity by reading the CD-ROM
# status register and comparing sector headers. When the DQ4 HBD is grafted
# onto the DW7 EXE, the disc identity check fails because the volume ID
# doesn't match. These patches force all exit paths to return success.

DISC_CHECK_PATCHES = [
    # --- Exit path forcing: replace conditional returns with li $v0, 1 (success) ---
    # These are the 3 exit points of the disc validation function.
    # Original: conditional branch + li $v0, 0 (failure)
    # Patched:  li $v0, 1 (unconditional success)
    {
        'offset': 0x6112C,
        'patch': struct.pack('<I', 0x24020001),  # li $v0, 1 (addiu $v0, $zero, 1)
        'desc': 'disc_check_exit1_force_success',
        'ram': 0x8007902C,
        'category': 'exit_force',
    },
    {
        'offset': 0x611D8,
        'patch': struct.pack('<I', 0x24020001),  # li $v0, 1
        'desc': 'disc_check_exit2_force_success',
        'ram': 0x800790D8,
        'category': 'exit_force',
    },
    {
        'offset': 0x613B8,
        'patch': struct.pack('<I', 0x24020001),  # li $v0, 1
        'desc': 'disc_check_exit3_force_success',
        'ram': 0x800792BC,
        'category': 'exit_force',
    },

    # --- NOP timeout/error checks: remove conditional branches on CD-ROM errors ---
    # These NOP out the branch-on-error instructions so errors are ignored
    {
        'offset': 0x614A4,
        'patch': struct.pack('<I', 0x00000000),  # NOP
        'desc': 'nop_timeout_check',
        'ram': 0x800793A4,
        'category': 'nop_error',
    },
    {
        'offset': 0x614F8,
        'patch': struct.pack('<I', 0x00000000),  # NOP
        'desc': 'nop_error_check',
        'ram': 0x800793F8,
        'category': 'nop_error',
    },

    # --- Branch redirect: force jump past disc validation ---
    # Redirect a trap handler to skip disc validation entirely
    {
        'offset': 0x7308C,
        'patch': struct.pack('<I', 0x08022BE9),  # j 0x800AFA4 (skip to post-validation)
        'desc': 'redirect_trap_past_validation',
        'ram': 0x8008B08C,
        'category': 'branch_redirect',
    },

    # --- Branch flips: convert BEQ to B (unconditional) ---
    # These flip conditional branches to unconditional, skipping disc checks
    {
        'offset': 0x61424,
        'patch': struct.pack('<I', 0x1000000B),  # b 11 (skip 11 instructions = past check)
        'desc': 'graft_a_skip_disc_check',
        'ram': 0x80079324,
        'category': 'branch_flip',
    },
    {
        'offset': 0x61520,
        'patch': struct.pack('<I', 0x1000000B),  # b 11
        'desc': 'graft_b_skip_disc_check',
        'ram': 0x80079420,
        'category': 'branch_flip',
    },
    {
        'offset': 0x61360,
        'patch': struct.pack('<I', 0x1000000A),  # b 10
        'desc': 'graft_c_skip_disc_check',
        'ram': 0x80079260,
        'category': 'branch_flip',
    },

    # --- Multi-word patches (variable length) ---
    # CD init: force CD-ROM init to return success immediately
    {
        'offset': 0x60FA4,
        'patch': bytes.fromhex('010002240800E00300000000'),
        'desc': 'cd_init_force_success',
        'ram': 0x80078FA4,
        'category': 'cd_init',
        # li $v0, 1; jr $ra; nop  →  immediate success return
    },
    # Neutralize disc identity comparison: replace comparison with unconditional return
    {
        'offset': 0x387CC,
        'patch': bytes.fromhex('0800E0030000000000000000'),
        'desc': 'neutralize_disc_identity_compare',
        'ram': 0x800507CC,
        'category': 'neutralize',
        # jr $ra; nop; nop  →  skip disc identity comparison entirely
    },
]

# ═══════════════════════════════════════════════════════════════════════════════
# MIPS INSTRUCTION ENCODING HELPERS
# ═══════════════════════════════════════════════════════════════════════════════

def mips_lui(rt: int, imm16: int) -> int:
    """LUI rt, imm16 — Load upper immediate."""
    return (0x0F << 26) | (0 << 21) | (rt << 16) | (imm16 & 0xFFFF)

def mips_addiu(rt: int, rs: int, imm16: int) -> int:
    """ADDIU rt, rs, imm16 — Add immediate unsigned."""
    return (0x09 << 26) | (rs << 21) | (rt << 16) | (imm16 & 0xFFFF)

def mips_beq(rs: int, rt: int, offset: int) -> int:
    """BEQ rs, rt, offset — Branch if equal."""
    return (0x04 << 26) | (rs << 21) | (rt << 16) | (offset & 0xFFFF)

def mips_bne(rs: int, rt: int, offset: int) -> int:
    """BNE rs, rt, offset — Branch if not equal."""
    return (0x05 << 26) | (rs << 21) | (rt << 16) | (offset & 0xFFFF)

def mips_b(offset: int) -> int:
    """B offset — Unconditional branch (BEQ $zero, $zero, offset)."""
    return mips_beq(0, 0, offset)

def mips_nop() -> int:
    """NOP — No operation."""
    return 0x00000000

def mips_j(addr: int) -> int:
    """J addr — Jump (absolute, 26-bit target)."""
    return (0x02 << 26) | ((addr >> 2) & 0x3FFFFFF)

def mips_jr(rs: int) -> int:
    """JR rs — Jump register."""
    return (0x00 << 26) | (rs << 21) | 0x08

def mips_li_v0(val: int) -> int:
    """LI $v0, val — Load immediate into $v0 (for small values)."""
    return mips_addiu(2, 0, val & 0xFFFF)

# ═══════════════════════════════════════════════════════════════════════════════
# DISC OFFSET CALCULATION
# ═══════════════════════════════════════════════════════════════════════════════

def exe_to_disc_offset(exe_offset: int) -> int:
    """Convert EXE file offset to disc byte offset.
    
    EXE data is spread across 2048-byte user data sectors starting at LBA 24.
    Each raw sector is 2352 bytes with a 24-byte header.
    """
    sector_idx = exe_offset // SECTOR_DATA
    offset_in_sector = exe_offset % SECTOR_DATA
    return (EXE_LBA + sector_idx) * SECTOR_SIZE + SECTOR_HEADER + offset_in_sector

def ram_to_exe_offset(ram_addr: int) -> int:
    """Convert PSX RAM address to EXE file offset (including 0x800 header)."""
    return (ram_addr - EXE_LOAD_ADDR) + 0x800

def ram_to_disc_offset(ram_addr: int) -> int:
    """Convert PSX RAM address directly to disc byte offset."""
    return exe_to_disc_offset(ram_to_exe_offset(ram_addr))

# ═══════════════════════════════════════════════════════════════════════════════
# DISC READER/WRITER
# ═══════════════════════════════════════════════════════════════════════════════

class DiscImage:
    def __init__(self, path: str):
        self.path = path
        self._file = None

    def __enter__(self):
        self._file = open(self.path, 'r+b')
        return self

    def __exit__(self, *args):
        if self._file:
            self._file.close()

    def read_exe_bytes(self, exe_offset: int, size: int) -> bytes:
        """Read bytes from EXE at the given EXE file offset."""
        disc_off = exe_to_disc_offset(exe_offset)
        self._file.seek(disc_off)
        return self._file.read(size)

    def write_exe_bytes(self, exe_offset: int, data: bytes):
        """Write bytes to EXE at the given EXE file offset."""
        disc_off = exe_to_disc_offset(exe_offset)
        self._file.seek(disc_off)
        self._file.write(data)
        self._file.flush()

    def read_ram(self, ram_addr: int, size: int) -> bytes:
        """Read bytes from the EXE at the given RAM address."""
        return self.read_exe_bytes(ram_to_exe_offset(ram_addr), size)

    def write_ram(self, ram_addr: int, data: bytes):
        """Write bytes to the EXE at the given RAM address."""
        self.write_exe_bytes(ram_to_exe_offset(ram_addr), data)

    def read32(self, exe_offset: int) -> int:
        """Read a 32-bit little-endian value from EXE offset."""
        return struct.unpack('<I', self.read_exe_bytes(exe_offset, 4))[0]

    def write32(self, exe_offset: int, val: int):
        """Write a 32-bit little-endian value to EXE offset."""
        self.write_exe_bytes(exe_offset, struct.pack('<I', val))

    def read_header(self) -> dict:
        """Read the PS-X EXE header."""
        header = self.read_exe_bytes(0, 0x800)
        return {
            'magic': header[:8],
            'pc': struct.unpack_from('<I', header, 0x10)[0],
            'gp': struct.unpack_from('<I', header, 0x14)[0],
            'load_addr': struct.unpack_from('<I', header, 0x18)[0],
            'file_size': struct.unpack_from('<I', header, 0x1C)[0],
            'memfill_start': struct.unpack_from('<I', header, 0x28)[0],
            'memfill_size': struct.unpack_from('<I', header, 0x2C)[0],
            'sp_base': struct.unpack_from('<I', header, 0x30)[0],
            'sp_offset': struct.unpack_from('<I', header, 0x34)[0],
        }

# ═══════════════════════════════════════════════════════════════════════════════
# 1. FILE-TABLE REDIRECTION (IFT PATCHING)
# ═══════════════════════════════════════════════════════════════════════════════

def verify_file_table(disc: DiscImage) -> dict:
    """Verify the ABS and REL folder pointer tables."""
    header = disc.read_header()
    load_end = header['load_addr'] + header['file_size']

    result = {
        'abs_entries': [],
        'rel_entries': [],
        'abs_count': 0,
        'rel_count': 0,
        'lba_refs': 0,
        'seq_table_entries': [],
    }

    # --- ABS Table: 4-byte LBA + 4-byte RAM address per entry ---
    print("\n=== ABS Folder Pointer Table (EXE offset 0x4184) ===")
    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 8 > header['file_size'] + 0x800:
            break
        lba = disc.read32(off)
        ram = disc.read32(off + 4)
        if lba == 0 and ram == 0:
            continue
        result['abs_entries'].append({'index': i, 'lba': lba, 'ram': ram, 'exe_offset': off})
        result['abs_count'] += 1
        if result['abs_count'] <= 20 or i >= result['abs_count'] - 5:
            print(f"  [{i:4d}] LBA={lba:6d}  RAM=0x{ram:08X}  (EXE off 0x{off:05X})")
        elif result['abs_count'] == 21:
            print(f"  ... ({MAX_TABLE_ENTRIES - 25} more entries) ...")

    # --- REL Table: 4-byte relative sector offset + 4-byte RAM address ---
    print(f"\n=== REL Folder Pointer Table (EXE offset 0x511C) ===")
    for i in range(MAX_TABLE_ENTRIES):
        off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 8 > header['file_size'] + 0x800:
            break
        rel_sector = disc.read32(off)
        ram = disc.read32(off + 4)
        if rel_sector == 0 and ram == 0:
            continue
        result['rel_entries'].append({
            'index': i, 'rel_sector': rel_sector, 'ram': ram, 'exe_offset': off
        })
        result['rel_count'] += 1
        if result['rel_count'] <= 20 or i >= result['rel_count'] - 5:
            print(f"  [{i:4d}] REL={rel_sector:6d}  RAM=0x{ram:08X}  (EXE off 0x{off:05X})")
        elif result['rel_count'] == 21:
            print(f"  ... ({MAX_TABLE_ENTRIES - 25} more entries) ...")

    # --- LBA broad scan: count 32-bit references to old HBD LBA 354 ---
    print("\n=== LBA Reference Scan ===")
    old_lba = 354
    lba_refs = 0
    exe_data = disc.read_exe_bytes(0x800, header['file_size'])
    for i in range(0, len(exe_data) - 4, 4):
        val = struct.unpack_from('<I', exe_data, i)[0]
        if val == old_lba:
            lba_refs += 1
            exe_off = i + 0x800
            ram_addr = EXE_LOAD_ADDR + i
            if lba_refs <= 10:
                print(f"  LBA 354 ref at EXE off 0x{exe_off:05X} (RAM 0x{ram_addr:08X})")
    if lba_refs > 10:
        print(f"  ... ({lba_refs - 10} more references)")
    print(f"  Total LBA 354 references: {lba_refs}")
    result['lba_refs'] = lba_refs

    # --- Sequential sector table (16-bit entries) ---
    print(f"\n=== Sequential Sector Table (EXE offset 0x{SEQ_TABLE_START:05X}) ===")
    for off in range(SEQ_TABLE_START, SEQ_TABLE_END, 2):
        if off + 2 > header['file_size'] + 0x800:
            break
        val = struct.unpack('<H', disc.read_exe_bytes(off, 2))[0]
        if SEQ_TABLE_MIN <= val <= SEQ_TABLE_MAX:
            result['seq_table_entries'].append({'offset': off, 'value': val})
            print(f"  0x{off:05X}: {val} (in range {SEQ_TABLE_MIN}-{SEQ_TABLE_MAX})")

    return result


def apply_file_table_redirection(disc: DiscImage, folder_map_path: str) -> dict:
    """Apply file-table redirection patches.

    1. Remap ABS table entries: matched folders → DQ4 sectors, unmatched → LBA delta
    2. Remap REL table entries: same strategy with relative offsets
    3. Broad scan: patch all 32-bit references from old LBA 354 → new HBD_LBA 355
    4. Sequential sector table: shift 16-bit entries by LBA delta
    """
    result = {'abs_matched': 0, 'abs_delta': 0, 'rel_matched': 0, 'lba_patches': 0, 'seq_patches': 0}

    # Load folder mappings
    with open(folder_map_path, 'r') as f:
        mappings = json.load(f)
    if isinstance(mappings, dict):
        mappings = mappings.get('mappings', mappings.get('folders', []))
    print(f"  Loaded {len(mappings)} folder mappings")

    lba_delta = HBD_LBA - 354  # = 1
    DW7_HBD_SECTORS = DW7_HBD_SIZE // SECTOR_DATA  # 301760
    DQ4_BASE_SECTOR = HBD_LBA + DW7_HBD_SECTORS    # 302115

    # --- ABS Table remapping ---
    print(f"\n  ABS table remapping (DQ4 base=sector {DQ4_BASE_SECTOR}, LBA delta={lba_delta}):")
    mapping_dict = {}
    for m in mappings:
        if isinstance(m, dict):
            dw7_s = m.get('dw7_sector', m.get('dw7', 0))
            dq4_s = m.get('dq4_sector', m.get('dq4', 0))
            if dw7_s and dq4_s:
                mapping_dict[dw7_s] = dq4_s

    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        lba = disc.read32(off)
        if lba == 0:
            continue

        if lba in mapping_dict:
            # Matched: redirect to DQ4 sector
            new_sector = mapping_dict[lba] + (DQ4_BASE_SECTOR - HBD_LBA)
            disc.write32(off, new_sector)
            result['abs_matched'] += 1
        elif 300 <= lba <= 400:
            # Unmatched in HBD range: apply LBA delta
            disc.write32(off, lba + lba_delta)
            result['abs_delta'] += 1

    print(f"    Matched: {result['abs_matched']}, Delta: {result['abs_delta']}")

    # --- REL Table remapping ---
    rel_adjust = DQ4_BASE_SECTOR - HBD_LBA
    for i in range(MAX_TABLE_ENTRIES):
        off = REL_TABLE_START + i * TABLE_ENTRY_SIZE
        rel_sector = disc.read32(off)
        if rel_sector == 0:
            continue
        if rel_sector in mapping_dict:
            new_rel = mapping_dict[rel_sector] + rel_adjust
            disc.write32(off, new_rel)
            result['rel_matched'] += 1

    print(f"    REL matched: {result['rel_matched']}")

    # --- LBA broad scan: 354 → 355 ---
    header = disc.read_header()
    exe_data = bytearray(disc.read_exe_bytes(0x800, header['file_size']))
    for i in range(0, len(exe_data) - 4, 4):
        val = struct.unpack_from('<I', exe_data, i)[0]
        if val == 354:
            struct.pack_into('<I', exe_data, i, HBD_LBA)
            result['lba_patches'] += 1
    disc.write_exe_bytes(0x800, bytes(exe_data))
    print(f"    LBA broad scan: {result['lba_patches']} references patched (354 → {HBD_LBA})")

    # --- Sequential sector table ---
    for off in range(SEQ_TABLE_START, SEQ_TABLE_END, 2):
        val = struct.unpack('<H', disc.read_exe_bytes(off, 2))[0]
        if SEQ_TABLE_MIN <= val <= SEQ_TABLE_MAX:
            new_val = val + lba_delta
            disc.write_exe_bytes(off, struct.pack('<H', new_val))
            result['seq_patches'] += 1
    print(f"    Sequential sector table: {result['seq_patches']} entries patched")

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# 2. DISC-CHECK SUBROUTINE BYPASS
# ═══════════════════════════════════════════════════════════════════════════════

def verify_disc_check(disc: DiscImage) -> dict:
    """Verify the current state of disc-check patches."""
    results = []
    for p in DISC_CHECK_PATCHES:
        exe_off = p['offset']
        current = disc.read_exe_bytes(exe_off, len(p['patch']))
        expected = p['patch']
        is_patched = current == expected

        # Try to identify the original value
        if len(current) == 4:
            curr_val = struct.unpack('<I', current)[0]
            curr_str = f"0x{curr_val:08X}"
        else:
            curr_str = current.hex()

        if len(expected) == 4:
            exp_val = struct.unpack('<I', expected)[0]
            exp_str = f"0x{exp_val:08X}"
        else:
            exp_str = expected.hex()

        status = '✓ PATCHED' if is_patched else '✗ NOT PATCHED'
        results.append({
            'desc': p['desc'],
            'offset': exe_off,
            'ram': p.get('ram', 0),
            'current': curr_str,
            'expected': exp_str,
            'patched': is_patched,
            'category': p['category'],
        })
        print(f"  {status}  0x{exe_off:05X} (RAM 0x{p.get('ram', 0):08X})  {p['desc']}")
        print(f"           current={curr_str}  expected={exp_str}")

    patched_count = sum(1 for r in results if r['patched'])
    print(f"\n  Summary: {patched_count}/{len(results)} patches applied")
    return {'patches': results, 'patched_count': patched_count, 'total': len(results)}


def apply_disc_check_bypass(disc: DiscImage) -> int:
    """Apply all disc-check bypass patches."""
    count = 0
    for p in DISC_CHECK_PATCHES:
        exe_off = p['offset']
        current = disc.read_exe_bytes(exe_off, len(p['patch']))
        if current == p['patch']:
            print(f"  ✓ Already patched: {p['desc']} (0x{exe_off:05X})")
            count += 1
            continue

        disc.write_exe_bytes(exe_off, p['patch'])
        written = disc.read_exe_bytes(exe_off, len(p['patch']))
        if written == p['patch']:
            print(f"  ✓ Applied: {p['desc']} (0x{exe_off:05X})")
            count += 1
        else:
            print(f"  ✗ FAILED: {p['desc']} (0x{exe_off:05X})")

    return count


# ═══════════════════════════════════════════════════════════════════════════════
# 3. TOC & ARCHIVE HEADER ACCOMMODATION
# ═══════════════════════════════════════════════════════════════════════════════

def verify_toc_archive(disc: DiscImage) -> dict:
    """Verify TOC and archive header integrity.

    The DW7 engine parses its internal Archive TOC on boot via:
    1. Reading the ABS table at EXE offset 0x4184 (RAM 0x8005C084)
    2. For each entry, reading the HBD block header at the specified LBA
    3. Validating block type, size, and checksum fields

    This function verifies:
    - All ABS table entries point to valid LBA ranges
    - The HBD block headers at those LBAs have valid type fields
    - No integrity faults would be triggered
    """
    header = disc.read_header()
    result = {'valid_entries': 0, 'invalid_entries': 0, 'warnings': []}

    print("\n=== TOC & Archive Header Verification ===")
    print(f"  EXE load range: 0x{header['load_addr']:08X} - 0x{header['load_addr'] + header['file_size']:08X}")
    print(f"  HBD LBA: {HBD_LBA}")
    print(f"  DQ4 HBD start: {DQ4_HBD_DISC_START}")

    # Check ABS table entries
    for i in range(MAX_TABLE_ENTRIES):
        off = ABS_TABLE_START + i * TABLE_ENTRY_SIZE
        if off + 8 > header['file_size'] + 0x800:
            break
        lba = disc.read32(off)
        ram = disc.read32(off + 4)
        if lba == 0 and ram == 0:
            continue

        # Validate LBA range
        if lba < 24 or lba > 500000:
            result['invalid_entries'] += 1
            result['warnings'].append(f"ABS[{i}]: LBA {lba} out of range")
            if result['invalid_entries'] <= 5:
                print(f"  ⚠ ABS[{i}]: LBA {lba} out of valid range")
        else:
            result['valid_entries'] += 1

        # Validate RAM address
        if ram != 0 and not (0x80000000 <= ram <= 0x80200000):
            result['warnings'].append(f"ABS[{i}]: RAM 0x{ram:08X} not in PSX range")
            if result['invalid_entries'] <= 5:
                print(f"  ⚠ ABS[{i}]: RAM 0x{ram:08X} not in PSX address space")

    print(f"\n  Valid entries: {result['valid_entries']}")
    print(f"  Invalid entries: {result['invalid_entries']}")
    print(f"  Warnings: {len(result['warnings'])}")

    # Check BSS clear range (must not overlap TOC entries)
    bss_lui = disc.read32(BSS_LUI_V1_OFF)
    bss_addiu = disc.read32(BSS_ADDIU_V1_OFF)
    lui_imm = bss_lui & 0xFFFF
    addiu_imm = bss_addiu & 0xFFFF
    addiu_signed = addiu_imm - 0x10000 if addiu_imm >= 0x8000 else addiu_imm
    bss_end = ((lui_imm << 16) + addiu_signed) & 0xFFFFFFFF

    print(f"\n  BSS clear range: 0x800BC668 - 0x{bss_end:08X}")
    print(f"  Thread entry 0x800D9E80 in BSS range: {0x800BC668 <= 0x800D9E80 < bss_end}")
    if 0x800BC668 <= 0x800D9E80 < bss_end:
        result['warnings'].append("BSS clear still zeros thread entry!")
        print(f"  ⚠ CRITICAL: BSS clear still zeros thread entry at 0x800D9E80!")
    else:
        print(f"  ✓ Thread entry preserved (outside BSS clear range)")

    # Check CD-ROM intercept
    cdrom_val = disc.read32(CDROM_CMD_WRITE_OFF)
    print(f"\n  CD-ROM intercept at 0x{CDROM_CMD_WRITE_OFF:05X}: 0x{cdrom_val:08X}")

    return result


# ═══════════════════════════════════════════════════════════════════════════════
# BSS CLEAR NARROW PATCH (prerequisite for disc-check to work)
# ═══════════════════════════════════════════════════════════════════════════════

def apply_bss_narrow(disc: DiscImage) -> bool:
    """Apply the BSS clear narrow patch (both LUI and ADDIU).

    CRITICAL: addiu 0xCCC8 is SIGNED (-13112). Must patch BOTH instructions:
      lui $v1, 0x800F → 0x800C  (upper 16 bits of BSS end)
      addiu $v1, 0x4980 → 0xCCC8  (lower 16 bits, signed)
    
    Without the LUI patch: 0x800F0000 + (-13112) = 0x800ECCC8 (WRONG)
    With both patches:     0x800C0000 + (-13112) = 0x800BCCC8 (CORRECT)
    """
    # Check current state
    curr_lui = disc.read32(BSS_LUI_V1_OFF)
    curr_addiu = disc.read32(BSS_ADDIU_V1_OFF)

    lui_ok = curr_lui == BSS_LUI_PATCHED
    addiu_ok = curr_addiu == BSS_ADDIU_PATCHED

    if lui_ok and addiu_ok:
        print("  ✓ BSS narrow patch already applied (both LUI + ADDIU)")
        return True

    print(f"  Current LUI:   0x{curr_lui:08X} ({'✓' if lui_ok else '✗ needs patch'})")
    print(f"  Current ADDIU: 0x{curr_addiu:08X} ({'✓' if addiu_ok else '✗ needs patch'})")

    if not lui_ok:
        disc.write32(BSS_LUI_V1_OFF, BSS_LUI_PATCHED)
        print(f"  ✓ LUI patched: 0x{curr_lui:08X} → 0x{BSS_LUI_PATCHED:08X}")

    if not addiu_ok:
        disc.write32(BSS_ADDIU_V1_OFF, BSS_ADDIU_PATCHED)
        print(f"  ✓ ADDIU patched: 0x{curr_addiu:08X} → 0x{BSS_ADDIU_PATCHED:08X}")

    # Verify
    final_lui = disc.read32(BSS_LUI_V1_OFF)
    final_addiu = disc.read32(BSS_ADDIU_V1_OFF)
    lui_imm = final_lui & 0xFFFF
    addiu_imm = final_addiu & 0xFFFF
    addiu_signed = addiu_imm - 0x10000 if addiu_imm >= 0x8000 else addiu_imm
    bss_end = ((lui_imm << 16) + addiu_signed) & 0xFFFFFFFF

    print(f"  BSS end: 0x{bss_end:08X} {'✓ CORRECT' if bss_end == 0x800BCCC8 else '✗ WRONG'}")
    return bss_end == 0x800BCCC8


# ═══════════════════════════════════════════════════════════════════════════════
# MAIN
# ═══════════════════════════════════════════════════════════════════════════════

def main():
    import argparse
    parser = argparse.ArgumentParser(
        description='DW7.EXE Binary Surgical Patching Tool — Disc-Check Bypass & File-Table Redirection'
    )
    parser.add_argument('disc', help='Path to disc image (.bin)')
    parser.add_argument('--verify-only', action='store_true', help='Verify patch state without applying')
    parser.add_argument('--dump-tables', action='store_true', help='Dump file-table entries')
    parser.add_argument('--apply-all', action='store_true', help='Apply all patches (BSS + disc-check + file-table)')
    parser.add_argument('--apply-disc-check', action='store_true', help='Apply disc-check bypass only')
    parser.add_argument('--apply-file-table', action='store_true', help='Apply file-table redirection only')
    parser.add_argument('--apply-bss', action='store_true', help='Apply BSS narrow patch only')
    parser.add_argument('--folder-map', default='folder_mapping.json', help='Path to folder mapping JSON')
    args = parser.parse_args()

    if not os.path.exists(args.disc):
        print(f"ERROR: Disc not found: {args.disc}")
        sys.exit(1)

    print("=" * 80)
    print("  DW7.EXE BINARY SURGICAL PATCHER")
    print("  Disc-Check Bypass & File-Table Redirection")
    print("=" * 80)
    print(f"  Disc: {args.disc}")

    with DiscImage(args.disc) as disc:
        # Read and display EXE header
        header = disc.read_header()
        print(f"\n=== EXE Header ===")
        print(f"  Magic:       {header['magic']}")
        print(f"  PC:          0x{header['pc']:08X}")
        print(f"  Load addr:   0x{header['load_addr']:08X}")
        print(f"  File size:   0x{header['file_size']:08X} ({header['file_size']:,} bytes)")
        print(f"  Loaded range: 0x{header['load_addr']:08X} - 0x{header['load_addr'] + header['file_size']:08X}")
        print(f"  SP base:     0x{header['sp_base']:08X}")

        if header['magic'] != b'PS-X EXE':
            print(f"\n✗ ERROR: Not a PS-X EXE! Got: {header['magic']}")
            sys.exit(1)
        print(f"  ✓ Valid PS-X EXE signature")

        # --- Verify mode ---
        if args.verify_only or args.dump_tables:
            print("\n" + "=" * 80)
            print("  VERIFICATION MODE")
            print("=" * 80)

            # BSS narrow check
            print("\n--- BSS Clear Narrow Patch ---")
            curr_lui = disc.read32(BSS_LUI_V1_OFF)
            curr_addiu = disc.read32(BSS_ADDIU_V1_OFF)
            lui_imm = curr_lui & 0xFFFF
            addiu_imm = curr_addiu & 0xFFFF
            addiu_signed = addiu_imm - 0x10000 if addiu_imm >= 0x8000 else addiu_imm
            bss_end = ((lui_imm << 16) + addiu_signed) & 0xFFFFFFFF
            print(f"  LUI $v1:   0x{curr_lui:08X} ({'✓ patched' if curr_lui == BSS_LUI_PATCHED else '✗ original'})")
            print(f"  ADDIU $v1: 0x{curr_addiu:08X} ({'✓ patched' if curr_addiu == BSS_ADDIU_PATCHED else '✗ original'})")
            print(f"  BSS end:   0x{bss_end:08X} {'✓' if bss_end == 0x800BCCC8 else '✗'}")
            print(f"  Thread entry 0x800D9E80 in BSS range: {0x800BC668 <= 0x800D9E80 < bss_end}")

            # Disc-check verification
            print("\n--- Disc-Check Bypass Patches ---")
            verify_disc_check(disc)

            # File table verification
            print("\n--- File-Table Redirection ---")
            verify_file_table(disc)

            # TOC verification
            verify_toc_archive(disc)

            print("\n" + "=" * 80)
            print("  VERIFICATION COMPLETE")
            print("=" * 80)
            return

        # --- Apply mode ---
        if not (args.apply_all or args.apply_disc_check or args.apply_file_table or args.apply_bss):
            print("\nNo action specified. Use --apply-all, --apply-disc-check, --apply-file-table, or --apply-bss")
            print("Or use --verify-only to check current patch state.")
            sys.exit(1)

        # Backup
        backup = args.disc + '.bak_surgical'
        if not os.path.exists(backup):
            shutil.copy2(args.disc, backup)
            print(f"\n  Backup: {backup}")

        if args.apply_all or args.apply_bss:
            print("\n--- Applying BSS Clear Narrow Patch ---")
            apply_bss_narrow(disc)

        if args.apply_all or args.apply_disc_check:
            print("\n--- Applying Disc-Check Bypass ---")
            count = apply_disc_check_bypass(disc)
            print(f"  {count}/{len(DISC_CHECK_PATCHES)} disc-check patches applied")

        if args.apply_all or args.apply_file_table:
            print("\n--- Applying File-Table Redirection ---")
            if not os.path.exists(args.folder_map):
                print(f"  ⚠ Folder mapping not found: {args.folder_map}")
                print(f"    Skipping file-table redirection (run with --apply-disc-check only)")
            else:
                apply_file_table_redirection(disc, args.folder_map)

        # Final verification
        print("\n--- Post-Apply Verification ---")
        verify_disc_check(disc)
        verify_toc_archive(disc)

        print("\n" + "=" * 80)
        print("  SURGICAL PATCHING COMPLETE")
        print("=" * 80)


if __name__ == '__main__':
    main()
