#!/usr/bin/env python3
"""
reencode_pipeline.py — Dual-Layer Huffman Compatibility Pre-Processing

Purpose:
  Pre-processes DQ4 HBD text blocks to normalize them for the DW7 engine,
  flagging blocks that can be fully re-encoded (Layer 1) and blocks that
  require runtime shim handling (Layer 2).

  Layer 1 (Static Re-encoding):
    - Decode DQ4 text using per-block Huffman tree
    - Re-encode using the global hybrid tree (dw7_hybrid_tree.bin)
    - Strip per-block tree, set hts=24, treeEnd=0, textEnd=0
    - These blocks are fully DW7-compatible; no runtime shim needed

  Layer 2 (Verbatim Fallback):
    - Blocks that fail re-encoding (tree parse failure, unknown leaf values)
    - These blocks keep their original text data verbatim but still get
      DW7 format headers (hts=24, treeEnd=0, textEnd=0)
    - Text may garble but the parser won't crash — no runtime shim needed

Integration:
  Called by frankenstein_builder.py before HBD assembly.
  Outputs a JSON manifest of re-encoding results for build verification.

Usage:
  python reencode_pipeline.py \
    --hbd HBD1PS1D.Q41 \
    --tree dw7_hybrid_tree.bin \
    --output HBD1PS1D.Q41.reencoded \
    --manifest reencode_manifest.json
"""

import struct
import json
import argparse
import os
import sys
from pathlib import Path
from dataclasses import dataclass, field
from typing import List, Optional, Tuple, Dict

# Add hbe to path for Huffman schema imports
sys.path.insert(0, str(Path(__file__).parent.parent / "translation-tools"))
from hbe.huffman.dq4 import DQ4Schema
from hbe.huffman.dw7 import DW7Schema
from hbe.huffman.node import HuffmanNode
from hbe.huffman.bitutils import bytes_to_bitstream, bitstream_to_bytes


# --- Constants ---

SECTOR_SIZE = 2048
DW7_HTS = 1366          # DW7 header-to-text gap size
DW7_GAP_SIZE = DW7_HTS - 24  # 1342 bytes of gap after 24-byte header
DQ4_HTS = 24            # DQ4 header-to-text gap (no gap)
GLOBAL_TREE_MAX_SIZE = 744  # DW7 native tree buffer size

# No runtime shim markers — all blocks get clean DW7 format headers


@dataclass
class BlockInfo:
    """Parsed block information."""
    offset: int               # offset within folder data
    end: int                  # block end offset
    block_id: int
    hts: int
    tree_end: int
    text_end: int
    unk1: int
    has_per_block_tree: bool
    tree_start: int = 0
    tree_middle: int = 0
    tree_nodes: int = 0
    tree_bytes: bytes = b''
    text_bytes: bytes = b''
    reencoded: bool = False
    reencode_error: str = ''
    needs_runtime_shim: bool = False


@dataclass
class ReencodeResult:
    """Result of re-encoding a single block."""
    block_index: int
    folder_index: int
    status: str               # 'reencoded', 'shim_flagged', 'error'
    original_size: int
    new_size: int
    tree_size: int
    leaf_count: int
    error: str = ''


@dataclass
class ReencodeManifest:
    """Manifest of all re-encoding operations."""
    total_blocks: int = 0
    blocks_reencoded: int = 0
    blocks_shim_flagged: int = 0
    blocks_error: int = 0
    blocks_native: int = 0
    results: List[ReencodeResult] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            'total_blocks': self.total_blocks,
            'blocks_reencoded': self.blocks_reencoded,
            'blocks_shim_flagged': self.blocks_shim_flagged,
            'blocks_error': self.blocks_error,
            'blocks_native': self.blocks_native,
            'results': [
                {
                    'block_index': r.block_index,
                    'folder_index': r.folder_index,
                    'status': r.status,
                    'original_size': r.original_size,
                    'new_size': r.new_size,
                    'tree_size': r.tree_size,
                    'leaf_count': r.leaf_count,
                    'error': r.error,
                }
                for r in self.results
            ],
        }


# --- Block Parsing ---

def parse_block_header(data: bytes, offset: int) -> Optional[BlockInfo]:
    """Parse a 24-byte block header at the given offset."""
    if offset + 24 > len(data):
        return None

    end, block_id, hts, tree_end, text_end, unk1 = struct.unpack_from('<6I', data, offset)

    if hts < 24 or hts > 65536:
        return None
    if end < hts or end > 1048576:
        return None

    has_tree = (tree_end != 0 and text_end != 0)

    info = BlockInfo(
        offset=offset,
        end=end,
        block_id=block_id,
        hts=hts,
        tree_end=tree_end,
        text_end=text_end,
        unk1=unk1,
        has_per_block_tree=has_tree,
    )

    if has_tree and text_end > hts and text_end <= end and tree_end > hts and tree_end <= end:
        # Extract text data
        info.text_bytes = data[offset + hts:offset + text_end]

        # Extract tree metadata (10 bytes at text_end)
        if offset + text_end + 10 <= len(data):
            tree_start, tree_middle = struct.unpack_from('<2I', data, offset + text_end)
            tree_nodes = struct.unpack_from('<H', data, offset + text_end + 8)[0]
            info.tree_start = tree_start
            info.tree_middle = tree_middle
            info.tree_nodes = tree_nodes

            # Extract tree bytes
            if tree_start < tree_end and tree_end <= end:
                info.tree_bytes = data[offset + tree_start:offset + tree_end]

    return info


# --- Re-encoding ---

def reencode_block(block: BlockInfo, hybrid_tree: HuffmanNode,
                   dq4_schema: DQ4Schema, dw7_schema: DW7Schema
                   ) -> Tuple[Optional[bytes], int, str]:
    """
    Re-encode a DQ4 block's text using the hybrid tree.

    Returns:
        (new_text_bytes, leaf_count, error_msg)
        If re-encoding fails, returns (None, 0, error_message)
    """
    if not block.has_per_block_tree:
        return None, 0, 'no per-block tree'

    if not block.tree_bytes or len(block.tree_bytes) < 4:
        return None, 0, 'invalid tree bytes'

    if len(block.tree_bytes) % 2 != 0:
        return None, 0, f'tree size {len(block.tree_bytes)} is odd'

    # Parse DQ4 per-block tree
    try:
        dq4_tree = dq4_schema.parse_tree(block.tree_bytes)
    except Exception as e:
        return None, 0, f'dq4 tree parse failed: {e}'

    # Decode text using DQ4 tree
    try:
        leaves = dq4_schema.decode(block.text_bytes, dq4_tree)
    except Exception as e:
        return None, 0, f'dq4 decode failed: {e}'

    if not leaves:
        return None, 0, 'decode produced no leaves'

    leaf_count = len(leaves)

    # Check if all leaf values exist in the hybrid tree
    # The hybrid tree was built to contain all DQ4 + DW7 leaf values,
    # so this should always pass. But we check for safety.
    hybrid_codes = dw7_schema._collect_codes(hybrid_tree) if hasattr(dw7_schema, '_collect_codes') else {}

    # Re-encode using hybrid (DW7 global) tree
    try:
        new_text = dw7_schema.encode(leaves, hybrid_tree)
    except Exception as e:
        return None, leaf_count, f'dw7 re-encode failed: {e}'

    if not new_text:
        return None, leaf_count, 're-encode produced empty output'

    return new_text, leaf_count, ''


def build_new_block(block: BlockInfo, new_text: bytes,
                    original_data: bytes) -> bytes:
    """
    Build a new block in DW7 format.

    All blocks get clean DW7 headers: hts=24, treeEnd=0, textEnd=0.
    No runtime shim markers. Failed re-encode blocks keep original text
    verbatim — may garble but parser won't crash.
    """
    new_end = DQ4_HTS + len(new_text)

    # Read dialog pointers from original block (at end..end+8+dp_count*8)
    dp_data = b''
    dp_count = 0
    at_end_val = 0
    if block.offset + block.end + 8 <= len(original_data):
        at_end_val, dp_count = struct.unpack_from('<2I', original_data, block.offset + block.end)
        if dp_count < 10000 and block.offset + block.end + 8 + dp_count * 8 <= len(original_data):
            dp_data = original_data[block.offset + block.end + 8:
                                    block.offset + block.end + 8 + dp_count * 8]

    # Assemble new block
    new_block = bytearray()

    # Header (24 bytes) — always DW7 format: hts=24, treeEnd=0, textEnd=0
    new_block += struct.pack('<6I', new_end, block.block_id, DQ4_HTS, 0, 0, block.unk1)

    # Text data
    new_block += new_text

    # Dialog pointers
    new_block += struct.pack('<2I', at_end_val, dp_count)
    new_block += dp_data

    return bytes(new_block)


# --- HBD Processing ---

def process_hbd(hbd_data: bytes, hybrid_tree_bytes: bytes,
                output_path: str, manifest_path: str) -> ReencodeManifest:
    """
    Process the entire HBD file, re-encoding all DQ4 text blocks.

    Args:
        hbd_data: Raw HBD file data
        hybrid_tree_bytes: Hybrid tree binary data (dw7_hybrid_tree.bin)
        output_path: Path to write re-encoded HBD
        manifest_path: Path to write JSON manifest

    Returns:
        ReencodeManifest with results
    """
    manifest = ReencodeManifest()

    # Parse hybrid tree using DW7 schema
    dw7_schema = DW7Schema()
    dq4_schema = DQ4Schema()

    try:
        hybrid_tree = dw7_schema.parse_tree(hybrid_tree_bytes)
    except Exception as e:
        print(f'FATAL: Failed to parse hybrid tree: {e}')
        return manifest

    print(f'Hybrid tree parsed: {len(hybrid_tree.leaf_nodes())} leaves, '
          f'{len(hybrid_tree.branch_nodes())} branches')

    total_sectors = len(hbd_data) // SECTOR_SIZE
    new_hbd = bytearray()
    new_hbd += hbd_data[:SECTOR_SIZE]  # Copy sector 0 (binary header)

    sector_idx = 1
    block_counter = 0

    while sector_idx < total_sectors:
        sec_start = sector_idx * SECTOR_SIZE
        sec = hbd_data[sec_start:sec_start + SECTOR_SIZE]

        # Check for 60010108 entry
        if sec[:4] == b'\x60\x01\x01\x80':
            new_hbd += sec
            sector_idx += 1
            continue

        # Check for zero/padding sector
        if sec[:4] == b'\x00\x00\x00\x00':
            new_hbd += sec
            sector_idx += 1
            continue

        # Parse folder header
        file_count, sector_count, folder_size = struct.unpack_from('<3I', sec, 0)

        if not (0 < file_count <= 1000 and 0 < sector_count <= 1000 and
                16 + file_count * 16 <= SECTOR_SIZE and
                sector_idx + sector_count <= total_sectors):
            new_hbd += sec
            sector_idx += 1
            continue

        # Copy folder data
        folder_start = sector_idx * SECTOR_SIZE
        folder_end = (sector_idx + sector_count) * SECTOR_SIZE
        folder_data = bytearray(hbd_data[folder_start:folder_end])

        # Parse file entries
        content_start = 16 + file_count * 16
        running_offset = content_start

        for f_idx in range(file_count):
            fh_off = 16 + f_idx * 16
            if fh_off + 16 > len(folder_data):
                break

            f_size, f_size_unc = struct.unpack_from('<2I', folder_data, fh_off)
            f_flags, f_type_id = struct.unpack_from('<2H', folder_data, fh_off + 12)
            f_content_offset = running_offset

            if f_content_offset + f_size > len(folder_data):
                break

            # Sub-block field swap (types 32, 39, 40, 42, 46)
            if f_type_id in (32, 39, 40, 42, 46):
                count = f_flags
                f_flags = 0
                f_type_id = count

            # Parse block header
            block = parse_block_header(bytes(folder_data), f_content_offset)
            if block is None:
                running_offset += f_size
                continue

            manifest.total_blocks += 1
            block_counter += 1

            result = ReencodeResult(
                block_index=block_counter,
                folder_index=sector_idx,
                status='native',
                original_size=f_size,
                new_size=f_size,
                tree_size=len(block.tree_bytes),
                leaf_count=0,
            )

            if block.has_per_block_tree:
                # Attempt re-encoding
                new_text, leaf_count, error = reencode_block(
                    block, hybrid_tree, dq4_schema, dw7_schema)

                if new_text is not None:
                    # Successfully re-encoded — standard DW7 format
                    result.status = 'reencoded'
                    result.leaf_count = leaf_count
                    result.new_size = DQ4_HTS + len(new_text)
                    manifest.blocks_reencoded += 1

                    # Build new block (no shim)
                    new_block = build_new_block(block, new_text, bytes(folder_data))
                else:
                    # Re-encoding failed — keep original text verbatim, still DW7 headers
                    result.status = 'verbatim_fallback'
                    result.error = error
                    result.leaf_count = 0
                    result.new_size = DQ4_HTS + len(block.text_bytes)
                    manifest.blocks_error += 1

                    # Build new block with original text (no shim)
                    new_block = build_new_block(block, block.text_bytes, bytes(folder_data))

                # Replace block in folder data
                old_size = f_size
                new_size = len(new_block)

                # Pad or truncate to original size to avoid offset shifts
                if new_size < old_size:
                    # Block shrank — pad with zeros to maintain alignment
                    new_block = new_block + b'\x00' * (old_size - new_size)
                    new_size = old_size
                elif new_size > old_size:
                    # Block grew — this is problematic, log it
                    # For now, truncate (text may be cut)
                    new_block = new_block[:old_size]
                    new_size = old_size
                    result.error = (result.error + '; ' if result.error else '') + 'size mismatch, truncated'

                folder_data[f_content_offset:f_content_offset + old_size] = new_block
                # File header size stays the same since we pad/truncate
                running_offset = f_content_offset + old_size
            else:
                # Native DW7 block or already stripped — no action needed
                manifest.blocks_native += 1
                running_offset += f_size

            manifest.results.append(result)

            if block_counter % 1000 == 0:
                print(f'  ...processed {block_counter} blocks '
                      f'(reencoded={manifest.blocks_reencoded}, '
                      f'fallback={manifest.blocks_error}, '
                      f'native={manifest.blocks_native})')

        # Write modified folder data
        new_hbd += folder_data
        sector_idx += sector_count

    # Write output
    with open(output_path, 'wb') as f:
        f.write(new_hbd)

    # Write manifest
    with open(manifest_path, 'w') as f:
        json.dump(manifest.to_dict(), f, indent=2)

    print(f'\nRe-encoding complete:')
    print(f'  Total blocks:    {manifest.total_blocks}')
    print(f'  Re-encoded:      {manifest.blocks_reencoded}')
    print(f'  Verbatim fallback: {manifest.blocks_error}')
    print(f'  Native (no-op):  {manifest.blocks_native}')
    print(f'  Errors:          {manifest.blocks_error}')
    print(f'  Output:          {output_path}')
    print(f'  Manifest:        {manifest_path}')

    return manifest


# --- CLI Entry Point ---

def main():
    parser = argparse.ArgumentParser(
        description='DQ4→DW7 HBD Re-encoding Pipeline (Dual-Layer Huffman Compatibility)')
    parser.add_argument('--hbd', required=True, help='Input DQ4 HBD file path')
    parser.add_argument('--tree', required=True, help='Hybrid tree file (dw7_hybrid_tree.bin)')
    parser.add_argument('--output', required=True, help='Output re-encoded HBD path')
    parser.add_argument('--manifest', default='reencode_manifest.json',
                        help='Output JSON manifest path')
    args = parser.parse_args()

    # Load HBD
    print(f'Loading HBD: {args.hbd}')
    with open(args.hbd, 'rb') as f:
        hbd_data = f.read()
    print(f'  Size: {len(hbd_data):,} bytes ({len(hbd_data) // SECTOR_SIZE:,} sectors)')

    # Load hybrid tree
    print(f'Loading hybrid tree: {args.tree}')
    with open(args.tree, 'rb') as f:
        tree_data = f.read()
    print(f'  Size: {len(tree_data)} bytes')

    # Process
    process_hbd(hbd_data, tree_data, args.output, args.manifest)


if __name__ == '__main__':
    main()
