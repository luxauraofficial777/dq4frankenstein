@echo off
REM Frankenstein Pipeline V.99 - Build Script
REM Builds the Reverse Frankenstein disc (Option A)
REM
REM Usage: build.bat [output_name]
REM Default output: dq4_frankenstein_v109.bin

setlocal
set PIPE=%~dp0
set BUILDER=%PIPE%builder\frankenstein_build.exe
set DQ4_DISC=%PIPE%disc\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin
set DW7_EXE=%PIPE%translation\SLUSP012.06_clean.bin
set HYBRID_TREE=%PIPE%translation\dw7_hybrid_tree.bin
set EDCRE=%PIPE%edcre\edcre.exe
set HOTFIXES=%PIPE%builder\hotfixes_empty.txt
set STAGING=%PIPE%build_staging
set OUTNAME=%1
if "%OUTNAME%"=="" set OUTNAME=dq4_frankenstein_v109

set OUTPUT_BIN=%STAGING%\%OUTNAME%.bin
set OUTPUT_CUE=%STAGING%\%OUTNAME%.cue

if not exist "%STAGING%" mkdir "%STAGING%"

echo ============================================================
echo   Frankenstein Pipeline V.99 - Reverse Build (Option A)
echo ============================================================
echo   DQ4 disc:    %DQ4_DISC%
echo   DW7 EXE:     %DW7_EXE%
echo   Hybrid tree: %HYBRID_TREE%
echo   EDC/ECC:     %EDCRE%
echo   Output:      %OUTPUT_BIN%
echo ============================================================
echo.

"%BUILDER%" --reverse ^
  --dq4-hbd "%DQ4_DISC%" ^
  --dw7-exe "%DW7_EXE%" ^
  --hybrid-tree "%HYBRID_TREE%" ^
  --edcre "%EDCRE%" ^
  --hotfixes "%HOTFIXES%" ^
  --output "%OUTPUT_BIN%" ^
  --output-cue "%OUTPUT_CUE%" ^
  --duckstation ^
  --reencode-hbd ^
  --skip-hash-check ^
  --staging-dir "%STAGING%"

echo.
if exist "%OUTPUT_BIN%" (
  echo BUILD COMPLETE: %OUTPUT_BIN%
  for %%A in ("%OUTPUT_BIN%") do echo Size: %%~zA bytes
) else (
  echo BUILD FAILED
  exit /b 1
)
endlocal
