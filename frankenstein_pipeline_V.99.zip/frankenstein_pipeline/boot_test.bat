@echo off
REM Frankenstein Pipeline V.99 - Boot Test Script
REM Launches DuckStation headless with SCPH-1001 BIOS
REM
REM Usage: boot_test.bat <disc.cue>

setlocal
set PIPE=%~dp0
set DS=%PIPE%duckstation\duckstation-qt-x64-ReleaseLTCG.exe
set DISC=%1

if "%DISC%"=="" (
  echo Usage: boot_test.bat ^<disc.cue^>
  echo Example: boot_test.bat build_staging\dq4_frankenstein_v109.cue
  exit /b 1
)

echo Launching DuckStation with SCPH-1001 BIOS...
echo Disc: %DISC%
echo.
"%DS%" -batch -earlyconsole "%DISC%"
endlocal
