@echo off
REM Frankenstein Pipeline V.99 - F-3 Comparison Build
REM Builds two discs: with and without XA stub for A/B testing
REM
REM Usage: build_comparison.bat

setlocal
set PIPE=%~dp0
set BUILDER=%PIPE%builder\frankenstein_build.exe
set DQ4_DISC=%PIPE%disc\Dragon Quest IV - Michibikareshi Mono Tachi (Japan).bin
set DW7_EXE=%PIPE%translation\SLUSP012.06_clean.bin
set HYBRID_TREE=%PIPE%translation\dw7_hybrid_tree.bin
set EDCRE=%PIPE%edcre\edcre.exe
set HOTFIXES=%PIPE%builder\hotfixes_empty.txt
set STAGING=%PIPE%build_staging

if not exist "%STAGING%" mkdir "%STAGING%"

echo === Building WITH XA stub ===
"%BUILDER%" --reverse --dq4-hbd "%DQ4_DISC%" --dw7-exe "%DW7_EXE%" --hybrid-tree "%HYBRID_TREE%" --edcre "%EDCRE%" --hotfixes "%HOTFIXES%" --output "%STAGING%\with_xa.bin" --output-cue "%STAGING%\with_xa.cue" --duckstation --reencode-hbd --skip-hash-check --staging-dir "%STAGING%"

echo.
echo === Building WITHOUT XA stub (--no-xa-stub) ===
"%BUILDER%" --reverse --dq4-hbd "%DQ4_DISC%" --dw7-exe "%DW7_EXE%" --hybrid-tree "%HYBRID_TREE%" --edcre "%EDCRE%" --hotfixes "%HOTFIXES%" --no-xa-stub --output "%STAGING%\no_xa.bin" --output-cue "%STAGING%\no_xa.cue" --duckstation --reencode-hbd --skip-hash-check --staging-dir "%STAGING%"

echo.
echo === Done ===
echo WITH XA: %STAGING%\with_xa.cue
echo NO XA:   %STAGING%\no_xa.cue
endlocal
