@echo off
REM Frankenstein Pipeline V.99 - Builder Compile Script
REM Requires Visual Studio 2022 Build Tools (vcvars64.bat)
call "C:\Progra~2\Microsoft Visual Studio\2022\BuildTools\VC\Auxiliary\Build\vcvars64.bat" >nul 2>&1
cd /d "%~dp0builder"
cl /nologo /std:c++17 /EHsc /O2 /Fe:frankenstein_build.exe frankenstein_build_main.cpp psx_binary_ops.cpp /I. /D_CRT_SECURE_NO_WARNINGS /link /SUBSYSTEM:CONSOLE /LARGEADDRESSAWARE
echo.
if exist frankenstein_build.exe (echo BUILD OK) else (echo BUILD FAILED)
